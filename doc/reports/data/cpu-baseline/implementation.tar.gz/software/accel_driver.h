// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 PCAA contributors
// Declares the bare-metal driver API for submitting accelerator descriptors.

#pragma once

#include "accel_protocol.h"
#include "pcaa.h"
#include "pcaa_submission.h"

#include <stddef.h>
#include <stdint.h>

#if !defined(__riscv) || !defined(__riscv_xlen)
#error "PCAA bare-metal driver requires a RISC-V compiler target"
#endif

#if __riscv_xlen != 64
#error "PCAA bare-metal driver currently requires RV64"
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifndef ACCEL_MMIO_BASE
#define ACCEL_MMIO_BASE 0x10002000UL
#endif
void accel_init(void);
/* Low-level transport for already encoded command bytes. */
int accel_submit_encoded(const void *bytes, size_t encoded_bytes);
int accel_submit_command(const pcaa_command_t *command);
int accel_wait(void);
/* Caller owns max-sized encoded workspace[count] until completion; this function waits. */
int accel_submit_command_batch(const pcaa_command_t *commands, size_t count,
                               pcaa_encoded_slot_t *encoded_workspace,
                               accel_batch_result_t *result);
int32_t accel_min_add(const int32_t *a, const int32_t *b, size_t n);
/* Writes a valid finite or INF result and separately reports submission/device failure. */
int accel_min_add_checked(const int32_t *a, const int32_t *b, size_t n, int32_t *result);
int32_t accel_min_add3(const int32_t *a, const int32_t *b, const int32_t *c, size_t n);
accel_min_argmin_result_t accel_min_add_argmin(const int32_t *a, const int32_t *b, size_t n);
accel_min_argmin_result_t accel_min_add3_argmin(const int32_t *a, const int32_t *b,
                                                const int32_t *c, size_t n);
int accel_min_add_argmin_checked(const int32_t *a, const int32_t *b, size_t n,
                                 accel_min_argmin_result_t *result);
int accel_min_add3_argmin_checked(const int32_t *a, const int32_t *b, const int32_t *c, size_t n,
                                  accel_min_argmin_result_t *result);

#ifdef __cplusplus
}  // extern "C"
#endif
