#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 PCAA contributors
# Runs current streams and controlled MAS sweeps, preserving raw evidence and failures.
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = dict(lanes=4, mem_bytes=16, tm=8, tn=16, memory_latency=1)
FACTORS = dict(lanes=[1,2,4,8,16], tm=[1,2,4,8,16,32], tn=[4,8,16,32,64],
               mem_bytes=[4,8,16,32], memory_latency=[1,2,4,8,16])
FLAGS = dict(lanes='--l2-lanes', mem_bytes='--l2-mem-bytes', tm='--l2-tm', tn='--l2-tn',
             memory_latency='--l2-memory-latency')

def invoke(command, timeout=180):
    try:
        p = subprocess.run(list(map(str, command)), cwd=ROOT, text=True, capture_output=True, timeout=timeout)
        return dict(command=list(map(str, command)), returncode=p.returncode, stdout=p.stdout, stderr=p.stderr,
                    status='ok' if p.returncode == 0 else 'failed')
    except subprocess.TimeoutExpired as e:
        def decode(x):
            return x.decode(errors='replace') if isinstance(x, bytes) else x or ''
        return dict(command=list(map(str, command)), status='timeout', stdout=decode(e.stdout), stderr=decode(e.stderr))

def configs(smoke):
    result = [BASE.copy()]
    if smoke:
        return result
    for key, values in FACTORS.items():
        for value in values:
            c = dict(BASE, **{key:value})
            if c not in result:
                result.append(c)
    for lanes in FACTORS['lanes']:
        for width in FACTORS['mem_bytes']:
            c = dict(BASE, lanes=lanes, mem_bytes=width)
            if c not in result:
                result.append(c)
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--build', default='build-release')
    parser.add_argument('--output', default='doc/reports/data/l2')
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    out = ROOT / args.output
    out.mkdir(parents=True, exist_ok=True)
    build = ROOT / args.build
    corpus = sorted((ROOT/'examples/regalloc').glob('*.pbqp'))
    ordered = sorted(corpus, key=lambda p:(next(int(line.split()[1]) for line in p.read_text().splitlines()
                                              if line.startswith('nodes ')),p.name))
    subset = [ordered[round(i*(len(ordered)-1)/7)] for i in range(8)]
    examples = [ROOT/f'examples/{name}.pbqp' for name in ['triangle','petersen','chvatal','random-20']]
    synthetic = []
    (out/'inputs').mkdir(exist_ok=True)
    for family in ['degree-3','degree-4','mixed-degree']:
        for domain in ([4] if args.smoke else [2,4,8,16]):
            command = [build/'pbqp_graph_generate','--family',family,'--profile','small',
                       '--nodes','20','--seed','1001','--domain-size',str(domain)]
            generated = invoke(command)
            if generated['status'] != 'ok':
                raise RuntimeError(generated)
            path = out/'inputs'/f'{family}-d{domain}.pbqp'
            path.write_text(generated['stdout'])
            synthetic.append(path)
    sources = sorted(set(ROOT.glob('accelerator/include/l2_*.h')) | set(ROOT.glob('accelerator/src/l2_*.cpp')) |
                     {ROOT/p for p in ['accelerator/tests/l2_support.h','accelerator/tests/l2_unit.cpp',
                     'tools/l2_microbench.cpp','tools/pbqp_model_kernel.cpp','tools/pbqp_model_kernel.h',
                     'tools/pbqp_run.cpp','tools/CMakeLists.txt','accelerator/CMakeLists.txt','scripts/l2_characterize.py']})
    metadata = dict(base_commit=invoke(['git','rev-parse','HEAD'])['stdout'].strip(), mas='1.0.0', isa='1.0.0',
                    baseline=BASE, configurations=configs(args.smoke),
                    selection='8 evenly spaced ranks after sorting by (nodes, filename), including endpoints',
                    subset=[str(p.relative_to(ROOT)) for p in subset],
                    implementation_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
                    input_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                                  for p in corpus+examples+synthetic},
                    command=[sys.executable]+sys.argv, build=str(build.relative_to(ROOT)))
    (out/'metadata.json').write_text(json.dumps(metadata, indent=2)+'\n')
    failures = 0
    with gzip.open(out/'microbench.jsonl.gz','wt') as rows, gzip.open(out/'runs.jsonl.gz','wt') as raw:
        for c in configs(args.smoke):
            flags = [v for key,value in c.items() for v in [FLAGS[key],str(value)]]
            result = invoke([build/'pcaa_l2_microbench']+flags+(['--smoke'] if args.smoke else []))
            raw.write(json.dumps(dict(kind='microbench', config=c, **result))+'\n')
            if result['status'] != 'ok':
                failures += 1
            else:
                for line in result['stdout'].splitlines():
                    row = json.loads(line)
                    if not row['verified']:
                        raise RuntimeError('unverified microbenchmark')
                    rows.write(json.dumps(row)+'\n')
            print('microbench',c,result['status'],flush=True)
    # L1 is executed separately on precisely the same semantic solver stream.
    l1_cache = {}
    with gzip.open(out/'workloads.jsonl.gz','wt') as rows, gzip.open(out/'workload-runs.jsonl.gz','wt') as raw:
        for ci,c in enumerate(configs(args.smoke)):
            if args.smoke:
                inputs = examples[:1]+subset[:1]+synthetic[:1]
            elif ci == 0:
                inputs = examples+corpus+synthetic
            else:
                inputs = examples+subset+[p for p in synthetic if '-d4.' in p.name or '-d16.' in p.name]
            flags = [v for key,value in c.items() for v in [FLAGS[key],str(value)]]
            for index,path in enumerate(inputs):
                identity = str(path.relative_to(ROOT))
                result = invoke([build/'pcaa_graph_run_l2','--solver','local','--verbose']+flags+[path])
                raw.write(json.dumps(dict(kind='l2', input=identity, config=c, **result))+'\n')
                if identity not in l1_cache:
                    l1_cache[identity] = invoke([build/'pcaa_graph_run_timed','--solver','local','--verbose',path])
                    raw.write(json.dumps(dict(kind='l1', input=identity, **l1_cache[identity]))+'\n')
                l1 = l1_cache[identity]
                row = dict(input=identity, config=c, status=result['status'])
                if result['status'] == 'ok' and l1['status'] == 'ok':
                    row['l2'] = json.loads(next(line[3:] for line in result['stdout'].splitlines() if line.startswith('l2 ')))
                    timing = next(line for line in l1['stdout'].splitlines() if line.startswith('timing cycles='))
                    row['l1'] = {key:int(value) for key,value in (field.split('=') for field in timing.split()[1:])}
                    answer = lambda text:[line for line in text.splitlines() if line.startswith(('optimum ','assignment ','solution ','strategy '))]
                    row['verified'] = answer(result['stdout']) == answer(l1['stdout'])
                    row['answer'] = answer(result['stdout'])
                    row['logical'] = next(line for line in result['stderr'].splitlines() if line.startswith('pcaa: operation mix '))
                    if not row['verified']:
                        row['status'] = 'differential_failure'
                        failures += 1
                else:
                    failures += 1
                rows.write(json.dumps(row)+'\n')
                if index % 50 == 0:
                    print('workloads',ci,index,len(inputs),identity,row['status'],flush=True)
    metadata['failures'] = failures
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    if failures:
        raise RuntimeError(f'{failures} failed/time-limited rows; headline conclusions prohibited')
    print('complete: no failed or time-limited rows',flush=True)

if __name__ == '__main__':
    main()
