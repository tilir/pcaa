; ModuleID = '/home/tilir/llvm-project/llvm/lib/CodeGen/MachineBasicBlock.cpp'
source_filename = "/home/tilir/llvm-project/llvm/lib/CodeGen/MachineBasicBlock.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%"class.llvm::cl::opt" = type { %"class.llvm::cl::Option", %"class.llvm::cl::opt_storage", %"class.llvm::cl::parser", %"class.std::function" }
%"class.llvm::cl::Option" = type { ptr, i16, i16, i16, %"class.llvm::StringRef", %"class.llvm::StringRef", %"class.llvm::StringRef", %"class.llvm::SmallVector", %"class.llvm::SmallPtrSet" }
%"class.llvm::StringRef" = type { ptr, i64 }
%"class.llvm::SmallVector" = type { %"class.llvm::SmallVectorImpl", %"struct.llvm::SmallVectorStorage" }
%"class.llvm::SmallVectorImpl" = type { %"class.llvm::SmallVectorTemplateBase" }
%"class.llvm::SmallVectorTemplateBase" = type { %"class.llvm::SmallVectorTemplateCommon" }
%"class.llvm::SmallVectorTemplateCommon" = type { %"class.llvm::SmallVectorBase" }
%"class.llvm::SmallVectorBase" = type { ptr, i32, i32 }
%"struct.llvm::SmallVectorStorage" = type { [8 x i8] }
%"class.llvm::SmallPtrSet" = type { %"class.llvm::SmallPtrSetImpl.base", [1 x ptr] }
%"class.llvm::SmallPtrSetImpl.base" = type { %"class.llvm::SmallPtrSetImplBase.base" }
%"class.llvm::SmallPtrSetImplBase.base" = type <{ ptr, i32, i32, i8 }>
%"class.llvm::cl::opt_storage" = type { i8, [7 x i8], %"struct.llvm::cl::OptionValue" }
%"struct.llvm::cl::OptionValue" = type { %"struct.llvm::cl::OptionValueBase.base", [6 x i8] }
%"struct.llvm::cl::OptionValueBase.base" = type { %"class.llvm::cl::OptionValueCopy.base" }
%"class.llvm::cl::OptionValueCopy.base" = type <{ %"struct.llvm::cl::GenericOptionValue", i8, i8 }>
%"struct.llvm::cl::GenericOptionValue" = type { ptr }
%"class.llvm::cl::parser" = type { %"class.llvm::cl::basic_parser" }
%"class.llvm::cl::basic_parser" = type { %"class.llvm::cl::basic_parser_impl" }
%"class.llvm::cl::basic_parser_impl" = type { ptr }
%"class.std::function" = type { %"class.std::_Function_base", ptr }
%"class.std::_Function_base" = type { %"union.std::_Any_data", ptr }
%"union.std::_Any_data" = type { %"union.std::_Nocopy_types" }
%"union.std::_Nocopy_types" = type { { i64, i64 } }
%"struct.llvm::MBBSectionID" = type { i32, i32 }
%"struct.llvm::AnalysisKey" = type { [8 x i8] }
%"class.llvm::SmallString.239" = type { %"class.llvm::SmallVector.base", [3 x i8] }
%"class.llvm::SmallVector.base" = type <{ %"class.llvm::SmallVectorImpl.174", %"struct.llvm::SmallVectorStorage.241" }>
%"class.llvm::SmallVectorImpl.174" = type { %"class.llvm::SmallVectorTemplateBase.175" }
%"class.llvm::SmallVectorTemplateBase.175" = type { %"class.llvm::SmallVectorTemplateCommon.176" }
%"class.llvm::SmallVectorTemplateCommon.176" = type { %"class.llvm::SmallVectorBase.177" }
%"class.llvm::SmallVectorBase.177" = type { ptr, i64, i64 }
%"struct.llvm::SmallVectorStorage.241" = type { [5 x i8] }
%"class.std::__cxx11::basic_string" = type { %"struct.std::__cxx11::basic_string<char>::_Alloc_hider", i64, %union.anon }
%"struct.std::__cxx11::basic_string<char>::_Alloc_hider" = type { ptr }
%union.anon = type { i64, [8 x i8] }
%"class.llvm::Twine" = type <{ %"union.llvm::Twine::Child", %"union.llvm::Twine::Child", i8, i8, [6 x i8] }>
%"union.llvm::Twine::Child" = type { %struct.anon }
%struct.anon = type { ptr, i64 }
%"class.llvm::SmallString" = type { %"class.llvm::SmallVector.173" }
%"class.llvm::SmallVector.173" = type { %"class.llvm::SmallVectorImpl.174", %"struct.llvm::SmallVectorStorage.178" }
%"struct.llvm::SmallVectorStorage.178" = type { [128 x i8] }
%"class.llvm::raw_svector_ostream" = type { %"class.llvm::raw_pwrite_stream", ptr }
%"class.llvm::raw_pwrite_stream" = type { %"class.llvm::raw_ostream" }
%"class.llvm::raw_ostream" = type { ptr, i32, ptr, ptr, ptr, i8, i32 }
%"class.llvm::ModuleSlotTracker" = type { ptr, %"class.std::unique_ptr.356", i8, ptr, ptr, ptr, %"class.std::function.364", %"class.std::function.366" }
%"class.std::unique_ptr.356" = type { %"struct.std::__uniq_ptr_data.357" }
%"struct.std::__uniq_ptr_data.357" = type { %"class.std::__uniq_ptr_impl.358" }
%"class.std::__uniq_ptr_impl.358" = type { %"class.std::tuple.359" }
%"class.std::tuple.359" = type { %"struct.std::_Tuple_impl.360" }
%"struct.std::_Tuple_impl.360" = type { %"struct.std::_Head_base.363" }
%"struct.std::_Head_base.363" = type { ptr }
%"class.std::function.364" = type { %"class.std::_Function_base", ptr }
%"class.std::function.366" = type { %"class.std::_Function_base", ptr }
%"class.llvm::Printable" = type { %"class.std::function.242" }
%"class.std::function.242" = type { %"class.std::_Function_base", ptr }
%class.anon.788 = type { ptr }
%"class.llvm::format_object.784" = type { ptr, %"class.std::tuple.785" }
%"class.std::tuple.785" = type { %"struct.std::_Tuple_impl.786" }
%"struct.std::_Tuple_impl.786" = type { %"struct.std::_Head_base.787" }
%"struct.std::_Head_base.787" = type { i64 }
%"class.llvm::SlotIndex" = type { %"class.llvm::PointerIntPair.369" }
%"class.llvm::PointerIntPair.369" = type { %"struct.llvm::detail::PunnedPointer.370" }
%"struct.llvm::detail::PunnedPointer.370" = type { [8 x i8] }
%class.anon.865 = type { ptr }
%class.anon.864 = type { ptr }
%"class.llvm::format_object" = type <{ ptr, %"class.std::tuple.388", [4 x i8] }>
%"class.std::tuple.388" = type { %"struct.std::_Tuple_impl.389" }
%"struct.std::_Tuple_impl.389" = type { %"struct.std::_Head_base.390" }
%"struct.std::_Head_base.390" = type { i32 }
%"class.llvm::format_object.391" = type { ptr, %"class.std::tuple.392" }
%"class.std::tuple.392" = type { %"struct.std::_Tuple_impl.393" }
%"struct.std::_Tuple_impl.393" = type { %"struct.std::_Head_base.394" }
%"struct.std::_Head_base.394" = type { double }
%"struct.std::pair.781" = type { %"class.llvm::SlotIndex", %"class.llvm::SlotIndex" }
%"struct.llvm::detail::DenseMapPair" = type { ptr, %"class.llvm::SlotIndex" }
%class.anon.399 = type { ptr, ptr }
%"struct.llvm::MCRegisterDesc" = type { i32, i32, i32, i32, i32, i16, i8, i8 }
%"struct.llvm::LaneBitmask" = type { i64 }
%"struct.llvm::MachineBasicBlock::RegisterMaskPair" = type { %"class.llvm::MCRegister", %"struct.llvm::LaneBitmask" }
%"class.llvm::MCRegister" = type { i32 }
%"class.llvm::MachineOperand" = type { i32, %union.anon.418, ptr, %"union.llvm::MachineOperand::ContentsUnion" }
%union.anon.418 = type { i32 }
%"union.llvm::MachineOperand::ContentsUnion" = type { %"class.llvm::ArrayRef.419" }
%"class.llvm::ArrayRef.419" = type { ptr, i64 }
%"class.llvm::MIMetadata" = type { %"class.llvm::DebugLoc", ptr, ptr, ptr }
%"class.llvm::DebugLoc" = type { ptr }
%"class.llvm::SmallVector.426" = type { %"class.llvm::SmallVectorImpl.427", %"struct.llvm::SmallVectorStorage.430" }
%"class.llvm::SmallVectorImpl.427" = type { %"class.llvm::SmallVectorTemplateBase.428" }
%"class.llvm::SmallVectorTemplateBase.428" = type { %"class.llvm::SmallVectorTemplateCommon.429" }
%"class.llvm::SmallVectorTemplateCommon.429" = type { %"class.llvm::SmallVectorBase" }
%"struct.llvm::SmallVectorStorage.430" = type { [128 x i8] }
%"class.llvm::BranchProbability" = type { i32 }
%"class.llvm::LivePhysRegs" = type { ptr, %"class.llvm::SparseSet" }
%"class.llvm::SparseSet" = type <{ %"class.llvm::SmallVector.436", %"class.std::unique_ptr.438", i32, [4 x i8] }>
%"class.llvm::SmallVector.436" = type { %"class.llvm::SmallVectorImpl.266", %"struct.llvm::SmallVectorStorage.437" }
%"class.llvm::SmallVectorImpl.266" = type { %"class.llvm::SmallVectorTemplateBase.267" }
%"class.llvm::SmallVectorTemplateBase.267" = type { %"class.llvm::SmallVectorTemplateCommon.268" }
%"class.llvm::SmallVectorTemplateCommon.268" = type { %"class.llvm::SmallVectorBase.177" }
%"struct.llvm::SmallVectorStorage.437" = type { [16 x i8] }
%"class.std::unique_ptr.438" = type { %"struct.std::__uniq_ptr_data.439" }
%"struct.std::__uniq_ptr_data.439" = type { %"class.std::__uniq_ptr_impl.440" }
%"class.std::__uniq_ptr_impl.440" = type { %"class.std::tuple.441" }
%"class.std::tuple.441" = type { %"struct.std::_Tuple_impl.442" }
%"struct.std::_Tuple_impl.442" = type { %"struct.std::_Head_base.445" }
%"struct.std::_Head_base.445" = type { ptr }
%"struct.llvm::MachineBasicBlock::SplitCriticalEdgeAnalyses" = type { ptr, ptr, ptr, ptr }
%"struct.llvm::detail::DenseMapPair.807" = type { %"struct.std::pair.805", ptr }
%"struct.std::pair.805" = type { ptr, ptr }
%"class.llvm::SmallVector.278" = type { %"class.llvm::SmallVectorImpl.279", %"struct.llvm::SmallVectorStorage.282" }
%"class.llvm::SmallVectorImpl.279" = type { %"class.llvm::SmallVectorTemplateBase.280" }
%"class.llvm::SmallVectorTemplateBase.280" = type { %"class.llvm::SmallVectorTemplateCommon.281" }
%"class.llvm::SmallVectorTemplateCommon.281" = type { %"class.llvm::SmallVectorBase" }
%"struct.llvm::SmallVectorStorage.282" = type { [16 x i8] }
%class.SlotIndexUpdateDelegate = type { %"class.llvm::MachineFunction::Delegate", ptr, ptr, %"class.llvm::SmallSetVector" }
%"class.llvm::MachineFunction::Delegate" = type { ptr }
%"class.llvm::SmallSetVector" = type { %"class.llvm::SetVector.520" }
%"class.llvm::SetVector.520" = type { %"class.llvm::DenseSet.521", %"class.llvm::SmallVector.525" }
%"class.llvm::DenseSet.521" = type { %"class.llvm::detail::DenseSetImpl.522" }
%"class.llvm::detail::DenseSetImpl.522" = type { %"class.llvm::DenseMap.523" }
%"class.llvm::DenseMap.523" = type { ptr, ptr, i32, i32 }
%"class.llvm::SmallVector.525" = type { %"class.llvm::SmallVectorImpl.526", %"struct.llvm::SmallVectorStorage.529" }
%"class.llvm::SmallVectorImpl.526" = type { %"class.llvm::SmallVectorTemplateBase.527" }
%"class.llvm::SmallVectorTemplateBase.527" = type { %"class.llvm::SmallVectorTemplateCommon.528" }
%"class.llvm::SmallVectorTemplateCommon.528" = type { %"class.llvm::SmallVectorBase" }
%"struct.llvm::SmallVectorStorage.529" = type { [16 x i8] }
%"class.llvm::SmallSet" = type { %"class.llvm::SmallVector.531", %"class.std::set" }
%"class.llvm::SmallVector.531" = type { %"class.llvm::SmallVectorImpl.279", %"struct.llvm::SmallVectorStorage.532" }
%"struct.llvm::SmallVectorStorage.532" = type { [32 x i8] }
%"class.std::set" = type { %"class.std::_Rb_tree.533" }
%"class.std::_Rb_tree.533" = type { %"struct.std::_Rb_tree<llvm::Register, llvm::Register, std::_Identity<llvm::Register>, std::less<llvm::Register>>::_Rb_tree_impl" }
%"struct.std::_Rb_tree<llvm::Register, llvm::Register, std::_Identity<llvm::Register>, std::less<llvm::Register>>::_Rb_tree_impl" = type { [8 x i8], %"struct.std::_Rb_tree_header" }
%"struct.std::_Rb_tree_header" = type { %"struct.std::_Rb_tree_node_base", i64 }
%"struct.std::_Rb_tree_node_base" = type { i32, ptr, ptr, ptr }
%"class.llvm::Register" = type { i32 }
%"struct.std::pair.538" = type { %"class.llvm::SmallSetIterator", i8, [7 x i8] }
%"class.llvm::SmallSetIterator" = type <{ %union.anon.541, i8, [7 x i8] }>
%union.anon.541 = type { %"struct.std::_Rb_tree_const_iterator" }
%"struct.std::_Rb_tree_const_iterator" = type { ptr }
%"struct.llvm::LiveRange::Segment" = type { %"class.llvm::SlotIndex", %"class.llvm::SlotIndex", ptr }
%"struct.llvm::MachineJumpTableEntry" = type <{ %"class.std::vector.24", i32, [4 x i8] }>
%"class.std::vector.24" = type { %"struct.std::_Vector_base.25" }
%"struct.std::_Vector_base.25" = type { %"struct.std::_Vector_base<llvm::MachineBasicBlock *, std::allocator<llvm::MachineBasicBlock *>>::_Vector_impl" }
%"struct.std::_Vector_base<llvm::MachineBasicBlock *, std::allocator<llvm::MachineBasicBlock *>>::_Vector_impl" = type { %"struct.std::_Vector_base<llvm::MachineBasicBlock *, std::allocator<llvm::MachineBasicBlock *>>::_Vector_impl_data" }
%"struct.std::_Vector_base<llvm::MachineBasicBlock *, std::allocator<llvm::MachineBasicBlock *>>::_Vector_impl_data" = type { ptr, ptr, ptr }
%"struct.std::pair.815" = type { %"class.llvm::SlotIndex", ptr }
%"class.llvm::SmallVector.667" = type { %"class.llvm::SmallVectorImpl.668", %"struct.llvm::SmallVectorStorage.671" }
%"class.llvm::SmallVectorImpl.668" = type { %"class.llvm::SmallVectorTemplateBase.669" }
%"class.llvm::SmallVectorTemplateBase.669" = type { %"class.llvm::SmallVectorTemplateCommon.670" }
%"class.llvm::SmallVectorTemplateCommon.670" = type { %"class.llvm::SmallVectorBase" }
%"struct.llvm::SmallVectorStorage.671" = type { [32 x i8] }
%"class.llvm::MachineBasicBlock::liveout_iterator" = type { %"class.llvm::MCRegister", %"class.llvm::MCRegister", ptr, ptr, %"class.__gnu_cxx::__normal_iterator" }
%"class.__gnu_cxx::__normal_iterator" = type { ptr }
%"struct.std::pair.817" = type { ptr, i64 }
%"class.llvm::detail::DenseSetPair" = type { ptr }
%class.anon.834 = type { i8 }
%"struct.std::pair.840" = type { ptr, %"class.llvm::SlotIndex" }
%"class.llvm::DenseMap.376" = type { ptr, ptr, i32, i32 }

$_ZN4llvm2cl3optIbLb0ENS0_6parserIbEEED2Ev = comdat any

$_ZNK4llvm11SlotIndexes19getInstructionIndexERKNS_12MachineInstrEb = comdat any

$_ZN4llvm7BuildMIERNS_17MachineBasicBlockENS_26MachineInstrBundleIteratorINS_12MachineInstrELb0EEERKNS_10MIMetadataERKNS_11MCInstrDescENS_8RegisterE = comdat any

$_ZN4llvm11SlotIndexes15insertMBBInMapsEPNS_17MachineBasicBlockE = comdat any

$_ZN23SlotIndexUpdateDelegateD2Ev = comdat any

$_ZN4llvm11iplist_implINS_12simple_ilistINS_12MachineInstrEJNS_23ilist_sentinel_trackingILb1EEEEEENS_12ilist_traitsIS2_EEE5eraseENS_14ilist_iteratorINS_12ilist_detail12node_optionsIS2_Lb1ELb1EvLb0EvEELb0ELb0EEESD_ = comdat any

$_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_13PrintLaneMaskENS0_11LaneBitmaskEEUlS2_E_E9_M_invokeERKSt9_Any_dataS2_ = comdat any

$_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_13PrintLaneMaskENS0_11LaneBitmaskEEUlS2_E_E10_M_managerERSt9_Any_dataRKS7_St18_Manager_operation = comdat any

$_ZN4llvm12function_refIFiPcmEE11callback_fnIZNS_lsIJmEEERNS_11raw_ostreamES7_NS_13format_objectIJDpT_EEEEUlS1_mE_EEilS1_m = comdat any

$_ZN4llvm20BumpPtrAllocatorImplINS_15MallocAllocatorELm4096ELm4096ELm128ELm8EE12AllocateSlowEmmNS_5AlignE = comdat any

$_ZN4llvm23SmallVectorTemplateBaseISt4pairIPvmELb1EE15growAndPushBackES3_ = comdat any

$_ZN4llvm23SmallVectorTemplateBaseIPvLb1EE15growAndPushBackES1_ = comdat any

$_ZN4llvm23SmallVectorTemplateBaseISt4pairINS_9SlotIndexES2_ELb1EE15growAndPushBackES3_ = comdat any

$_ZN4llvm23SmallVectorTemplateBaseISt4pairINS_9SlotIndexEPNS_17MachineBasicBlockEELb1EE15growAndPushBackES5_ = comdat any

$_ZSt16__introsort_loopIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEElNS1_10less_firstEEvT_S8_T0_T1_ = comdat any

$_ZSt22__final_insertion_sortIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEENS1_10less_firstEEvT_S8_T0_ = comdat any

$_ZSt13__adjust_heapIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEElS5_NS1_10less_firstEEvT_T0_S9_T1_T2_ = comdat any

$_ZSt22__move_median_to_firstIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEENS1_10less_firstEEvT_S8_S8_S8_T0_ = comdat any

$_ZN23SlotIndexUpdateDelegateD0Ev = comdat any

$_ZN23SlotIndexUpdateDelegate18MF_HandleInsertionERN4llvm12MachineInstrE = comdat any

$_ZN23SlotIndexUpdateDelegate16MF_HandleRemovalERN4llvm12MachineInstrE = comdat any

$_ZN4llvm15MachineFunction8Delegate19MF_HandleChangeDescERNS_12MachineInstrERKNS_11MCInstrDescE = comdat any

$_ZN4llvm9SetVectorIPNS_12MachineInstrENS_11SmallVectorIS2_Lj2EEENS_8DenseSetIS2_NS_12DenseMapInfoIS2_vEEEELj2EE6insertERKS2_ = comdat any

$_ZN4llvm23SmallVectorTemplateBaseIPNS_12MachineInstrELb1EE15growAndPushBackES2_ = comdat any

$_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E24lookupOrInsertIntoBucketIRKS3_JEEESt4pairIPS9_bEOT_DpOT0_ = comdat any

$_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E15LookupBucketForIS3_EEbRKT_RPS9_ = comdat any

$_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E4growEj = comdat any

$_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E8moveFromERSA_ = comdat any

$_ZN4llvm9SetVectorIPNS_12MachineInstrENS_11SmallVectorIS2_Lj2EEENS_8DenseSetIS2_NS_12DenseMapInfoIS2_vEEEELj2EE6removeERKS2_ = comdat any

$_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E21eraseFromFilledBucketIZNSB_21eraseFromFilledBucketEPS9_EUlRS9_E_EEvSD_OT_ = comdat any

$_ZN4llvm11SlotIndexes24insertMachineInstrInMapsERNS_12MachineInstrEb = comdat any

$_ZNK4llvm11SlotIndexes13getIndexAfterERKNS_12MachineInstrE = comdat any

$_ZNK4llvm11SlotIndexes14getIndexBeforeERKNS_12MachineInstrE = comdat any

$_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E24lookupOrInsertIntoBucketIS4_JS5_EEESt4pairIPSA_bEOT_DpOT0_ = comdat any

$_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E15LookupBucketForIS4_EEbRKT_RPSA_ = comdat any

$_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E4growEj = comdat any

$_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E8moveFromERSB_ = comdat any

$_ZN4llvm13LiveIntervals13removeRegUnitENS_9MCRegUnitE = comdat any

$_ZNSt8_Rb_treeIN4llvm9LiveRange7SegmentES2_St9_IdentityIS2_ESt4lessIS2_ESaIS2_EE8_M_eraseEPSt13_Rb_tree_nodeIS2_E = comdat any

$_ZNSt8_Rb_treeIN4llvm8RegisterES1_St9_IdentityIS1_ESt4lessIS1_ESaIS1_EE8_M_eraseEPSt13_Rb_tree_nodeIS1_E = comdat any

$_ZN4llvm23SmallVectorTemplateBaseINS_8RegisterELb1EE15growAndPushBackES1_ = comdat any

$_ZNK4llvm2cl15OptionValueCopyIbE7compareERKNS0_18GenericOptionValueE = comdat any

$_ZN4llvm12function_refIFiPcmEE11callback_fnIZNS_lsIJjEEERNS_11raw_ostreamES7_NS_13format_objectIJDpT_EEEEUlS1_mE_EEilS1_m = comdat any

$_ZN4llvm12function_refIFiPcmEE11callback_fnIZNS_lsIJdEEERNS_11raw_ostreamES7_NS_13format_objectIJDpT_EEEEUlS1_mE_EEilS1_m = comdat any

$_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_ = comdat any

$_ZN4llvm8SmallSetINS_8RegisterELj8ESt4lessIS1_EE10insertImplIRKS1_EESt4pairINS_16SmallSetIteratorIS1_Lj8ES3_EEbEOT_ = comdat any

$_ZNSt3setIN4llvm8RegisterESt4lessIS1_ESaIS1_EE6insertISt13move_iteratorIPS1_EEEvT_SA_ = comdat any

$_ZTV23SlotIndexUpdateDelegate = comdat any

$_ZTVN4llvm2cl11OptionValueIbEE = comdat any

@_ZN4llvm24DisableABIBreakingChecksE = external global i32, align 4
@_ZN4llvm30VerifyDisableABIBreakingChecksE = weak hidden local_unnamed_addr global ptr @_ZN4llvm24DisableABIBreakingChecksE, align 8
@_ZL16PrintSlotIndexes = internal global %"class.llvm::cl::opt" zeroinitializer, align 8
@.str = private unnamed_addr constant [18 x i8] c"print-slotindexes\00", align 1
@.str.1 = private unnamed_addr constant [91 x i8] c"When printing machine IR, annotate instructions and blocks with SlotIndexes when available\00", align 1
@__dso_handle = external hidden global i8
@_ZN4llvm12MBBSectionID13ColdSectionIDE = global %"struct.llvm::MBBSectionID" zeroinitializer, align 4
@.str.2 = private unnamed_addr constant [6 x i8] c".cold\00", align 1
@_ZN4llvm12MBBSectionID18ExceptionSectionIDE = global %"struct.llvm::MBBSectionID" zeroinitializer, align 4
@.str.3 = private unnamed_addr constant [4 x i8] c".eh\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c".__part.\00", align 1
@.str.5 = private unnamed_addr constant [3 x i8] c"BB\00", align 1
@.str.6 = private unnamed_addr constant [2 x i8] c"_\00", align 1
@.str.7 = private unnamed_addr constant [8 x i8] c"$ehgcr_\00", align 1
@.str.8 = private unnamed_addr constant [7 x i8] c"BB_END\00", align 1
@.str.9 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@.str.10 = private unnamed_addr constant [2 x i8] c":\00", align 1
@.str.11 = private unnamed_addr constant [65 x i8] c"Can't print out MachineBasicBlock because parent MachineFunction\00", align 1
@.str.12 = private unnamed_addr constant [10 x i8] c" is null\0A\00", align 1
@.str.13 = private unnamed_addr constant [3 x i8] c":\0A\00", align 1
@.str.14 = private unnamed_addr constant [17 x i8] c"; predecessors: \00", align 1
@.str.15 = private unnamed_addr constant [3 x i8] c", \00", align 1
@.str.16 = private unnamed_addr constant [13 x i8] c"successors: \00", align 1
@.str.17 = private unnamed_addr constant [7 x i8] c"0x%08x\00", align 1
@.str.18 = private unnamed_addr constant [3 x i8] c"; \00", align 1
@.str.19 = private unnamed_addr constant [7 x i8] c"%.2f%%\00", align 1
@.str.20 = private unnamed_addr constant [10 x i8] c"liveins: \00", align 1
@.str.21 = private unnamed_addr constant [4 x i8] c":0x\00", align 1
@.str.22 = private unnamed_addr constant [3 x i8] c"}\0A\00", align 1
@.str.23 = private unnamed_addr constant [3 x i8] c" {\00", align 1
@.str.24 = private unnamed_addr constant [35 x i8] c"; Irreducible loop header weight: \00", align 1
@.str.25 = private unnamed_addr constant [4 x i8] c"bb.\00", align 1
@.str.26 = private unnamed_addr constant [3 x i8] c" (\00", align 1
@.str.27 = private unnamed_addr constant [28 x i8] c"machine-block-address-taken\00", align 1
@.str.28 = private unnamed_addr constant [24 x i8] c"ir-block-address-taken \00", align 1
@.str.29 = private unnamed_addr constant [12 x i8] c"landing-pad\00", align 1
@.str.30 = private unnamed_addr constant [29 x i8] c"inlineasm-br-indirect-target\00", align 1
@.str.31 = private unnamed_addr constant [16 x i8] c"ehfunclet-entry\00", align 1
@.str.32 = private unnamed_addr constant [14 x i8] c"ehscope-entry\00", align 1
@.str.33 = private unnamed_addr constant [7 x i8] c"align \00", align 1
@.str.34 = private unnamed_addr constant [12 x i8] c"bbsections \00", align 1
@.str.35 = private unnamed_addr constant [10 x i8] c"Exception\00", align 1
@.str.36 = private unnamed_addr constant [5 x i8] c"Cold\00", align 1
@.str.37 = private unnamed_addr constant [7 x i8] c"bb_id \00", align 1
@.str.38 = private unnamed_addr constant [2 x i8] c" \00", align 1
@.str.39 = private unnamed_addr constant [17 x i8] c"call-frame-size \00", align 1
@_ZTVN4llvm2cl3optIbLb0ENS0_6parserIbEEEE = external unnamed_addr constant { [13 x ptr] }, align 8
@_ZTVN4llvm2cl6OptionE = external unnamed_addr constant { [13 x ptr] }, align 8
@_ZTVN4llvm19raw_svector_ostreamE = external unnamed_addr constant { [16 x ptr] }, align 8
@.str.42 = private unnamed_addr constant [26 x i8] c"vector::_M_realloc_append\00", align 1
@.str.43 = private unnamed_addr constant [21 x i8] c"basic_string::append\00", align 1
@.str.44 = private unnamed_addr constant [8 x i8] c"%016llX\00", align 1
@.str.45 = private unnamed_addr constant [11 x i8] c"%ir-block.\00", align 1
@.str.46 = private unnamed_addr constant [18 x i8] c"<ir-block badref>\00", align 1
@.str.47 = private unnamed_addr constant [18 x i8] c"Allocation failed\00", align 1
@_ZN4llvm24LiveIntervalsWrapperPass2IDE = external global i8, align 1
@_ZN4llvm21LiveIntervalsAnalysis3KeyE = external global %"struct.llvm::AnalysisKey", align 8
@_ZN4llvm22SlotIndexesWrapperPass2IDE = external global i8, align 1
@_ZN4llvm19SlotIndexesAnalysis3KeyE = external global %"struct.llvm::AnalysisKey", align 8
@_ZN4llvm24LiveVariablesWrapperPass2IDE = external global i8, align 1
@_ZN4llvm21LiveVariablesAnalysis3KeyE = external global %"struct.llvm::AnalysisKey", align 8
@_ZN4llvm26MachineLoopInfoWrapperPass2IDE = external global i8, align 1
@_ZN4llvm19MachineLoopAnalysis3KeyE = external global %"struct.llvm::AnalysisKey", align 8
@_ZTV23SlotIndexUpdateDelegate = linkonce_odr unnamed_addr constant { [8 x ptr] } { [8 x ptr] [ptr null, ptr null, ptr @_ZN4llvm15MachineFunction8Delegate6anchorEv, ptr @_ZN23SlotIndexUpdateDelegateD2Ev, ptr @_ZN23SlotIndexUpdateDelegateD0Ev, ptr @_ZN23SlotIndexUpdateDelegate18MF_HandleInsertionERN4llvm12MachineInstrE, ptr @_ZN23SlotIndexUpdateDelegate16MF_HandleRemovalERN4llvm12MachineInstrE, ptr @_ZN4llvm15MachineFunction8Delegate19MF_HandleChangeDescERNS_12MachineInstrERKNS_11MCInstrDescE] }, comdat, align 8
@_ZTVN4llvm2cl11OptionValueIbEE = linkonce_odr unnamed_addr constant { [4 x ptr] } { [4 x ptr] [ptr null, ptr null, ptr @_ZNK4llvm2cl15OptionValueCopyIbE7compareERKNS0_18GenericOptionValueE, ptr @_ZN4llvm2cl18GenericOptionValue6anchorEv] }, comdat, align 8
@_ZTVN4llvm2cl6parserIbEE = external unnamed_addr constant { [6 x ptr] }, align 8
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 65535, ptr @_GLOBAL__sub_I_MachineBasicBlock.cpp, ptr null }]

@_ZN4llvm17MachineBasicBlockC1ERNS_15MachineFunctionEPKNS_10BasicBlockE = unnamed_addr alias void (ptr, ptr, ptr), ptr @_ZN4llvm17MachineBasicBlockC2ERNS_15MachineFunctionEPKNS_10BasicBlockE
@_ZN4llvm17MachineBasicBlockD1Ev = unnamed_addr alias void (ptr), ptr @_ZN4llvm17MachineBasicBlockD2Ev

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #0

; Function Attrs: inlinehint mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm2cl3optIbLb0ENS0_6parserIbEEED2Ev(ptr noundef nonnull align 8 dereferenceable(184) %0) unnamed_addr #1 comdat align 2 {
  store ptr getelementptr inbounds nuw inrange(-16, 88) (i8, ptr @_ZTVN4llvm2cl3optIbLb0ENS0_6parserIbEEEE, i64 16), ptr %0, align 8, !tbaa !4
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 168
  %3 = load ptr, ptr %2, align 8, !tbaa !7
  %4 = icmp eq ptr %3, null
  br i1 %4, label %8, label %5

5:                                                ; preds = %1
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %7 = tail call noundef zeroext i1 %3(ptr noundef nonnull align 8 dereferenceable(32) %6, ptr noundef nonnull align 8 dereferenceable(32) %6, i32 noundef 3) #33
  br label %8

8:                                                ; preds = %1, %5
  store ptr getelementptr inbounds nuw inrange(-16, 88) (i8, ptr @_ZTVN4llvm2cl6OptionE, i64 16), ptr %0, align 8, !tbaa !4
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 104
  %10 = load i8, ptr %9, align 8, !tbaa !11, !range !16, !noundef !17
  %11 = trunc nuw i8 %10 to i1
  br i1 %11, label %15, label %12

12:                                               ; preds = %8
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 88
  %14 = load ptr, ptr %13, align 8, !tbaa !18
  tail call void @free(ptr noundef %14) #33
  br label %15

15:                                               ; preds = %12, %8
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %17 = load ptr, ptr %16, align 8, !tbaa !19
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %19 = icmp eq ptr %17, %18
  br i1 %19, label %21, label %20

20:                                               ; preds = %15
  tail call void @free(ptr noundef %17) #33
  br label %21

21:                                               ; preds = %15, %20
  ret void
}

; Function Attrs: nofree nounwind
declare i32 @__cxa_atexit(ptr, ptr, ptr) local_unnamed_addr #2

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlockC2ERNS_15MachineFunctionEPKNS_10BasicBlockE(ptr noundef nonnull align 8 dereferenceable(288) initializes((0, 40)) %0, ptr noundef nonnull align 8 dereferenceable(1057) %1, ptr noundef %2) unnamed_addr #3 align 2 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %0, i8 0, i64 16, i1 false)
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store ptr %2, ptr %4, align 8, !tbaa !21
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 24
  store i32 -1, ptr %5, align 8, !tbaa !72
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 28
  store i32 0, ptr %6, align 4, !tbaa !73
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store ptr %1, ptr %7, align 8, !tbaa !74
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %10 = ptrtoint ptr %9 to i64
  %11 = or disjoint i64 %10, 4
  store i64 %11, ptr %9, align 8
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 56
  store ptr %9, ptr %12, align 8, !tbaa !75
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 80
  store ptr %14, ptr %13, align 8, !tbaa !19
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 72
  store i32 0, ptr %15, align 8, !tbaa !76
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 76
  store i32 4, ptr %16, align 4, !tbaa !77
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 128
  store ptr %18, ptr %17, align 8, !tbaa !19
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 120
  store i32 0, ptr %19, align 8, !tbaa !76
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 124
  store i32 2, ptr %20, align 4, !tbaa !77
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 144
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %21, i8 0, i64 24, i1 false)
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 176
  store i8 0, ptr %22, align 8, !tbaa !78
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 212
  store i32 0, ptr %24, align 4, !tbaa !79
  %25 = getelementptr inbounds nuw i8, ptr %0, i64 216
  store i8 0, ptr %25, align 8, !tbaa !80
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 217
  store i8 0, ptr %26, align 1, !tbaa !81
  %27 = getelementptr inbounds nuw i8, ptr %0, i64 220
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 248
  store i8 0, ptr %28, align 8, !tbaa !82
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 252
  %30 = getelementptr inbounds nuw i8, ptr %0, i64 264
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(25) %23, i8 0, i64 25, i1 false)
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(17) %27, i8 0, i64 17, i1 false)
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(11) %29, i8 0, i64 11, i1 false)
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %30, i8 0, i64 24, i1 false)
  store ptr %0, ptr %8, align 8, !tbaa !83
  %31 = icmp eq ptr %2, null
  br i1 %31, label %37, label %32

32:                                               ; preds = %3
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 168
  %34 = tail call { i64, i8 } @_ZNK4llvm10BasicBlock22getIrrLoopHeaderWeightEv(ptr noundef nonnull align 8 dereferenceable(80) %2) #33
  %35 = extractvalue { i64, i8 } %34, 0
  %36 = extractvalue { i64, i8 } %34, 1
  store i64 %35, ptr %33, align 8
  store i8 %36, ptr %22, align 8
  br label %37

37:                                               ; preds = %32, %3
  ret void
}

declare { i64, i8 } @_ZNK4llvm10BasicBlock22getIrrLoopHeaderWeightEv(ptr noundef nonnull align 8 dereferenceable(80)) local_unnamed_addr #4

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #5

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlockD2Ev(ptr noundef nonnull align 8 dereferenceable(288) %0) unnamed_addr #3 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 200
  %4 = load ptr, ptr %3, align 8, !tbaa !84
  %5 = load ptr, ptr %2, align 8, !tbaa !85
  %6 = ptrtoint ptr %4 to i64
  %7 = ptrtoint ptr %5 to i64
  %8 = sub i64 %6, %7
  %9 = icmp sgt i64 %8, -1
  tail call void @llvm.assume(i1 %9)
  %10 = icmp eq ptr %5, null
  br i1 %10, label %12, label %11

11:                                               ; preds = %1
  tail call void @_ZdlPvm(ptr noundef nonnull %5, i64 noundef %8) #34
  br label %12

12:                                               ; preds = %1, %11
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 160
  %15 = load ptr, ptr %14, align 8, !tbaa !86
  %16 = load ptr, ptr %13, align 8, !tbaa !87
  %17 = ptrtoint ptr %15 to i64
  %18 = ptrtoint ptr %16 to i64
  %19 = sub i64 %17, %18
  %20 = icmp sgt i64 %19, -1
  tail call void @llvm.assume(i1 %20)
  %21 = icmp eq ptr %16, null
  br i1 %21, label %23, label %22

22:                                               ; preds = %12
  tail call void @_ZdlPvm(ptr noundef nonnull %16, i64 noundef %19) #34
  br label %23

23:                                               ; preds = %12, %22
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %25 = load ptr, ptr %24, align 8, !tbaa !19
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 128
  %27 = icmp eq ptr %25, %26
  br i1 %27, label %29, label %28

28:                                               ; preds = %23
  tail call void @free(ptr noundef %25) #33
  br label %29

29:                                               ; preds = %23, %28
  %30 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %31 = load ptr, ptr %30, align 8, !tbaa !19
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 80
  %33 = icmp eq ptr %31, %32
  br i1 %33, label %35, label %34

34:                                               ; preds = %29
  tail call void @free(ptr noundef %31) #33
  br label %35

35:                                               ; preds = %29, %34
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %37 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %39 = load ptr, ptr %38, align 8, !tbaa !75
  %40 = tail call ptr @_ZN4llvm11iplist_implINS_12simple_ilistINS_12MachineInstrEJNS_23ilist_sentinel_trackingILb1EEEEEENS_12ilist_traitsIS2_EEE5eraseENS_14ilist_iteratorINS_12ilist_detail12node_optionsIS2_Lb1ELb1EvLb0EvEELb0ELb0EEESD_(ptr noundef nonnull align 8 dereferenceable(24) %36, ptr %39, ptr nonnull %37)
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZNK4llvm17MachineBasicBlock9getSymbolEv(ptr noundef nonnull align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = alloca %"class.llvm::SmallString.239", align 8
  %3 = alloca %"class.std::__cxx11::basic_string", align 8
  %4 = alloca %"class.llvm::Twine", align 8
  %5 = alloca %"class.llvm::Twine", align 8
  %6 = alloca %"class.llvm::Twine", align 8
  %7 = alloca %"class.llvm::Twine", align 8
  %8 = alloca %"class.llvm::Twine", align 8
  %9 = alloca %"class.llvm::Twine", align 8
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 264
  %11 = load ptr, ptr %10, align 8, !tbaa !88
  %12 = icmp eq ptr %11, null
  br i1 %12, label %13, label %125

13:                                               ; preds = %1
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %15 = load ptr, ptr %14, align 8, !tbaa !74
  %16 = getelementptr inbounds nuw i8, ptr %15, i64 24
  %17 = load ptr, ptr %16, align 8, !tbaa !89, !nonnull !17, !align !200
  %18 = getelementptr inbounds nuw i8, ptr %15, i64 540
  %19 = load i32, ptr %18, align 4, !tbaa !201
  %20 = icmp ult i32 %19, 3
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 260
  %22 = load i8, ptr %21, align 4, !range !16
  %23 = trunc nuw i8 %22 to i1
  %24 = select i1 %20, i1 %23, i1 false
  br i1 %24, label %25, label %103

25:                                               ; preds = %13
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %2) #33
  %26 = getelementptr inbounds nuw i8, ptr %2, i64 24
  store ptr %26, ptr %2, align 8, !tbaa !202
  %27 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store i64 0, ptr %27, align 8, !tbaa !204
  %28 = getelementptr inbounds nuw i8, ptr %2, i64 16
  store i64 5, ptr %28, align 8, !tbaa !205
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 252
  %30 = load i32, ptr %29, align 4, !tbaa !206
  %31 = load i32, ptr @_ZN4llvm12MBBSectionID13ColdSectionIDE, align 4, !tbaa !206
  %32 = icmp eq i32 %30, %31
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 256
  %34 = load i32, ptr %33, align 8
  %35 = load i32, ptr getelementptr inbounds nuw (i8, ptr @_ZN4llvm12MBBSectionID13ColdSectionIDE, i64 4), align 4
  %36 = icmp eq i32 %34, %35
  %37 = select i1 %32, i1 %36, i1 false
  br i1 %37, label %38, label %39

38:                                               ; preds = %25
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(5) %26, ptr noundef nonnull align 1 dereferenceable(5) @.str.2, i64 5, i1 false)
  store i64 5, ptr %27, align 8, !tbaa !204
  br label %85

39:                                               ; preds = %25
  %40 = load i32, ptr @_ZN4llvm12MBBSectionID18ExceptionSectionIDE, align 4, !tbaa !206
  %41 = icmp eq i32 %30, %40
  %42 = load i32, ptr getelementptr inbounds nuw (i8, ptr @_ZN4llvm12MBBSectionID18ExceptionSectionIDE, i64 4), align 4
  %43 = icmp eq i32 %34, %42
  %44 = select i1 %41, i1 %43, i1 false
  br i1 %44, label %45, label %46

45:                                               ; preds = %39
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(3) %26, ptr noundef nonnull align 1 dereferenceable(3) @.str.3, i64 3, i1 false)
  store i64 3, ptr %27, align 8, !tbaa !204
  br label %85

46:                                               ; preds = %39
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %3) #33
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %4) #33
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %5) #33
  store ptr %26, ptr %5, align 8, !alias.scope !207
  %47 = getelementptr inbounds nuw i8, ptr %5, i64 8
  store i64 0, ptr %47, align 8, !tbaa !212, !alias.scope !207
  %48 = getelementptr inbounds nuw i8, ptr %5, i64 16
  store ptr @.str.4, ptr %48, align 8, !alias.scope !207
  %49 = getelementptr inbounds nuw i8, ptr %5, i64 32
  store i8 5, ptr %49, align 8, !tbaa !213, !alias.scope !207
  %50 = getelementptr inbounds nuw i8, ptr %5, i64 33
  store i8 3, ptr %50, align 1, !tbaa !216, !alias.scope !207
  %51 = zext i32 %34 to i64
  %52 = inttoptr i64 %51 to ptr
  store ptr %5, ptr %4, align 8, !alias.scope !217
  %53 = getelementptr inbounds nuw i8, ptr %4, i64 16
  store ptr %52, ptr %53, align 8, !alias.scope !217
  %54 = getelementptr inbounds nuw i8, ptr %4, i64 32
  store i8 2, ptr %54, align 8, !tbaa !213, !alias.scope !217
  %55 = getelementptr inbounds nuw i8, ptr %4, i64 33
  store i8 9, ptr %55, align 1, !tbaa !216, !alias.scope !217
  call void @_ZNK4llvm5Twine3strB5cxx11Ev(ptr dead_on_unwind nonnull writable sret(%"class.std::__cxx11::basic_string") align 8 %3, ptr noundef nonnull align 8 dereferenceable(34) %4) #33
  %56 = load ptr, ptr %3, align 8, !tbaa !222
  %57 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %58 = load i64, ptr %57, align 8, !tbaa !225
  %59 = icmp ult i64 %58, 9223372036854775807
  call void @llvm.assume(i1 %59)
  store i64 0, ptr %27, align 8, !tbaa !204
  %60 = load i64, ptr %28, align 8, !tbaa !205
  %61 = icmp ult i64 %60, %58
  br i1 %61, label %62, label %64

62:                                               ; preds = %46
  call void @_ZN4llvm15SmallVectorBaseImE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(29) %2, ptr noundef nonnull %26, i64 noundef %58, i64 noundef 1) #33
  %63 = load i64, ptr %27, align 8, !tbaa !204
  br label %66

64:                                               ; preds = %46
  %65 = icmp samesign eq i64 %58, 0
  br i1 %65, label %72, label %66

66:                                               ; preds = %64, %62
  %67 = phi i64 [ %63, %62 ], [ 0, %64 ]
  %68 = load ptr, ptr %2, align 8, !tbaa !202
  %69 = getelementptr inbounds nuw i8, ptr %68, i64 %67
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %69, ptr align 1 %56, i64 %58, i1 false)
  %70 = load i64, ptr %27, align 8, !tbaa !204
  %71 = load ptr, ptr %3, align 8, !tbaa !222
  br label %72

72:                                               ; preds = %64, %66
  %73 = phi ptr [ %56, %64 ], [ %71, %66 ]
  %74 = phi i64 [ 0, %64 ], [ %70, %66 ]
  %75 = add i64 %74, %58
  store i64 %75, ptr %27, align 8, !tbaa !204
  %76 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %77 = icmp eq ptr %73, %76
  br i1 %77, label %78, label %81

78:                                               ; preds = %72
  %79 = load i64, ptr %57, align 8, !tbaa !225
  %80 = icmp ult i64 %79, 16
  call void @llvm.assume(i1 %80)
  br label %84

81:                                               ; preds = %72
  %82 = load i64, ptr %76, align 8, !tbaa !212
  %83 = add i64 %82, 1
  call void @_ZdlPvm(ptr noundef %73, i64 noundef %83) #34
  br label %84

84:                                               ; preds = %78, %81
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %5) #33
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %4) #33
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %3) #33
  br label %85

85:                                               ; preds = %38, %84, %45
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %6) #33
  %86 = call { ptr, i64 } @_ZNK4llvm15MachineFunction7getNameEv(ptr noundef nonnull align 8 dereferenceable(1057) %15) #33
  %87 = extractvalue { ptr, i64 } %86, 0
  %88 = extractvalue { ptr, i64 } %86, 1
  %89 = load ptr, ptr %2, align 8, !tbaa !202
  %90 = load i64, ptr %27, align 8, !tbaa !204
  store ptr %87, ptr %6, align 8, !alias.scope !226
  %91 = getelementptr inbounds nuw i8, ptr %6, i64 8
  store i64 %88, ptr %91, align 8, !tbaa !212, !alias.scope !226
  %92 = getelementptr inbounds nuw i8, ptr %6, i64 16
  store ptr %89, ptr %92, align 8, !alias.scope !226
  %93 = getelementptr inbounds nuw i8, ptr %6, i64 24
  store i64 %90, ptr %93, align 8, !tbaa !212, !alias.scope !226
  %94 = getelementptr inbounds nuw i8, ptr %6, i64 32
  store i8 5, ptr %94, align 8, !tbaa !213, !alias.scope !226
  %95 = getelementptr inbounds nuw i8, ptr %6, i64 33
  store i8 5, ptr %95, align 1, !tbaa !216, !alias.scope !226
  %96 = call noundef ptr @_ZN4llvm9MCContext17getOrCreateSymbolERKNS_5TwineE(ptr noundef nonnull align 8 dereferenceable(2208) %17, ptr noundef nonnull align 8 dereferenceable(34) %6) #33
  store ptr %96, ptr %10, align 8, !tbaa !88
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %6) #33
  %97 = load ptr, ptr %2, align 8, !tbaa !202
  %98 = icmp eq ptr %97, %26
  br i1 %98, label %101, label %99

99:                                               ; preds = %85
  call void @free(ptr noundef %97) #33
  %100 = load ptr, ptr %10, align 8, !tbaa !88
  br label %101

101:                                              ; preds = %85, %99
  %102 = phi ptr [ %96, %85 ], [ %100, %99 ]
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %2) #33
  br label %125

103:                                              ; preds = %13
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %7) #33
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %8) #33
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %9) #33
  %104 = getelementptr inbounds nuw i8, ptr %15, i64 312
  %105 = load i32, ptr %104, align 8, !tbaa !231
  %106 = zext i32 %105 to i64
  %107 = inttoptr i64 %106 to ptr
  store ptr @.str.5, ptr %9, align 8, !alias.scope !232
  %108 = getelementptr inbounds nuw i8, ptr %9, i64 16
  store ptr %107, ptr %108, align 8, !alias.scope !232
  %109 = getelementptr inbounds nuw i8, ptr %9, i64 32
  store i8 3, ptr %109, align 8, !tbaa !213, !alias.scope !232
  %110 = getelementptr inbounds nuw i8, ptr %9, i64 33
  store i8 9, ptr %110, align 1, !tbaa !216, !alias.scope !232
  store ptr %9, ptr %8, align 8, !alias.scope !237
  %111 = getelementptr inbounds nuw i8, ptr %8, i64 16
  store ptr @.str.6, ptr %111, align 8, !alias.scope !237
  %112 = getelementptr inbounds nuw i8, ptr %8, i64 32
  store i8 2, ptr %112, align 8, !tbaa !213, !alias.scope !237
  %113 = getelementptr inbounds nuw i8, ptr %8, i64 33
  store i8 3, ptr %113, align 1, !tbaa !216, !alias.scope !237
  %114 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %115 = load i32, ptr %114, align 8, !tbaa !72
  %116 = zext i32 %115 to i64
  %117 = inttoptr i64 %116 to ptr
  store ptr %8, ptr %7, align 8, !alias.scope !242
  %118 = getelementptr inbounds nuw i8, ptr %7, i64 16
  store ptr %117, ptr %118, align 8, !alias.scope !242
  %119 = getelementptr inbounds nuw i8, ptr %7, i64 32
  store i8 2, ptr %119, align 8, !tbaa !213, !alias.scope !242
  %120 = getelementptr inbounds nuw i8, ptr %7, i64 33
  store i8 10, ptr %120, align 1, !tbaa !216, !alias.scope !242
  %121 = getelementptr inbounds nuw i8, ptr %0, i64 232
  %122 = load i8, ptr %121, align 8, !tbaa !247, !range !16, !noundef !17
  %123 = trunc nuw i8 %122 to i1
  %124 = call noundef ptr @_ZN4llvm9MCContext17createBlockSymbolERKNS_5TwineEb(ptr noundef nonnull align 8 dereferenceable(2208) %17, ptr noundef nonnull align 8 dereferenceable(34) %7, i1 noundef zeroext %123) #33
  store ptr %124, ptr %10, align 8, !tbaa !88
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %9) #33
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %8) #33
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %7) #33
  br label %125

125:                                              ; preds = %101, %103, %1
  %126 = phi ptr [ %102, %101 ], [ %124, %103 ], [ %11, %1 ]
  ret ptr %126
}

declare void @_ZNK4llvm5Twine3strB5cxx11Ev(ptr dead_on_unwind writable sret(%"class.std::__cxx11::basic_string") align 8, ptr noundef nonnull align 8 dereferenceable(34)) local_unnamed_addr #4

declare noundef ptr @_ZN4llvm9MCContext17getOrCreateSymbolERKNS_5TwineE(ptr noundef nonnull align 8 dereferenceable(2208), ptr noundef nonnull align 8 dereferenceable(34)) local_unnamed_addr #4

declare { ptr, i64 } @_ZNK4llvm15MachineFunction7getNameEv(ptr noundef nonnull align 8 dereferenceable(1057)) local_unnamed_addr #4

declare noundef ptr @_ZN4llvm9MCContext17createBlockSymbolERKNS_5TwineEb(ptr noundef nonnull align 8 dereferenceable(2208), ptr noundef nonnull align 8 dereferenceable(34), i1 noundef zeroext) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZNK4llvm17MachineBasicBlock15getEHContSymbolEv(ptr noundef nonnull align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = alloca %"class.llvm::SmallString", align 8
  %3 = alloca %"class.llvm::raw_svector_ostream", align 8
  %4 = alloca %"class.llvm::Twine", align 8
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 272
  %6 = load ptr, ptr %5, align 8, !tbaa !248
  %7 = icmp eq ptr %6, null
  br i1 %7, label %8, label %63

8:                                                ; preds = %1
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %10 = load ptr, ptr %9, align 8, !tbaa !74
  call void @llvm.lifetime.start.p0(i64 152, ptr nonnull %2) #33
  %11 = getelementptr inbounds nuw i8, ptr %2, i64 24
  store ptr %11, ptr %2, align 8, !tbaa !202
  %12 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store i64 0, ptr %12, align 8, !tbaa !204
  %13 = getelementptr inbounds nuw i8, ptr %2, i64 16
  store i64 128, ptr %13, align 8, !tbaa !205
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %3) #33
  %14 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store i32 2, ptr %14, align 8, !tbaa !249
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 40
  store i8 0, ptr %15, align 8, !tbaa !253
  %16 = getelementptr inbounds nuw i8, ptr %3, i64 44
  store i32 1, ptr %16, align 4, !tbaa !254
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %17, i8 0, i64 24, i1 false)
  store ptr getelementptr inbounds nuw inrange(-16, 112) (i8, ptr @_ZTVN4llvm19raw_svector_ostreamE, i64 16), ptr %3, align 8, !tbaa !4
  %18 = getelementptr inbounds nuw i8, ptr %3, i64 48
  store ptr %2, ptr %18, align 8, !tbaa !255
  call void @_ZN4llvm11raw_ostream16SetBufferAndModeEPcmNS0_10BufferKindE(ptr noundef nonnull align 8 dereferenceable(56) %3, ptr noundef null, i64 noundef 0, i32 noundef 0) #33
  %19 = getelementptr inbounds nuw i8, ptr %3, i64 24
  %20 = load ptr, ptr %19, align 8, !tbaa !257
  %21 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %22 = load ptr, ptr %21, align 8, !tbaa !258
  %23 = ptrtoint ptr %20 to i64
  %24 = ptrtoint ptr %22 to i64
  %25 = sub i64 %23, %24
  %26 = icmp ult i64 %25, 7
  br i1 %26, label %27, label %29

27:                                               ; preds = %8
  %28 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(56) %3, ptr noundef nonnull @.str.7, i64 noundef 7) #33
  br label %32

29:                                               ; preds = %8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %22, ptr noundef nonnull align 1 dereferenceable(7) @.str.7, i64 7, i1 false)
  %30 = load ptr, ptr %21, align 8, !tbaa !258
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 7
  store ptr %31, ptr %21, align 8, !tbaa !258
  br label %32

32:                                               ; preds = %27, %29
  %33 = getelementptr inbounds nuw i8, ptr %10, i64 312
  %34 = load i32, ptr %33, align 8, !tbaa !231
  %35 = zext i32 %34 to i64
  %36 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEm(ptr noundef nonnull align 8 dereferenceable(56) %3, i64 noundef %35) #33
  %37 = load ptr, ptr %21, align 8, !tbaa !258
  %38 = load ptr, ptr %19, align 8, !tbaa !257
  %39 = icmp ult ptr %37, %38
  br i1 %39, label %42, label %40

40:                                               ; preds = %32
  %41 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(56) %3, i8 noundef zeroext 95) #33
  br label %44

42:                                               ; preds = %32
  %43 = getelementptr inbounds nuw i8, ptr %37, i64 1
  store ptr %43, ptr %21, align 8, !tbaa !258
  store i8 95, ptr %37, align 1, !tbaa !212
  br label %44

44:                                               ; preds = %40, %42
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %46 = load i32, ptr %45, align 8, !tbaa !72
  %47 = sext i32 %46 to i64
  %48 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEl(ptr noundef nonnull align 8 dereferenceable(56) %3, i64 noundef %47) #33
  call void @_ZN4llvm11raw_ostreamD2Ev(ptr noundef nonnull align 8 dereferenceable(56) %3) #33
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %3) #33
  %49 = getelementptr inbounds nuw i8, ptr %10, i64 24
  %50 = load ptr, ptr %49, align 8, !tbaa !89, !nonnull !17, !align !200
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %4) #33
  %51 = getelementptr inbounds nuw i8, ptr %4, i64 32
  store i8 5, ptr %51, align 8, !tbaa !213
  %52 = getelementptr inbounds nuw i8, ptr %4, i64 33
  store i8 1, ptr %52, align 1, !tbaa !216
  %53 = load ptr, ptr %2, align 8, !tbaa !202
  store ptr %53, ptr %4, align 8, !tbaa !212
  %54 = load i64, ptr %12, align 8, !tbaa !204
  %55 = getelementptr inbounds nuw i8, ptr %4, i64 8
  store i64 %54, ptr %55, align 8, !tbaa !212
  %56 = call noundef ptr @_ZN4llvm9MCContext17getOrCreateSymbolERKNS_5TwineE(ptr noundef nonnull align 8 dereferenceable(2208) %50, ptr noundef nonnull align 8 dereferenceable(34) %4) #33
  store ptr %56, ptr %5, align 8, !tbaa !248
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %4) #33
  %57 = load ptr, ptr %2, align 8, !tbaa !202
  %58 = icmp eq ptr %57, %11
  br i1 %58, label %61, label %59

59:                                               ; preds = %44
  call void @free(ptr noundef %57) #33
  %60 = load ptr, ptr %5, align 8, !tbaa !248
  br label %61

61:                                               ; preds = %44, %59
  %62 = phi ptr [ %56, %44 ], [ %60, %59 ]
  call void @llvm.lifetime.end.p0(i64 152, ptr nonnull %2) #33
  br label %63

63:                                               ; preds = %61, %1
  %64 = phi ptr [ %62, %61 ], [ %6, %1 ]
  ret ptr %64
}

; Function Attrs: nounwind
declare void @_ZN4llvm11raw_ostreamD2Ev(ptr noundef nonnull align 8 dereferenceable(48)) unnamed_addr #6

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZNK4llvm17MachineBasicBlock12getEndSymbolEv(ptr noundef nonnull align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = alloca %"class.llvm::Twine", align 8
  %3 = alloca %"class.llvm::Twine", align 8
  %4 = alloca %"class.llvm::Twine", align 8
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 280
  %6 = load ptr, ptr %5, align 8, !tbaa !259
  %7 = icmp eq ptr %6, null
  br i1 %7, label %8, label %31

8:                                                ; preds = %1
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %10 = load ptr, ptr %9, align 8, !tbaa !74
  %11 = getelementptr inbounds nuw i8, ptr %10, i64 24
  %12 = load ptr, ptr %11, align 8, !tbaa !89, !nonnull !17, !align !200
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %2) #33
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %3) #33
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %4) #33
  %13 = getelementptr inbounds nuw i8, ptr %10, i64 312
  %14 = load i32, ptr %13, align 8, !tbaa !231
  %15 = zext i32 %14 to i64
  %16 = inttoptr i64 %15 to ptr
  store ptr @.str.8, ptr %4, align 8, !alias.scope !260
  %17 = getelementptr inbounds nuw i8, ptr %4, i64 16
  store ptr %16, ptr %17, align 8, !alias.scope !260
  %18 = getelementptr inbounds nuw i8, ptr %4, i64 32
  store i8 3, ptr %18, align 8, !tbaa !213, !alias.scope !260
  %19 = getelementptr inbounds nuw i8, ptr %4, i64 33
  store i8 9, ptr %19, align 1, !tbaa !216, !alias.scope !260
  store ptr %4, ptr %3, align 8, !alias.scope !265
  %20 = getelementptr inbounds nuw i8, ptr %3, i64 16
  store ptr @.str.6, ptr %20, align 8, !alias.scope !265
  %21 = getelementptr inbounds nuw i8, ptr %3, i64 32
  store i8 2, ptr %21, align 8, !tbaa !213, !alias.scope !265
  %22 = getelementptr inbounds nuw i8, ptr %3, i64 33
  store i8 3, ptr %22, align 1, !tbaa !216, !alias.scope !265
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %24 = load i32, ptr %23, align 8, !tbaa !72
  %25 = zext i32 %24 to i64
  %26 = inttoptr i64 %25 to ptr
  store ptr %3, ptr %2, align 8, !alias.scope !270
  %27 = getelementptr inbounds nuw i8, ptr %2, i64 16
  store ptr %26, ptr %27, align 8, !alias.scope !270
  %28 = getelementptr inbounds nuw i8, ptr %2, i64 32
  store i8 2, ptr %28, align 8, !tbaa !213, !alias.scope !270
  %29 = getelementptr inbounds nuw i8, ptr %2, i64 33
  store i8 10, ptr %29, align 1, !tbaa !216, !alias.scope !270
  %30 = call noundef ptr @_ZN4llvm9MCContext17createBlockSymbolERKNS_5TwineEb(ptr noundef nonnull align 8 dereferenceable(2208) %12, ptr noundef nonnull align 8 dereferenceable(34) %2, i1 noundef zeroext false) #33
  store ptr %30, ptr %5, align 8, !tbaa !259
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %4) #33
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %3) #33
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %2) #33
  br label %31

31:                                               ; preds = %8, %1
  %32 = phi ptr [ %30, %8 ], [ %6, %1 ]
  ret ptr %32
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvmlsERNS_11raw_ostreamERKNS_17MachineBasicBlockE(ptr noundef nonnull returned align 8 dereferenceable(48) %0, ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %1) local_unnamed_addr #3 {
  tail call void @_ZNK4llvm17MachineBasicBlock5printERNS_11raw_ostreamEPKNS_11SlotIndexesEb(ptr noundef nonnull align 8 dereferenceable(288) %1, ptr noundef nonnull align 8 dereferenceable(48) %0, ptr noundef null, i1 noundef zeroext true)
  ret ptr %0
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZNK4llvm17MachineBasicBlock5printERNS_11raw_ostreamEPKNS_11SlotIndexesEb(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef %2, i1 noundef zeroext %3) local_unnamed_addr #3 align 2 {
  %5 = alloca %"class.llvm::ModuleSlotTracker", align 8
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %7 = load ptr, ptr %6, align 8, !tbaa !74
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %40

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %11 = load ptr, ptr %10, align 8, !tbaa !257
  %12 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %13 = load ptr, ptr %12, align 8, !tbaa !258
  %14 = ptrtoint ptr %11 to i64
  %15 = ptrtoint ptr %13 to i64
  %16 = sub i64 %14, %15
  %17 = icmp ult i64 %16, 64
  br i1 %17, label %18, label %22

18:                                               ; preds = %9
  %19 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.11, i64 noundef 64) #33
  %20 = getelementptr inbounds nuw i8, ptr %19, i64 32
  %21 = load ptr, ptr %20, align 8, !tbaa !258
  br label %25

22:                                               ; preds = %9
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(64) %13, ptr noundef nonnull align 1 dereferenceable(64) @.str.11, i64 64, i1 false)
  %23 = load ptr, ptr %12, align 8, !tbaa !258
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 64
  store ptr %24, ptr %12, align 8, !tbaa !258
  br label %25

25:                                               ; preds = %18, %22
  %26 = phi ptr [ %21, %18 ], [ %24, %22 ]
  %27 = phi ptr [ %19, %18 ], [ %1, %22 ]
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 24
  %29 = load ptr, ptr %28, align 8, !tbaa !257
  %30 = ptrtoint ptr %29 to i64
  %31 = ptrtoint ptr %26 to i64
  %32 = sub i64 %30, %31
  %33 = icmp ult i64 %32, 9
  br i1 %33, label %34, label %36

34:                                               ; preds = %25
  %35 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %27, ptr noundef nonnull @.str.12, i64 noundef 9) #33
  br label %44

36:                                               ; preds = %25
  %37 = getelementptr inbounds nuw i8, ptr %27, i64 32
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %26, ptr noundef nonnull align 1 dereferenceable(9) @.str.12, i64 9, i1 false)
  %38 = load ptr, ptr %37, align 8, !tbaa !258
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 9
  store ptr %39, ptr %37, align 8, !tbaa !258
  br label %44

40:                                               ; preds = %4
  %41 = load ptr, ptr %7, align 8, !tbaa !275, !nonnull !17, !align !200
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 40
  %43 = load ptr, ptr %42, align 8, !tbaa !276
  call void @llvm.lifetime.start.p0(i64 112, ptr nonnull %5) #33
  call void @_ZN4llvm17ModuleSlotTrackerC1EPKNS_6ModuleE(ptr noundef nonnull align 8 dereferenceable(112) %5, ptr noundef %43) #33
  call void @_ZN4llvm17ModuleSlotTracker19incorporateFunctionERKNS_8FunctionE(ptr noundef nonnull align 8 dereferenceable(112) %5, ptr noundef nonnull align 8 dereferenceable(140) %41) #33
  call void @_ZNK4llvm17MachineBasicBlock5printERNS_11raw_ostreamERNS_17ModuleSlotTrackerEPKNS_11SlotIndexesEb(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull align 8 dereferenceable(112) %5, ptr noundef %2, i1 noundef zeroext %3)
  call void @_ZN4llvm17ModuleSlotTrackerD1Ev(ptr noundef nonnull align 8 dereferenceable(112) %5) #33
  call void @llvm.lifetime.end.p0(i64 112, ptr nonnull %5) #33
  br label %44

44:                                               ; preds = %36, %34, %40
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @_ZN4llvm17printMBBReferenceERKNS_17MachineBasicBlockE(ptr dead_on_unwind noalias writable writeonly sret(%"class.llvm::Printable") align 8 captures(none) initializes((0, 32)) %0, ptr noundef nonnull align 8 dereferenceable(288) %1) local_unnamed_addr #7 {
  %3 = ptrtoint ptr %1 to i64
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 24
  store ptr @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E9_M_invokeERKSt9_Any_dataS2_", ptr %4, align 8, !tbaa !285
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store i64 %3, ptr %0, align 8
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store i64 0, ptr %6, align 8, !tbaa !212
  store ptr @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation", ptr %5, align 8, !tbaa !7
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm21ilist_callback_traitsINS_17MachineBasicBlockEE13addNodeToListEPS1_(ptr nonnull readnone align 1 captures(none) %0, ptr noundef %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %4 = load ptr, ptr %3, align 8, !tbaa !74
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 88
  %6 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %7 = load ptr, ptr %6, align 8, !tbaa !287
  %8 = getelementptr inbounds nuw i8, ptr %4, i64 104
  %9 = load ptr, ptr %8, align 8, !tbaa !288
  %10 = icmp eq ptr %7, %9
  br i1 %10, label %14, label %11

11:                                               ; preds = %2
  store ptr %1, ptr %7, align 8, !tbaa !289
  %12 = getelementptr inbounds nuw i8, ptr %7, i64 8
  store ptr %12, ptr %6, align 8, !tbaa !287
  %13 = load ptr, ptr %5, align 8, !tbaa !290
  br label %38

14:                                               ; preds = %2
  %15 = load ptr, ptr %5, align 8, !tbaa !290
  %16 = ptrtoint ptr %7 to i64
  %17 = ptrtoint ptr %15 to i64
  %18 = sub i64 %16, %17
  %19 = ashr exact i64 %18, 3
  %20 = icmp sgt i64 %19, -1
  tail call void @llvm.assume(i1 %20)
  %21 = icmp eq i64 %18, 9223372036854775800
  br i1 %21, label %22, label %23

22:                                               ; preds = %14
  tail call void @_ZSt20__throw_length_errorPKc(ptr noundef nonnull @.str.42) #35
  unreachable

23:                                               ; preds = %14
  %24 = tail call i64 @llvm.umax.i64(i64 %19, i64 1)
  %25 = add nuw nsw i64 %24, %19
  %26 = tail call noundef i64 @llvm.umin.i64(i64 %25, i64 1152921504606846975)
  %27 = shl nuw nsw i64 %26, 3
  %28 = tail call noalias noundef nonnull ptr @_Znwm(i64 noundef %27) #36
  %29 = getelementptr inbounds i8, ptr %28, i64 %18
  store ptr %1, ptr %29, align 8, !tbaa !289
  %30 = icmp sgt i64 %18, 0
  br i1 %30, label %31, label %32

31:                                               ; preds = %23
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %28, ptr align 8 %15, i64 %18, i1 false)
  br label %32

32:                                               ; preds = %31, %23
  %33 = icmp eq ptr %15, null
  br i1 %33, label %35, label %34

34:                                               ; preds = %32
  tail call void @_ZdlPvm(ptr noundef nonnull %15, i64 noundef %18) #34
  br label %35

35:                                               ; preds = %34, %32
  %36 = getelementptr inbounds nuw i8, ptr %29, i64 8
  store ptr %28, ptr %5, align 8, !tbaa !290
  store ptr %36, ptr %6, align 8, !tbaa !287
  %37 = getelementptr inbounds nuw ptr, ptr %28, i64 %26
  store ptr %37, ptr %8, align 8, !tbaa !288
  br label %38

38:                                               ; preds = %11, %35
  %39 = phi ptr [ %13, %11 ], [ %28, %35 ]
  %40 = phi ptr [ %12, %11 ], [ %36, %35 ]
  %41 = ptrtoint ptr %40 to i64
  %42 = ptrtoint ptr %39 to i64
  %43 = sub i64 %41, %42
  %44 = ashr exact i64 %43, 3
  %45 = icmp sgt i64 %44, -1
  tail call void @llvm.assume(i1 %45)
  %46 = trunc i64 %44 to i32
  %47 = add i32 %46, -1
  %48 = getelementptr inbounds nuw i8, ptr %1, i64 24
  store i32 %47, ptr %48, align 8, !tbaa !72
  %49 = getelementptr inbounds nuw i8, ptr %4, i64 116
  %50 = load i32, ptr %49, align 4, !tbaa !291
  %51 = add i32 %50, 1
  store i32 %51, ptr %49, align 4, !tbaa !291
  %52 = getelementptr inbounds nuw i8, ptr %1, i64 220
  store i32 %50, ptr %52, align 4, !tbaa !292
  %53 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %54 = load ptr, ptr %53, align 8, !tbaa !293
  %55 = getelementptr inbounds nuw i8, ptr %1, i64 56
  %56 = getelementptr inbounds nuw i8, ptr %1, i64 48
  %57 = load ptr, ptr %55, align 8, !tbaa !75
  %58 = icmp eq ptr %57, %56
  br i1 %58, label %59, label %60

59:                                               ; preds = %60, %38
  ret void

60:                                               ; preds = %38, %60
  %61 = phi ptr [ %63, %60 ], [ %57, %38 ]
  tail call void @_ZN4llvm12MachineInstr24addRegOperandsToUseListsERNS_19MachineRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80) %61, ptr noundef nonnull align 8 dereferenceable(520) %54) #33
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 8
  %63 = load ptr, ptr %62, align 8, !tbaa !75
  %64 = icmp eq ptr %63, %56
  br i1 %64, label %59, label %60
}

declare void @_ZN4llvm12MachineInstr24addRegOperandsToUseListsERNS_19MachineRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80), ptr noundef nonnull align 8 dereferenceable(520)) local_unnamed_addr #4

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @_ZN4llvm21ilist_callback_traitsINS_17MachineBasicBlockEE18removeNodeFromListEPS1_(ptr noundef nonnull readnone align 1 captures(none) dereferenceable(1) %0, ptr noundef captures(none) initializes((220, 224)) %1) local_unnamed_addr #8 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %4 = load ptr, ptr %3, align 8, !tbaa !74
  %5 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %6 = load i32, ptr %5, align 8, !tbaa !72
  %7 = getelementptr inbounds nuw i8, ptr %4, i64 88
  %8 = zext i32 %6 to i64
  %9 = load ptr, ptr %7, align 8, !tbaa !290
  %10 = getelementptr inbounds nuw ptr, ptr %9, i64 %8
  store ptr null, ptr %10, align 8, !tbaa !289
  store i32 -1, ptr %5, align 8, !tbaa !72
  %11 = getelementptr inbounds nuw i8, ptr %1, i64 220
  store i32 -1, ptr %11, align 4, !tbaa !292
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm12ilist_traitsINS_12MachineInstrEE13addNodeToListEPS1_(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(8) %0, ptr noundef nonnull initializes((24, 32)) %1) local_unnamed_addr #3 align 2 {
  %3 = load ptr, ptr %0, align 8, !tbaa !83
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 24
  store ptr %3, ptr %4, align 8, !tbaa !294
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %6 = load ptr, ptr %5, align 8, !tbaa !74
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %8 = load ptr, ptr %7, align 8, !tbaa !293
  tail call void @_ZN4llvm12MachineInstr24addRegOperandsToUseListsERNS_19MachineRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80) %1, ptr noundef nonnull align 8 dereferenceable(520) %8) #33
  tail call void @_ZN4llvm15MachineFunction15handleInsertionERNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057) %6, ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  ret void
}

declare void @_ZN4llvm15MachineFunction15handleInsertionERNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057), ptr noundef nonnull align 8 dereferenceable(80)) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm12ilist_traitsINS_12MachineInstrEE18removeNodeFromListEPS1_(ptr noundef nonnull readnone align 8 captures(none) dereferenceable(8) %0, ptr noundef nonnull %1) local_unnamed_addr #3 align 2 {
  %3 = tail call noundef ptr @_ZNK4llvm12MachineInstr5getMFEv(ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  %4 = icmp eq ptr %3, null
  br i1 %4, label %8, label %5

5:                                                ; preds = %2
  tail call void @_ZN4llvm15MachineFunction13handleRemovalERNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057) %3, ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  %6 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %7 = load ptr, ptr %6, align 8, !tbaa !293
  tail call void @_ZN4llvm12MachineInstr29removeRegOperandsFromUseListsERNS_19MachineRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80) %1, ptr noundef nonnull align 8 dereferenceable(520) %7) #33
  br label %8

8:                                                ; preds = %5, %2
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 24
  store ptr null, ptr %9, align 8, !tbaa !294
  ret void
}

declare void @_ZN4llvm15MachineFunction13handleRemovalERNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057), ptr noundef nonnull align 8 dereferenceable(80)) local_unnamed_addr #4

declare void @_ZN4llvm12MachineInstr29removeRegOperandsFromUseListsERNS_19MachineRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80), ptr noundef nonnull align 8 dereferenceable(520)) local_unnamed_addr #4

; Function Attrs: mustprogress nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @_ZN4llvm12ilist_traitsINS_12MachineInstrEE21transferNodesFromListERS2_NS_14ilist_iteratorINS_12ilist_detail12node_optionsIS1_Lb1ELb1EvLb0EvEELb0ELb0EEES8_(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(8) %0, ptr noundef nonnull readnone align 8 captures(address) dereferenceable(8) %1, ptr captures(address) %2, ptr readnone captures(address) %3) local_unnamed_addr #9 align 2 {
  %5 = icmp eq ptr %0, %1
  %6 = icmp eq ptr %2, %3
  %7 = select i1 %5, i1 true, i1 %6
  br i1 %7, label %16, label %8

8:                                                ; preds = %4
  %9 = load ptr, ptr %0, align 8, !tbaa !83
  br label %10

10:                                               ; preds = %8, %10
  %11 = phi ptr [ %2, %8 ], [ %14, %10 ]
  %12 = getelementptr inbounds nuw i8, ptr %11, i64 24
  store ptr %9, ptr %12, align 8, !tbaa !294
  %13 = getelementptr inbounds nuw i8, ptr %11, i64 8
  %14 = load ptr, ptr %13, align 8, !tbaa !75
  %15 = icmp eq ptr %14, %3
  br i1 %15, label %16, label %10, !llvm.loop !304

16:                                               ; preds = %10, %4
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm12ilist_traitsINS_12MachineInstrEE10deleteNodeEPS1_(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(8) %0, ptr noundef %1) local_unnamed_addr #3 align 2 {
  %3 = load ptr, ptr %0, align 8, !tbaa !83
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %5 = load ptr, ptr %4, align 8, !tbaa !74
  tail call void @_ZN4llvm15MachineFunction18deleteMachineInstrEPNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057) %5, ptr noundef %1) #33
  ret void
}

declare void @_ZN4llvm15MachineFunction18deleteMachineInstrEPNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057), ptr noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock14getFirstNonPHIEv(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0) local_unnamed_addr #10 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %4 = load ptr, ptr %2, align 8, !tbaa !75
  %5 = icmp eq ptr %4, %3
  br i1 %5, label %14, label %6

6:                                                ; preds = %1, %10
  %7 = phi ptr [ %12, %10 ], [ %4, %1 ]
  %8 = getelementptr inbounds nuw i8, ptr %7, i64 52
  %9 = load i32, ptr %8, align 4, !tbaa !306
  switch i32 %9, label %14 [
    i32 74, label %10
    i32 0, label %10
  ]

10:                                               ; preds = %6, %6
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 8
  %12 = load ptr, ptr %11, align 8, !tbaa !75
  %13 = icmp eq ptr %12, %3
  br i1 %13, label %14, label %6, !llvm.loop !307

14:                                               ; preds = %10, %6, %1
  %15 = phi ptr [ %4, %1 ], [ %7, %6 ], [ %12, %10 ]
  ret ptr %15
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock17SkipPHIsAndLabelsENS_26MachineInstrBundleIteratorINS_12MachineInstrELb0EEE(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, ptr %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %4 = load ptr, ptr %3, align 8, !tbaa !74
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 16
  %6 = load ptr, ptr %5, align 8, !tbaa !308, !nonnull !17, !align !200
  %7 = load ptr, ptr %6, align 8, !tbaa !4
  %8 = getelementptr inbounds nuw i8, ptr %7, i64 120
  %9 = load ptr, ptr %8, align 8
  %10 = tail call noundef ptr %9(ptr noundef nonnull align 8 dereferenceable(368) %6) #33
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %12 = icmp eq ptr %1, %11
  br i1 %12, label %47, label %13

13:                                               ; preds = %2, %42
  %14 = phi ptr [ %45, %42 ], [ %1, %2 ]
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 52
  %16 = load i32, ptr %15, align 4, !tbaa !306
  switch i32 %16, label %17 [
    i32 74, label %25
    i32 0, label %25
  ]

17:                                               ; preds = %13
  %18 = add i32 %16, -3
  %19 = icmp ult i32 %18, 4
  br i1 %19, label %25, label %20

20:                                               ; preds = %17
  %21 = load ptr, ptr %10, align 8, !tbaa !4
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 1280
  %23 = load ptr, ptr %22, align 8
  %24 = tail call noundef zeroext i1 %23(ptr noundef nonnull align 8 dereferenceable(112) %10, ptr noundef nonnull align 8 dereferenceable(80) %14, i32 0) #33
  br i1 %24, label %25, label %47

25:                                               ; preds = %13, %13, %17, %20
  %26 = load i64, ptr %14, align 8
  %27 = and i64 %26, 4
  %28 = icmp eq i64 %27, 0
  br i1 %28, label %29, label %42

29:                                               ; preds = %25
  %30 = getelementptr inbounds nuw i8, ptr %14, i64 44
  %31 = load i32, ptr %30, align 4, !tbaa !309
  %32 = and i32 %31, 8
  %33 = icmp eq i32 %32, 0
  br i1 %33, label %42, label %34

34:                                               ; preds = %29, %34
  %35 = phi ptr [ %37, %34 ], [ %14, %29 ]
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 8
  %37 = load ptr, ptr %36, align 8, !tbaa !75
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 44
  %39 = load i32, ptr %38, align 4, !tbaa !309
  %40 = and i32 %39, 8
  %41 = icmp eq i32 %40, 0
  br i1 %41, label %42, label %34, !llvm.loop !310

42:                                               ; preds = %34, %25, %29
  %43 = phi ptr [ %14, %25 ], [ %14, %29 ], [ %37, %34 ]
  %44 = getelementptr inbounds nuw i8, ptr %43, i64 8
  %45 = load ptr, ptr %44, align 8, !tbaa !75
  %46 = icmp eq ptr %45, %11
  br i1 %46, label %47, label %13, !llvm.loop !311

47:                                               ; preds = %20, %42, %2
  %48 = phi ptr [ %1, %2 ], [ %45, %42 ], [ %14, %20 ]
  ret ptr %48
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock22SkipPHIsLabelsAndDebugENS_26MachineInstrBundleIteratorINS_12MachineInstrELb0EEENS_8RegisterEb(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, ptr %1, i32 %2, i1 noundef zeroext %3) local_unnamed_addr #3 align 2 {
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %6 = load ptr, ptr %5, align 8, !tbaa !74
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 16
  %8 = load ptr, ptr %7, align 8, !tbaa !308, !nonnull !17, !align !200
  %9 = load ptr, ptr %8, align 8, !tbaa !4
  %10 = getelementptr inbounds nuw i8, ptr %9, i64 120
  %11 = load ptr, ptr %10, align 8
  %12 = tail call noundef ptr %11(ptr noundef nonnull align 8 dereferenceable(368) %8) #33
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %14 = icmp eq ptr %1, %13
  br i1 %14, label %49, label %15

15:                                               ; preds = %4, %44
  %16 = phi ptr [ %47, %44 ], [ %1, %4 ]
  %17 = getelementptr inbounds nuw i8, ptr %16, i64 52
  %18 = load i32, ptr %17, align 4, !tbaa !306
  switch i32 %18, label %19 [
    i32 74, label %27
    i32 0, label %27
    i32 18, label %27
    i32 17, label %27
    i32 16, label %27
    i32 15, label %27
    i32 14, label %27
    i32 6, label %27
    i32 5, label %27
    i32 4, label %27
    i32 3, label %27
  ]

19:                                               ; preds = %15
  %20 = icmp eq i32 %18, 25
  %21 = and i1 %3, %20
  br i1 %21, label %27, label %22

22:                                               ; preds = %19
  %23 = load ptr, ptr %12, align 8, !tbaa !4
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 1280
  %25 = load ptr, ptr %24, align 8
  %26 = tail call noundef zeroext i1 %25(ptr noundef nonnull align 8 dereferenceable(112) %12, ptr noundef nonnull align 8 dereferenceable(80) %16, i32 %2) #33
  br i1 %26, label %27, label %49

27:                                               ; preds = %15, %15, %15, %15, %15, %15, %15, %15, %15, %15, %15, %19, %22
  %28 = load i64, ptr %16, align 8
  %29 = and i64 %28, 4
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %31, label %44

31:                                               ; preds = %27
  %32 = getelementptr inbounds nuw i8, ptr %16, i64 44
  %33 = load i32, ptr %32, align 4, !tbaa !309
  %34 = and i32 %33, 8
  %35 = icmp eq i32 %34, 0
  br i1 %35, label %44, label %36

36:                                               ; preds = %31, %36
  %37 = phi ptr [ %39, %36 ], [ %16, %31 ]
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 8
  %39 = load ptr, ptr %38, align 8, !tbaa !75
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 44
  %41 = load i32, ptr %40, align 4, !tbaa !309
  %42 = and i32 %41, 8
  %43 = icmp eq i32 %42, 0
  br i1 %43, label %44, label %36, !llvm.loop !310

44:                                               ; preds = %36, %27, %31
  %45 = phi ptr [ %16, %27 ], [ %16, %31 ], [ %39, %36 ]
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 8
  %47 = load ptr, ptr %46, align 8, !tbaa !75
  %48 = icmp eq ptr %47, %13
  br i1 %48, label %49, label %15, !llvm.loop !312

49:                                               ; preds = %22, %44, %4
  %50 = phi ptr [ %1, %4 ], [ %47, %44 ], [ %16, %22 ]
  ret ptr %50
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock18getFirstTerminatorEv(ptr noundef nonnull readonly align 8 captures(address, ret: address, provenance) dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %3 = load ptr, ptr %2, align 8, !tbaa !75
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %5 = icmp eq ptr %4, %3
  br i1 %5, label %96, label %6

6:                                                ; preds = %1, %54
  %7 = phi ptr [ %30, %54 ], [ %4, %1 ]
  %8 = load i64, ptr %7, align 8
  %9 = and i64 %8, -8
  %10 = inttoptr i64 %9 to ptr
  %11 = load i64, ptr %10, align 8
  %12 = and i64 %11, 4
  %13 = icmp ne i64 %12, 0
  %14 = getelementptr inbounds nuw i8, ptr %10, i64 44
  %15 = load i32, ptr %14, align 4, !tbaa !309
  %16 = and i32 %15, 4
  %17 = icmp eq i32 %16, 0
  %18 = select i1 %13, i1 true, i1 %17
  br i1 %18, label %28, label %19

19:                                               ; preds = %6, %19
  %20 = phi ptr [ %23, %19 ], [ %10, %6 ]
  %21 = load i64, ptr %20, align 8
  %22 = and i64 %21, -8
  %23 = inttoptr i64 %22 to ptr
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 44
  %25 = load i32, ptr %24, align 4, !tbaa !309
  %26 = and i32 %25, 4
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %28, label %19, !llvm.loop !313

28:                                               ; preds = %19, %6
  %29 = phi i32 [ %15, %6 ], [ %25, %19 ]
  %30 = phi ptr [ %10, %6 ], [ %23, %19 ]
  %31 = and i32 %29, 12
  %32 = icmp eq i32 %31, 0
  %33 = and i32 %29, 4
  %34 = icmp ne i32 %33, 0
  %35 = or i1 %32, %34
  br i1 %35, label %36, label %43

36:                                               ; preds = %28
  %37 = getelementptr inbounds nuw i8, ptr %30, i64 16
  %38 = load ptr, ptr %37, align 8, !tbaa !314
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 16
  %40 = load i64, ptr %39, align 8, !tbaa !315
  %41 = and i64 %40, 512
  %42 = icmp eq i64 %41, 0
  br i1 %42, label %45, label %52

43:                                               ; preds = %28
  %44 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %30, i64 noundef 512, i32 noundef 1) #33
  br i1 %44, label %52, label %45

45:                                               ; preds = %36, %43
  %46 = getelementptr inbounds nuw i8, ptr %30, i64 52
  %47 = load i32, ptr %46, align 4, !tbaa !306
  %48 = add i32 %47, -19
  %49 = icmp ult i32 %48, -5
  %50 = icmp eq ptr %30, %3
  %51 = or i1 %49, %50
  br i1 %51, label %55, label %54

52:                                               ; preds = %36, %43
  %53 = icmp eq ptr %30, %3
  br i1 %53, label %55, label %54

54:                                               ; preds = %52, %45
  br label %6, !llvm.loop !317

55:                                               ; preds = %45, %52
  %56 = icmp eq ptr %30, %4
  br i1 %56, label %96, label %57

57:                                               ; preds = %55, %91
  %58 = phi ptr [ %94, %91 ], [ %30, %55 ]
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 44
  %60 = load i32, ptr %59, align 4, !tbaa !309
  %61 = and i32 %60, 12
  %62 = icmp eq i32 %61, 0
  %63 = and i32 %60, 4
  %64 = icmp ne i32 %63, 0
  %65 = or i1 %62, %64
  br i1 %65, label %66, label %73

66:                                               ; preds = %57
  %67 = getelementptr inbounds nuw i8, ptr %58, i64 16
  %68 = load ptr, ptr %67, align 8, !tbaa !314
  %69 = getelementptr inbounds nuw i8, ptr %68, i64 16
  %70 = load i64, ptr %69, align 8, !tbaa !315
  %71 = and i64 %70, 512
  %72 = icmp eq i64 %71, 0
  br i1 %72, label %75, label %96

73:                                               ; preds = %57
  %74 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %58, i64 noundef 512, i32 noundef 1) #33
  br i1 %74, label %96, label %75

75:                                               ; preds = %66, %73
  %76 = load i64, ptr %58, align 8
  %77 = and i64 %76, 4
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %79, label %91

79:                                               ; preds = %75
  %80 = load i32, ptr %59, align 4, !tbaa !309
  %81 = and i32 %80, 8
  %82 = icmp eq i32 %81, 0
  br i1 %82, label %91, label %83

83:                                               ; preds = %79, %83
  %84 = phi ptr [ %86, %83 ], [ %58, %79 ]
  %85 = getelementptr inbounds nuw i8, ptr %84, i64 8
  %86 = load ptr, ptr %85, align 8, !tbaa !75
  %87 = getelementptr inbounds nuw i8, ptr %86, i64 44
  %88 = load i32, ptr %87, align 4, !tbaa !309
  %89 = and i32 %88, 8
  %90 = icmp eq i32 %89, 0
  br i1 %90, label %91, label %83, !llvm.loop !310

91:                                               ; preds = %83, %75, %79
  %92 = phi ptr [ %58, %75 ], [ %58, %79 ], [ %86, %83 ]
  %93 = getelementptr inbounds nuw i8, ptr %92, i64 8
  %94 = load ptr, ptr %93, align 8, !tbaa !75
  %95 = icmp eq ptr %94, %4
  br i1 %95, label %96, label %57, !llvm.loop !318

96:                                               ; preds = %73, %91, %66, %1, %55
  %97 = phi ptr [ %30, %55 ], [ %4, %1 ], [ %58, %66 ], [ %94, %91 ], [ %58, %73 ]
  ret ptr %97
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock23getFirstInstrTerminatorEv(ptr noundef nonnull readonly align 8 captures(address, ret: address, provenance) dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %3 = load ptr, ptr %2, align 8, !tbaa !75
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %5 = icmp eq ptr %4, %3
  br i1 %5, label %61, label %6

6:                                                ; preds = %1, %36
  %7 = phi ptr [ %10, %36 ], [ %4, %1 ]
  %8 = load i64, ptr %7, align 8
  %9 = and i64 %8, -8
  %10 = inttoptr i64 %9 to ptr
  %11 = getelementptr inbounds nuw i8, ptr %10, i64 44
  %12 = load i32, ptr %11, align 4, !tbaa !309
  %13 = and i32 %12, 12
  %14 = icmp eq i32 %13, 0
  %15 = and i32 %12, 4
  %16 = icmp ne i32 %15, 0
  %17 = or i1 %14, %16
  br i1 %17, label %18, label %25

18:                                               ; preds = %6
  %19 = getelementptr inbounds nuw i8, ptr %10, i64 16
  %20 = load ptr, ptr %19, align 8, !tbaa !314
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 16
  %22 = load i64, ptr %21, align 8, !tbaa !315
  %23 = and i64 %22, 512
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %27, label %34

25:                                               ; preds = %6
  %26 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %10, i64 noundef 512, i32 noundef 1) #33
  br i1 %26, label %34, label %27

27:                                               ; preds = %18, %25
  %28 = getelementptr inbounds nuw i8, ptr %10, i64 52
  %29 = load i32, ptr %28, align 4, !tbaa !306
  %30 = add i32 %29, -19
  %31 = icmp ult i32 %30, -5
  %32 = icmp eq ptr %3, %10
  %33 = or i1 %31, %32
  br i1 %33, label %37, label %36

34:                                               ; preds = %18, %25
  %35 = icmp eq ptr %3, %10
  br i1 %35, label %37, label %36

36:                                               ; preds = %34, %27
  br label %6, !llvm.loop !319

37:                                               ; preds = %27, %34
  %38 = icmp eq ptr %4, %10
  br i1 %38, label %61, label %39

39:                                               ; preds = %37, %57
  %40 = phi ptr [ %59, %57 ], [ %10, %37 ]
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 44
  %42 = load i32, ptr %41, align 4, !tbaa !309
  %43 = and i32 %42, 12
  %44 = icmp eq i32 %43, 0
  %45 = and i32 %42, 4
  %46 = icmp ne i32 %45, 0
  %47 = or i1 %44, %46
  br i1 %47, label %48, label %55

48:                                               ; preds = %39
  %49 = getelementptr inbounds nuw i8, ptr %40, i64 16
  %50 = load ptr, ptr %49, align 8, !tbaa !314
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 16
  %52 = load i64, ptr %51, align 8, !tbaa !315
  %53 = and i64 %52, 512
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %57, label %61

55:                                               ; preds = %39
  %56 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %40, i64 noundef 512, i32 noundef 1) #33
  br i1 %56, label %61, label %57

57:                                               ; preds = %48, %55
  %58 = getelementptr inbounds nuw i8, ptr %40, i64 8
  %59 = load ptr, ptr %58, align 8, !tbaa !75
  %60 = icmp eq ptr %59, %4
  br i1 %60, label %61, label %39, !llvm.loop !320

61:                                               ; preds = %55, %57, %48, %1, %37
  %62 = phi ptr [ %10, %37 ], [ %4, %1 ], [ %40, %48 ], [ %59, %57 ], [ %40, %55 ]
  ret ptr %62
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock25getFirstTerminatorForwardEv(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %3 = load ptr, ptr %2, align 8, !tbaa !75
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %5 = icmp eq ptr %3, %4
  br i1 %5, label %91, label %6

6:                                                ; preds = %1, %87
  %7 = phi ptr [ %89, %87 ], [ %3, %1 ]
  %8 = getelementptr inbounds nuw i8, ptr %7, i64 44
  %9 = load i32, ptr %8, align 4, !tbaa !309
  %10 = and i32 %9, 12
  %11 = icmp eq i32 %10, 0
  %12 = and i32 %9, 4
  %13 = icmp ne i32 %12, 0
  %14 = or i1 %11, %13
  br i1 %14, label %15, label %22

15:                                               ; preds = %6
  %16 = getelementptr inbounds nuw i8, ptr %7, i64 16
  %17 = load ptr, ptr %16, align 8, !tbaa !314
  %18 = getelementptr inbounds nuw i8, ptr %17, i64 16
  %19 = load i64, ptr %18, align 8, !tbaa !315
  %20 = and i64 %19, 512
  %21 = icmp eq i64 %20, 0
  br i1 %21, label %24, label %91

22:                                               ; preds = %6
  %23 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %7, i64 noundef 512, i32 noundef 1) #33
  br i1 %23, label %91, label %24

24:                                               ; preds = %22, %15
  %25 = getelementptr inbounds nuw i8, ptr %7, i64 8
  %26 = load ptr, ptr %25, align 8, !tbaa !75
  %27 = icmp eq ptr %26, %4
  br i1 %27, label %91, label %28, !llvm.loop !321

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw i8, ptr %26, i64 44
  %30 = load i32, ptr %29, align 4, !tbaa !309
  %31 = and i32 %30, 12
  %32 = icmp eq i32 %31, 0
  %33 = and i32 %30, 4
  %34 = icmp ne i32 %33, 0
  %35 = or i1 %32, %34
  br i1 %35, label %38, label %36

36:                                               ; preds = %28
  %37 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %26, i64 noundef 512, i32 noundef 1) #33
  br i1 %37, label %91, label %45

38:                                               ; preds = %28
  %39 = getelementptr inbounds nuw i8, ptr %26, i64 16
  %40 = load ptr, ptr %39, align 8, !tbaa !314
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 16
  %42 = load i64, ptr %41, align 8, !tbaa !315
  %43 = and i64 %42, 512
  %44 = icmp eq i64 %43, 0
  br i1 %44, label %45, label %91

45:                                               ; preds = %38, %36
  %46 = getelementptr inbounds nuw i8, ptr %26, i64 8
  %47 = load ptr, ptr %46, align 8, !tbaa !75
  %48 = icmp eq ptr %47, %4
  br i1 %48, label %91, label %49, !llvm.loop !321

49:                                               ; preds = %45
  %50 = getelementptr inbounds nuw i8, ptr %47, i64 44
  %51 = load i32, ptr %50, align 4, !tbaa !309
  %52 = and i32 %51, 12
  %53 = icmp eq i32 %52, 0
  %54 = and i32 %51, 4
  %55 = icmp ne i32 %54, 0
  %56 = or i1 %53, %55
  br i1 %56, label %59, label %57

57:                                               ; preds = %49
  %58 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %47, i64 noundef 512, i32 noundef 1) #33
  br i1 %58, label %91, label %66

59:                                               ; preds = %49
  %60 = getelementptr inbounds nuw i8, ptr %47, i64 16
  %61 = load ptr, ptr %60, align 8, !tbaa !314
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 16
  %63 = load i64, ptr %62, align 8, !tbaa !315
  %64 = and i64 %63, 512
  %65 = icmp eq i64 %64, 0
  br i1 %65, label %66, label %91

66:                                               ; preds = %59, %57
  %67 = getelementptr inbounds nuw i8, ptr %47, i64 8
  %68 = load ptr, ptr %67, align 8, !tbaa !75
  %69 = icmp eq ptr %68, %4
  br i1 %69, label %91, label %70, !llvm.loop !321

70:                                               ; preds = %66
  %71 = getelementptr inbounds nuw i8, ptr %68, i64 44
  %72 = load i32, ptr %71, align 4, !tbaa !309
  %73 = and i32 %72, 12
  %74 = icmp eq i32 %73, 0
  %75 = and i32 %72, 4
  %76 = icmp ne i32 %75, 0
  %77 = or i1 %74, %76
  br i1 %77, label %80, label %78

78:                                               ; preds = %70
  %79 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %68, i64 noundef 512, i32 noundef 1) #33
  br i1 %79, label %91, label %87

80:                                               ; preds = %70
  %81 = getelementptr inbounds nuw i8, ptr %68, i64 16
  %82 = load ptr, ptr %81, align 8, !tbaa !314
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 16
  %84 = load i64, ptr %83, align 8, !tbaa !315
  %85 = and i64 %84, 512
  %86 = icmp eq i64 %85, 0
  br i1 %86, label %87, label %91

87:                                               ; preds = %80, %78
  %88 = getelementptr inbounds nuw i8, ptr %68, i64 8
  %89 = load ptr, ptr %88, align 8, !tbaa !75
  %90 = icmp eq ptr %89, %4
  br i1 %90, label %91, label %6, !llvm.loop !323

91:                                               ; preds = %15, %22, %24, %36, %38, %45, %57, %59, %66, %78, %80, %87, %1
  %92 = phi ptr [ %3, %1 ], [ %7, %22 ], [ %26, %24 ], [ %7, %15 ], [ %26, %36 ], [ %26, %38 ], [ %47, %45 ], [ %47, %57 ], [ %47, %59 ], [ %68, %66 ], [ %68, %78 ], [ %68, %80 ], [ %89, %87 ]
  ret ptr %92
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock21getFirstNonDebugInstrEb(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, i1 noundef zeroext %1) local_unnamed_addr #10 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %4 = load ptr, ptr %3, align 8, !tbaa !75
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %6 = icmp eq ptr %4, %5
  br i1 %6, label %38, label %7

7:                                                ; preds = %2, %33
  %8 = phi ptr [ %36, %33 ], [ %4, %2 ]
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 52
  %10 = load i32, ptr %9, align 4, !tbaa !306
  %11 = add i32 %10, -14
  %12 = icmp ult i32 %11, 5
  %13 = icmp eq i32 %10, 25
  %14 = and i1 %1, %13
  %15 = or i1 %12, %14
  br i1 %15, label %16, label %38

16:                                               ; preds = %7
  %17 = load i64, ptr %8, align 8
  %18 = and i64 %17, 4
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %20, label %33

20:                                               ; preds = %16
  %21 = getelementptr inbounds nuw i8, ptr %8, i64 44
  %22 = load i32, ptr %21, align 4, !tbaa !309
  %23 = and i32 %22, 8
  %24 = icmp eq i32 %23, 0
  br i1 %24, label %33, label %25

25:                                               ; preds = %20, %25
  %26 = phi ptr [ %28, %25 ], [ %8, %20 ]
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 8
  %28 = load ptr, ptr %27, align 8, !tbaa !75
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 44
  %30 = load i32, ptr %29, align 4, !tbaa !309
  %31 = and i32 %30, 8
  %32 = icmp eq i32 %31, 0
  br i1 %32, label %33, label %25, !llvm.loop !310

33:                                               ; preds = %25, %20, %16
  %34 = phi ptr [ %8, %16 ], [ %8, %20 ], [ %28, %25 ]
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 8
  %36 = load ptr, ptr %35, align 8, !tbaa !75
  %37 = icmp eq ptr %36, %5
  br i1 %37, label %38, label %7, !llvm.loop !325

38:                                               ; preds = %7, %33, %2
  %39 = phi ptr [ %4, %2 ], [ %36, %33 ], [ %8, %7 ]
  ret ptr %39
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock20getLastNonDebugInstrEb(ptr noundef nonnull readonly align 8 captures(address, ret: address, provenance) dereferenceable(288) %0, i1 noundef zeroext %1) local_unnamed_addr #10 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %4 = load ptr, ptr %3, align 8, !tbaa !75
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %6 = icmp eq ptr %5, %4
  br i1 %6, label %26, label %7

7:                                                ; preds = %2, %24
  %8 = phi ptr [ %11, %24 ], [ %5, %2 ]
  %9 = load i64, ptr %8, align 8
  %10 = and i64 %9, -8
  %11 = inttoptr i64 %10 to ptr
  %12 = getelementptr inbounds nuw i8, ptr %11, i64 52
  %13 = load i32, ptr %12, align 4, !tbaa !306
  %14 = add i32 %13, -14
  %15 = icmp ult i32 %14, 5
  br i1 %15, label %24, label %16

16:                                               ; preds = %7
  %17 = getelementptr inbounds nuw i8, ptr %11, i64 44
  %18 = load i32, ptr %17, align 4, !tbaa !309
  %19 = and i32 %18, 4
  %20 = icmp ne i32 %19, 0
  %21 = icmp eq i32 %13, 25
  %22 = and i1 %1, %21
  %23 = or i1 %20, %22
  br i1 %23, label %24, label %26

24:                                               ; preds = %7, %16
  %25 = icmp eq ptr %4, %11
  br i1 %25, label %26, label %7, !llvm.loop !326

26:                                               ; preds = %16, %24, %2
  %27 = phi ptr [ %5, %2 ], [ %5, %24 ], [ %11, %16 ]
  ret ptr %27
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock17hasEHPadSuccessorEv(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #10 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %3 = load ptr, ptr %2, align 8, !tbaa !19
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %5 = load i32, ptr %4, align 8, !tbaa !76
  %6 = zext i32 %5 to i64
  %7 = shl nuw nsw i64 %6, 3
  %8 = getelementptr inbounds nuw i8, ptr %3, i64 %7
  %9 = icmp eq i32 %5, 0
  br i1 %9, label %19, label %10

10:                                               ; preds = %1, %10
  %11 = phi ptr [ %16, %10 ], [ %3, %1 ]
  %12 = load ptr, ptr %11, align 8, !tbaa !289
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 216
  %14 = load i8, ptr %13, align 8, !tbaa !80, !range !16, !noundef !17
  %15 = trunc nuw i8 %14 to i1
  %16 = getelementptr inbounds nuw i8, ptr %11, i64 8
  %17 = icmp eq ptr %16, %8
  %18 = select i1 %15, i1 true, i1 %17
  br i1 %18, label %19, label %10

19:                                               ; preds = %10, %1
  %20 = phi i1 [ false, %1 ], [ %15, %10 ]
  ret i1 %20
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock12isEntryBlockEv(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0) local_unnamed_addr #10 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %3 = load ptr, ptr %2, align 8, !tbaa !74
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 304
  %5 = load ptr, ptr %4, align 8, !tbaa !327
  %6 = icmp eq ptr %5, %0
  ret i1 %6
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock18mayHaveInlineAsmBrEv(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #10 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %3 = load ptr, ptr %2, align 8, !tbaa !19
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %5 = load i32, ptr %4, align 8, !tbaa !76
  %6 = zext i32 %5 to i64
  %7 = shl nuw nsw i64 %6, 3
  %8 = getelementptr inbounds nuw i8, ptr %3, i64 %7
  %9 = icmp eq i32 %5, 0
  br i1 %9, label %19, label %10

10:                                               ; preds = %1, %10
  %11 = phi ptr [ %16, %10 ], [ %3, %1 ]
  %12 = load ptr, ptr %11, align 8, !tbaa !289
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 262
  %14 = load i8, ptr %13, align 2, !tbaa !328, !range !16, !noundef !17
  %15 = trunc nuw i8 %14 to i1
  %16 = getelementptr inbounds nuw i8, ptr %11, i64 8
  %17 = icmp eq ptr %16, %8
  %18 = select i1 %15, i1 true, i1 %17
  br i1 %18, label %19, label %10

19:                                               ; preds = %10, %1
  %20 = phi i1 [ false, %1 ], [ %15, %10 ]
  ret i1 %20
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock18isLegalToHoistIntoEv(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %3 = load i64, ptr %2, align 8
  %4 = and i64 %3, -8
  %5 = inttoptr i64 %4 to ptr
  %6 = icmp eq ptr %2, %5
  br i1 %6, label %42, label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %5, align 8
  %9 = and i64 %8, 4
  %10 = icmp ne i64 %9, 0
  %11 = getelementptr inbounds nuw i8, ptr %5, i64 44
  %12 = load i32, ptr %11, align 4, !tbaa !309
  %13 = and i32 %12, 4
  %14 = icmp eq i32 %13, 0
  %15 = select i1 %10, i1 true, i1 %14
  br i1 %15, label %25, label %16

16:                                               ; preds = %7, %16
  %17 = phi ptr [ %20, %16 ], [ %5, %7 ]
  %18 = load i64, ptr %17, align 8
  %19 = and i64 %18, -8
  %20 = inttoptr i64 %19 to ptr
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 44
  %22 = load i32, ptr %21, align 4, !tbaa !309
  %23 = and i32 %22, 4
  %24 = icmp eq i32 %23, 0
  br i1 %24, label %25, label %16, !llvm.loop !329

25:                                               ; preds = %16, %7
  %26 = phi i32 [ %12, %7 ], [ %22, %16 ]
  %27 = phi ptr [ %5, %7 ], [ %20, %16 ]
  %28 = and i32 %26, 12
  %29 = icmp eq i32 %28, 0
  %30 = and i32 %26, 4
  %31 = icmp ne i32 %30, 0
  %32 = or i1 %29, %31
  br i1 %32, label %33, label %40

33:                                               ; preds = %25
  %34 = getelementptr inbounds nuw i8, ptr %27, i64 16
  %35 = load ptr, ptr %34, align 8, !tbaa !314
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 16
  %37 = load i64, ptr %36, align 8, !tbaa !315
  %38 = and i64 %37, 32
  %39 = icmp eq i64 %38, 0
  br i1 %39, label %42, label %71

40:                                               ; preds = %25
  %41 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %27, i64 noundef 32, i32 noundef 1) #33
  br i1 %41, label %71, label %42

42:                                               ; preds = %1, %33, %40
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %44 = load ptr, ptr %43, align 8, !tbaa !19
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %46 = load i32, ptr %45, align 8, !tbaa !76
  %47 = zext i32 %46 to i64
  %48 = shl nuw nsw i64 %47, 3
  %49 = getelementptr inbounds nuw i8, ptr %44, i64 %48
  %50 = icmp eq i32 %46, 0
  br i1 %50, label %71, label %54

51:                                               ; preds = %54
  %52 = getelementptr inbounds nuw i8, ptr %55, i64 8
  %53 = icmp eq ptr %52, %49
  br i1 %53, label %60, label %54

54:                                               ; preds = %42, %51
  %55 = phi ptr [ %52, %51 ], [ %44, %42 ]
  %56 = load ptr, ptr %55, align 8, !tbaa !289
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 216
  %58 = load i8, ptr %57, align 8, !tbaa !80, !range !16, !noundef !17
  %59 = trunc nuw i8 %58 to i1
  br i1 %59, label %71, label %51

60:                                               ; preds = %51, %60
  %61 = phi ptr [ %66, %60 ], [ %44, %51 ]
  %62 = load ptr, ptr %61, align 8, !tbaa !289
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 262
  %64 = load i8, ptr %63, align 2, !tbaa !328, !range !16, !noundef !17
  %65 = trunc nuw i8 %64 to i1
  %66 = getelementptr inbounds nuw i8, ptr %61, i64 8
  %67 = icmp eq ptr %66, %49
  %68 = select i1 %65, i1 true, i1 %67
  br i1 %68, label %69, label %60

69:                                               ; preds = %60
  %70 = xor i1 %65, true
  br label %71

71:                                               ; preds = %54, %69, %42, %33, %40
  %72 = phi i1 [ false, %40 ], [ false, %33 ], [ true, %42 ], [ %70, %69 ], [ false, %54 ]
  ret i1 %72
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock7hasNameEv(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #10 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %3 = load ptr, ptr %2, align 8, !tbaa !21
  %4 = icmp eq ptr %3, null
  br i1 %4, label %10, label %5

5:                                                ; preds = %1
  %6 = getelementptr inbounds nuw i8, ptr %3, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = and i32 %7, 536870912
  %9 = icmp ne i32 %8, 0
  br label %10

10:                                               ; preds = %1, %5
  %11 = phi i1 [ %9, %5 ], [ false, %1 ]
  ret i1 %11
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local { ptr, i64 } @_ZNK4llvm17MachineBasicBlock7getNameEv(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %3 = load ptr, ptr %2, align 8, !tbaa !21
  %4 = icmp eq ptr %3, null
  br i1 %4, label %9, label %5

5:                                                ; preds = %1
  %6 = tail call { ptr, i64 } @_ZNK4llvm5Value7getNameEv(ptr noundef nonnull align 8 dereferenceable(24) %3) #33
  %7 = extractvalue { ptr, i64 } %6, 0
  %8 = extractvalue { ptr, i64 } %6, 1
  br label %9

9:                                                ; preds = %1, %5
  %10 = phi i64 [ %8, %5 ], [ 0, %1 ]
  %11 = phi ptr [ %7, %5 ], [ @.str.9, %1 ]
  %12 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %10, 1
  ret { ptr, i64 } %13
}

declare { ptr, i64 } @_ZNK4llvm5Value7getNameEv(ptr noundef nonnull align 8 dereferenceable(24)) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZNK4llvm17MachineBasicBlock11getFullNameB5cxx11Ev(ptr dead_on_unwind noalias writable sret(%"class.std::__cxx11::basic_string") align 8 %0, ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %1) local_unnamed_addr #3 align 2 {
  %3 = alloca %"class.std::__cxx11::basic_string", align 8
  %4 = alloca %"class.llvm::Twine", align 8
  %5 = alloca %"class.std::__cxx11::basic_string", align 8
  %6 = alloca %"class.llvm::Twine", align 8
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store ptr %7, ptr %0, align 8, !tbaa !330
  store i8 0, ptr %7, align 8, !tbaa !212
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store i64 0, ptr %8, align 8, !tbaa !225
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %10 = load ptr, ptr %9, align 8, !tbaa !74
  %11 = icmp eq ptr %10, null
  br i1 %11, label %72, label %12

12:                                               ; preds = %2
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %3) #33
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %4) #33
  %13 = tail call { ptr, i64 } @_ZNK4llvm15MachineFunction7getNameEv(ptr noundef nonnull align 8 dereferenceable(1057) %10) #33
  %14 = extractvalue { ptr, i64 } %13, 0
  %15 = extractvalue { ptr, i64 } %13, 1
  %16 = getelementptr inbounds nuw i8, ptr %4, i64 32
  store i8 5, ptr %16, align 8, !tbaa !213, !alias.scope !331
  %17 = getelementptr inbounds nuw i8, ptr %4, i64 33
  store i8 3, ptr %17, align 1, !tbaa !216, !alias.scope !331
  store ptr %14, ptr %4, align 8, !tbaa !212, !alias.scope !331
  %18 = getelementptr inbounds nuw i8, ptr %4, i64 8
  store i64 %15, ptr %18, align 8, !tbaa !212, !alias.scope !331
  %19 = getelementptr inbounds nuw i8, ptr %4, i64 16
  store ptr @.str.10, ptr %19, align 8, !tbaa !212, !alias.scope !331
  call void @_ZNK4llvm5Twine3strB5cxx11Ev(ptr dead_on_unwind nonnull writable sret(%"class.std::__cxx11::basic_string") align 8 %3, ptr noundef nonnull align 8 dereferenceable(34) %4) #33
  %20 = load ptr, ptr %0, align 8, !tbaa !222
  %21 = icmp eq ptr %20, %7
  br i1 %21, label %22, label %28

22:                                               ; preds = %12
  %23 = load i64, ptr %8, align 8, !tbaa !225
  %24 = icmp ult i64 %23, 16
  call void @llvm.assume(i1 %24)
  %25 = load ptr, ptr %3, align 8, !tbaa !222
  %26 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %27 = icmp eq ptr %25, %26
  br i1 %27, label %32, label %50

28:                                               ; preds = %12
  %29 = load ptr, ptr %3, align 8, !tbaa !222
  %30 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %31 = icmp eq ptr %29, %30
  br i1 %31, label %32, label %48

32:                                               ; preds = %28, %22
  %33 = phi ptr [ %29, %28 ], [ %25, %22 ]
  %34 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %35 = load i64, ptr %34, align 8, !tbaa !225
  %36 = icmp ult i64 %35, 16
  call void @llvm.assume(i1 %36)
  %37 = icmp eq ptr %3, %0
  br i1 %37, label %62, label %38, !prof !334

38:                                               ; preds = %32
  switch i64 %35, label %41 [
    i64 0, label %42
    i64 1, label %39
  ]

39:                                               ; preds = %38
  %40 = load i8, ptr %33, align 1, !tbaa !212
  store i8 %40, ptr %20, align 1, !tbaa !212
  br label %42

41:                                               ; preds = %38
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %20, ptr align 1 %33, i64 %35, i1 false)
  br label %42

42:                                               ; preds = %41, %39, %38
  %43 = load i64, ptr %34, align 8, !tbaa !225
  %44 = icmp ult i64 %43, 9223372036854775807
  call void @llvm.assume(i1 %44)
  %45 = load ptr, ptr %0, align 8, !tbaa !222
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 %43
  store i8 0, ptr %46, align 1, !tbaa !212
  store i64 %43, ptr %8, align 8, !tbaa !225
  %47 = load ptr, ptr %3, align 8, !tbaa !222
  br label %62

48:                                               ; preds = %28
  %49 = load i64, ptr %7, align 8, !tbaa !212
  br label %50

50:                                               ; preds = %48, %22
  %51 = phi ptr [ %30, %48 ], [ %26, %22 ]
  %52 = phi ptr [ %29, %48 ], [ %25, %22 ]
  %53 = phi ptr [ %20, %48 ], [ null, %22 ]
  %54 = phi i64 [ %49, %48 ], [ undef, %22 ]
  store ptr %52, ptr %0, align 8, !tbaa !222
  %55 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %56 = load i64, ptr %55, align 8, !tbaa !225
  %57 = icmp ult i64 %56, 9223372036854775807
  call void @llvm.assume(i1 %57)
  store i64 %56, ptr %8, align 8, !tbaa !225
  %58 = load i64, ptr %51, align 8, !tbaa !212
  store i64 %58, ptr %7, align 8, !tbaa !212
  %59 = icmp eq ptr %53, null
  br i1 %59, label %61, label %60

60:                                               ; preds = %50
  store ptr %53, ptr %3, align 8, !tbaa !222
  store i64 %54, ptr %51, align 8, !tbaa !212
  br label %62

61:                                               ; preds = %50
  store ptr %51, ptr %3, align 8, !tbaa !222
  br label %62

62:                                               ; preds = %32, %42, %60, %61
  %63 = phi ptr [ %53, %60 ], [ %51, %61 ], [ %33, %32 ], [ %47, %42 ]
  store i8 0, ptr %63, align 1, !tbaa !212
  %64 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store i64 0, ptr %64, align 8, !tbaa !225
  %65 = load ptr, ptr %3, align 8, !tbaa !222
  %66 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %67 = icmp eq ptr %65, %66
  br i1 %67, label %71, label %68

68:                                               ; preds = %62
  %69 = load i64, ptr %66, align 8, !tbaa !212
  %70 = add i64 %69, 1
  call void @_ZdlPvm(ptr noundef %65, i64 noundef %70) #34
  br label %71

71:                                               ; preds = %62, %68
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %4) #33
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %3) #33
  br label %72

72:                                               ; preds = %71, %2
  %73 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %74 = load ptr, ptr %73, align 8, !tbaa !21
  %75 = icmp eq ptr %74, null
  br i1 %75, label %87, label %76

76:                                               ; preds = %72
  %77 = call { ptr, i64 } @_ZNK4llvm5Value7getNameEv(ptr noundef nonnull align 8 dereferenceable(24) %74) #33
  %78 = extractvalue { ptr, i64 } %77, 1
  %79 = load i64, ptr %8, align 8, !tbaa !225
  %80 = icmp ult i64 %79, 9223372036854775807
  call void @llvm.assume(i1 %80)
  %81 = sub nuw nsw i64 9223372036854775806, %79
  %82 = icmp ult i64 %81, %78
  br i1 %82, label %83, label %84

83:                                               ; preds = %76
  call void @_ZSt20__throw_length_errorPKc(ptr noundef nonnull @.str.43) #35
  unreachable

84:                                               ; preds = %76
  %85 = extractvalue { ptr, i64 } %77, 0
  %86 = call noundef nonnull align 8 dereferenceable(32) ptr @_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm(ptr noundef nonnull align 8 dereferenceable(32) %0, ptr noundef %85, i64 noundef %78) #33
  br label %116

87:                                               ; preds = %72
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %5) #33
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %6) #33
  %88 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %89 = load i32, ptr %88, align 8, !tbaa !72
  %90 = zext i32 %89 to i64
  %91 = inttoptr i64 %90 to ptr
  store ptr @.str.5, ptr %6, align 8, !alias.scope !335
  %92 = getelementptr inbounds nuw i8, ptr %6, i64 16
  store ptr %91, ptr %92, align 8, !alias.scope !335
  %93 = getelementptr inbounds nuw i8, ptr %6, i64 32
  store i8 3, ptr %93, align 8, !tbaa !213, !alias.scope !335
  %94 = getelementptr inbounds nuw i8, ptr %6, i64 33
  store i8 10, ptr %94, align 1, !tbaa !216, !alias.scope !335
  call void @_ZNK4llvm5Twine3strB5cxx11Ev(ptr dead_on_unwind nonnull writable sret(%"class.std::__cxx11::basic_string") align 8 %5, ptr noundef nonnull align 8 dereferenceable(34) %6) #33
  %95 = load ptr, ptr %5, align 8, !tbaa !222
  %96 = getelementptr inbounds nuw i8, ptr %5, i64 8
  %97 = load i64, ptr %96, align 8, !tbaa !225
  %98 = icmp ult i64 %97, 9223372036854775807
  call void @llvm.assume(i1 %98)
  %99 = load i64, ptr %8, align 8, !tbaa !225
  %100 = icmp ult i64 %99, 9223372036854775807
  call void @llvm.assume(i1 %100)
  %101 = sub nuw nsw i64 9223372036854775806, %99
  %102 = icmp samesign ult i64 %101, %97
  br i1 %102, label %103, label %104

103:                                              ; preds = %87
  call void @_ZSt20__throw_length_errorPKc(ptr noundef nonnull @.str.43) #35
  unreachable

104:                                              ; preds = %87
  %105 = call noundef nonnull align 8 dereferenceable(32) ptr @_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm(ptr noundef nonnull align 8 dereferenceable(32) %0, ptr noundef %95, i64 noundef %97) #33
  %106 = load ptr, ptr %5, align 8, !tbaa !222
  %107 = getelementptr inbounds nuw i8, ptr %5, i64 16
  %108 = icmp eq ptr %106, %107
  br i1 %108, label %109, label %112

109:                                              ; preds = %104
  %110 = load i64, ptr %96, align 8, !tbaa !225
  %111 = icmp ult i64 %110, 16
  call void @llvm.assume(i1 %111)
  br label %115

112:                                              ; preds = %104
  %113 = load i64, ptr %107, align 8, !tbaa !212
  %114 = add i64 %113, 1
  call void @_ZdlPvm(ptr noundef %106, i64 noundef %114) #34
  br label %115

115:                                              ; preds = %109, %112
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %6) #33
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %5) #33
  br label %116

116:                                              ; preds = %84, %115
  ret void
}

declare void @_ZN4llvm17ModuleSlotTrackerC1EPKNS_6ModuleE(ptr noundef nonnull align 8 dereferenceable(112), ptr noundef) unnamed_addr #4

declare void @_ZN4llvm17ModuleSlotTracker19incorporateFunctionERKNS_8FunctionE(ptr noundef nonnull align 8 dereferenceable(112), ptr noundef nonnull align 8 dereferenceable(140)) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZNK4llvm17MachineBasicBlock5printERNS_11raw_ostreamERNS_17ModuleSlotTrackerEPKNS_11SlotIndexesEb(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull align 8 dereferenceable(112) %2, ptr noundef %3, i1 noundef zeroext %4) local_unnamed_addr #3 align 2 {
  %6 = alloca %class.anon.788, align 8
  %7 = alloca %"class.llvm::format_object.784", align 8
  %8 = alloca %"class.llvm::SlotIndex", align 8
  %9 = alloca %class.anon.865, align 8
  %10 = alloca %class.anon.864, align 8
  %11 = alloca %"class.llvm::SlotIndex", align 8
  %12 = alloca %"class.llvm::Printable", align 8
  %13 = alloca %"class.llvm::Printable", align 8
  %14 = alloca %"class.llvm::format_object", align 8
  %15 = alloca %"class.llvm::Printable", align 8
  %16 = alloca %"class.llvm::format_object.391", align 8
  %17 = alloca %"class.llvm::Printable", align 8
  %18 = alloca %"class.llvm::Printable", align 8
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %20 = load ptr, ptr %19, align 8, !tbaa !74
  %21 = icmp eq ptr %20, null
  br i1 %21, label %22, label %53

22:                                               ; preds = %5
  %23 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !257
  %25 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %26 = load ptr, ptr %25, align 8, !tbaa !258
  %27 = ptrtoint ptr %24 to i64
  %28 = ptrtoint ptr %26 to i64
  %29 = sub i64 %27, %28
  %30 = icmp ult i64 %29, 64
  br i1 %30, label %31, label %35

31:                                               ; preds = %22
  %32 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.11, i64 noundef 64) #33
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 32
  %34 = load ptr, ptr %33, align 8, !tbaa !258
  br label %38

35:                                               ; preds = %22
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(64) %26, ptr noundef nonnull align 1 dereferenceable(64) @.str.11, i64 64, i1 false)
  %36 = load ptr, ptr %25, align 8, !tbaa !258
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 64
  store ptr %37, ptr %25, align 8, !tbaa !258
  br label %38

38:                                               ; preds = %31, %35
  %39 = phi ptr [ %34, %31 ], [ %37, %35 ]
  %40 = phi ptr [ %32, %31 ], [ %1, %35 ]
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 24
  %42 = load ptr, ptr %41, align 8, !tbaa !257
  %43 = ptrtoint ptr %42 to i64
  %44 = ptrtoint ptr %39 to i64
  %45 = sub i64 %43, %44
  %46 = icmp ult i64 %45, 9
  br i1 %46, label %47, label %49

47:                                               ; preds = %38
  %48 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %40, ptr noundef nonnull @.str.12, i64 noundef 9) #33
  br label %884

49:                                               ; preds = %38
  %50 = getelementptr inbounds nuw i8, ptr %40, i64 32
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %39, ptr noundef nonnull align 1 dereferenceable(9) @.str.12, i64 9, i1 false)
  %51 = load ptr, ptr %50, align 8, !tbaa !258
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 9
  store ptr %52, ptr %50, align 8, !tbaa !258
  br label %884

53:                                               ; preds = %5
  %54 = icmp ne ptr %3, null
  %55 = load i8, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 120), align 8, !range !16
  %56 = trunc nuw i8 %55 to i1
  %57 = select i1 %54, i1 %56, i1 false
  br i1 %57, label %58, label %75

58:                                               ; preds = %53
  %59 = getelementptr inbounds nuw i8, ptr %3, i64 128
  %60 = getelementptr inbounds nuw i8, ptr %0, i64 220
  %61 = load i32, ptr %60, align 4, !tbaa !292
  %62 = sext i32 %61 to i64
  %63 = load ptr, ptr %59, align 8, !tbaa !19
  %64 = getelementptr inbounds nuw %"struct.std::pair.781", ptr %63, i64 %62
  %65 = load i64, ptr %64, align 8, !tbaa !212
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %11)
  store i64 %65, ptr %11, align 8
  call void @_ZNK4llvm9SlotIndex5printERNS_11raw_ostreamE(ptr noundef nonnull align 8 dereferenceable(8) %11, ptr noundef nonnull align 8 dereferenceable(48) %1) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %11)
  %66 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %67 = load ptr, ptr %66, align 8, !tbaa !258
  %68 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %69 = load ptr, ptr %68, align 8, !tbaa !257
  %70 = icmp ult ptr %67, %69
  br i1 %70, label %73, label %71

71:                                               ; preds = %58
  %72 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 9) #33
  br label %75

73:                                               ; preds = %58
  %74 = getelementptr inbounds nuw i8, ptr %67, i64 1
  store ptr %74, ptr %66, align 8, !tbaa !258
  store i8 9, ptr %67, align 1, !tbaa !212
  br label %75

75:                                               ; preds = %73, %71, %53
  call void @_ZNK4llvm17MachineBasicBlock9printNameERNS_11raw_ostreamEjPNS_17ModuleSlotTrackerE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(48) %1, i32 noundef 3, ptr noundef nonnull %2)
  %76 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %77 = load ptr, ptr %76, align 8, !tbaa !257
  %78 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %79 = load ptr, ptr %78, align 8, !tbaa !258
  %80 = ptrtoint ptr %77 to i64
  %81 = ptrtoint ptr %79 to i64
  %82 = sub i64 %80, %81
  %83 = icmp ult i64 %82, 2
  br i1 %83, label %84, label %86

84:                                               ; preds = %75
  %85 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.13, i64 noundef 2) #33
  br label %89

86:                                               ; preds = %75
  store i16 2618, ptr %79, align 1
  %87 = load ptr, ptr %78, align 8, !tbaa !258
  %88 = getelementptr inbounds nuw i8, ptr %87, i64 2
  store ptr %88, ptr %78, align 8, !tbaa !258
  br label %89

89:                                               ; preds = %84, %86
  %90 = getelementptr inbounds nuw i8, ptr %20, i64 16
  %91 = load ptr, ptr %90, align 8, !tbaa !308, !nonnull !17, !align !200
  %92 = load ptr, ptr %91, align 8, !tbaa !4
  %93 = getelementptr inbounds nuw i8, ptr %92, i64 192
  %94 = load ptr, ptr %93, align 8
  %95 = call noundef ptr %94(ptr noundef nonnull align 8 dereferenceable(368) %91) #33
  %96 = getelementptr inbounds nuw i8, ptr %20, i64 32
  %97 = load ptr, ptr %96, align 8, !tbaa !293
  %98 = load ptr, ptr %19, align 8, !tbaa !74
  %99 = getelementptr inbounds nuw i8, ptr %98, i64 16
  %100 = load ptr, ptr %99, align 8, !tbaa !308, !nonnull !17, !align !200
  %101 = load ptr, ptr %100, align 8, !tbaa !4
  %102 = getelementptr inbounds nuw i8, ptr %101, i64 120
  %103 = load ptr, ptr %102, align 8
  %104 = call noundef ptr %103(ptr noundef nonnull align 8 dereferenceable(368) %100) #33
  %105 = getelementptr inbounds nuw i8, ptr %0, i64 72
  %106 = load i32, ptr %105, align 8, !tbaa !76
  %107 = icmp ne i32 %106, 0
  %108 = and i1 %4, %107
  br i1 %108, label %109, label %241

109:                                              ; preds = %89
  br i1 %54, label %110, label %118

110:                                              ; preds = %109
  %111 = load ptr, ptr %78, align 8, !tbaa !258
  %112 = load ptr, ptr %76, align 8, !tbaa !257
  %113 = icmp ult ptr %111, %112
  br i1 %113, label %116, label %114

114:                                              ; preds = %110
  %115 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 9) #33
  br label %118

116:                                              ; preds = %110
  %117 = getelementptr inbounds nuw i8, ptr %111, i64 1
  store ptr %117, ptr %78, align 8, !tbaa !258
  store i8 9, ptr %111, align 1, !tbaa !212
  br label %118

118:                                              ; preds = %116, %114, %109
  %119 = load ptr, ptr %76, align 8, !tbaa !257
  %120 = load ptr, ptr %78, align 8, !tbaa !258
  %121 = ptrtoint ptr %119 to i64
  %122 = ptrtoint ptr %120 to i64
  %123 = sub i64 %121, %122
  %124 = icmp ult i64 %123, 16
  br i1 %124, label %125, label %128

125:                                              ; preds = %118
  %126 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.14, i64 noundef 16) #33
  %127 = load ptr, ptr %78, align 8, !tbaa !258
  br label %131

128:                                              ; preds = %118
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(16) %120, ptr noundef nonnull align 1 dereferenceable(16) @.str.14, i64 16, i1 false)
  %129 = load ptr, ptr %78, align 8, !tbaa !258
  %130 = getelementptr inbounds nuw i8, ptr %129, i64 16
  store ptr %130, ptr %78, align 8, !tbaa !258
  br label %131

131:                                              ; preds = %125, %128
  %132 = phi ptr [ %127, %125 ], [ %130, %128 ]
  %133 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %134 = load ptr, ptr %133, align 8, !tbaa !19
  %135 = load i32, ptr %105, align 8, !tbaa !76
  %136 = zext i32 %135 to i64
  %137 = shl nuw nsw i64 %136, 3
  %138 = getelementptr inbounds nuw i8, ptr %134, i64 %137
  %139 = icmp eq i32 %135, 0
  br i1 %139, label %180, label %140

140:                                              ; preds = %131
  %141 = getelementptr inbounds nuw i8, ptr %12, i64 24
  %142 = getelementptr inbounds nuw i8, ptr %12, i64 16
  %143 = getelementptr inbounds nuw i8, ptr %12, i64 8
  %144 = load ptr, ptr %134, align 8, !tbaa !289
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %12) #33
  %145 = ptrtoint ptr %144 to i64
  store ptr @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E9_M_invokeERKSt9_Any_dataS2_", ptr %141, align 8, !tbaa !285, !alias.scope !340
  store i64 %145, ptr %12, align 8, !alias.scope !340
  store i64 0, ptr %143, align 8, !tbaa !212, !alias.scope !340
  store ptr @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation", ptr %142, align 8, !tbaa !7, !alias.scope !340
  %146 = load ptr, ptr %76, align 8, !tbaa !257
  %147 = icmp ult ptr %132, %146
  br i1 %147, label %150, label %148

148:                                              ; preds = %140
  %149 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 37) #33
  br label %152

150:                                              ; preds = %140
  %151 = getelementptr inbounds nuw i8, ptr %132, i64 1
  store ptr %151, ptr %78, align 8, !tbaa !258
  store i8 37, ptr %132, align 1, !tbaa !212
  br label %152

152:                                              ; preds = %150, %148
  %153 = load ptr, ptr %76, align 8, !tbaa !257
  %154 = load ptr, ptr %78, align 8, !tbaa !258
  %155 = ptrtoint ptr %153 to i64
  %156 = ptrtoint ptr %154 to i64
  %157 = sub i64 %155, %156
  %158 = icmp ult i64 %157, 3
  br i1 %158, label %159, label %161

159:                                              ; preds = %152
  %160 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.25, i64 noundef 3) #33
  br label %164

161:                                              ; preds = %152
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %154, ptr noundef nonnull align 1 dereferenceable(3) @.str.25, i64 3, i1 false)
  %162 = load ptr, ptr %78, align 8, !tbaa !258
  %163 = getelementptr inbounds nuw i8, ptr %162, i64 3
  store ptr %163, ptr %78, align 8, !tbaa !258
  br label %164

164:                                              ; preds = %159, %161
  %165 = phi ptr [ %160, %159 ], [ %1, %161 ]
  %166 = getelementptr inbounds nuw i8, ptr %144, i64 24
  %167 = load i32, ptr %166, align 8, !tbaa !72
  %168 = sext i32 %167 to i64
  %169 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEl(ptr noundef nonnull align 8 dereferenceable(48) %165, i64 noundef %168) #33
  %170 = load ptr, ptr %142, align 8, !tbaa !7
  %171 = icmp eq ptr %170, null
  br i1 %171, label %174, label %172

172:                                              ; preds = %164
  %173 = call noundef zeroext i1 %170(ptr noundef nonnull align 8 dereferenceable(32) %12, ptr noundef nonnull align 8 dereferenceable(32) %12, i32 noundef 3) #33
  br label %174

174:                                              ; preds = %172, %164
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %12) #33
  %175 = icmp eq i32 %135, 1
  br i1 %175, label %178, label %176

176:                                              ; preds = %174
  %177 = getelementptr inbounds nuw i8, ptr %134, i64 8
  br label %188

178:                                              ; preds = %238, %174
  %179 = load ptr, ptr %78, align 8, !tbaa !258
  br label %180

180:                                              ; preds = %178, %131
  %181 = phi ptr [ %179, %178 ], [ %132, %131 ]
  %182 = load ptr, ptr %76, align 8, !tbaa !257
  %183 = icmp ult ptr %181, %182
  br i1 %183, label %186, label %184

184:                                              ; preds = %180
  %185 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 10) #33
  br label %241

186:                                              ; preds = %180
  %187 = getelementptr inbounds nuw i8, ptr %181, i64 1
  store ptr %187, ptr %78, align 8, !tbaa !258
  store i8 10, ptr %181, align 1, !tbaa !212
  br label %241

188:                                              ; preds = %176, %238
  %189 = phi ptr [ %177, %176 ], [ %239, %238 ]
  %190 = load ptr, ptr %189, align 8, !tbaa !289
  %191 = load ptr, ptr %76, align 8, !tbaa !257
  %192 = load ptr, ptr %78, align 8, !tbaa !258
  %193 = ptrtoint ptr %191 to i64
  %194 = ptrtoint ptr %192 to i64
  %195 = sub i64 %193, %194
  %196 = icmp ult i64 %195, 2
  br i1 %196, label %197, label %201

197:                                              ; preds = %188
  %198 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.15, i64 noundef 2) #33
  %199 = getelementptr inbounds nuw i8, ptr %198, i64 32
  %200 = load ptr, ptr %199, align 8, !tbaa !258
  br label %204

201:                                              ; preds = %188
  store i16 8236, ptr %192, align 1
  %202 = load ptr, ptr %78, align 8, !tbaa !258
  %203 = getelementptr inbounds nuw i8, ptr %202, i64 2
  store ptr %203, ptr %78, align 8, !tbaa !258
  br label %204

204:                                              ; preds = %201, %197
  %205 = phi ptr [ %200, %197 ], [ %203, %201 ]
  %206 = phi ptr [ %198, %197 ], [ %1, %201 ]
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %12) #33
  %207 = ptrtoint ptr %190 to i64
  store ptr @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E9_M_invokeERKSt9_Any_dataS2_", ptr %141, align 8, !tbaa !285, !alias.scope !340
  store i64 %207, ptr %12, align 8, !alias.scope !340
  store i64 0, ptr %143, align 8, !tbaa !212, !alias.scope !340
  store ptr @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation", ptr %142, align 8, !tbaa !7, !alias.scope !340
  %208 = getelementptr inbounds nuw i8, ptr %206, i64 32
  %209 = getelementptr inbounds nuw i8, ptr %206, i64 24
  %210 = load ptr, ptr %209, align 8, !tbaa !257
  %211 = icmp ult ptr %205, %210
  br i1 %211, label %214, label %212

212:                                              ; preds = %204
  %213 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %206, i8 noundef zeroext 37) #33
  br label %216

214:                                              ; preds = %204
  %215 = getelementptr inbounds nuw i8, ptr %205, i64 1
  store ptr %215, ptr %208, align 8, !tbaa !258
  store i8 37, ptr %205, align 1, !tbaa !212
  br label %216

216:                                              ; preds = %214, %212
  %217 = load ptr, ptr %209, align 8, !tbaa !257
  %218 = load ptr, ptr %208, align 8, !tbaa !258
  %219 = ptrtoint ptr %217 to i64
  %220 = ptrtoint ptr %218 to i64
  %221 = sub i64 %219, %220
  %222 = icmp ult i64 %221, 3
  br i1 %222, label %223, label %225

223:                                              ; preds = %216
  %224 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %206, ptr noundef nonnull @.str.25, i64 noundef 3) #33
  br label %228

225:                                              ; preds = %216
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %218, ptr noundef nonnull align 1 dereferenceable(3) @.str.25, i64 3, i1 false)
  %226 = load ptr, ptr %208, align 8, !tbaa !258
  %227 = getelementptr inbounds nuw i8, ptr %226, i64 3
  store ptr %227, ptr %208, align 8, !tbaa !258
  br label %228

228:                                              ; preds = %223, %225
  %229 = phi ptr [ %224, %223 ], [ %206, %225 ]
  %230 = getelementptr inbounds nuw i8, ptr %190, i64 24
  %231 = load i32, ptr %230, align 8, !tbaa !72
  %232 = sext i32 %231 to i64
  %233 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEl(ptr noundef nonnull align 8 dereferenceable(48) %229, i64 noundef %232) #33
  %234 = load ptr, ptr %142, align 8, !tbaa !7
  %235 = icmp eq ptr %234, null
  br i1 %235, label %238, label %236

236:                                              ; preds = %228
  %237 = call noundef zeroext i1 %234(ptr noundef nonnull align 8 dereferenceable(32) %12, ptr noundef nonnull align 8 dereferenceable(32) %12, i32 noundef 3) #33
  br label %238

238:                                              ; preds = %228, %236
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %12) #33
  %239 = getelementptr inbounds nuw i8, ptr %189, i64 8
  %240 = icmp eq ptr %239, %138
  br i1 %240, label %178, label %188, !llvm.loop !343

241:                                              ; preds = %186, %184, %89
  %242 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %243 = load i32, ptr %242, align 8, !tbaa !76
  %244 = icmp eq i32 %243, 0
  br i1 %244, label %589, label %245

245:                                              ; preds = %241
  br i1 %54, label %246, label %254

246:                                              ; preds = %245
  %247 = load ptr, ptr %78, align 8, !tbaa !258
  %248 = load ptr, ptr %76, align 8, !tbaa !257
  %249 = icmp ult ptr %247, %248
  br i1 %249, label %252, label %250

250:                                              ; preds = %246
  %251 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 9) #33
  br label %254

252:                                              ; preds = %246
  %253 = getelementptr inbounds nuw i8, ptr %247, i64 1
  store ptr %253, ptr %78, align 8, !tbaa !258
  store i8 9, ptr %247, align 1, !tbaa !212
  br label %254

254:                                              ; preds = %252, %250, %245
  %255 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream6indentEj(ptr noundef nonnull align 8 dereferenceable(48) %1, i32 noundef 2) #33
  %256 = getelementptr inbounds nuw i8, ptr %255, i64 24
  %257 = load ptr, ptr %256, align 8, !tbaa !257
  %258 = getelementptr inbounds nuw i8, ptr %255, i64 32
  %259 = load ptr, ptr %258, align 8, !tbaa !258
  %260 = ptrtoint ptr %257 to i64
  %261 = ptrtoint ptr %259 to i64
  %262 = sub i64 %260, %261
  %263 = icmp ult i64 %262, 12
  br i1 %263, label %264, label %266

264:                                              ; preds = %254
  %265 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %255, ptr noundef nonnull @.str.16, i64 noundef 12) #33
  br label %269

266:                                              ; preds = %254
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(12) %259, ptr noundef nonnull align 1 dereferenceable(12) @.str.16, i64 12, i1 false)
  %267 = load ptr, ptr %258, align 8, !tbaa !258
  %268 = getelementptr inbounds nuw i8, ptr %267, i64 12
  store ptr %268, ptr %258, align 8, !tbaa !258
  br label %269

269:                                              ; preds = %264, %266
  %270 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %271 = load ptr, ptr %270, align 8, !tbaa !19
  %272 = load i32, ptr %242, align 8, !tbaa !76
  %273 = zext i32 %272 to i64
  %274 = shl nuw nsw i64 %273, 3
  %275 = getelementptr inbounds nuw i8, ptr %271, i64 %274
  %276 = icmp eq i32 %272, 0
  br i1 %276, label %285, label %277

277:                                              ; preds = %269
  %278 = getelementptr inbounds nuw i8, ptr %13, i64 24
  %279 = getelementptr inbounds nuw i8, ptr %13, i64 16
  %280 = getelementptr inbounds nuw i8, ptr %13, i64 8
  %281 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %282 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %283 = getelementptr inbounds nuw i8, ptr %14, i64 8
  %284 = ptrtoint ptr %10 to i64
  br label %292

285:                                              ; preds = %420, %269
  %286 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %287 = load ptr, ptr %286, align 8, !tbaa !345
  %288 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %289 = load ptr, ptr %288, align 8, !tbaa !345
  %290 = icmp ne ptr %287, %289
  %291 = and i1 %4, %290
  br i1 %291, label %423, label %581

292:                                              ; preds = %277, %420
  %293 = phi ptr [ %271, %277 ], [ %421, %420 ]
  %294 = phi i1 [ true, %277 ], [ false, %420 ]
  %295 = select i1 %294, i64 0, i64 2
  %296 = load ptr, ptr %76, align 8, !tbaa !257
  %297 = load ptr, ptr %78, align 8, !tbaa !258
  %298 = ptrtoint ptr %296 to i64
  %299 = ptrtoint ptr %297 to i64
  %300 = sub i64 %298, %299
  %301 = icmp ugt i64 %295, %300
  br i1 %301, label %302, label %307

302:                                              ; preds = %292
  %303 = select i1 %294, ptr @.str.9, ptr @.str.15
  %304 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %303, i64 noundef %295) #33
  %305 = getelementptr inbounds nuw i8, ptr %304, i64 32
  %306 = load ptr, ptr %305, align 8, !tbaa !258
  br label %311

307:                                              ; preds = %292
  br i1 %294, label %311, label %308

308:                                              ; preds = %307
  store i16 8236, ptr %297, align 1
  %309 = load ptr, ptr %78, align 8, !tbaa !258
  %310 = getelementptr inbounds nuw i8, ptr %309, i64 2
  store ptr %310, ptr %78, align 8, !tbaa !258
  br label %311

311:                                              ; preds = %308, %307, %302
  %312 = phi ptr [ %306, %302 ], [ %310, %308 ], [ %297, %307 ]
  %313 = phi ptr [ %304, %302 ], [ %1, %308 ], [ %1, %307 ]
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %13) #33
  %314 = load ptr, ptr %293, align 8, !tbaa !289
  %315 = ptrtoint ptr %314 to i64
  store ptr @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E9_M_invokeERKSt9_Any_dataS2_", ptr %278, align 8, !tbaa !285, !alias.scope !346
  store i64 %315, ptr %13, align 8, !alias.scope !346
  store i64 0, ptr %280, align 8, !tbaa !212, !alias.scope !346
  store ptr @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation", ptr %279, align 8, !tbaa !7, !alias.scope !346
  %316 = getelementptr inbounds nuw i8, ptr %313, i64 32
  %317 = getelementptr inbounds nuw i8, ptr %313, i64 24
  %318 = load ptr, ptr %317, align 8, !tbaa !257
  %319 = icmp ult ptr %312, %318
  br i1 %319, label %322, label %320

320:                                              ; preds = %311
  %321 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %313, i8 noundef zeroext 37) #33
  br label %324

322:                                              ; preds = %311
  %323 = getelementptr inbounds nuw i8, ptr %312, i64 1
  store ptr %323, ptr %316, align 8, !tbaa !258
  store i8 37, ptr %312, align 1, !tbaa !212
  br label %324

324:                                              ; preds = %322, %320
  %325 = load ptr, ptr %317, align 8, !tbaa !257
  %326 = load ptr, ptr %316, align 8, !tbaa !258
  %327 = ptrtoint ptr %325 to i64
  %328 = ptrtoint ptr %326 to i64
  %329 = sub i64 %327, %328
  %330 = icmp ult i64 %329, 3
  br i1 %330, label %331, label %333

331:                                              ; preds = %324
  %332 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %313, ptr noundef nonnull @.str.25, i64 noundef 3) #33
  br label %336

333:                                              ; preds = %324
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %326, ptr noundef nonnull align 1 dereferenceable(3) @.str.25, i64 3, i1 false)
  %334 = load ptr, ptr %316, align 8, !tbaa !258
  %335 = getelementptr inbounds nuw i8, ptr %334, i64 3
  store ptr %335, ptr %316, align 8, !tbaa !258
  br label %336

336:                                              ; preds = %331, %333
  %337 = phi ptr [ %332, %331 ], [ %313, %333 ]
  %338 = getelementptr inbounds nuw i8, ptr %314, i64 24
  %339 = load i32, ptr %338, align 8, !tbaa !72
  %340 = sext i32 %339 to i64
  %341 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEl(ptr noundef nonnull align 8 dereferenceable(48) %337, i64 noundef %340) #33
  %342 = load ptr, ptr %279, align 8, !tbaa !7
  %343 = icmp eq ptr %342, null
  br i1 %343, label %346, label %344

344:                                              ; preds = %336
  %345 = call noundef zeroext i1 %342(ptr noundef nonnull align 8 dereferenceable(32) %13, ptr noundef nonnull align 8 dereferenceable(32) %13, i32 noundef 3) #33
  br label %346

346:                                              ; preds = %336, %344
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %13) #33
  %347 = load ptr, ptr %281, align 8, !tbaa !345
  %348 = load ptr, ptr %282, align 8, !tbaa !345
  %349 = icmp eq ptr %347, %348
  br i1 %349, label %420, label %350

350:                                              ; preds = %346
  %351 = load ptr, ptr %78, align 8, !tbaa !258
  %352 = load ptr, ptr %76, align 8, !tbaa !257
  %353 = icmp ult ptr %351, %352
  br i1 %353, label %356, label %354

354:                                              ; preds = %350
  %355 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 40) #33
  br label %358

356:                                              ; preds = %350
  %357 = getelementptr inbounds nuw i8, ptr %351, i64 1
  store ptr %357, ptr %78, align 8, !tbaa !258
  store i8 40, ptr %351, align 1, !tbaa !212
  br label %358

358:                                              ; preds = %354, %356
  %359 = phi ptr [ %355, %354 ], [ %1, %356 ]
  %360 = load ptr, ptr %281, align 8, !tbaa !345
  %361 = load ptr, ptr %282, align 8, !tbaa !345
  %362 = icmp eq ptr %360, %361
  br i1 %362, label %363, label %370

363:                                              ; preds = %358
  %364 = load i32, ptr %242, align 8, !tbaa !76
  %365 = icmp eq i32 %364, -2147483648
  br i1 %365, label %408, label %366

366:                                              ; preds = %363
  %367 = lshr i32 %364, 1
  %368 = or disjoint i32 %367, -2147483648
  %369 = udiv i32 %368, %364
  br label %408

370:                                              ; preds = %358
  %371 = load ptr, ptr %270, align 8, !tbaa !19
  %372 = ptrtoint ptr %293 to i64
  %373 = ptrtoint ptr %371 to i64
  %374 = sub i64 %372, %373
  %375 = ashr exact i64 %374, 1
  %376 = getelementptr inbounds i8, ptr %360, i64 %375
  %377 = load i32, ptr %376, align 4, !tbaa !349
  %378 = icmp eq i32 %377, -1
  br i1 %378, label %389, label %408

379:                                              ; preds = %403
  %380 = sub i32 -2147483648, %404
  %381 = ptrtoint ptr %361 to i64
  %382 = ptrtoint ptr %360 to i64
  %383 = sub i64 %381, %382
  %384 = ashr exact i64 %383, 2
  %385 = icmp sgt i64 %384, -1
  call void @llvm.assume(i1 %385)
  %386 = trunc i64 %384 to i32
  %387 = sub i32 %386, %405
  %388 = udiv i32 %380, %387
  br label %408

389:                                              ; preds = %370, %403
  %390 = phi i32 [ %405, %403 ], [ 0, %370 ]
  %391 = phi i32 [ %404, %403 ], [ 0, %370 ]
  %392 = phi ptr [ %406, %403 ], [ %360, %370 ]
  %393 = load i32, ptr %392, align 4, !tbaa !349
  %394 = icmp eq i32 %393, -1
  br i1 %394, label %403, label %395

395:                                              ; preds = %389
  %396 = zext i32 %391 to i64
  %397 = zext i32 %393 to i64
  %398 = add nuw nsw i64 %397, %396
  %399 = icmp samesign ugt i64 %398, 2147483648
  %400 = add i32 %393, %391
  %401 = select i1 %399, i32 -2147483648, i32 %400
  %402 = add i32 %390, 1
  br label %403

403:                                              ; preds = %395, %389
  %404 = phi i32 [ %391, %389 ], [ %401, %395 ]
  %405 = phi i32 [ %390, %389 ], [ %402, %395 ]
  %406 = getelementptr inbounds nuw i8, ptr %392, i64 4
  %407 = icmp eq ptr %406, %361
  br i1 %407, label %379, label %389

408:                                              ; preds = %363, %366, %370, %379
  %409 = phi i32 [ %388, %379 ], [ %369, %366 ], [ 1, %363 ], [ %377, %370 ]
  store ptr @.str.17, ptr %14, align 8, !tbaa !351, !alias.scope !356
  store i32 %409, ptr %283, align 8, !tbaa !359, !alias.scope !356
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %10) #33
  store ptr %14, ptr %10, align 8, !tbaa !360
  %410 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsENS_12function_refIFiPcmEEE(ptr noundef nonnull align 8 dereferenceable(48) %359, ptr nonnull @_ZN4llvm12function_refIFiPcmEE11callback_fnIZNS_lsIJjEEERNS_11raw_ostreamES7_NS_13format_objectIJDpT_EEEEUlS1_mE_EEilS1_m, i64 %284) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %10) #33
  %411 = getelementptr inbounds nuw i8, ptr %359, i64 32
  %412 = load ptr, ptr %411, align 8, !tbaa !258
  %413 = getelementptr inbounds nuw i8, ptr %359, i64 24
  %414 = load ptr, ptr %413, align 8, !tbaa !257
  %415 = icmp ult ptr %412, %414
  br i1 %415, label %418, label %416

416:                                              ; preds = %408
  %417 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %359, i8 noundef zeroext 41) #33
  br label %420

418:                                              ; preds = %408
  %419 = getelementptr inbounds nuw i8, ptr %412, i64 1
  store ptr %419, ptr %411, align 8, !tbaa !258
  store i8 41, ptr %412, align 1, !tbaa !212
  br label %420

420:                                              ; preds = %418, %416, %346
  %421 = getelementptr inbounds nuw i8, ptr %293, i64 8
  %422 = icmp eq ptr %421, %275
  br i1 %422, label %285, label %292, !llvm.loop !362

423:                                              ; preds = %285
  %424 = load ptr, ptr %76, align 8, !tbaa !257
  %425 = load ptr, ptr %78, align 8, !tbaa !258
  %426 = ptrtoint ptr %424 to i64
  %427 = ptrtoint ptr %425 to i64
  %428 = sub i64 %426, %427
  %429 = icmp ult i64 %428, 2
  br i1 %429, label %430, label %432

430:                                              ; preds = %423
  %431 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.18, i64 noundef 2) #33
  br label %435

432:                                              ; preds = %423
  store i16 8251, ptr %425, align 1
  %433 = load ptr, ptr %78, align 8, !tbaa !258
  %434 = getelementptr inbounds nuw i8, ptr %433, i64 2
  store ptr %434, ptr %78, align 8, !tbaa !258
  br label %435

435:                                              ; preds = %430, %432
  %436 = load ptr, ptr %270, align 8, !tbaa !19
  %437 = load i32, ptr %242, align 8, !tbaa !76
  %438 = zext i32 %437 to i64
  %439 = shl nuw nsw i64 %438, 3
  %440 = getelementptr inbounds nuw i8, ptr %436, i64 %439
  %441 = icmp eq i32 %437, 0
  br i1 %441, label %581, label %442

442:                                              ; preds = %435
  %443 = getelementptr inbounds nuw i8, ptr %15, i64 24
  %444 = getelementptr inbounds nuw i8, ptr %15, i64 16
  %445 = getelementptr inbounds nuw i8, ptr %15, i64 8
  %446 = getelementptr inbounds nuw i8, ptr %16, i64 8
  %447 = ptrtoint ptr %9 to i64
  br label %448

448:                                              ; preds = %442, %578
  %449 = phi ptr [ %436, %442 ], [ %579, %578 ]
  %450 = phi i1 [ true, %442 ], [ false, %578 ]
  %451 = load ptr, ptr %286, align 8, !tbaa !345
  %452 = load ptr, ptr %288, align 8, !tbaa !345
  %453 = icmp eq ptr %451, %452
  br i1 %453, label %454, label %461

454:                                              ; preds = %448
  %455 = load i32, ptr %242, align 8, !tbaa !76
  %456 = icmp eq i32 %455, -2147483648
  br i1 %456, label %499, label %457

457:                                              ; preds = %454
  %458 = lshr i32 %455, 1
  %459 = or disjoint i32 %458, -2147483648
  %460 = udiv i32 %459, %455
  br label %499

461:                                              ; preds = %448
  %462 = load ptr, ptr %270, align 8, !tbaa !19
  %463 = ptrtoint ptr %449 to i64
  %464 = ptrtoint ptr %462 to i64
  %465 = sub i64 %463, %464
  %466 = ashr exact i64 %465, 1
  %467 = getelementptr inbounds i8, ptr %451, i64 %466
  %468 = load i32, ptr %467, align 4, !tbaa !349
  %469 = icmp eq i32 %468, -1
  br i1 %469, label %480, label %499

470:                                              ; preds = %494
  %471 = sub i32 -2147483648, %495
  %472 = ptrtoint ptr %452 to i64
  %473 = ptrtoint ptr %451 to i64
  %474 = sub i64 %472, %473
  %475 = ashr exact i64 %474, 2
  %476 = icmp sgt i64 %475, -1
  call void @llvm.assume(i1 %476)
  %477 = trunc i64 %475 to i32
  %478 = sub i32 %477, %496
  %479 = udiv i32 %471, %478
  br label %499

480:                                              ; preds = %461, %494
  %481 = phi i32 [ %496, %494 ], [ 0, %461 ]
  %482 = phi i32 [ %495, %494 ], [ 0, %461 ]
  %483 = phi ptr [ %497, %494 ], [ %451, %461 ]
  %484 = load i32, ptr %483, align 4, !tbaa !349
  %485 = icmp eq i32 %484, -1
  br i1 %485, label %494, label %486

486:                                              ; preds = %480
  %487 = zext i32 %482 to i64
  %488 = zext i32 %484 to i64
  %489 = add nuw nsw i64 %488, %487
  %490 = icmp samesign ugt i64 %489, 2147483648
  %491 = add i32 %484, %482
  %492 = select i1 %490, i32 -2147483648, i32 %491
  %493 = add i32 %481, 1
  br label %494

494:                                              ; preds = %486, %480
  %495 = phi i32 [ %482, %480 ], [ %492, %486 ]
  %496 = phi i32 [ %481, %480 ], [ %493, %486 ]
  %497 = getelementptr inbounds nuw i8, ptr %483, i64 4
  %498 = icmp eq ptr %497, %452
  br i1 %498, label %470, label %480

499:                                              ; preds = %454, %457, %461, %470
  %500 = phi i32 [ %479, %470 ], [ %460, %457 ], [ 1, %454 ], [ %468, %461 ]
  %501 = select i1 %450, i64 0, i64 2
  %502 = load ptr, ptr %76, align 8, !tbaa !257
  %503 = load ptr, ptr %78, align 8, !tbaa !258
  %504 = ptrtoint ptr %502 to i64
  %505 = ptrtoint ptr %503 to i64
  %506 = sub i64 %504, %505
  %507 = icmp ugt i64 %501, %506
  br i1 %507, label %508, label %513

508:                                              ; preds = %499
  %509 = select i1 %450, ptr @.str.9, ptr @.str.15
  %510 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %509, i64 noundef %501) #33
  %511 = getelementptr inbounds nuw i8, ptr %510, i64 32
  %512 = load ptr, ptr %511, align 8, !tbaa !258
  br label %517

513:                                              ; preds = %499
  br i1 %450, label %517, label %514

514:                                              ; preds = %513
  store i16 8236, ptr %503, align 1
  %515 = load ptr, ptr %78, align 8, !tbaa !258
  %516 = getelementptr inbounds nuw i8, ptr %515, i64 2
  store ptr %516, ptr %78, align 8, !tbaa !258
  br label %517

517:                                              ; preds = %514, %513, %508
  %518 = phi ptr [ %512, %508 ], [ %516, %514 ], [ %503, %513 ]
  %519 = phi ptr [ %510, %508 ], [ %1, %514 ], [ %1, %513 ]
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %15) #33
  %520 = load ptr, ptr %449, align 8, !tbaa !289
  %521 = ptrtoint ptr %520 to i64
  store ptr @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E9_M_invokeERKSt9_Any_dataS2_", ptr %443, align 8, !tbaa !285, !alias.scope !363
  store i64 %521, ptr %15, align 8, !alias.scope !363
  store i64 0, ptr %445, align 8, !tbaa !212, !alias.scope !363
  store ptr @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation", ptr %444, align 8, !tbaa !7, !alias.scope !363
  %522 = getelementptr inbounds nuw i8, ptr %519, i64 32
  %523 = getelementptr inbounds nuw i8, ptr %519, i64 24
  %524 = load ptr, ptr %523, align 8, !tbaa !257
  %525 = icmp ult ptr %518, %524
  br i1 %525, label %528, label %526

526:                                              ; preds = %517
  %527 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %519, i8 noundef zeroext 37) #33
  br label %530

528:                                              ; preds = %517
  %529 = getelementptr inbounds nuw i8, ptr %518, i64 1
  store ptr %529, ptr %522, align 8, !tbaa !258
  store i8 37, ptr %518, align 1, !tbaa !212
  br label %530

530:                                              ; preds = %528, %526
  %531 = load ptr, ptr %523, align 8, !tbaa !257
  %532 = load ptr, ptr %522, align 8, !tbaa !258
  %533 = ptrtoint ptr %531 to i64
  %534 = ptrtoint ptr %532 to i64
  %535 = sub i64 %533, %534
  %536 = icmp ult i64 %535, 3
  br i1 %536, label %537, label %539

537:                                              ; preds = %530
  %538 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %519, ptr noundef nonnull @.str.25, i64 noundef 3) #33
  br label %542

539:                                              ; preds = %530
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %532, ptr noundef nonnull align 1 dereferenceable(3) @.str.25, i64 3, i1 false)
  %540 = load ptr, ptr %522, align 8, !tbaa !258
  %541 = getelementptr inbounds nuw i8, ptr %540, i64 3
  store ptr %541, ptr %522, align 8, !tbaa !258
  br label %542

542:                                              ; preds = %537, %539
  %543 = phi ptr [ %538, %537 ], [ %519, %539 ]
  %544 = getelementptr inbounds nuw i8, ptr %520, i64 24
  %545 = load i32, ptr %544, align 8, !tbaa !72
  %546 = sext i32 %545 to i64
  %547 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEl(ptr noundef nonnull align 8 dereferenceable(48) %543, i64 noundef %546) #33
  %548 = load ptr, ptr %522, align 8, !tbaa !258
  %549 = load ptr, ptr %523, align 8, !tbaa !257
  %550 = icmp ult ptr %548, %549
  br i1 %550, label %553, label %551

551:                                              ; preds = %542
  %552 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %519, i8 noundef zeroext 40) #33
  br label %555

553:                                              ; preds = %542
  %554 = getelementptr inbounds nuw i8, ptr %548, i64 1
  store ptr %554, ptr %522, align 8, !tbaa !258
  store i8 40, ptr %548, align 1, !tbaa !212
  br label %555

555:                                              ; preds = %551, %553
  %556 = phi ptr [ %552, %551 ], [ %519, %553 ]
  %557 = uitofp i32 %500 to double
  %558 = fmul double %557, 0x3E00000000000000
  %559 = fmul double %558, 1.000000e+02
  %560 = fmul double %559, 1.000000e+02
  %561 = call double @llvm.rint.f64(double %560)
  %562 = fdiv double %561, 1.000000e+02
  store ptr @.str.19, ptr %16, align 8, !tbaa !366, !alias.scope !372
  store double %562, ptr %446, align 8, !tbaa !375, !alias.scope !372
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %9) #33
  store ptr %16, ptr %9, align 8, !tbaa !376
  %563 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsENS_12function_refIFiPcmEEE(ptr noundef nonnull align 8 dereferenceable(48) %556, ptr nonnull @_ZN4llvm12function_refIFiPcmEE11callback_fnIZNS_lsIJdEEERNS_11raw_ostreamES7_NS_13format_objectIJDpT_EEEEUlS1_mE_EEilS1_m, i64 %447) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %9) #33
  %564 = getelementptr inbounds nuw i8, ptr %556, i64 32
  %565 = load ptr, ptr %564, align 8, !tbaa !258
  %566 = getelementptr inbounds nuw i8, ptr %556, i64 24
  %567 = load ptr, ptr %566, align 8, !tbaa !257
  %568 = icmp ult ptr %565, %567
  br i1 %568, label %571, label %569

569:                                              ; preds = %555
  %570 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %556, i8 noundef zeroext 41) #33
  br label %573

571:                                              ; preds = %555
  %572 = getelementptr inbounds nuw i8, ptr %565, i64 1
  store ptr %572, ptr %564, align 8, !tbaa !258
  store i8 41, ptr %565, align 1, !tbaa !212
  br label %573

573:                                              ; preds = %569, %571
  %574 = load ptr, ptr %444, align 8, !tbaa !7
  %575 = icmp eq ptr %574, null
  br i1 %575, label %578, label %576

576:                                              ; preds = %573
  %577 = call noundef zeroext i1 %574(ptr noundef nonnull align 8 dereferenceable(32) %15, ptr noundef nonnull align 8 dereferenceable(32) %15, i32 noundef 3) #33
  br label %578

578:                                              ; preds = %573, %576
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %15) #33
  %579 = getelementptr inbounds nuw i8, ptr %449, i64 8
  %580 = icmp eq ptr %579, %440
  br i1 %580, label %581, label %448, !llvm.loop !378

581:                                              ; preds = %578, %435, %285
  %582 = load ptr, ptr %78, align 8, !tbaa !258
  %583 = load ptr, ptr %76, align 8, !tbaa !257
  %584 = icmp ult ptr %582, %583
  br i1 %584, label %587, label %585

585:                                              ; preds = %581
  %586 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 10) #33
  br label %589

587:                                              ; preds = %581
  %588 = getelementptr inbounds nuw i8, ptr %582, i64 1
  store ptr %588, ptr %78, align 8, !tbaa !258
  store i8 10, ptr %582, align 1, !tbaa !212
  br label %589

589:                                              ; preds = %587, %585, %241
  %590 = phi i1 [ %108, %241 ], [ true, %585 ], [ true, %587 ]
  %591 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %592 = load ptr, ptr %591, align 8, !tbaa !379
  %593 = getelementptr inbounds nuw i8, ptr %0, i64 192
  %594 = load ptr, ptr %593, align 8, !tbaa !379
  %595 = icmp eq ptr %592, %594
  br i1 %595, label %695, label %596

596:                                              ; preds = %589
  %597 = load ptr, ptr %97, align 8, !tbaa !380
  %598 = getelementptr inbounds nuw i8, ptr %597, i64 320
  %599 = load i64, ptr %598, align 8, !tbaa !450
  %600 = and i64 %599, 4
  %601 = icmp eq i64 %600, 0
  br i1 %601, label %695, label %602

602:                                              ; preds = %596
  br i1 %54, label %603, label %611

603:                                              ; preds = %602
  %604 = load ptr, ptr %78, align 8, !tbaa !258
  %605 = load ptr, ptr %76, align 8, !tbaa !257
  %606 = icmp ult ptr %604, %605
  br i1 %606, label %609, label %607

607:                                              ; preds = %603
  %608 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 9) #33
  br label %611

609:                                              ; preds = %603
  %610 = getelementptr inbounds nuw i8, ptr %604, i64 1
  store ptr %610, ptr %78, align 8, !tbaa !258
  store i8 9, ptr %604, align 1, !tbaa !212
  br label %611

611:                                              ; preds = %609, %607, %602
  %612 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream6indentEj(ptr noundef nonnull align 8 dereferenceable(48) %1, i32 noundef 2) #33
  %613 = getelementptr inbounds nuw i8, ptr %612, i64 24
  %614 = load ptr, ptr %613, align 8, !tbaa !257
  %615 = getelementptr inbounds nuw i8, ptr %612, i64 32
  %616 = load ptr, ptr %615, align 8, !tbaa !258
  %617 = ptrtoint ptr %614 to i64
  %618 = ptrtoint ptr %616 to i64
  %619 = sub i64 %617, %618
  %620 = icmp ult i64 %619, 9
  br i1 %620, label %621, label %623

621:                                              ; preds = %611
  %622 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %612, ptr noundef nonnull @.str.20, i64 noundef 9) #33
  br label %626

623:                                              ; preds = %611
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %616, ptr noundef nonnull align 1 dereferenceable(9) @.str.20, i64 9, i1 false)
  %624 = load ptr, ptr %615, align 8, !tbaa !258
  %625 = getelementptr inbounds nuw i8, ptr %624, i64 9
  store ptr %625, ptr %615, align 8, !tbaa !258
  br label %626

626:                                              ; preds = %621, %623
  %627 = load ptr, ptr %591, align 8, !tbaa !379
  %628 = load ptr, ptr %593, align 8, !tbaa !379
  %629 = icmp eq ptr %627, %628
  br i1 %629, label %696, label %630

630:                                              ; preds = %626
  %631 = getelementptr inbounds nuw i8, ptr %17, i64 16
  %632 = getelementptr inbounds nuw i8, ptr %17, i64 24
  %633 = getelementptr inbounds nuw i8, ptr %18, i64 24
  %634 = getelementptr inbounds nuw i8, ptr %18, i64 16
  %635 = getelementptr inbounds nuw i8, ptr %18, i64 8
  %636 = getelementptr inbounds nuw i8, ptr %7, i64 8
  %637 = ptrtoint ptr %6 to i64
  br label %638

638:                                              ; preds = %630, %692
  %639 = phi i1 [ true, %630 ], [ false, %692 ]
  %640 = phi ptr [ %627, %630 ], [ %693, %692 ]
  %641 = select i1 %639, i64 0, i64 2
  %642 = load ptr, ptr %76, align 8, !tbaa !257
  %643 = load ptr, ptr %78, align 8, !tbaa !258
  %644 = ptrtoint ptr %642 to i64
  %645 = ptrtoint ptr %643 to i64
  %646 = sub i64 %644, %645
  %647 = icmp ugt i64 %641, %646
  br i1 %647, label %648, label %651

648:                                              ; preds = %638
  %649 = select i1 %639, ptr @.str.9, ptr @.str.15
  %650 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %649, i64 noundef %641) #33
  br label %655

651:                                              ; preds = %638
  br i1 %639, label %655, label %652

652:                                              ; preds = %651
  store i16 8236, ptr %643, align 1
  %653 = load ptr, ptr %78, align 8, !tbaa !258
  %654 = getelementptr inbounds nuw i8, ptr %653, i64 2
  store ptr %654, ptr %78, align 8, !tbaa !258
  br label %655

655:                                              ; preds = %648, %651, %652
  %656 = phi ptr [ %650, %648 ], [ %1, %652 ], [ %1, %651 ]
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %17) #33
  %657 = load i32, ptr %640, align 8, !tbaa !451
  call void @_ZN4llvm8printRegENS_8RegisterEPKNS_18TargetRegisterInfoEjPKNS_19MachineRegisterInfoE(ptr dead_on_unwind nonnull writable sret(%"class.llvm::Printable") align 8 %17, i32 %657, ptr noundef %95, i32 noundef 0, ptr noundef null) #33
  %658 = load ptr, ptr %631, align 8, !tbaa !7
  %659 = icmp eq ptr %658, null
  br i1 %659, label %660, label %661

660:                                              ; preds = %655
  call void @_ZSt25__throw_bad_function_callv() #35
  unreachable

661:                                              ; preds = %655
  %662 = load ptr, ptr %632, align 8, !tbaa !285
  call void %662(ptr noundef nonnull align 8 dereferenceable(32) %17, ptr noundef nonnull align 8 dereferenceable(48) %656) #33
  %663 = load ptr, ptr %631, align 8, !tbaa !7
  %664 = icmp eq ptr %663, null
  br i1 %664, label %667, label %665

665:                                              ; preds = %661
  %666 = call noundef zeroext i1 %663(ptr noundef nonnull align 8 dereferenceable(32) %17, ptr noundef nonnull align 8 dereferenceable(32) %17, i32 noundef 3) #33
  br label %667

667:                                              ; preds = %661, %665
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %17) #33
  %668 = getelementptr inbounds nuw i8, ptr %640, i64 8
  %669 = load i64, ptr %668, align 8, !tbaa !452
  %670 = icmp eq i64 %669, -1
  br i1 %670, label %692, label %671

671:                                              ; preds = %667
  %672 = load ptr, ptr %76, align 8, !tbaa !257
  %673 = load ptr, ptr %78, align 8, !tbaa !258
  %674 = ptrtoint ptr %672 to i64
  %675 = ptrtoint ptr %673 to i64
  %676 = sub i64 %674, %675
  %677 = icmp ult i64 %676, 3
  br i1 %677, label %678, label %680

678:                                              ; preds = %671
  %679 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.21, i64 noundef 3) #33
  br label %683

680:                                              ; preds = %671
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %673, ptr noundef nonnull align 1 dereferenceable(3) @.str.21, i64 3, i1 false)
  %681 = load ptr, ptr %78, align 8, !tbaa !258
  %682 = getelementptr inbounds nuw i8, ptr %681, i64 3
  store ptr %682, ptr %78, align 8, !tbaa !258
  br label %683

683:                                              ; preds = %680, %678
  %684 = phi ptr [ %679, %678 ], [ %1, %680 ]
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %18) #33
  %685 = load i64, ptr %668, align 8, !tbaa !454
  store ptr @_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_13PrintLaneMaskENS0_11LaneBitmaskEEUlS2_E_E9_M_invokeERKSt9_Any_dataS2_, ptr %633, align 8, !tbaa !285, !alias.scope !455
  store i64 %685, ptr %18, align 8, !alias.scope !455
  store i64 0, ptr %635, align 8, !tbaa !212, !alias.scope !455
  store ptr @_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_13PrintLaneMaskENS0_11LaneBitmaskEEUlS2_E_E10_M_managerERSt9_Any_dataRKS7_St18_Manager_operation, ptr %634, align 8, !tbaa !7, !alias.scope !455
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %7)
  store ptr @.str.44, ptr %7, align 8, !tbaa !458, !alias.scope !463
  store i64 %685, ptr %636, align 8, !tbaa !466, !alias.scope !463
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %6) #33
  store ptr %7, ptr %6, align 8, !tbaa !467
  %686 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsENS_12function_refIFiPcmEEE(ptr noundef nonnull align 8 dereferenceable(48) %684, ptr nonnull @_ZN4llvm12function_refIFiPcmEE11callback_fnIZNS_lsIJmEEERNS_11raw_ostreamES7_NS_13format_objectIJDpT_EEEEUlS1_mE_EEilS1_m, i64 %637) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %6) #33
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %7)
  %687 = load ptr, ptr %634, align 8, !tbaa !7
  %688 = icmp eq ptr %687, null
  br i1 %688, label %691, label %689

689:                                              ; preds = %683
  %690 = call noundef zeroext i1 %687(ptr noundef nonnull align 8 dereferenceable(32) %18, ptr noundef nonnull align 8 dereferenceable(32) %18, i32 noundef 3) #33
  br label %691

691:                                              ; preds = %683, %689
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %18) #33
  br label %692

692:                                              ; preds = %691, %667
  %693 = getelementptr inbounds nuw i8, ptr %640, i64 16
  %694 = icmp eq ptr %693, %628
  br i1 %694, label %696, label %638

695:                                              ; preds = %596, %589
  br i1 %590, label %696, label %704

696:                                              ; preds = %692, %626, %695
  %697 = load ptr, ptr %78, align 8, !tbaa !258
  %698 = load ptr, ptr %76, align 8, !tbaa !257
  %699 = icmp ult ptr %697, %698
  br i1 %699, label %702, label %700

700:                                              ; preds = %696
  %701 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 10) #33
  br label %704

702:                                              ; preds = %696
  %703 = getelementptr inbounds nuw i8, ptr %697, i64 1
  store ptr %703, ptr %78, align 8, !tbaa !258
  store i8 10, ptr %697, align 1, !tbaa !212
  br label %704

704:                                              ; preds = %702, %700, %695
  %705 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %706 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %707 = load ptr, ptr %705, align 8, !tbaa !75
  %708 = icmp eq ptr %707, %706
  br i1 %708, label %841, label %709

709:                                              ; preds = %704
  %710 = getelementptr inbounds nuw i8, ptr %3, i64 120
  %711 = getelementptr inbounds nuw i8, ptr %3, i64 104
  %712 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %713 = getelementptr inbounds nuw i8, ptr %3, i64 124
  br label %716

714:                                              ; preds = %822
  %715 = trunc nuw i8 %814 to i1
  br i1 %715, label %826, label %841

716:                                              ; preds = %709, %822
  %717 = phi ptr [ %707, %709 ], [ %824, %822 ]
  %718 = phi i8 [ 0, %709 ], [ %814, %822 ]
  %719 = load i8, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 120), align 8, !range !16
  %720 = trunc nuw i8 %719 to i1
  %721 = select i1 %54, i1 %720, i1 false
  br i1 %721, label %722, label %771

722:                                              ; preds = %716
  %723 = load i32, ptr %710, align 8, !tbaa !469
  %724 = icmp eq i32 %723, 0
  br i1 %724, label %763, label %725

725:                                              ; preds = %722
  %726 = load ptr, ptr %711, align 8, !tbaa !472, !noalias !473
  %727 = load ptr, ptr %712, align 8, !tbaa !478, !noalias !473
  %728 = load i32, ptr %713, align 4, !tbaa !479, !noalias !473
  %729 = add i32 %728, -1
  %730 = ptrtoint ptr %717 to i64
  %731 = mul i64 %730, -4658895280553007687
  %732 = lshr i64 %731, 31
  %733 = xor i64 %732, %731
  %734 = trunc i64 %733 to i32
  %735 = and i32 %729, %734
  %736 = zext i32 %735 to i64
  %737 = lshr i64 %736, 5
  %738 = getelementptr inbounds nuw i32, ptr %727, i64 %737
  %739 = load i32, ptr %738, align 4, !tbaa !451
  %740 = and i32 %735, 31
  %741 = shl nuw i32 1, %740
  %742 = and i32 %741, %739
  %743 = icmp eq i32 %742, 0
  br i1 %743, label %763, label %744, !prof !480

744:                                              ; preds = %725, %750
  %745 = phi i64 [ %753, %750 ], [ %736, %725 ]
  %746 = phi i32 [ %752, %750 ], [ %735, %725 ]
  %747 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %726, i64 %745
  %748 = load ptr, ptr %747, align 8, !tbaa !481
  %749 = icmp eq ptr %717, %748
  br i1 %749, label %761, label %750, !prof !483

750:                                              ; preds = %744
  %751 = add i32 %746, 1
  %752 = and i32 %751, %729
  %753 = zext i32 %752 to i64
  %754 = lshr i64 %753, 5
  %755 = getelementptr inbounds nuw i32, ptr %727, i64 %754
  %756 = load i32, ptr %755, align 4, !tbaa !451
  %757 = and i32 %752, 31
  %758 = shl nuw i32 1, %757
  %759 = and i32 %756, %758
  %760 = icmp eq i32 %759, 0
  br i1 %760, label %763, label %744, !prof !484

761:                                              ; preds = %744
  %762 = call i64 @_ZNK4llvm11SlotIndexes19getInstructionIndexERKNS_12MachineInstrEb(ptr noundef nonnull align 8 dereferenceable(416) %3, ptr noundef nonnull align 8 dereferenceable(80) %717, i1 noundef zeroext false)
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %8)
  store i64 %762, ptr %8, align 8
  call void @_ZNK4llvm9SlotIndex5printERNS_11raw_ostreamE(ptr noundef nonnull align 8 dereferenceable(8) %8, ptr noundef nonnull align 8 dereferenceable(48) %1) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %8)
  br label %763

763:                                              ; preds = %750, %725, %722, %761
  %764 = load ptr, ptr %78, align 8, !tbaa !258
  %765 = load ptr, ptr %76, align 8, !tbaa !257
  %766 = icmp ult ptr %764, %765
  br i1 %766, label %769, label %767

767:                                              ; preds = %763
  %768 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 9) #33
  br label %771

769:                                              ; preds = %763
  %770 = getelementptr inbounds nuw i8, ptr %764, i64 1
  store ptr %770, ptr %78, align 8, !tbaa !258
  store i8 9, ptr %764, align 1, !tbaa !212
  br label %771

771:                                              ; preds = %769, %767, %716
  %772 = trunc nuw i8 %718 to i1
  br i1 %772, label %773, label %793

773:                                              ; preds = %771
  %774 = getelementptr inbounds nuw i8, ptr %717, i64 44
  %775 = load i32, ptr %774, align 4, !tbaa !309
  %776 = and i32 %775, 4
  %777 = icmp eq i32 %776, 0
  br i1 %777, label %778, label %811

778:                                              ; preds = %773
  %779 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream6indentEj(ptr noundef nonnull align 8 dereferenceable(48) %1, i32 noundef 2) #33
  %780 = getelementptr inbounds nuw i8, ptr %779, i64 24
  %781 = load ptr, ptr %780, align 8, !tbaa !257
  %782 = getelementptr inbounds nuw i8, ptr %779, i64 32
  %783 = load ptr, ptr %782, align 8, !tbaa !258
  %784 = ptrtoint ptr %781 to i64
  %785 = ptrtoint ptr %783 to i64
  %786 = sub i64 %784, %785
  %787 = icmp ult i64 %786, 2
  br i1 %787, label %788, label %790

788:                                              ; preds = %778
  %789 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %779, ptr noundef nonnull @.str.22, i64 noundef 2) #33
  br label %793

790:                                              ; preds = %778
  store i16 2685, ptr %783, align 1
  %791 = load ptr, ptr %782, align 8, !tbaa !258
  %792 = getelementptr inbounds nuw i8, ptr %791, i64 2
  store ptr %792, ptr %782, align 8, !tbaa !258
  br label %793

793:                                              ; preds = %790, %788, %771
  %794 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream6indentEj(ptr noundef nonnull align 8 dereferenceable(48) %1, i32 noundef 2) #33
  call void @_ZNK4llvm12MachineInstr5printERNS_11raw_ostreamERNS_17ModuleSlotTrackerEbbbbPKNS_15TargetInstrInfoE(ptr noundef nonnull align 8 dereferenceable(80) %717, ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull align 8 dereferenceable(112) %2, i1 noundef zeroext %4, i1 noundef zeroext false, i1 noundef zeroext false, i1 noundef zeroext false, ptr noundef %104) #33
  %795 = getelementptr inbounds nuw i8, ptr %717, i64 44
  %796 = load i32, ptr %795, align 4, !tbaa !309
  %797 = and i32 %796, 8
  %798 = icmp eq i32 %797, 0
  br i1 %798, label %813, label %799

799:                                              ; preds = %793
  %800 = load ptr, ptr %76, align 8, !tbaa !257
  %801 = load ptr, ptr %78, align 8, !tbaa !258
  %802 = ptrtoint ptr %800 to i64
  %803 = ptrtoint ptr %801 to i64
  %804 = sub i64 %802, %803
  %805 = icmp ult i64 %804, 2
  br i1 %805, label %806, label %808

806:                                              ; preds = %799
  %807 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.23, i64 noundef 2) #33
  br label %813

808:                                              ; preds = %799
  store i16 31520, ptr %801, align 1
  %809 = load ptr, ptr %78, align 8, !tbaa !258
  %810 = getelementptr inbounds nuw i8, ptr %809, i64 2
  store ptr %810, ptr %78, align 8, !tbaa !258
  br label %813

811:                                              ; preds = %773
  %812 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream6indentEj(ptr noundef nonnull align 8 dereferenceable(48) %1, i32 noundef 4) #33
  call void @_ZNK4llvm12MachineInstr5printERNS_11raw_ostreamERNS_17ModuleSlotTrackerEbbbbPKNS_15TargetInstrInfoE(ptr noundef nonnull align 8 dereferenceable(80) %717, ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull align 8 dereferenceable(112) %2, i1 noundef zeroext %4, i1 noundef zeroext false, i1 noundef zeroext false, i1 noundef zeroext false, ptr noundef %104) #33
  br label %813

813:                                              ; preds = %811, %808, %806, %793
  %814 = phi i8 [ 0, %793 ], [ 1, %806 ], [ 1, %808 ], [ 1, %811 ]
  %815 = load ptr, ptr %78, align 8, !tbaa !258
  %816 = load ptr, ptr %76, align 8, !tbaa !257
  %817 = icmp ult ptr %815, %816
  br i1 %817, label %820, label %818

818:                                              ; preds = %813
  %819 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 10) #33
  br label %822

820:                                              ; preds = %813
  %821 = getelementptr inbounds nuw i8, ptr %815, i64 1
  store ptr %821, ptr %78, align 8, !tbaa !258
  store i8 10, ptr %815, align 1, !tbaa !212
  br label %822

822:                                              ; preds = %818, %820
  %823 = getelementptr inbounds nuw i8, ptr %717, i64 8
  %824 = load ptr, ptr %823, align 8, !tbaa !75
  %825 = icmp eq ptr %824, %706
  br i1 %825, label %714, label %716

826:                                              ; preds = %714
  %827 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream6indentEj(ptr noundef nonnull align 8 dereferenceable(48) %1, i32 noundef 2) #33
  %828 = getelementptr inbounds nuw i8, ptr %827, i64 24
  %829 = load ptr, ptr %828, align 8, !tbaa !257
  %830 = getelementptr inbounds nuw i8, ptr %827, i64 32
  %831 = load ptr, ptr %830, align 8, !tbaa !258
  %832 = ptrtoint ptr %829 to i64
  %833 = ptrtoint ptr %831 to i64
  %834 = sub i64 %832, %833
  %835 = icmp ult i64 %834, 2
  br i1 %835, label %836, label %838

836:                                              ; preds = %826
  %837 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %827, ptr noundef nonnull @.str.22, i64 noundef 2) #33
  br label %841

838:                                              ; preds = %826
  store i16 2685, ptr %831, align 1
  %839 = load ptr, ptr %830, align 8, !tbaa !258
  %840 = getelementptr inbounds nuw i8, ptr %839, i64 2
  store ptr %840, ptr %830, align 8, !tbaa !258
  br label %841

841:                                              ; preds = %704, %838, %836, %714
  %842 = getelementptr inbounds nuw i8, ptr %0, i64 168
  %843 = getelementptr inbounds nuw i8, ptr %0, i64 176
  %844 = load i8, ptr %843, align 8, !tbaa !78, !range !16, !noundef !17
  %845 = trunc nuw i8 %844 to i1
  %846 = and i1 %4, %845
  br i1 %846, label %847, label %884

847:                                              ; preds = %841
  br i1 %54, label %848, label %856

848:                                              ; preds = %847
  %849 = load ptr, ptr %78, align 8, !tbaa !258
  %850 = load ptr, ptr %76, align 8, !tbaa !257
  %851 = icmp ult ptr %849, %850
  br i1 %851, label %854, label %852

852:                                              ; preds = %848
  %853 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 9) #33
  br label %856

854:                                              ; preds = %848
  %855 = getelementptr inbounds nuw i8, ptr %849, i64 1
  store ptr %855, ptr %78, align 8, !tbaa !258
  store i8 9, ptr %849, align 1, !tbaa !212
  br label %856

856:                                              ; preds = %854, %852, %847
  %857 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream6indentEj(ptr noundef nonnull align 8 dereferenceable(48) %1, i32 noundef 2) #33
  %858 = getelementptr inbounds nuw i8, ptr %857, i64 24
  %859 = load ptr, ptr %858, align 8, !tbaa !257
  %860 = getelementptr inbounds nuw i8, ptr %857, i64 32
  %861 = load ptr, ptr %860, align 8, !tbaa !258
  %862 = ptrtoint ptr %859 to i64
  %863 = ptrtoint ptr %861 to i64
  %864 = sub i64 %862, %863
  %865 = icmp ult i64 %864, 34
  br i1 %865, label %866, label %868

866:                                              ; preds = %856
  %867 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %857, ptr noundef nonnull @.str.24, i64 noundef 34) #33
  br label %871

868:                                              ; preds = %856
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(34) %861, ptr noundef nonnull align 1 dereferenceable(34) @.str.24, i64 34, i1 false)
  %869 = load ptr, ptr %860, align 8, !tbaa !258
  %870 = getelementptr inbounds nuw i8, ptr %869, i64 34
  store ptr %870, ptr %860, align 8, !tbaa !258
  br label %871

871:                                              ; preds = %866, %868
  %872 = phi ptr [ %867, %866 ], [ %857, %868 ]
  %873 = load i64, ptr %842, align 8, !tbaa !454
  %874 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEm(ptr noundef nonnull align 8 dereferenceable(48) %872, i64 noundef %873) #33
  %875 = getelementptr inbounds nuw i8, ptr %874, i64 32
  %876 = load ptr, ptr %875, align 8, !tbaa !258
  %877 = getelementptr inbounds nuw i8, ptr %874, i64 24
  %878 = load ptr, ptr %877, align 8, !tbaa !257
  %879 = icmp ult ptr %876, %878
  br i1 %879, label %882, label %880

880:                                              ; preds = %871
  %881 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %874, i8 noundef zeroext 10) #33
  br label %884

882:                                              ; preds = %871
  %883 = getelementptr inbounds nuw i8, ptr %876, i64 1
  store ptr %883, ptr %875, align 8, !tbaa !258
  store i8 10, ptr %876, align 1, !tbaa !212
  br label %884

884:                                              ; preds = %882, %880, %49, %47, %841
  ret void
}

; Function Attrs: nounwind
declare void @_ZN4llvm17ModuleSlotTrackerD1Ev(ptr noundef nonnull align 8 dereferenceable(112)) unnamed_addr #6

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZNK4llvm17MachineBasicBlock9printNameERNS_11raw_ostreamEjPNS_17ModuleSlotTrackerE(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(48) %1, i32 noundef %2, ptr noundef %3) local_unnamed_addr #3 align 2 {
  %5 = alloca ptr, align 8
  %6 = alloca %class.anon.399, align 8
  store ptr %3, ptr %5, align 8, !tbaa !485
  %7 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %8 = load ptr, ptr %7, align 8, !tbaa !257
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %10 = load ptr, ptr %9, align 8, !tbaa !258
  %11 = ptrtoint ptr %8 to i64
  %12 = ptrtoint ptr %10 to i64
  %13 = sub i64 %11, %12
  %14 = icmp ult i64 %13, 3
  br i1 %14, label %15, label %17

15:                                               ; preds = %4
  %16 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.25, i64 noundef 3) #33
  br label %20

17:                                               ; preds = %4
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %10, ptr noundef nonnull align 1 dereferenceable(3) @.str.25, i64 3, i1 false)
  %18 = load ptr, ptr %9, align 8, !tbaa !258
  %19 = getelementptr inbounds nuw i8, ptr %18, i64 3
  store ptr %19, ptr %9, align 8, !tbaa !258
  br label %20

20:                                               ; preds = %15, %17
  %21 = phi ptr [ %16, %15 ], [ %1, %17 ]
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %23 = load i32, ptr %22, align 8, !tbaa !72
  %24 = sext i32 %23 to i64
  %25 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEl(ptr noundef nonnull align 8 dereferenceable(48) %21, i64 noundef %24) #33
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %6) #33
  store ptr %1, ptr %6, align 8, !tbaa !487
  %26 = getelementptr inbounds nuw i8, ptr %6, i64 8
  store ptr %5, ptr %26, align 8, !tbaa !489
  %27 = and i32 %2, 1
  %28 = icmp eq i32 %27, 0
  br i1 %28, label %63, label %29

29:                                               ; preds = %20
  %30 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %31 = load ptr, ptr %30, align 8, !tbaa !21
  %32 = icmp eq ptr %31, null
  br i1 %32, label %63, label %33

33:                                               ; preds = %29
  %34 = getelementptr inbounds nuw i8, ptr %31, i64 4
  %35 = load i32, ptr %34, align 4
  %36 = and i32 %35, 536870912
  %37 = icmp eq i32 %36, 0
  br i1 %37, label %50, label %38

38:                                               ; preds = %33
  %39 = load ptr, ptr %9, align 8, !tbaa !258
  %40 = load ptr, ptr %7, align 8, !tbaa !257
  %41 = icmp ult ptr %39, %40
  br i1 %41, label %44, label %42

42:                                               ; preds = %38
  %43 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 46) #33
  br label %46

44:                                               ; preds = %38
  %45 = getelementptr inbounds nuw i8, ptr %39, i64 1
  store ptr %45, ptr %9, align 8, !tbaa !258
  store i8 46, ptr %39, align 1, !tbaa !212
  br label %46

46:                                               ; preds = %42, %44
  %47 = call { ptr, i64 } @_ZNK4llvm5Value7getNameEv(ptr noundef nonnull align 8 dereferenceable(24) %31) #33
  %48 = extractvalue { ptr, i64 } %47, 0
  %49 = extractvalue { ptr, i64 } %47, 1
  call void @_ZN4llvm26printLLVMNameWithoutPrefixERNS_11raw_ostreamENS_9StringRefE(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr %48, i64 %49) #33
  br label %63

50:                                               ; preds = %33
  %51 = load ptr, ptr %7, align 8, !tbaa !257
  %52 = load ptr, ptr %9, align 8, !tbaa !258
  %53 = ptrtoint ptr %51 to i64
  %54 = ptrtoint ptr %52 to i64
  %55 = sub i64 %53, %54
  %56 = icmp ult i64 %55, 2
  br i1 %56, label %57, label %59

57:                                               ; preds = %50
  %58 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.26, i64 noundef 2) #33
  br label %62

59:                                               ; preds = %50
  store i16 10272, ptr %52, align 1
  %60 = load ptr, ptr %9, align 8, !tbaa !258
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 2
  store ptr %61, ptr %9, align 8, !tbaa !258
  br label %62

62:                                               ; preds = %57, %59
  call fastcc void @"_ZZNK4llvm17MachineBasicBlock9printNameERNS_11raw_ostreamEjPNS_17ModuleSlotTrackerEENK3$_0clEPKNS_10BasicBlockE"(ptr noundef nonnull align 8 dereferenceable(16) %6, ptr noundef nonnull %31)
  br label %63

63:                                               ; preds = %29, %62, %46, %20
  %64 = phi i8 [ 0, %20 ], [ 0, %46 ], [ 1, %62 ], [ 0, %29 ]
  %65 = and i32 %2, 2
  %66 = icmp eq i32 %65, 0
  br i1 %66, label %461, label %67

67:                                               ; preds = %63
  %68 = getelementptr inbounds nuw i8, ptr %0, i64 217
  %69 = load i8, ptr %68, align 1, !tbaa !81, !range !16, !noundef !17
  %70 = trunc nuw i8 %69 to i1
  br i1 %70, label %71, label %99

71:                                               ; preds = %67
  %72 = trunc nuw i8 %64 to i1
  %73 = select i1 %72, ptr @.str.15, ptr @.str.26
  %74 = load ptr, ptr %7, align 8, !tbaa !257
  %75 = load ptr, ptr %9, align 8, !tbaa !258
  %76 = ptrtoint ptr %74 to i64
  %77 = ptrtoint ptr %75 to i64
  %78 = sub i64 %76, %77
  %79 = icmp ult i64 %78, 2
  br i1 %79, label %80, label %83

80:                                               ; preds = %71
  %81 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %73, i64 noundef 2) #33
  %82 = load ptr, ptr %9, align 8, !tbaa !258
  br label %87

83:                                               ; preds = %71
  %84 = load i16, ptr %73, align 1
  store i16 %84, ptr %75, align 1
  %85 = load ptr, ptr %9, align 8, !tbaa !258
  %86 = getelementptr inbounds nuw i8, ptr %85, i64 2
  store ptr %86, ptr %9, align 8, !tbaa !258
  br label %87

87:                                               ; preds = %80, %83
  %88 = phi ptr [ %82, %80 ], [ %86, %83 ]
  %89 = load ptr, ptr %7, align 8, !tbaa !257
  %90 = ptrtoint ptr %89 to i64
  %91 = ptrtoint ptr %88 to i64
  %92 = sub i64 %90, %91
  %93 = icmp ult i64 %92, 27
  br i1 %93, label %94, label %96

94:                                               ; preds = %87
  %95 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.27, i64 noundef 27) #33
  br label %99

96:                                               ; preds = %87
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(27) %88, ptr noundef nonnull align 1 dereferenceable(27) @.str.27, i64 27, i1 false)
  %97 = load ptr, ptr %9, align 8, !tbaa !258
  %98 = getelementptr inbounds nuw i8, ptr %97, i64 27
  store ptr %98, ptr %9, align 8, !tbaa !258
  br label %99

99:                                               ; preds = %96, %94, %67
  %100 = phi i8 [ %64, %67 ], [ 1, %94 ], [ 1, %96 ]
  %101 = getelementptr inbounds nuw i8, ptr %0, i64 224
  %102 = load ptr, ptr %101, align 8, !tbaa !491
  %103 = icmp eq ptr %102, null
  br i1 %103, label %134, label %104

104:                                              ; preds = %99
  %105 = trunc nuw i8 %100 to i1
  %106 = select i1 %105, ptr @.str.15, ptr @.str.26
  %107 = load ptr, ptr %7, align 8, !tbaa !257
  %108 = load ptr, ptr %9, align 8, !tbaa !258
  %109 = ptrtoint ptr %107 to i64
  %110 = ptrtoint ptr %108 to i64
  %111 = sub i64 %109, %110
  %112 = icmp ult i64 %111, 2
  br i1 %112, label %113, label %116

113:                                              ; preds = %104
  %114 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %106, i64 noundef 2) #33
  %115 = load ptr, ptr %9, align 8, !tbaa !258
  br label %120

116:                                              ; preds = %104
  %117 = load i16, ptr %106, align 1
  store i16 %117, ptr %108, align 1
  %118 = load ptr, ptr %9, align 8, !tbaa !258
  %119 = getelementptr inbounds nuw i8, ptr %118, i64 2
  store ptr %119, ptr %9, align 8, !tbaa !258
  br label %120

120:                                              ; preds = %113, %116
  %121 = phi ptr [ %115, %113 ], [ %119, %116 ]
  %122 = load ptr, ptr %7, align 8, !tbaa !257
  %123 = ptrtoint ptr %122 to i64
  %124 = ptrtoint ptr %121 to i64
  %125 = sub i64 %123, %124
  %126 = icmp ult i64 %125, 23
  br i1 %126, label %127, label %129

127:                                              ; preds = %120
  %128 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.28, i64 noundef 23) #33
  br label %132

129:                                              ; preds = %120
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %121, ptr noundef nonnull align 1 dereferenceable(23) @.str.28, i64 23, i1 false)
  %130 = load ptr, ptr %9, align 8, !tbaa !258
  %131 = getelementptr inbounds nuw i8, ptr %130, i64 23
  store ptr %131, ptr %9, align 8, !tbaa !258
  br label %132

132:                                              ; preds = %127, %129
  %133 = load ptr, ptr %101, align 8, !tbaa !491
  call fastcc void @"_ZZNK4llvm17MachineBasicBlock9printNameERNS_11raw_ostreamEjPNS_17ModuleSlotTrackerEENK3$_0clEPKNS_10BasicBlockE"(ptr noundef nonnull align 8 dereferenceable(16) %6, ptr noundef %133)
  br label %134

134:                                              ; preds = %132, %99
  %135 = phi i8 [ 1, %132 ], [ %100, %99 ]
  %136 = getelementptr inbounds nuw i8, ptr %0, i64 216
  %137 = load i8, ptr %136, align 8, !tbaa !80, !range !16, !noundef !17
  %138 = trunc nuw i8 %137 to i1
  br i1 %138, label %139, label %167

139:                                              ; preds = %134
  %140 = trunc nuw i8 %135 to i1
  %141 = select i1 %140, ptr @.str.15, ptr @.str.26
  %142 = load ptr, ptr %7, align 8, !tbaa !257
  %143 = load ptr, ptr %9, align 8, !tbaa !258
  %144 = ptrtoint ptr %142 to i64
  %145 = ptrtoint ptr %143 to i64
  %146 = sub i64 %144, %145
  %147 = icmp ult i64 %146, 2
  br i1 %147, label %148, label %151

148:                                              ; preds = %139
  %149 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %141, i64 noundef 2) #33
  %150 = load ptr, ptr %9, align 8, !tbaa !258
  br label %155

151:                                              ; preds = %139
  %152 = load i16, ptr %141, align 1
  store i16 %152, ptr %143, align 1
  %153 = load ptr, ptr %9, align 8, !tbaa !258
  %154 = getelementptr inbounds nuw i8, ptr %153, i64 2
  store ptr %154, ptr %9, align 8, !tbaa !258
  br label %155

155:                                              ; preds = %148, %151
  %156 = phi ptr [ %150, %148 ], [ %154, %151 ]
  %157 = load ptr, ptr %7, align 8, !tbaa !257
  %158 = ptrtoint ptr %157 to i64
  %159 = ptrtoint ptr %156 to i64
  %160 = sub i64 %158, %159
  %161 = icmp ult i64 %160, 11
  br i1 %161, label %162, label %164

162:                                              ; preds = %155
  %163 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.29, i64 noundef 11) #33
  br label %167

164:                                              ; preds = %155
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(11) %156, ptr noundef nonnull align 1 dereferenceable(11) @.str.29, i64 11, i1 false)
  %165 = load ptr, ptr %9, align 8, !tbaa !258
  %166 = getelementptr inbounds nuw i8, ptr %165, i64 11
  store ptr %166, ptr %9, align 8, !tbaa !258
  br label %167

167:                                              ; preds = %164, %162, %134
  %168 = phi i8 [ %135, %134 ], [ 1, %162 ], [ 1, %164 ]
  %169 = getelementptr inbounds nuw i8, ptr %0, i64 262
  %170 = load i8, ptr %169, align 2, !tbaa !328, !range !16, !noundef !17
  %171 = trunc nuw i8 %170 to i1
  br i1 %171, label %172, label %200

172:                                              ; preds = %167
  %173 = trunc nuw i8 %168 to i1
  %174 = select i1 %173, ptr @.str.15, ptr @.str.26
  %175 = load ptr, ptr %7, align 8, !tbaa !257
  %176 = load ptr, ptr %9, align 8, !tbaa !258
  %177 = ptrtoint ptr %175 to i64
  %178 = ptrtoint ptr %176 to i64
  %179 = sub i64 %177, %178
  %180 = icmp ult i64 %179, 2
  br i1 %180, label %181, label %184

181:                                              ; preds = %172
  %182 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %174, i64 noundef 2) #33
  %183 = load ptr, ptr %9, align 8, !tbaa !258
  br label %188

184:                                              ; preds = %172
  %185 = load i16, ptr %174, align 1
  store i16 %185, ptr %176, align 1
  %186 = load ptr, ptr %9, align 8, !tbaa !258
  %187 = getelementptr inbounds nuw i8, ptr %186, i64 2
  store ptr %187, ptr %9, align 8, !tbaa !258
  br label %188

188:                                              ; preds = %181, %184
  %189 = phi ptr [ %183, %181 ], [ %187, %184 ]
  %190 = load ptr, ptr %7, align 8, !tbaa !257
  %191 = ptrtoint ptr %190 to i64
  %192 = ptrtoint ptr %189 to i64
  %193 = sub i64 %191, %192
  %194 = icmp ult i64 %193, 28
  br i1 %194, label %195, label %197

195:                                              ; preds = %188
  %196 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.30, i64 noundef 28) #33
  br label %200

197:                                              ; preds = %188
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(28) %189, ptr noundef nonnull align 1 dereferenceable(28) @.str.30, i64 28, i1 false)
  %198 = load ptr, ptr %9, align 8, !tbaa !258
  %199 = getelementptr inbounds nuw i8, ptr %198, i64 28
  store ptr %199, ptr %9, align 8, !tbaa !258
  br label %200

200:                                              ; preds = %197, %195, %167
  %201 = phi i8 [ %168, %167 ], [ 1, %195 ], [ 1, %197 ]
  %202 = getelementptr inbounds nuw i8, ptr %0, i64 235
  %203 = load i8, ptr %202, align 1, !tbaa !492, !range !16, !noundef !17
  %204 = trunc nuw i8 %203 to i1
  br i1 %204, label %205, label %233

205:                                              ; preds = %200
  %206 = trunc nuw i8 %201 to i1
  %207 = select i1 %206, ptr @.str.15, ptr @.str.26
  %208 = load ptr, ptr %7, align 8, !tbaa !257
  %209 = load ptr, ptr %9, align 8, !tbaa !258
  %210 = ptrtoint ptr %208 to i64
  %211 = ptrtoint ptr %209 to i64
  %212 = sub i64 %210, %211
  %213 = icmp ult i64 %212, 2
  br i1 %213, label %214, label %217

214:                                              ; preds = %205
  %215 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %207, i64 noundef 2) #33
  %216 = load ptr, ptr %9, align 8, !tbaa !258
  br label %221

217:                                              ; preds = %205
  %218 = load i16, ptr %207, align 1
  store i16 %218, ptr %209, align 1
  %219 = load ptr, ptr %9, align 8, !tbaa !258
  %220 = getelementptr inbounds nuw i8, ptr %219, i64 2
  store ptr %220, ptr %9, align 8, !tbaa !258
  br label %221

221:                                              ; preds = %214, %217
  %222 = phi ptr [ %216, %214 ], [ %220, %217 ]
  %223 = load ptr, ptr %7, align 8, !tbaa !257
  %224 = ptrtoint ptr %223 to i64
  %225 = ptrtoint ptr %222 to i64
  %226 = sub i64 %224, %225
  %227 = icmp ult i64 %226, 15
  br i1 %227, label %228, label %230

228:                                              ; preds = %221
  %229 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.31, i64 noundef 15) #33
  br label %233

230:                                              ; preds = %221
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(15) %222, ptr noundef nonnull align 1 dereferenceable(15) @.str.31, i64 15, i1 false)
  %231 = load ptr, ptr %9, align 8, !tbaa !258
  %232 = getelementptr inbounds nuw i8, ptr %231, i64 15
  store ptr %232, ptr %9, align 8, !tbaa !258
  br label %233

233:                                              ; preds = %230, %228, %200
  %234 = phi i8 [ %201, %200 ], [ 1, %228 ], [ 1, %230 ]
  %235 = getelementptr inbounds nuw i8, ptr %0, i64 233
  %236 = load i8, ptr %235, align 1, !tbaa !493, !range !16, !noundef !17
  %237 = trunc nuw i8 %236 to i1
  br i1 %237, label %238, label %266

238:                                              ; preds = %233
  %239 = trunc nuw i8 %234 to i1
  %240 = select i1 %239, ptr @.str.15, ptr @.str.26
  %241 = load ptr, ptr %7, align 8, !tbaa !257
  %242 = load ptr, ptr %9, align 8, !tbaa !258
  %243 = ptrtoint ptr %241 to i64
  %244 = ptrtoint ptr %242 to i64
  %245 = sub i64 %243, %244
  %246 = icmp ult i64 %245, 2
  br i1 %246, label %247, label %250

247:                                              ; preds = %238
  %248 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %240, i64 noundef 2) #33
  %249 = load ptr, ptr %9, align 8, !tbaa !258
  br label %254

250:                                              ; preds = %238
  %251 = load i16, ptr %240, align 1
  store i16 %251, ptr %242, align 1
  %252 = load ptr, ptr %9, align 8, !tbaa !258
  %253 = getelementptr inbounds nuw i8, ptr %252, i64 2
  store ptr %253, ptr %9, align 8, !tbaa !258
  br label %254

254:                                              ; preds = %247, %250
  %255 = phi ptr [ %249, %247 ], [ %253, %250 ]
  %256 = load ptr, ptr %7, align 8, !tbaa !257
  %257 = ptrtoint ptr %256 to i64
  %258 = ptrtoint ptr %255 to i64
  %259 = sub i64 %257, %258
  %260 = icmp ult i64 %259, 13
  br i1 %260, label %261, label %263

261:                                              ; preds = %254
  %262 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.32, i64 noundef 13) #33
  br label %266

263:                                              ; preds = %254
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %255, ptr noundef nonnull align 1 dereferenceable(13) @.str.32, i64 13, i1 false)
  %264 = load ptr, ptr %9, align 8, !tbaa !258
  %265 = getelementptr inbounds nuw i8, ptr %264, i64 13
  store ptr %265, ptr %9, align 8, !tbaa !258
  br label %266

266:                                              ; preds = %263, %261, %233
  %267 = phi i8 [ %234, %233 ], [ 1, %261 ], [ 1, %263 ]
  %268 = getelementptr inbounds nuw i8, ptr %0, i64 208
  %269 = load i8, ptr %268, align 8, !tbaa !212
  %270 = icmp eq i8 %269, 0
  br i1 %270, label %305, label %271

271:                                              ; preds = %266
  %272 = trunc nuw i8 %267 to i1
  %273 = select i1 %272, ptr @.str.15, ptr @.str.26
  %274 = load ptr, ptr %7, align 8, !tbaa !257
  %275 = load ptr, ptr %9, align 8, !tbaa !258
  %276 = ptrtoint ptr %274 to i64
  %277 = ptrtoint ptr %275 to i64
  %278 = sub i64 %276, %277
  %279 = icmp ult i64 %278, 2
  br i1 %279, label %280, label %283

280:                                              ; preds = %271
  %281 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %273, i64 noundef 2) #33
  %282 = load ptr, ptr %9, align 8, !tbaa !258
  br label %287

283:                                              ; preds = %271
  %284 = load i16, ptr %273, align 1
  store i16 %284, ptr %275, align 1
  %285 = load ptr, ptr %9, align 8, !tbaa !258
  %286 = getelementptr inbounds nuw i8, ptr %285, i64 2
  store ptr %286, ptr %9, align 8, !tbaa !258
  br label %287

287:                                              ; preds = %280, %283
  %288 = phi ptr [ %282, %280 ], [ %286, %283 ]
  %289 = load ptr, ptr %7, align 8, !tbaa !257
  %290 = ptrtoint ptr %289 to i64
  %291 = ptrtoint ptr %288 to i64
  %292 = sub i64 %290, %291
  %293 = icmp ult i64 %292, 6
  br i1 %293, label %294, label %296

294:                                              ; preds = %287
  %295 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.33, i64 noundef 6) #33
  br label %299

296:                                              ; preds = %287
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) %288, ptr noundef nonnull align 1 dereferenceable(6) @.str.33, i64 6, i1 false)
  %297 = load ptr, ptr %9, align 8, !tbaa !258
  %298 = getelementptr inbounds nuw i8, ptr %297, i64 6
  store ptr %298, ptr %9, align 8, !tbaa !258
  br label %299

299:                                              ; preds = %294, %296
  %300 = phi ptr [ %295, %294 ], [ %1, %296 ]
  %301 = load i8, ptr %268, align 8, !tbaa !212
  %302 = zext nneg i8 %301 to i64
  %303 = shl nuw i64 1, %302
  %304 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEm(ptr noundef nonnull align 8 dereferenceable(48) %300, i64 noundef %303) #33
  br label %305

305:                                              ; preds = %299, %266
  %306 = phi i8 [ 1, %299 ], [ %267, %266 ]
  %307 = getelementptr inbounds nuw i8, ptr %0, i64 252
  %308 = load i64, ptr %307, align 4
  %309 = icmp eq i64 %308, 0
  br i1 %309, label %368, label %310

310:                                              ; preds = %305
  %311 = trunc nuw i8 %306 to i1
  %312 = select i1 %311, ptr @.str.15, ptr @.str.26
  %313 = load ptr, ptr %7, align 8, !tbaa !257
  %314 = load ptr, ptr %9, align 8, !tbaa !258
  %315 = ptrtoint ptr %313 to i64
  %316 = ptrtoint ptr %314 to i64
  %317 = sub i64 %315, %316
  %318 = icmp ult i64 %317, 2
  br i1 %318, label %319, label %322

319:                                              ; preds = %310
  %320 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %312, i64 noundef 2) #33
  %321 = load ptr, ptr %9, align 8, !tbaa !258
  br label %326

322:                                              ; preds = %310
  %323 = load i16, ptr %312, align 1
  store i16 %323, ptr %314, align 1
  %324 = load ptr, ptr %9, align 8, !tbaa !258
  %325 = getelementptr inbounds nuw i8, ptr %324, i64 2
  store ptr %325, ptr %9, align 8, !tbaa !258
  br label %326

326:                                              ; preds = %319, %322
  %327 = phi ptr [ %321, %319 ], [ %325, %322 ]
  %328 = load ptr, ptr %7, align 8, !tbaa !257
  %329 = ptrtoint ptr %328 to i64
  %330 = ptrtoint ptr %327 to i64
  %331 = sub i64 %329, %330
  %332 = icmp ult i64 %331, 11
  br i1 %332, label %333, label %335

333:                                              ; preds = %326
  %334 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.34, i64 noundef 11) #33
  br label %338

335:                                              ; preds = %326
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(11) %327, ptr noundef nonnull align 1 dereferenceable(11) @.str.34, i64 11, i1 false)
  %336 = load ptr, ptr %9, align 8, !tbaa !258
  %337 = getelementptr inbounds nuw i8, ptr %336, i64 11
  store ptr %337, ptr %9, align 8, !tbaa !258
  br label %338

338:                                              ; preds = %333, %335
  %339 = load i64, ptr %307, align 4
  %340 = trunc i64 %339 to i32
  switch i32 %340, label %365 [
    i32 1, label %341
    i32 2, label %353
  ]

341:                                              ; preds = %338
  %342 = load ptr, ptr %7, align 8, !tbaa !257
  %343 = load ptr, ptr %9, align 8, !tbaa !258
  %344 = ptrtoint ptr %342 to i64
  %345 = ptrtoint ptr %343 to i64
  %346 = sub i64 %344, %345
  %347 = icmp ult i64 %346, 9
  br i1 %347, label %348, label %350

348:                                              ; preds = %341
  %349 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.35, i64 noundef 9) #33
  br label %368

350:                                              ; preds = %341
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %343, ptr noundef nonnull align 1 dereferenceable(9) @.str.35, i64 9, i1 false)
  %351 = load ptr, ptr %9, align 8, !tbaa !258
  %352 = getelementptr inbounds nuw i8, ptr %351, i64 9
  store ptr %352, ptr %9, align 8, !tbaa !258
  br label %368

353:                                              ; preds = %338
  %354 = load ptr, ptr %7, align 8, !tbaa !257
  %355 = load ptr, ptr %9, align 8, !tbaa !258
  %356 = ptrtoint ptr %354 to i64
  %357 = ptrtoint ptr %355 to i64
  %358 = sub i64 %356, %357
  %359 = icmp ult i64 %358, 4
  br i1 %359, label %360, label %362

360:                                              ; preds = %353
  %361 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.36, i64 noundef 4) #33
  br label %368

362:                                              ; preds = %353
  store i32 1684827971, ptr %355, align 1
  %363 = load ptr, ptr %9, align 8, !tbaa !258
  %364 = getelementptr inbounds nuw i8, ptr %363, i64 4
  store ptr %364, ptr %9, align 8, !tbaa !258
  br label %368

365:                                              ; preds = %338
  %366 = lshr i64 %339, 32
  %367 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEm(ptr noundef nonnull align 8 dereferenceable(48) %1, i64 noundef %366) #33
  br label %368

368:                                              ; preds = %362, %360, %350, %348, %365, %305
  %369 = phi i8 [ %306, %305 ], [ 1, %365 ], [ 1, %348 ], [ 1, %350 ], [ 1, %360 ], [ 1, %362 ]
  %370 = getelementptr inbounds nuw i8, ptr %0, i64 240
  %371 = getelementptr inbounds nuw i8, ptr %0, i64 248
  %372 = load i8, ptr %371, align 8
  %373 = trunc nuw i8 %372 to i1
  br i1 %373, label %374, label %423

374:                                              ; preds = %368
  %375 = trunc nuw i8 %369 to i1
  %376 = select i1 %375, ptr @.str.15, ptr @.str.26
  %377 = load ptr, ptr %7, align 8, !tbaa !257
  %378 = load ptr, ptr %9, align 8, !tbaa !258
  %379 = ptrtoint ptr %377 to i64
  %380 = ptrtoint ptr %378 to i64
  %381 = sub i64 %379, %380
  %382 = icmp ult i64 %381, 2
  br i1 %382, label %383, label %386

383:                                              ; preds = %374
  %384 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %376, i64 noundef 2) #33
  %385 = load ptr, ptr %9, align 8, !tbaa !258
  br label %390

386:                                              ; preds = %374
  %387 = load i16, ptr %376, align 1
  store i16 %387, ptr %378, align 1
  %388 = load ptr, ptr %9, align 8, !tbaa !258
  %389 = getelementptr inbounds nuw i8, ptr %388, i64 2
  store ptr %389, ptr %9, align 8, !tbaa !258
  br label %390

390:                                              ; preds = %383, %386
  %391 = phi ptr [ %385, %383 ], [ %389, %386 ]
  %392 = load ptr, ptr %7, align 8, !tbaa !257
  %393 = ptrtoint ptr %392 to i64
  %394 = ptrtoint ptr %391 to i64
  %395 = sub i64 %393, %394
  %396 = icmp ult i64 %395, 6
  br i1 %396, label %397, label %399

397:                                              ; preds = %390
  %398 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.37, i64 noundef 6) #33
  br label %402

399:                                              ; preds = %390
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) %391, ptr noundef nonnull align 1 dereferenceable(6) @.str.37, i64 6, i1 false)
  %400 = load ptr, ptr %9, align 8, !tbaa !258
  %401 = getelementptr inbounds nuw i8, ptr %400, i64 6
  store ptr %401, ptr %9, align 8, !tbaa !258
  br label %402

402:                                              ; preds = %397, %399
  %403 = phi ptr [ %398, %397 ], [ %1, %399 ]
  %404 = load i64, ptr %370, align 8
  %405 = and i64 %404, 4294967295
  %406 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEm(ptr noundef nonnull align 8 dereferenceable(48) %403, i64 noundef %405) #33
  %407 = load i64, ptr %370, align 8
  %408 = icmp ult i64 %407, 4294967296
  br i1 %408, label %423, label %409

409:                                              ; preds = %402
  %410 = load ptr, ptr %7, align 8, !tbaa !257
  %411 = load ptr, ptr %9, align 8, !tbaa !258
  %412 = icmp eq ptr %410, %411
  br i1 %412, label %413, label %415

413:                                              ; preds = %409
  %414 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.38, i64 noundef 1) #33
  br label %418

415:                                              ; preds = %409
  store i8 32, ptr %411, align 1
  %416 = load ptr, ptr %9, align 8, !tbaa !258
  %417 = getelementptr inbounds nuw i8, ptr %416, i64 1
  store ptr %417, ptr %9, align 8, !tbaa !258
  br label %418

418:                                              ; preds = %413, %415
  %419 = phi ptr [ %414, %413 ], [ %1, %415 ]
  %420 = load i64, ptr %370, align 8
  %421 = lshr i64 %420, 32
  %422 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEm(ptr noundef nonnull align 8 dereferenceable(48) %419, i64 noundef %421) #33
  br label %423

423:                                              ; preds = %402, %418, %368
  %424 = phi i8 [ %369, %368 ], [ 1, %418 ], [ 1, %402 ]
  %425 = getelementptr inbounds nuw i8, ptr %0, i64 28
  %426 = load i32, ptr %425, align 4, !tbaa !73
  %427 = icmp eq i32 %426, 0
  br i1 %427, label %461, label %428

428:                                              ; preds = %423
  %429 = trunc nuw i8 %424 to i1
  %430 = select i1 %429, ptr @.str.15, ptr @.str.26
  %431 = load ptr, ptr %7, align 8, !tbaa !257
  %432 = load ptr, ptr %9, align 8, !tbaa !258
  %433 = ptrtoint ptr %431 to i64
  %434 = ptrtoint ptr %432 to i64
  %435 = sub i64 %433, %434
  %436 = icmp ult i64 %435, 2
  br i1 %436, label %437, label %440

437:                                              ; preds = %428
  %438 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull %430, i64 noundef 2) #33
  %439 = load ptr, ptr %9, align 8, !tbaa !258
  br label %444

440:                                              ; preds = %428
  %441 = load i16, ptr %430, align 1
  store i16 %441, ptr %432, align 1
  %442 = load ptr, ptr %9, align 8, !tbaa !258
  %443 = getelementptr inbounds nuw i8, ptr %442, i64 2
  store ptr %443, ptr %9, align 8, !tbaa !258
  br label %444

444:                                              ; preds = %437, %440
  %445 = phi ptr [ %439, %437 ], [ %443, %440 ]
  %446 = load ptr, ptr %7, align 8, !tbaa !257
  %447 = ptrtoint ptr %446 to i64
  %448 = ptrtoint ptr %445 to i64
  %449 = sub i64 %447, %448
  %450 = icmp ult i64 %449, 16
  br i1 %450, label %451, label %453

451:                                              ; preds = %444
  %452 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.39, i64 noundef 16) #33
  br label %456

453:                                              ; preds = %444
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(16) %445, ptr noundef nonnull align 1 dereferenceable(16) @.str.39, i64 16, i1 false)
  %454 = load ptr, ptr %9, align 8, !tbaa !258
  %455 = getelementptr inbounds nuw i8, ptr %454, i64 16
  store ptr %455, ptr %9, align 8, !tbaa !258
  br label %456

456:                                              ; preds = %453, %451
  %457 = phi ptr [ %452, %451 ], [ %1, %453 ]
  %458 = load i32, ptr %425, align 4, !tbaa !73
  %459 = zext i32 %458 to i64
  %460 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEm(ptr noundef nonnull align 8 dereferenceable(48) %457, i64 noundef %459) #33
  br label %464

461:                                              ; preds = %423, %63
  %462 = phi i8 [ %424, %423 ], [ %64, %63 ]
  %463 = trunc nuw i8 %462 to i1
  br i1 %463, label %464, label %472

464:                                              ; preds = %456, %461
  %465 = load ptr, ptr %9, align 8, !tbaa !258
  %466 = load ptr, ptr %7, align 8, !tbaa !257
  %467 = icmp ult ptr %465, %466
  br i1 %467, label %470, label %468

468:                                              ; preds = %464
  %469 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 41) #33
  br label %472

470:                                              ; preds = %464
  %471 = getelementptr inbounds nuw i8, ptr %465, i64 1
  store ptr %471, ptr %9, align 8, !tbaa !258
  store i8 41, ptr %465, align 1, !tbaa !212
  br label %472

472:                                              ; preds = %470, %468, %461
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %6) #33
  ret void
}

declare noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream6indentEj(ptr noundef nonnull align 8 dereferenceable(48), i32 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nofree norecurse nosync nounwind memory(read, inaccessiblemem: write) uwtable
define dso_local i32 @_ZNK4llvm17MachineBasicBlock18getSuccProbabilityEPKPS0_(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr noundef %1) local_unnamed_addr #11 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %4 = load ptr, ptr %3, align 8, !tbaa !345
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %6 = load ptr, ptr %5, align 8, !tbaa !345
  %7 = icmp eq ptr %4, %6
  br i1 %7, label %8, label %16

8:                                                ; preds = %2
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %10 = load i32, ptr %9, align 8, !tbaa !76
  %11 = icmp eq i32 %10, -2147483648
  br i1 %11, label %55, label %12

12:                                               ; preds = %8
  %13 = lshr i32 %10, 1
  %14 = or disjoint i32 %13, -2147483648
  %15 = udiv i32 %14, %10
  br label %55

16:                                               ; preds = %2
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %18 = load ptr, ptr %17, align 8, !tbaa !19
  %19 = ptrtoint ptr %1 to i64
  %20 = ptrtoint ptr %18 to i64
  %21 = sub i64 %19, %20
  %22 = ashr exact i64 %21, 1
  %23 = getelementptr inbounds i8, ptr %4, i64 %22
  %24 = load i32, ptr %23, align 4, !tbaa !349
  %25 = icmp eq i32 %24, -1
  br i1 %25, label %36, label %55

26:                                               ; preds = %50
  %27 = sub i32 -2147483648, %51
  %28 = ptrtoint ptr %6 to i64
  %29 = ptrtoint ptr %4 to i64
  %30 = sub i64 %28, %29
  %31 = ashr exact i64 %30, 2
  %32 = icmp sgt i64 %31, -1
  tail call void @llvm.assume(i1 %32)
  %33 = trunc i64 %31 to i32
  %34 = sub i32 %33, %52
  %35 = udiv i32 %27, %34
  br label %55

36:                                               ; preds = %16, %50
  %37 = phi i32 [ %52, %50 ], [ 0, %16 ]
  %38 = phi i32 [ %51, %50 ], [ 0, %16 ]
  %39 = phi ptr [ %53, %50 ], [ %4, %16 ]
  %40 = load i32, ptr %39, align 4, !tbaa !349
  %41 = icmp eq i32 %40, -1
  br i1 %41, label %50, label %42

42:                                               ; preds = %36
  %43 = zext i32 %38 to i64
  %44 = zext i32 %40 to i64
  %45 = add nuw nsw i64 %44, %43
  %46 = icmp samesign ugt i64 %45, 2147483648
  %47 = add i32 %40, %38
  %48 = select i1 %46, i32 -2147483648, i32 %47
  %49 = add i32 %37, 1
  br label %50

50:                                               ; preds = %42, %36
  %51 = phi i32 [ %38, %36 ], [ %48, %42 ]
  %52 = phi i32 [ %37, %36 ], [ %49, %42 ]
  %53 = getelementptr inbounds nuw i8, ptr %39, i64 4
  %54 = icmp eq ptr %53, %6
  br i1 %54, label %26, label %36

55:                                               ; preds = %16, %12, %8, %26
  %56 = phi i32 [ %35, %26 ], [ %15, %12 ], [ 1, %8 ], [ %24, %16 ]
  ret i32 %56
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.rint.f64(double) #12

declare void @_ZN4llvm8printRegENS_8RegisterEPKNS_18TargetRegisterInfoEjPKNS_19MachineRegisterInfoE(ptr dead_on_unwind writable sret(%"class.llvm::Printable") align 8, i32, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden i64 @_ZNK4llvm11SlotIndexes19getInstructionIndexERKNS_12MachineInstrEb(ptr noundef nonnull align 8 dereferenceable(416) %0, ptr noundef nonnull align 8 dereferenceable(80) %1, i1 noundef zeroext %2) local_unnamed_addr #3 comdat align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 44
  %5 = load i32, ptr %4, align 4, !tbaa !309
  %6 = and i32 %5, 4
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %17, label %8

8:                                                ; preds = %3, %8
  %9 = phi ptr [ %12, %8 ], [ %1, %3 ]
  %10 = load i64, ptr %9, align 8
  %11 = and i64 %10, -8
  %12 = inttoptr i64 %11 to ptr
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 44
  %14 = load i32, ptr %13, align 4, !tbaa !309
  %15 = and i32 %14, 4
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %8, !llvm.loop !494

17:                                               ; preds = %8, %3
  %18 = phi ptr [ %1, %3 ], [ %12, %8 ]
  %19 = and i32 %5, 8
  %20 = icmp eq i32 %19, 0
  br i1 %20, label %29, label %21

21:                                               ; preds = %17, %21
  %22 = phi ptr [ %24, %21 ], [ %1, %17 ]
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 8
  %24 = load ptr, ptr %23, align 8, !tbaa !75
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 44
  %26 = load i32, ptr %25, align 4, !tbaa !309
  %27 = and i32 %26, 8
  %28 = icmp eq i32 %27, 0
  br i1 %28, label %29, label %21, !llvm.loop !495

29:                                               ; preds = %21, %17
  %30 = phi ptr [ %1, %17 ], [ %24, %21 ]
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 8
  %32 = load ptr, ptr %31, align 8, !tbaa !75
  br i1 %2, label %43, label %33

33:                                               ; preds = %29
  %34 = icmp eq ptr %18, %32
  br i1 %34, label %43, label %35

35:                                               ; preds = %33, %39
  %36 = phi ptr [ %41, %39 ], [ %18, %33 ]
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 52
  %38 = load i32, ptr %37, align 4, !tbaa !306
  switch i32 %38, label %43 [
    i32 25, label %39
    i32 18, label %39
    i32 17, label %39
    i32 16, label %39
    i32 15, label %39
    i32 14, label %39
  ]

39:                                               ; preds = %35, %35, %35, %35, %35, %35
  %40 = getelementptr inbounds nuw i8, ptr %36, i64 8
  %41 = load ptr, ptr %40, align 8, !tbaa !75
  %42 = icmp eq ptr %41, %32
  br i1 %42, label %43, label %35, !llvm.loop !496

43:                                               ; preds = %35, %39, %33, %29
  %44 = phi ptr [ %1, %29 ], [ %18, %33 ], [ %32, %39 ], [ %36, %35 ]
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 104
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %47 = load i32, ptr %46, align 8, !tbaa !469, !noalias !497
  %48 = icmp eq i32 %47, 0
  %49 = load ptr, ptr %45, align 8, !tbaa !472, !noalias !502
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %51 = load ptr, ptr %50, align 8, !tbaa !478, !noalias !497
  %52 = getelementptr inbounds nuw i8, ptr %0, i64 124
  %53 = load i32, ptr %52, align 4, !tbaa !479, !noalias !497
  br i1 %48, label %87, label %54

54:                                               ; preds = %43
  %55 = add i32 %53, -1
  %56 = ptrtoint ptr %44 to i64
  %57 = mul i64 %56, -4658895280553007687
  %58 = lshr i64 %57, 31
  %59 = xor i64 %58, %57
  %60 = trunc i64 %59 to i32
  %61 = and i32 %55, %60
  %62 = zext i32 %61 to i64
  %63 = lshr i64 %62, 5
  %64 = getelementptr inbounds nuw i32, ptr %51, i64 %63
  %65 = load i32, ptr %64, align 4, !tbaa !451, !noalias !497
  %66 = and i32 %61, 31
  %67 = shl nuw i32 1, %66
  %68 = and i32 %65, %67
  %69 = icmp eq i32 %68, 0
  br i1 %69, label %87, label %70, !prof !480

70:                                               ; preds = %54, %76
  %71 = phi i64 [ %79, %76 ], [ %62, %54 ]
  %72 = phi i32 [ %78, %76 ], [ %61, %54 ]
  %73 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %49, i64 %71
  %74 = load ptr, ptr %73, align 8, !tbaa !481, !noalias !497
  %75 = icmp eq ptr %44, %74
  br i1 %75, label %89, label %76, !prof !483

76:                                               ; preds = %70
  %77 = add i32 %72, 1
  %78 = and i32 %77, %55
  %79 = zext i32 %78 to i64
  %80 = lshr i64 %79, 5
  %81 = getelementptr inbounds nuw i32, ptr %51, i64 %80
  %82 = load i32, ptr %81, align 4, !tbaa !451, !noalias !497
  %83 = and i32 %78, 31
  %84 = shl nuw i32 1, %83
  %85 = and i32 %82, %84
  %86 = icmp eq i32 %85, 0
  br i1 %86, label %87, label %70, !prof !484

87:                                               ; preds = %76, %54, %43
  %88 = zext i32 %53 to i64
  br label %89

89:                                               ; preds = %70, %87
  %90 = phi i64 [ %88, %87 ], [ %71, %70 ]
  %91 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %49, i64 %90, i32 1
  %92 = load i64, ptr %91, align 8, !tbaa !212
  ret i64 %92
}

declare void @_ZNK4llvm12MachineInstr5printERNS_11raw_ostreamERNS_17ModuleSlotTrackerEbbbbPKNS_15TargetInstrInfoE(ptr noundef nonnull align 8 dereferenceable(80), ptr noundef nonnull align 8 dereferenceable(48), ptr noundef nonnull align 8 dereferenceable(112), i1 noundef zeroext, i1 noundef zeroext, i1 noundef zeroext, i1 noundef zeroext, ptr noundef) local_unnamed_addr #4

declare noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEm(ptr noundef nonnull align 8 dereferenceable(48), i64 noundef) local_unnamed_addr #4

declare void @_ZN4llvm26printLLVMNameWithoutPrefixERNS_11raw_ostreamENS_9StringRefE(ptr noundef nonnull align 8 dereferenceable(48), ptr, i64) local_unnamed_addr #4

; Function Attrs: inlinehint mustprogress nounwind uwtable
define internal fastcc void @"_ZZNK4llvm17MachineBasicBlock9printNameERNS_11raw_ostreamEjPNS_17ModuleSlotTrackerEENK3$_0clEPKNS_10BasicBlockE"(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(16) %0, ptr noundef %1) unnamed_addr #1 align 2 {
  %3 = alloca %"class.llvm::ModuleSlotTracker", align 8
  %4 = load ptr, ptr %0, align 8, !tbaa !505, !nonnull !17, !align !200
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 24
  %6 = load ptr, ptr %5, align 8, !tbaa !257
  %7 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %8 = load ptr, ptr %7, align 8, !tbaa !258
  %9 = ptrtoint ptr %6 to i64
  %10 = ptrtoint ptr %8 to i64
  %11 = sub i64 %9, %10
  %12 = icmp ult i64 %11, 10
  br i1 %12, label %13, label %15

13:                                               ; preds = %2
  %14 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %4, ptr noundef nonnull @.str.45, i64 noundef 10) #33
  br label %18

15:                                               ; preds = %2
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(10) %8, ptr noundef nonnull align 1 dereferenceable(10) @.str.45, i64 10, i1 false)
  %16 = load ptr, ptr %7, align 8, !tbaa !258
  %17 = getelementptr inbounds nuw i8, ptr %16, i64 10
  store ptr %17, ptr %7, align 8, !tbaa !258
  br label %18

18:                                               ; preds = %13, %15
  %19 = getelementptr inbounds nuw i8, ptr %1, i64 4
  %20 = load i32, ptr %19, align 4
  %21 = and i32 %20, 536870912
  %22 = icmp eq i32 %21, 0
  br i1 %22, label %28, label %23

23:                                               ; preds = %18
  %24 = load ptr, ptr %0, align 8, !tbaa !505, !nonnull !17, !align !200
  %25 = tail call { ptr, i64 } @_ZNK4llvm5Value7getNameEv(ptr noundef nonnull align 8 dereferenceable(24) %1) #33
  %26 = extractvalue { ptr, i64 } %25, 0
  %27 = extractvalue { ptr, i64 } %25, 1
  tail call void @_ZN4llvm26printLLVMNameWithoutPrefixERNS_11raw_ostreamENS_9StringRefE(ptr noundef nonnull align 8 dereferenceable(48) %24, ptr %26, i64 %27) #33
  br label %65

28:                                               ; preds = %18
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %30 = load ptr, ptr %29, align 8, !tbaa !507, !nonnull !17, !align !200
  %31 = load ptr, ptr %30, align 8, !tbaa !485
  %32 = icmp eq ptr %31, null
  br i1 %32, label %35, label %33

33:                                               ; preds = %28
  %34 = tail call noundef i32 @_ZN4llvm17ModuleSlotTracker12getLocalSlotEPKNS_5ValueE(ptr noundef nonnull align 8 dereferenceable(112) %31, ptr noundef nonnull %1) #33
  br label %43

35:                                               ; preds = %28
  %36 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %37 = load ptr, ptr %36, align 8, !tbaa !508
  %38 = icmp eq ptr %37, null
  br i1 %38, label %46, label %39

39:                                               ; preds = %35
  call void @llvm.lifetime.start.p0(i64 112, ptr nonnull %3) #33
  %40 = tail call noundef ptr @_ZNK4llvm10BasicBlock9getModuleEv(ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  call void @_ZN4llvm17ModuleSlotTrackerC1EPKNS_6ModuleE(ptr noundef nonnull align 8 dereferenceable(112) %3, ptr noundef %40) #33
  %41 = load ptr, ptr %36, align 8, !tbaa !508
  call void @_ZN4llvm17ModuleSlotTracker19incorporateFunctionERKNS_8FunctionE(ptr noundef nonnull align 8 dereferenceable(112) %3, ptr noundef nonnull align 8 dereferenceable(140) %41) #33
  %42 = call noundef i32 @_ZN4llvm17ModuleSlotTracker12getLocalSlotEPKNS_5ValueE(ptr noundef nonnull align 8 dereferenceable(112) %3, ptr noundef nonnull %1) #33
  call void @_ZN4llvm17ModuleSlotTrackerD1Ev(ptr noundef nonnull align 8 dereferenceable(112) %3) #33
  call void @llvm.lifetime.end.p0(i64 112, ptr nonnull %3) #33
  br label %43

43:                                               ; preds = %39, %33
  %44 = phi i32 [ %34, %33 ], [ %42, %39 ]
  %45 = icmp eq i32 %44, -1
  br i1 %45, label %46, label %61

46:                                               ; preds = %35, %43
  %47 = load ptr, ptr %0, align 8, !tbaa !505, !nonnull !17, !align !200
  %48 = getelementptr inbounds nuw i8, ptr %47, i64 24
  %49 = load ptr, ptr %48, align 8, !tbaa !257
  %50 = getelementptr inbounds nuw i8, ptr %47, i64 32
  %51 = load ptr, ptr %50, align 8, !tbaa !258
  %52 = ptrtoint ptr %49 to i64
  %53 = ptrtoint ptr %51 to i64
  %54 = sub i64 %52, %53
  %55 = icmp ult i64 %54, 17
  br i1 %55, label %56, label %58

56:                                               ; preds = %46
  %57 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %47, ptr noundef nonnull @.str.46, i64 noundef 17) #33
  br label %65

58:                                               ; preds = %46
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(17) %51, ptr noundef nonnull align 1 dereferenceable(17) @.str.46, i64 17, i1 false)
  %59 = load ptr, ptr %50, align 8, !tbaa !258
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 17
  store ptr %60, ptr %50, align 8, !tbaa !258
  br label %65

61:                                               ; preds = %43
  %62 = load ptr, ptr %0, align 8, !tbaa !505, !nonnull !17, !align !200
  %63 = sext i32 %44 to i64
  %64 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEl(ptr noundef nonnull align 8 dereferenceable(48) %62, i64 noundef %63) #33
  br label %65

65:                                               ; preds = %58, %56, %61, %23
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZNK4llvm17MachineBasicBlock14printAsOperandERNS_11raw_ostreamEb(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(48) %1, i1 noundef zeroext %2) local_unnamed_addr #3 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %5 = load ptr, ptr %4, align 8, !tbaa !258
  %6 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %7 = load ptr, ptr %6, align 8, !tbaa !257
  %8 = icmp ult ptr %5, %7
  br i1 %8, label %11, label %9

9:                                                ; preds = %3
  %10 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 37) #33
  br label %13

11:                                               ; preds = %3
  %12 = getelementptr inbounds nuw i8, ptr %5, i64 1
  store ptr %12, ptr %4, align 8, !tbaa !258
  store i8 37, ptr %5, align 1, !tbaa !212
  br label %13

13:                                               ; preds = %9, %11
  %14 = load ptr, ptr %6, align 8, !tbaa !257
  %15 = load ptr, ptr %4, align 8, !tbaa !258
  %16 = ptrtoint ptr %14 to i64
  %17 = ptrtoint ptr %15 to i64
  %18 = sub i64 %16, %17
  %19 = icmp ult i64 %18, 3
  br i1 %19, label %20, label %22

20:                                               ; preds = %13
  %21 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.25, i64 noundef 3) #33
  br label %25

22:                                               ; preds = %13
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %15, ptr noundef nonnull align 1 dereferenceable(3) @.str.25, i64 3, i1 false)
  %23 = load ptr, ptr %4, align 8, !tbaa !258
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 3
  store ptr %24, ptr %4, align 8, !tbaa !258
  br label %25

25:                                               ; preds = %20, %22
  %26 = phi ptr [ %21, %20 ], [ %1, %22 ]
  %27 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %28 = load i32, ptr %27, align 8, !tbaa !72
  %29 = sext i32 %28 to i64
  %30 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEl(ptr noundef nonnull align 8 dereferenceable(48) %26, i64 noundef %29) #33
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock12removeLiveInENS_10MCRegisterENS_11LaneBitmaskE(ptr noundef nonnull align 8 captures(none) dereferenceable(288) %0, i32 %1, i64 %2) local_unnamed_addr #9 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %5 = load ptr, ptr %4, align 8, !tbaa !379
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 192
  %7 = load ptr, ptr %6, align 8, !tbaa !379
  %8 = icmp eq ptr %5, %7
  br i1 %8, label %34, label %9

9:                                                ; preds = %3, %31
  %10 = phi ptr [ %32, %31 ], [ %5, %3 ]
  %11 = load i32, ptr %10, align 4, !tbaa !522
  %12 = icmp eq i32 %11, %1
  br i1 %12, label %34, label %13

13:                                               ; preds = %9
  %14 = getelementptr inbounds nuw i8, ptr %10, i64 16
  %15 = icmp eq ptr %14, %7
  br i1 %15, label %34, label %16, !llvm.loop !524

16:                                               ; preds = %13
  %17 = load i32, ptr %14, align 4, !tbaa !522
  %18 = icmp eq i32 %17, %1
  br i1 %18, label %34, label %19

19:                                               ; preds = %16
  %20 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %21 = icmp eq ptr %20, %7
  br i1 %21, label %34, label %22, !llvm.loop !524

22:                                               ; preds = %19
  %23 = load i32, ptr %20, align 4, !tbaa !522
  %24 = icmp eq i32 %23, %1
  br i1 %24, label %34, label %25

25:                                               ; preds = %22
  %26 = getelementptr inbounds nuw i8, ptr %10, i64 48
  %27 = icmp eq ptr %26, %7
  br i1 %27, label %34, label %28, !llvm.loop !524

28:                                               ; preds = %25
  %29 = load i32, ptr %26, align 4, !tbaa !522
  %30 = icmp eq i32 %29, %1
  br i1 %30, label %34, label %31

31:                                               ; preds = %28
  %32 = getelementptr inbounds nuw i8, ptr %10, i64 64
  %33 = icmp eq ptr %32, %7
  br i1 %33, label %34, label %9, !llvm.loop !525

34:                                               ; preds = %9, %13, %16, %19, %22, %25, %28, %31, %3
  %35 = phi ptr [ %5, %3 ], [ %10, %9 ], [ %14, %13 ], [ %14, %16 ], [ %20, %19 ], [ %20, %22 ], [ %26, %25 ], [ %26, %28 ], [ %32, %31 ]
  %36 = icmp eq ptr %35, %7
  br i1 %36, label %62, label %37

37:                                               ; preds = %34
  %38 = xor i64 %2, -1
  %39 = getelementptr inbounds nuw i8, ptr %35, i64 8
  %40 = load i64, ptr %39, align 8, !tbaa !452
  %41 = and i64 %40, %38
  store i64 %41, ptr %39, align 8, !tbaa !452
  %42 = icmp eq i64 %41, 0
  br i1 %42, label %43, label %62

43:                                               ; preds = %37
  %44 = ptrtoint ptr %35 to i64
  %45 = ptrtoint ptr %5 to i64
  %46 = sub i64 %44, %45
  %47 = getelementptr inbounds i8, ptr %5, i64 %46
  %48 = getelementptr inbounds nuw i8, ptr %47, i64 16
  %49 = icmp eq ptr %48, %7
  br i1 %49, label %59, label %50

50:                                               ; preds = %43
  %51 = ptrtoint ptr %7 to i64
  %52 = ptrtoint ptr %48 to i64
  %53 = sub i64 %51, %52
  %54 = icmp sgt i64 %53, 16
  br i1 %54, label %55, label %56, !prof !483

55:                                               ; preds = %50
  tail call void @llvm.memmove.p0.p0.i64(ptr align 8 %47, ptr nonnull align 8 %48, i64 %53, i1 false)
  br label %59

56:                                               ; preds = %50
  %57 = icmp eq i64 %53, 16
  br i1 %57, label %58, label %59

58:                                               ; preds = %56
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %47, ptr noundef nonnull align 8 dereferenceable(16) %48, i64 16, i1 false), !tbaa.struct !526
  br label %59

59:                                               ; preds = %43, %55, %56, %58
  %60 = load ptr, ptr %6, align 8, !tbaa !527
  %61 = getelementptr inbounds i8, ptr %60, i64 -16
  store ptr %61, ptr %6, align 8, !tbaa !527
  br label %62

62:                                               ; preds = %37, %59, %34
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock26removeLiveInOverlappedWithENS_10MCRegisterE(ptr noundef nonnull align 8 captures(none) dereferenceable(288) %0, i32 %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %4 = load ptr, ptr %3, align 8, !tbaa !74
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 16
  %6 = load ptr, ptr %5, align 8, !tbaa !308, !nonnull !17, !align !200
  %7 = load ptr, ptr %6, align 8, !tbaa !4
  %8 = getelementptr inbounds nuw i8, ptr %7, i64 192
  %9 = load ptr, ptr %8, align 8
  %10 = tail call noundef ptr %9(ptr noundef nonnull align 8 dereferenceable(368) %6) #33
  %11 = getelementptr inbounds nuw i8, ptr %10, i64 56
  %12 = load ptr, ptr %11, align 8, !tbaa !528, !noalias !542, !nonnull !17, !noundef !17
  %13 = getelementptr inbounds nuw i8, ptr %10, i64 8
  %14 = zext i32 %1 to i64
  %15 = load ptr, ptr %13, align 8, !tbaa !545, !noalias !546
  %16 = getelementptr inbounds nuw %"struct.llvm::MCRegisterDesc", ptr %15, i64 %14, i32 1
  %17 = load i32, ptr %16, align 4, !tbaa !549, !noalias !542
  %18 = zext i32 %17 to i64
  %19 = getelementptr inbounds nuw i16, ptr %12, i64 %18
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 192
  %22 = load ptr, ptr %21, align 8, !tbaa !379
  br label %39

23:                                               ; preds = %94
  %24 = load ptr, ptr %11, align 8, !tbaa !528, !noalias !546
  %25 = load ptr, ptr %13, align 8, !tbaa !545, !noalias !546
  %26 = getelementptr inbounds nuw %"struct.llvm::MCRegisterDesc", ptr %25, i64 %14, i32 2
  %27 = load i32, ptr %26, align 4, !tbaa !551, !noalias !546
  %28 = zext i32 %27 to i64
  %29 = getelementptr inbounds nuw i16, ptr %24, i64 %28
  %30 = load i16, ptr %29, align 2, !tbaa !552, !noalias !546
  %31 = icmp eq i16 %30, 0
  br i1 %31, label %101, label %32

32:                                               ; preds = %23
  %33 = zext i16 %30 to i32
  %34 = add i32 %1, %33
  %35 = getelementptr inbounds nuw i8, ptr %10, i64 88
  %36 = getelementptr inbounds nuw i8, ptr %10, i64 280
  %37 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 192
  br label %102

39:                                               ; preds = %2, %94
  %40 = phi ptr [ %22, %2 ], [ %95, %94 ]
  %41 = phi ptr [ %19, %2 ], [ %96, %94 ]
  %42 = phi i32 [ %1, %2 ], [ %99, %94 ]
  %43 = and i32 %42, 65535
  %44 = load ptr, ptr %20, align 8, !tbaa !379
  %45 = icmp eq ptr %44, %40
  br i1 %45, label %71, label %46

46:                                               ; preds = %39, %68
  %47 = phi ptr [ %69, %68 ], [ %44, %39 ]
  %48 = load i32, ptr %47, align 4, !tbaa !522
  %49 = icmp eq i32 %48, %43
  br i1 %49, label %71, label %50

50:                                               ; preds = %46
  %51 = getelementptr inbounds nuw i8, ptr %47, i64 16
  %52 = icmp eq ptr %51, %40
  br i1 %52, label %71, label %53, !llvm.loop !524

53:                                               ; preds = %50
  %54 = load i32, ptr %51, align 4, !tbaa !522
  %55 = icmp eq i32 %54, %43
  br i1 %55, label %71, label %56

56:                                               ; preds = %53
  %57 = getelementptr inbounds nuw i8, ptr %47, i64 32
  %58 = icmp eq ptr %57, %40
  br i1 %58, label %71, label %59, !llvm.loop !524

59:                                               ; preds = %56
  %60 = load i32, ptr %57, align 4, !tbaa !522
  %61 = icmp eq i32 %60, %43
  br i1 %61, label %71, label %62

62:                                               ; preds = %59
  %63 = getelementptr inbounds nuw i8, ptr %47, i64 48
  %64 = icmp eq ptr %63, %40
  br i1 %64, label %71, label %65, !llvm.loop !524

65:                                               ; preds = %62
  %66 = load i32, ptr %63, align 4, !tbaa !522
  %67 = icmp eq i32 %66, %43
  br i1 %67, label %71, label %68

68:                                               ; preds = %65
  %69 = getelementptr inbounds nuw i8, ptr %47, i64 64
  %70 = icmp eq ptr %69, %40
  br i1 %70, label %71, label %46, !llvm.loop !525

71:                                               ; preds = %68, %65, %62, %59, %56, %53, %50, %46, %39
  %72 = phi ptr [ %44, %39 ], [ %69, %68 ], [ %63, %65 ], [ %63, %62 ], [ %57, %59 ], [ %57, %56 ], [ %51, %53 ], [ %51, %50 ], [ %47, %46 ]
  %73 = icmp eq ptr %72, %40
  br i1 %73, label %94, label %74

74:                                               ; preds = %71
  %75 = getelementptr inbounds nuw i8, ptr %72, i64 8
  store i64 0, ptr %75, align 8, !tbaa !452
  %76 = ptrtoint ptr %72 to i64
  %77 = ptrtoint ptr %44 to i64
  %78 = sub i64 %76, %77
  %79 = getelementptr inbounds i8, ptr %44, i64 %78
  %80 = getelementptr inbounds nuw i8, ptr %79, i64 16
  %81 = icmp eq ptr %80, %40
  br i1 %81, label %91, label %82

82:                                               ; preds = %74
  %83 = ptrtoint ptr %40 to i64
  %84 = ptrtoint ptr %80 to i64
  %85 = sub i64 %83, %84
  %86 = icmp sgt i64 %85, 16
  br i1 %86, label %87, label %88, !prof !483

87:                                               ; preds = %82
  tail call void @llvm.memmove.p0.p0.i64(ptr align 8 %79, ptr nonnull align 8 %80, i64 %85, i1 false)
  br label %91

88:                                               ; preds = %82
  %89 = icmp eq i64 %85, 16
  br i1 %89, label %90, label %91

90:                                               ; preds = %88
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %79, ptr noundef nonnull align 8 dereferenceable(16) %80, i64 16, i1 false), !tbaa.struct !526
  br label %91

91:                                               ; preds = %90, %88, %87, %74
  %92 = load ptr, ptr %21, align 8, !tbaa !527
  %93 = getelementptr inbounds i8, ptr %92, i64 -16
  store ptr %93, ptr %21, align 8, !tbaa !527
  br label %94

94:                                               ; preds = %71, %91
  %95 = phi ptr [ %40, %71 ], [ %93, %91 ]
  %96 = getelementptr inbounds nuw i8, ptr %41, i64 2
  %97 = load i16, ptr %41, align 2, !tbaa !552
  %98 = zext i16 %97 to i32
  %99 = add i32 %42, %98
  %100 = icmp eq i16 %97, 0
  br i1 %100, label %23, label %39

101:                                              ; preds = %199, %23
  ret void

102:                                              ; preds = %32, %199
  %103 = phi ptr [ %29, %32 ], [ %105, %199 ]
  %104 = phi i32 [ %34, %32 ], [ %202, %199 ]
  %105 = getelementptr inbounds nuw i8, ptr %103, i64 2
  %106 = and i32 %104, 65535
  %107 = load ptr, ptr %11, align 8, !tbaa !528
  %108 = load ptr, ptr %13, align 8, !tbaa !545
  %109 = zext nneg i32 %106 to i64
  %110 = getelementptr inbounds nuw %"struct.llvm::MCRegisterDesc", ptr %108, i64 %109, i32 1
  %111 = load i32, ptr %110, align 4, !tbaa !549
  %112 = zext i32 %111 to i64
  %113 = getelementptr inbounds nuw i16, ptr %107, i64 %112
  %114 = load i16, ptr %113, align 2, !tbaa !552
  %115 = icmp eq i16 %114, 0
  br i1 %115, label %199, label %116

116:                                              ; preds = %102
  %117 = load ptr, ptr %35, align 8, !tbaa !553
  %118 = getelementptr inbounds nuw %"struct.llvm::MCRegisterDesc", ptr %108, i64 %109, i32 3
  %119 = load i32, ptr %118, align 4, !tbaa !554
  %120 = zext i32 %119 to i64
  %121 = getelementptr inbounds nuw i16, ptr %117, i64 %120
  %122 = zext i16 %114 to i32
  %123 = add nuw nsw i32 %106, %122
  br label %124

124:                                              ; preds = %116, %192
  %125 = phi i32 [ %196, %192 ], [ %123, %116 ]
  %126 = phi ptr [ %193, %192 ], [ %113, %116 ]
  %127 = phi ptr [ %198, %192 ], [ %121, %116 ]
  %128 = and i32 %125, 65535
  %129 = icmp eq i32 %1, %128
  br i1 %129, label %130, label %192

130:                                              ; preds = %124
  %131 = load i16, ptr %127, align 2, !tbaa !552
  %132 = load ptr, ptr %36, align 8, !tbaa !555
  %133 = zext i16 %131 to i64
  %134 = getelementptr inbounds nuw %"struct.llvm::LaneBitmask", ptr %132, i64 %133
  %135 = load i64, ptr %134, align 8, !tbaa !454
  %136 = load ptr, ptr %37, align 8, !tbaa !379
  %137 = load ptr, ptr %38, align 8, !tbaa !379
  %138 = icmp eq ptr %136, %137
  br i1 %138, label %164, label %139

139:                                              ; preds = %130, %161
  %140 = phi ptr [ %162, %161 ], [ %136, %130 ]
  %141 = load i32, ptr %140, align 4, !tbaa !522
  %142 = icmp eq i32 %141, %106
  br i1 %142, label %164, label %143

143:                                              ; preds = %139
  %144 = getelementptr inbounds nuw i8, ptr %140, i64 16
  %145 = icmp eq ptr %144, %137
  br i1 %145, label %164, label %146, !llvm.loop !524

146:                                              ; preds = %143
  %147 = load i32, ptr %144, align 4, !tbaa !522
  %148 = icmp eq i32 %147, %106
  br i1 %148, label %164, label %149

149:                                              ; preds = %146
  %150 = getelementptr inbounds nuw i8, ptr %140, i64 32
  %151 = icmp eq ptr %150, %137
  br i1 %151, label %164, label %152, !llvm.loop !524

152:                                              ; preds = %149
  %153 = load i32, ptr %150, align 4, !tbaa !522
  %154 = icmp eq i32 %153, %106
  br i1 %154, label %164, label %155

155:                                              ; preds = %152
  %156 = getelementptr inbounds nuw i8, ptr %140, i64 48
  %157 = icmp eq ptr %156, %137
  br i1 %157, label %164, label %158, !llvm.loop !524

158:                                              ; preds = %155
  %159 = load i32, ptr %156, align 4, !tbaa !522
  %160 = icmp eq i32 %159, %106
  br i1 %160, label %164, label %161

161:                                              ; preds = %158
  %162 = getelementptr inbounds nuw i8, ptr %140, i64 64
  %163 = icmp eq ptr %162, %137
  br i1 %163, label %164, label %139, !llvm.loop !525

164:                                              ; preds = %161, %158, %155, %152, %149, %146, %143, %139, %130
  %165 = phi ptr [ %136, %130 ], [ %162, %161 ], [ %156, %158 ], [ %156, %155 ], [ %150, %152 ], [ %150, %149 ], [ %144, %146 ], [ %144, %143 ], [ %140, %139 ]
  %166 = icmp eq ptr %165, %137
  br i1 %166, label %199, label %167

167:                                              ; preds = %164
  %168 = xor i64 %135, -1
  %169 = getelementptr inbounds nuw i8, ptr %165, i64 8
  %170 = load i64, ptr %169, align 8, !tbaa !452
  %171 = and i64 %170, %168
  store i64 %171, ptr %169, align 8, !tbaa !452
  %172 = icmp eq i64 %171, 0
  br i1 %172, label %173, label %199

173:                                              ; preds = %167
  %174 = ptrtoint ptr %165 to i64
  %175 = ptrtoint ptr %136 to i64
  %176 = sub i64 %174, %175
  %177 = getelementptr inbounds i8, ptr %136, i64 %176
  %178 = getelementptr inbounds nuw i8, ptr %177, i64 16
  %179 = icmp eq ptr %178, %137
  br i1 %179, label %189, label %180

180:                                              ; preds = %173
  %181 = ptrtoint ptr %137 to i64
  %182 = ptrtoint ptr %178 to i64
  %183 = sub i64 %181, %182
  %184 = icmp sgt i64 %183, 16
  br i1 %184, label %185, label %186, !prof !483

185:                                              ; preds = %180
  tail call void @llvm.memmove.p0.p0.i64(ptr align 8 %177, ptr nonnull align 8 %178, i64 %183, i1 false)
  br label %189

186:                                              ; preds = %180
  %187 = icmp eq i64 %183, 16
  br i1 %187, label %188, label %189

188:                                              ; preds = %186
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %177, ptr noundef nonnull align 8 dereferenceable(16) %178, i64 16, i1 false), !tbaa.struct !526
  br label %189

189:                                              ; preds = %188, %186, %185, %173
  %190 = load ptr, ptr %38, align 8, !tbaa !527
  %191 = getelementptr inbounds i8, ptr %190, i64 -16
  store ptr %191, ptr %38, align 8, !tbaa !527
  br label %199

192:                                              ; preds = %124
  %193 = getelementptr inbounds nuw i8, ptr %126, i64 2
  %194 = load i16, ptr %193, align 2, !tbaa !552
  %195 = zext i16 %194 to i32
  %196 = add i32 %125, %195
  %197 = icmp eq i16 %194, 0
  %198 = getelementptr inbounds nuw i8, ptr %127, i64 2
  br i1 %197, label %199, label %124, !llvm.loop !561

199:                                              ; preds = %192, %102, %189, %167, %164
  %200 = load i16, ptr %105, align 2, !tbaa !552
  %201 = zext i16 %200 to i32
  %202 = add i32 %104, %201
  %203 = icmp eq i16 %200, 0
  br i1 %203, label %101, label %102
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock12removeLiveInEN9__gnu_cxx17__normal_iteratorIPKNS0_16RegisterMaskPairESt6vectorIS3_SaIS3_EEEE(ptr noundef nonnull align 8 captures(none) dereferenceable(288) %0, ptr %1) local_unnamed_addr #8 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %4 = load ptr, ptr %3, align 8, !tbaa !379
  %5 = ptrtoint ptr %1 to i64
  %6 = ptrtoint ptr %4 to i64
  %7 = sub i64 %5, %6
  %8 = getelementptr inbounds i8, ptr %4, i64 %7
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 16
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 192
  %11 = load ptr, ptr %10, align 8, !tbaa !379
  %12 = icmp eq ptr %9, %11
  br i1 %12, label %22, label %13

13:                                               ; preds = %2
  %14 = ptrtoint ptr %11 to i64
  %15 = ptrtoint ptr %9 to i64
  %16 = sub i64 %14, %15
  %17 = icmp sgt i64 %16, 16
  br i1 %17, label %18, label %19, !prof !483

18:                                               ; preds = %13
  tail call void @llvm.memmove.p0.p0.i64(ptr align 8 %8, ptr nonnull align 8 %9, i64 %16, i1 false)
  br label %22

19:                                               ; preds = %13
  %20 = icmp eq i64 %16, 16
  br i1 %20, label %21, label %22

21:                                               ; preds = %19
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %8, ptr noundef nonnull align 8 dereferenceable(16) %9, i64 16, i1 false), !tbaa.struct !526
  br label %22

22:                                               ; preds = %2, %18, %19, %21
  %23 = load ptr, ptr %10, align 8, !tbaa !527
  %24 = getelementptr inbounds i8, ptr %23, i64 -16
  store ptr %24, ptr %10, align 8, !tbaa !527
  ret ptr %8
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock8isLiveInENS_10MCRegisterENS_11LaneBitmaskE(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, i32 %1, i64 %2) local_unnamed_addr #10 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %5 = load ptr, ptr %4, align 8, !tbaa !379
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 192
  %7 = load ptr, ptr %6, align 8, !tbaa !379
  %8 = icmp eq ptr %5, %7
  br i1 %8, label %34, label %9

9:                                                ; preds = %3, %31
  %10 = phi ptr [ %32, %31 ], [ %5, %3 ]
  %11 = load i32, ptr %10, align 4, !tbaa !522
  %12 = icmp eq i32 %11, %1
  br i1 %12, label %34, label %13

13:                                               ; preds = %9
  %14 = getelementptr inbounds nuw i8, ptr %10, i64 16
  %15 = icmp eq ptr %14, %7
  br i1 %15, label %34, label %16, !llvm.loop !562

16:                                               ; preds = %13
  %17 = load i32, ptr %14, align 4, !tbaa !522
  %18 = icmp eq i32 %17, %1
  br i1 %18, label %34, label %19

19:                                               ; preds = %16
  %20 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %21 = icmp eq ptr %20, %7
  br i1 %21, label %34, label %22, !llvm.loop !562

22:                                               ; preds = %19
  %23 = load i32, ptr %20, align 4, !tbaa !522
  %24 = icmp eq i32 %23, %1
  br i1 %24, label %34, label %25

25:                                               ; preds = %22
  %26 = getelementptr inbounds nuw i8, ptr %10, i64 48
  %27 = icmp eq ptr %26, %7
  br i1 %27, label %34, label %28, !llvm.loop !562

28:                                               ; preds = %25
  %29 = load i32, ptr %26, align 4, !tbaa !522
  %30 = icmp eq i32 %29, %1
  br i1 %30, label %34, label %31

31:                                               ; preds = %28
  %32 = getelementptr inbounds nuw i8, ptr %10, i64 64
  %33 = icmp eq ptr %32, %7
  br i1 %33, label %34, label %9, !llvm.loop !563

34:                                               ; preds = %9, %13, %16, %19, %22, %25, %28, %31, %3
  %35 = phi ptr [ %5, %3 ], [ %10, %9 ], [ %14, %13 ], [ %14, %16 ], [ %20, %19 ], [ %20, %22 ], [ %26, %25 ], [ %26, %28 ], [ %32, %31 ]
  %36 = icmp eq ptr %35, %7
  br i1 %36, label %42, label %37

37:                                               ; preds = %34
  %38 = getelementptr inbounds nuw i8, ptr %35, i64 8
  %39 = load i64, ptr %38, align 8, !tbaa !452
  %40 = and i64 %39, %2
  %41 = icmp ne i64 %40, 0
  br label %42

42:                                               ; preds = %37, %34
  %43 = phi i1 [ false, %34 ], [ %41, %37 ]
  ret i1 %43
}

; Function Attrs: mustprogress nofree nosync nounwind memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock17sortUniqueLiveInsEv(ptr noundef nonnull align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #13 align 2 {
  %2 = alloca [12 x i8], align 4
  %3 = alloca %"struct.llvm::MachineBasicBlock::RegisterMaskPair", align 8
  %4 = alloca [12 x i8], align 4
  %5 = alloca [12 x i8], align 4
  %6 = alloca %"struct.llvm::MachineBasicBlock::RegisterMaskPair", align 8
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %8 = load ptr, ptr %7, align 8, !tbaa !379
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 192
  %10 = load ptr, ptr %9, align 8, !tbaa !379
  %11 = icmp eq ptr %8, %10
  br i1 %11, label %108, label %12

12:                                               ; preds = %1
  %13 = ptrtoint ptr %10 to i64
  %14 = ptrtoint ptr %8 to i64
  %15 = sub i64 %13, %14
  %16 = ashr exact i64 %15, 4
  %17 = tail call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %16, i1 true)
  %18 = shl nuw nsw i64 %17, 1
  %19 = xor i64 %18, 126
  tail call fastcc void @"_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN4llvm17MachineBasicBlock16RegisterMaskPairESt6vectorIS4_SaIS4_EEEElZNS3_17sortUniqueLiveInsEvE3$_0EvT_SB_T0_T1_"(ptr %8, ptr %10, i64 noundef %19)
  %20 = icmp sgt i64 %15, 256
  %21 = getelementptr i8, ptr %8, i64 16
  br i1 %20, label %22, label %71

22:                                               ; preds = %12, %47
  %23 = phi i64 [ %48, %47 ], [ 16, %12 ]
  %24 = phi ptr [ %25, %47 ], [ %8, %12 ]
  %25 = getelementptr inbounds nuw i8, ptr %8, i64 %23
  %26 = load i32, ptr %25, align 4, !tbaa !522
  %27 = load i32, ptr %8, align 4, !tbaa !522
  %28 = icmp ult i32 %26, %27
  br i1 %28, label %29, label %34

29:                                               ; preds = %22
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %6)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %6, ptr noundef nonnull align 8 dereferenceable(16) %25, i64 16, i1 false), !tbaa.struct !526
  %30 = icmp samesign ugt i64 %23, 16
  br i1 %30, label %31, label %32, !prof !564

31:                                               ; preds = %29
  tail call void @llvm.memmove.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(1) %21, ptr noundef nonnull align 8 dereferenceable(1) %8, i64 %23, i1 false)
  br label %33

32:                                               ; preds = %29
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %21, ptr noundef nonnull align 8 dereferenceable(16) %8, i64 16, i1 false), !tbaa.struct !526
  br label %33

33:                                               ; preds = %32, %31
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %8, ptr noundef nonnull align 8 dereferenceable(16) %6, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %6)
  br label %47

34:                                               ; preds = %22
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %5)
  %35 = getelementptr inbounds nuw i8, ptr %24, i64 20
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(12) %5, ptr noundef nonnull align 4 dereferenceable(12) %35, i64 12, i1 false), !tbaa.struct !565
  %36 = load i32, ptr %24, align 4, !tbaa !522
  %37 = icmp ult i32 %26, %36
  br i1 %37, label %38, label %44

38:                                               ; preds = %34, %38
  %39 = phi ptr [ %41, %38 ], [ %24, %34 ]
  %40 = phi ptr [ %39, %38 ], [ %25, %34 ]
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %40, ptr noundef nonnull align 8 dereferenceable(16) %39, i64 16, i1 false), !tbaa.struct !526
  %41 = getelementptr inbounds i8, ptr %39, i64 -16
  %42 = load i32, ptr %41, align 4, !tbaa !522
  %43 = icmp ult i32 %26, %42
  br i1 %43, label %38, label %44, !llvm.loop !566

44:                                               ; preds = %38, %34
  %45 = phi ptr [ %25, %34 ], [ %39, %38 ]
  store i32 %26, ptr %45, align 8, !tbaa !451
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(12) %46, ptr noundef nonnull align 4 dereferenceable(12) %5, i64 12, i1 false), !tbaa.struct !565
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %5)
  br label %47

47:                                               ; preds = %44, %33
  %48 = add nuw nsw i64 %23, 16
  %49 = icmp eq i64 %48, 256
  br i1 %49, label %50, label %22, !llvm.loop !567

50:                                               ; preds = %47
  %51 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %52 = icmp eq ptr %51, %10
  br i1 %52, label %108, label %53

53:                                               ; preds = %50, %66
  %54 = phi ptr [ %69, %66 ], [ %51, %50 ]
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %4)
  %55 = load i32, ptr %54, align 8, !tbaa !451
  %56 = getelementptr inbounds nuw i8, ptr %54, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(12) %4, ptr noundef nonnull align 4 dereferenceable(12) %56, i64 12, i1 false), !tbaa.struct !565
  %57 = getelementptr inbounds i8, ptr %54, i64 -16
  %58 = load i32, ptr %57, align 4, !tbaa !522
  %59 = icmp ult i32 %55, %58
  br i1 %59, label %60, label %66

60:                                               ; preds = %53, %60
  %61 = phi ptr [ %63, %60 ], [ %57, %53 ]
  %62 = phi ptr [ %61, %60 ], [ %54, %53 ]
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %62, ptr noundef nonnull align 8 dereferenceable(16) %61, i64 16, i1 false), !tbaa.struct !526
  %63 = getelementptr inbounds i8, ptr %61, i64 -16
  %64 = load i32, ptr %63, align 4, !tbaa !522
  %65 = icmp ult i32 %55, %64
  br i1 %65, label %60, label %66, !llvm.loop !566

66:                                               ; preds = %60, %53
  %67 = phi ptr [ %54, %53 ], [ %61, %60 ]
  store i32 %55, ptr %67, align 8, !tbaa !451
  %68 = getelementptr inbounds nuw i8, ptr %67, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(12) %68, ptr noundef nonnull align 4 dereferenceable(12) %4, i64 12, i1 false), !tbaa.struct !565
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %4)
  %69 = getelementptr inbounds nuw i8, ptr %54, i64 16
  %70 = icmp eq ptr %69, %10
  br i1 %70, label %108, label %53, !llvm.loop !568

71:                                               ; preds = %12
  %72 = icmp eq ptr %21, %10
  br i1 %72, label %108, label %73

73:                                               ; preds = %71, %105
  %74 = phi ptr [ %106, %105 ], [ %21, %71 ]
  %75 = phi ptr [ %74, %105 ], [ %8, %71 ]
  %76 = load i32, ptr %74, align 4, !tbaa !522
  %77 = load i32, ptr %8, align 4, !tbaa !522
  %78 = icmp ult i32 %76, %77
  br i1 %78, label %79, label %92

79:                                               ; preds = %73
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %3, ptr noundef nonnull align 8 dereferenceable(16) %74, i64 16, i1 false), !tbaa.struct !526
  %80 = getelementptr inbounds nuw i8, ptr %75, i64 32
  %81 = ptrtoint ptr %74 to i64
  %82 = sub i64 %81, %14
  %83 = ashr exact i64 %82, 4
  %84 = sub nsw i64 0, %83
  %85 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %80, i64 %84
  %86 = icmp sgt i64 %83, 1
  br i1 %86, label %87, label %88, !prof !564

87:                                               ; preds = %79
  tail call void @llvm.memmove.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(1) %85, ptr noundef nonnull align 8 dereferenceable(1) %8, i64 %82, i1 false)
  br label %91

88:                                               ; preds = %79
  %89 = icmp eq i64 %82, 16
  br i1 %89, label %90, label %91

90:                                               ; preds = %88
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %85, ptr noundef nonnull align 8 dereferenceable(16) %8, i64 16, i1 false), !tbaa.struct !526
  br label %91

91:                                               ; preds = %90, %88, %87
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %8, ptr noundef nonnull align 8 dereferenceable(16) %3, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3)
  br label %105

92:                                               ; preds = %73
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %2)
  %93 = getelementptr inbounds nuw i8, ptr %75, i64 20
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(12) %2, ptr noundef nonnull align 4 dereferenceable(12) %93, i64 12, i1 false), !tbaa.struct !565
  %94 = load i32, ptr %75, align 4, !tbaa !522
  %95 = icmp ult i32 %76, %94
  br i1 %95, label %96, label %102

96:                                               ; preds = %92, %96
  %97 = phi ptr [ %99, %96 ], [ %75, %92 ]
  %98 = phi ptr [ %97, %96 ], [ %74, %92 ]
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %98, ptr noundef nonnull align 8 dereferenceable(16) %97, i64 16, i1 false), !tbaa.struct !526
  %99 = getelementptr inbounds i8, ptr %97, i64 -16
  %100 = load i32, ptr %99, align 4, !tbaa !522
  %101 = icmp ult i32 %76, %100
  br i1 %101, label %96, label %102, !llvm.loop !566

102:                                              ; preds = %96, %92
  %103 = phi ptr [ %74, %92 ], [ %97, %96 ]
  store i32 %76, ptr %103, align 8, !tbaa !451
  %104 = getelementptr inbounds nuw i8, ptr %103, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(12) %104, ptr noundef nonnull align 4 dereferenceable(12) %2, i64 12, i1 false), !tbaa.struct !565
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %2)
  br label %105

105:                                              ; preds = %102, %91
  %106 = getelementptr inbounds nuw i8, ptr %74, i64 16
  %107 = icmp eq ptr %106, %10
  br i1 %107, label %108, label %73, !llvm.loop !567

108:                                              ; preds = %105, %66, %1, %50, %71
  %109 = load ptr, ptr %7, align 8, !tbaa !379
  %110 = load ptr, ptr %9, align 8, !tbaa !379
  %111 = icmp eq ptr %109, %110
  br i1 %111, label %138, label %112

112:                                              ; preds = %108, %132
  %113 = phi ptr [ %134, %132 ], [ %109, %108 ]
  %114 = phi ptr [ %136, %132 ], [ %109, %108 ]
  %115 = load i32, ptr %113, align 8, !tbaa !451
  %116 = getelementptr inbounds nuw i8, ptr %113, i64 8
  %117 = load i64, ptr %116, align 8, !tbaa !454
  %118 = getelementptr inbounds nuw i8, ptr %113, i64 16
  %119 = icmp eq ptr %118, %110
  br i1 %119, label %132, label %120

120:                                              ; preds = %112, %126
  %121 = phi ptr [ %130, %126 ], [ %118, %112 ]
  %122 = phi ptr [ %121, %126 ], [ %113, %112 ]
  %123 = phi i64 [ %129, %126 ], [ %117, %112 ]
  %124 = load i32, ptr %121, align 4, !tbaa !522
  %125 = icmp eq i32 %124, %115
  br i1 %125, label %126, label %132

126:                                              ; preds = %120
  %127 = getelementptr inbounds nuw i8, ptr %122, i64 24
  %128 = load i64, ptr %127, align 8, !tbaa !454
  %129 = or i64 %128, %123
  %130 = getelementptr inbounds nuw i8, ptr %121, i64 16
  %131 = icmp eq ptr %130, %110
  br i1 %131, label %132, label %120, !llvm.loop !569

132:                                              ; preds = %120, %126, %112
  %133 = phi i64 [ %117, %112 ], [ %129, %126 ], [ %123, %120 ]
  %134 = phi ptr [ %118, %112 ], [ %130, %126 ], [ %121, %120 ]
  store i32 %115, ptr %114, align 8, !tbaa !451
  %135 = getelementptr inbounds nuw i8, ptr %114, i64 8
  store i64 %133, ptr %135, align 8, !tbaa !454
  %136 = getelementptr inbounds nuw i8, ptr %114, i64 16
  %137 = icmp eq ptr %134, %110
  br i1 %137, label %138, label %112, !llvm.loop !570

138:                                              ; preds = %132, %108
  %139 = phi ptr [ %109, %108 ], [ %136, %132 ]
  %140 = icmp eq ptr %139, %110
  br i1 %140, label %146, label %141

141:                                              ; preds = %138
  %142 = ptrtoint ptr %139 to i64
  %143 = ptrtoint ptr %109 to i64
  %144 = sub i64 %142, %143
  %145 = getelementptr inbounds i8, ptr %109, i64 %144
  store ptr %145, ptr %9, align 8, !tbaa !527
  br label %146

146:                                              ; preds = %138, %141
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local i32 @_ZN4llvm17MachineBasicBlock9addLiveInENS_10MCRegisterEPKNS_15MCRegisterClassE(ptr noundef nonnull align 8 dereferenceable(288) %0, i32 %1, ptr noundef %2) local_unnamed_addr #3 align 2 {
  %4 = alloca %"class.llvm::MachineOperand", align 8
  %5 = alloca %"class.llvm::MIMetadata", align 8
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %7 = load ptr, ptr %6, align 8, !tbaa !379
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 192
  %9 = load ptr, ptr %8, align 8, !tbaa !379
  %10 = icmp eq ptr %7, %9
  br i1 %10, label %36, label %11

11:                                               ; preds = %3, %33
  %12 = phi ptr [ %34, %33 ], [ %7, %3 ]
  %13 = load i32, ptr %12, align 4, !tbaa !522
  %14 = icmp eq i32 %13, %1
  br i1 %14, label %36, label %15

15:                                               ; preds = %11
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 16
  %17 = icmp eq ptr %16, %9
  br i1 %17, label %36, label %18, !llvm.loop !562

18:                                               ; preds = %15
  %19 = load i32, ptr %16, align 4, !tbaa !522
  %20 = icmp eq i32 %19, %1
  br i1 %20, label %36, label %21

21:                                               ; preds = %18
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %23 = icmp eq ptr %22, %9
  br i1 %23, label %36, label %24, !llvm.loop !562

24:                                               ; preds = %21
  %25 = load i32, ptr %22, align 4, !tbaa !522
  %26 = icmp eq i32 %25, %1
  br i1 %26, label %36, label %27

27:                                               ; preds = %24
  %28 = getelementptr inbounds nuw i8, ptr %12, i64 48
  %29 = icmp eq ptr %28, %9
  br i1 %29, label %36, label %30, !llvm.loop !562

30:                                               ; preds = %27
  %31 = load i32, ptr %28, align 4, !tbaa !522
  %32 = icmp eq i32 %31, %1
  br i1 %32, label %36, label %33

33:                                               ; preds = %30
  %34 = getelementptr inbounds nuw i8, ptr %12, i64 64
  %35 = icmp eq ptr %34, %9
  br i1 %35, label %36, label %11, !llvm.loop !563

36:                                               ; preds = %33, %30, %27, %24, %21, %18, %15, %11, %3
  %37 = phi ptr [ %7, %3 ], [ %34, %33 ], [ %28, %30 ], [ %28, %27 ], [ %22, %24 ], [ %22, %21 ], [ %16, %18 ], [ %16, %15 ], [ %12, %11 ]
  %38 = icmp eq ptr %37, %9
  br i1 %38, label %43, label %39

39:                                               ; preds = %36
  %40 = getelementptr inbounds nuw i8, ptr %37, i64 8
  %41 = load i64, ptr %40, align 8, !tbaa !452
  %42 = icmp ne i64 %41, 0
  br label %43

43:                                               ; preds = %36, %39
  %44 = phi i1 [ false, %36 ], [ %42, %39 ]
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %46 = load ptr, ptr %45, align 8, !tbaa !75
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %48 = load ptr, ptr %47, align 8, !tbaa !74
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 16
  %50 = load ptr, ptr %49, align 8, !tbaa !308, !nonnull !17, !align !200
  %51 = load ptr, ptr %50, align 8, !tbaa !4
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 120
  %53 = load ptr, ptr %52, align 8
  %54 = tail call noundef ptr %53(ptr noundef nonnull align 8 dereferenceable(368) %50) #33
  %55 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %56 = icmp eq ptr %46, %55
  br i1 %56, label %91, label %57

57:                                               ; preds = %43, %86
  %58 = phi ptr [ %89, %86 ], [ %46, %43 ]
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 52
  %60 = load i32, ptr %59, align 4, !tbaa !306
  switch i32 %60, label %61 [
    i32 74, label %69
    i32 0, label %69
  ]

61:                                               ; preds = %57
  %62 = add i32 %60, -3
  %63 = icmp ult i32 %62, 4
  br i1 %63, label %69, label %64

64:                                               ; preds = %61
  %65 = load ptr, ptr %54, align 8, !tbaa !4
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 1280
  %67 = load ptr, ptr %66, align 8
  %68 = tail call noundef zeroext i1 %67(ptr noundef nonnull align 8 dereferenceable(112) %54, ptr noundef nonnull align 8 dereferenceable(80) %58, i32 0) #33
  br i1 %68, label %69, label %91

69:                                               ; preds = %64, %61, %57, %57
  %70 = load i64, ptr %58, align 8
  %71 = and i64 %70, 4
  %72 = icmp eq i64 %71, 0
  br i1 %72, label %73, label %86

73:                                               ; preds = %69
  %74 = getelementptr inbounds nuw i8, ptr %58, i64 44
  %75 = load i32, ptr %74, align 4, !tbaa !309
  %76 = and i32 %75, 8
  %77 = icmp eq i32 %76, 0
  br i1 %77, label %86, label %78

78:                                               ; preds = %73, %78
  %79 = phi ptr [ %81, %78 ], [ %58, %73 ]
  %80 = getelementptr inbounds nuw i8, ptr %79, i64 8
  %81 = load ptr, ptr %80, align 8, !tbaa !75
  %82 = getelementptr inbounds nuw i8, ptr %81, i64 44
  %83 = load i32, ptr %82, align 4, !tbaa !309
  %84 = and i32 %83, 8
  %85 = icmp eq i32 %84, 0
  br i1 %85, label %86, label %78, !llvm.loop !310

86:                                               ; preds = %78, %73, %69
  %87 = phi ptr [ %58, %69 ], [ %58, %73 ], [ %81, %78 ]
  %88 = getelementptr inbounds nuw i8, ptr %87, i64 8
  %89 = load ptr, ptr %88, align 8, !tbaa !75
  %90 = icmp eq ptr %89, %55
  br i1 %90, label %91, label %57, !llvm.loop !311

91:                                               ; preds = %64, %86, %43
  %92 = phi ptr [ %46, %43 ], [ %58, %64 ], [ %89, %86 ]
  %93 = load ptr, ptr %47, align 8, !tbaa !74
  %94 = getelementptr inbounds nuw i8, ptr %93, i64 32
  %95 = load ptr, ptr %94, align 8, !tbaa !293
  %96 = getelementptr inbounds nuw i8, ptr %93, i64 16
  %97 = load ptr, ptr %96, align 8, !tbaa !308, !nonnull !17, !align !200
  %98 = load ptr, ptr %97, align 8, !tbaa !4
  %99 = getelementptr inbounds nuw i8, ptr %98, i64 120
  %100 = load ptr, ptr %99, align 8
  %101 = tail call noundef ptr %100(ptr noundef nonnull align 8 dereferenceable(368) %97) #33
  %102 = icmp ne ptr %92, %55
  %103 = select i1 %44, i1 %102, i1 false
  br i1 %103, label %104, label %142

104:                                              ; preds = %91, %137
  %105 = phi ptr [ %140, %137 ], [ %92, %91 ]
  %106 = getelementptr inbounds nuw i8, ptr %105, i64 52
  %107 = load i32, ptr %106, align 4, !tbaa !306
  %108 = icmp eq i32 %107, 20
  br i1 %108, label %109, label %142

109:                                              ; preds = %104
  %110 = getelementptr inbounds nuw i8, ptr %105, i64 32
  %111 = load ptr, ptr %110, align 8, !tbaa !571
  %112 = getelementptr inbounds nuw i8, ptr %111, i64 36
  %113 = load i32, ptr %112, align 4, !tbaa !212
  %114 = icmp eq i32 %113, %1
  br i1 %114, label %115, label %120

115:                                              ; preds = %109
  %116 = getelementptr inbounds nuw i8, ptr %111, i64 4
  %117 = load i32, ptr %116, align 4, !tbaa !212
  %118 = tail call noundef ptr @_ZN4llvm19MachineRegisterInfo17constrainRegClassENS_8RegisterEPKNS_15MCRegisterClassEj(ptr noundef nonnull align 8 dereferenceable(520) %95, i32 %117, ptr noundef %2, i32 noundef 0) #33
  %119 = icmp ne ptr %118, null
  tail call void @llvm.assume(i1 %119)
  br label %193

120:                                              ; preds = %109
  %121 = load i64, ptr %105, align 8
  %122 = and i64 %121, 4
  %123 = icmp eq i64 %122, 0
  br i1 %123, label %124, label %137

124:                                              ; preds = %120
  %125 = getelementptr inbounds nuw i8, ptr %105, i64 44
  %126 = load i32, ptr %125, align 4, !tbaa !309
  %127 = and i32 %126, 8
  %128 = icmp eq i32 %127, 0
  br i1 %128, label %137, label %129

129:                                              ; preds = %124, %129
  %130 = phi ptr [ %132, %129 ], [ %105, %124 ]
  %131 = getelementptr inbounds nuw i8, ptr %130, i64 8
  %132 = load ptr, ptr %131, align 8, !tbaa !75
  %133 = getelementptr inbounds nuw i8, ptr %132, i64 44
  %134 = load i32, ptr %133, align 4, !tbaa !309
  %135 = and i32 %134, 8
  %136 = icmp eq i32 %135, 0
  br i1 %136, label %137, label %129, !llvm.loop !310

137:                                              ; preds = %129, %120, %124
  %138 = phi ptr [ %105, %120 ], [ %105, %124 ], [ %132, %129 ]
  %139 = getelementptr inbounds nuw i8, ptr %138, i64 8
  %140 = load ptr, ptr %139, align 8, !tbaa !75
  %141 = icmp eq ptr %140, %55
  br i1 %141, label %142, label %104, !llvm.loop !572

142:                                              ; preds = %137, %104, %91
  %143 = phi ptr [ %92, %91 ], [ %140, %137 ], [ %105, %104 ]
  %144 = tail call i32 @_ZN4llvm19MachineRegisterInfo21createVirtualRegisterEPKNS_15MCRegisterClassENS_9StringRefE(ptr noundef nonnull align 8 dereferenceable(520) %95, ptr noundef %2, ptr nonnull @.str.9, i64 0) #33
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %5) #33
  %145 = getelementptr inbounds nuw i8, ptr %101, i64 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %5, i8 0, i64 32, i1 false)
  %146 = load ptr, ptr %145, align 8, !tbaa !573
  %147 = getelementptr inbounds i8, ptr %146, i64 -640
  %148 = call { ptr, ptr } @_ZN4llvm7BuildMIERNS_17MachineBasicBlockENS_26MachineInstrBundleIteratorINS_12MachineInstrELb0EEERKNS_10MIMetadataERKNS_11MCInstrDescENS_8RegisterE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr %143, ptr noundef nonnull align 8 dereferenceable(32) %5, ptr noundef nonnull align 8 dereferenceable(32) %147, i32 %144)
  %149 = extractvalue { ptr, ptr } %148, 0
  %150 = extractvalue { ptr, ptr } %148, 1
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %4) #33
  %151 = getelementptr inbounds nuw i8, ptr %4, i64 8
  store ptr null, ptr %151, align 8, !tbaa !575, !alias.scope !577
  %152 = getelementptr inbounds nuw i8, ptr %4, i64 4
  store i32 %1, ptr %152, align 4, !tbaa !212, !alias.scope !577
  %153 = getelementptr inbounds nuw i8, ptr %4, i64 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %153, i8 0, i64 16, i1 false), !alias.scope !577
  store i32 67108864, ptr %4, align 8, !alias.scope !577
  call void @_ZN4llvm12MachineInstr10addOperandERNS_15MachineFunctionERKNS_14MachineOperandE(ptr noundef nonnull align 8 dereferenceable(80) %150, ptr noundef nonnull align 8 dereferenceable(1057) %149, ptr noundef nonnull align 8 dereferenceable(32) %4) #33
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %4) #33
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %5) #33
  br i1 %44, label %193, label %154

154:                                              ; preds = %142
  %155 = load ptr, ptr %8, align 8, !tbaa !527
  %156 = getelementptr inbounds nuw i8, ptr %0, i64 200
  %157 = load ptr, ptr %156, align 8, !tbaa !84
  %158 = icmp eq ptr %155, %157
  br i1 %158, label %162, label %159

159:                                              ; preds = %154
  store i32 %1, ptr %155, align 8, !tbaa !451
  %160 = getelementptr inbounds nuw i8, ptr %155, i64 8
  store i64 -1, ptr %160, align 8, !tbaa !454
  %161 = getelementptr inbounds nuw i8, ptr %155, i64 16
  store ptr %161, ptr %8, align 8, !tbaa !527
  br label %193

162:                                              ; preds = %154
  %163 = load ptr, ptr %6, align 8, !tbaa !85
  %164 = ptrtoint ptr %155 to i64
  %165 = ptrtoint ptr %163 to i64
  %166 = sub i64 %164, %165
  %167 = ashr exact i64 %166, 4
  %168 = icmp sgt i64 %167, -1
  call void @llvm.assume(i1 %168)
  %169 = icmp eq i64 %166, 9223372036854775792
  br i1 %169, label %170, label %171

170:                                              ; preds = %162
  call void @_ZSt20__throw_length_errorPKc(ptr noundef nonnull @.str.42) #35
  unreachable

171:                                              ; preds = %162
  %172 = call i64 @llvm.umax.i64(i64 %167, i64 1)
  %173 = add nuw nsw i64 %172, %167
  %174 = call noundef i64 @llvm.umin.i64(i64 %173, i64 576460752303423487)
  %175 = shl nuw nsw i64 %174, 4
  %176 = call noalias noundef nonnull ptr @_Znwm(i64 noundef %175) #36
  %177 = getelementptr inbounds nuw i8, ptr %176, i64 %166
  store i32 %1, ptr %177, align 8, !tbaa !451
  %178 = getelementptr inbounds nuw i8, ptr %177, i64 8
  store i64 -1, ptr %178, align 8, !tbaa !454
  %179 = icmp eq ptr %163, %155
  br i1 %179, label %186, label %180

180:                                              ; preds = %171, %180
  %181 = phi ptr [ %184, %180 ], [ %176, %171 ]
  %182 = phi ptr [ %183, %180 ], [ %163, %171 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %181, ptr noundef nonnull align 8 dereferenceable(16) %182, i64 16, i1 false), !tbaa.struct !526, !alias.scope !580
  %183 = getelementptr inbounds nuw i8, ptr %182, i64 16
  %184 = getelementptr inbounds nuw i8, ptr %181, i64 16
  %185 = icmp eq ptr %183, %155
  br i1 %185, label %186, label %180, !llvm.loop !584

186:                                              ; preds = %180, %171
  %187 = phi ptr [ %176, %171 ], [ %184, %180 ]
  %188 = icmp eq ptr %163, null
  br i1 %188, label %190, label %189

189:                                              ; preds = %186
  call void @_ZdlPvm(ptr noundef nonnull %163, i64 noundef %166) #34
  br label %190

190:                                              ; preds = %189, %186
  %191 = getelementptr inbounds nuw i8, ptr %187, i64 16
  store ptr %176, ptr %6, align 8, !tbaa !85
  store ptr %191, ptr %8, align 8, !tbaa !527
  %192 = getelementptr inbounds nuw %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %176, i64 %174
  store ptr %192, ptr %156, align 8, !tbaa !84
  br label %193

193:                                              ; preds = %190, %159, %142, %115
  %194 = phi i32 [ %117, %115 ], [ %144, %142 ], [ %144, %159 ], [ %144, %190 ]
  ret i32 %194
}

declare noundef ptr @_ZN4llvm19MachineRegisterInfo17constrainRegClassENS_8RegisterEPKNS_15MCRegisterClassEj(ptr noundef nonnull align 8 dereferenceable(520), i32, ptr noundef, i32 noundef) local_unnamed_addr #4

declare i32 @_ZN4llvm19MachineRegisterInfo21createVirtualRegisterEPKNS_15MCRegisterClassENS_9StringRefE(ptr noundef nonnull align 8 dereferenceable(520), ptr noundef, ptr, i64) local_unnamed_addr #4

; Function Attrs: inlinehint mustprogress nounwind uwtable
define linkonce_odr hidden { ptr, ptr } @_ZN4llvm7BuildMIERNS_17MachineBasicBlockENS_26MachineInstrBundleIteratorINS_12MachineInstrELb0EEERKNS_10MIMetadataERKNS_11MCInstrDescENS_8RegisterE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr %1, ptr noundef nonnull align 8 dereferenceable(32) %2, ptr noundef nonnull align 8 dereferenceable(32) %3, i32 %4) local_unnamed_addr #1 comdat {
  %6 = alloca %"class.llvm::MachineOperand", align 8
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %8 = load ptr, ptr %7, align 8, !tbaa !74
  %9 = load ptr, ptr %2, align 8, !tbaa !585
  %10 = tail call noundef ptr @_ZN4llvm15MachineFunction18CreateMachineInstrERKNS_11MCInstrDescENS_8DebugLocEb(ptr noundef nonnull align 8 dereferenceable(1057) %8, ptr noundef nonnull align 8 dereferenceable(32) %3, ptr %9, i1 noundef zeroext false) #33
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %12 = load ptr, ptr %11, align 8, !tbaa !83
  %13 = getelementptr inbounds nuw i8, ptr %10, i64 24
  store ptr %12, ptr %13, align 8, !tbaa !294
  %14 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %15 = load ptr, ptr %14, align 8, !tbaa !74
  %16 = getelementptr inbounds nuw i8, ptr %15, i64 32
  %17 = load ptr, ptr %16, align 8, !tbaa !293
  tail call void @_ZN4llvm12MachineInstr24addRegOperandsToUseListsERNS_19MachineRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80) %10, ptr noundef nonnull align 8 dereferenceable(520) %17) #33
  tail call void @_ZN4llvm15MachineFunction15handleInsertionERNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057) %15, ptr noundef nonnull align 8 dereferenceable(80) %10) #33
  %18 = load i64, ptr %1, align 8
  %19 = and i64 %18, -8
  %20 = inttoptr i64 %19 to ptr
  %21 = getelementptr inbounds nuw i8, ptr %10, i64 8
  store ptr %1, ptr %21, align 8, !tbaa !75
  %22 = load i64, ptr %10, align 8
  %23 = and i64 %22, 7
  %24 = or disjoint i64 %23, %19
  store i64 %24, ptr %10, align 8
  %25 = getelementptr inbounds nuw i8, ptr %20, i64 8
  store ptr %10, ptr %25, align 8, !tbaa !75
  %26 = load i64, ptr %1, align 8
  %27 = ptrtoint ptr %10 to i64
  %28 = and i64 %26, 7
  %29 = or disjoint i64 %28, %27
  store i64 %29, ptr %1, align 8
  %30 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %31 = load ptr, ptr %30, align 8, !tbaa !586
  %32 = icmp eq ptr %31, null
  br i1 %32, label %34, label %33

33:                                               ; preds = %5
  tail call void @_ZN4llvm12MachineInstr13setPCSectionsERNS_15MachineFunctionEPNS_6MDNodeE(ptr noundef nonnull align 8 dereferenceable(80) %10, ptr noundef nonnull align 8 dereferenceable(1057) %8, ptr noundef nonnull %31) #33
  br label %34

34:                                               ; preds = %33, %5
  %35 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %36 = load ptr, ptr %35, align 8, !tbaa !590
  %37 = icmp eq ptr %36, null
  br i1 %37, label %39, label %38

38:                                               ; preds = %34
  tail call void @_ZN4llvm12MachineInstr15setMMRAMetadataERNS_15MachineFunctionEPNS_6MDNodeE(ptr noundef nonnull align 8 dereferenceable(80) %10, ptr noundef nonnull align 8 dereferenceable(1057) %8, ptr noundef nonnull %36) #33
  br label %39

39:                                               ; preds = %38, %34
  %40 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %41 = load ptr, ptr %40, align 8, !tbaa !591
  %42 = icmp eq ptr %41, null
  br i1 %42, label %44, label %43

43:                                               ; preds = %39
  tail call void @_ZN4llvm12MachineInstr21setDeactivationSymbolERNS_15MachineFunctionEPNS_5ValueE(ptr noundef nonnull align 8 dereferenceable(80) %10, ptr noundef nonnull align 8 dereferenceable(1057) %8, ptr noundef nonnull %41) #33
  br label %44

44:                                               ; preds = %39, %43
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %6) #33
  %45 = getelementptr inbounds nuw i8, ptr %6, i64 8
  store ptr null, ptr %45, align 8, !tbaa !575, !alias.scope !592
  %46 = getelementptr inbounds nuw i8, ptr %6, i64 4
  store i32 %4, ptr %46, align 4, !tbaa !212, !alias.scope !592
  %47 = getelementptr inbounds nuw i8, ptr %6, i64 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %47, i8 0, i64 16, i1 false), !alias.scope !592
  store i32 16777216, ptr %6, align 8, !alias.scope !592
  call void @_ZN4llvm12MachineInstr10addOperandERNS_15MachineFunctionERKNS_14MachineOperandE(ptr noundef nonnull align 8 dereferenceable(80) %10, ptr noundef nonnull align 8 dereferenceable(1057) %8, ptr noundef nonnull align 8 dereferenceable(32) %6) #33
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %6) #33
  %48 = insertvalue { ptr, ptr } poison, ptr %8, 0
  %49 = insertvalue { ptr, ptr } %48, ptr %10, 1
  ret { ptr, ptr } %49
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock10moveBeforeEPS0_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1) local_unnamed_addr #8 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %4 = load ptr, ptr %3, align 8, !tbaa !327
  %5 = icmp eq ptr %1, %0
  %6 = icmp eq ptr %1, %4
  %7 = icmp eq ptr %0, %4
  %8 = or i1 %6, %7
  %9 = select i1 %5, i1 true, i1 %8
  br i1 %9, label %17, label %10

10:                                               ; preds = %2
  %11 = load ptr, ptr %4, align 8, !tbaa !595
  %12 = load ptr, ptr %0, align 8, !tbaa !595
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 8
  store ptr %4, ptr %13, align 8, !tbaa !327
  store ptr %12, ptr %4, align 8, !tbaa !595
  %14 = load ptr, ptr %1, align 8, !tbaa !595
  %15 = getelementptr inbounds nuw i8, ptr %11, i64 8
  store ptr %1, ptr %15, align 8, !tbaa !327
  store ptr %14, ptr %0, align 8, !tbaa !595
  %16 = getelementptr inbounds nuw i8, ptr %14, i64 8
  store ptr %0, ptr %16, align 8, !tbaa !327
  store ptr %11, ptr %1, align 8, !tbaa !595
  br label %17

17:                                               ; preds = %2, %10
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock9moveAfterEPS0_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef readonly captures(none) %1) local_unnamed_addr #8 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %4 = load ptr, ptr %3, align 8, !tbaa !327
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8, !tbaa !327
  %7 = icmp eq ptr %4, %0
  %8 = icmp eq ptr %4, %6
  %9 = icmp eq ptr %0, %6
  %10 = or i1 %8, %9
  %11 = select i1 %7, i1 true, i1 %10
  br i1 %11, label %19, label %12

12:                                               ; preds = %2
  %13 = load ptr, ptr %6, align 8, !tbaa !595
  %14 = load ptr, ptr %0, align 8, !tbaa !595
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 8
  store ptr %6, ptr %15, align 8, !tbaa !327
  store ptr %14, ptr %6, align 8, !tbaa !595
  %16 = load ptr, ptr %4, align 8, !tbaa !595
  %17 = getelementptr inbounds nuw i8, ptr %13, i64 8
  store ptr %4, ptr %17, align 8, !tbaa !327
  store ptr %16, ptr %0, align 8, !tbaa !595
  %18 = getelementptr inbounds nuw i8, ptr %16, i64 8
  store ptr %0, ptr %18, align 8, !tbaa !327
  store ptr %13, ptr %4, align 8, !tbaa !595
  br label %19

19:                                               ; preds = %2, %12
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock16updateTerminatorEPS0_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1) local_unnamed_addr #3 align 2 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca %"class.llvm::SmallVector.426", align 8
  %6 = alloca %"class.llvm::DebugLoc", align 8
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %8 = load ptr, ptr %7, align 8, !tbaa !74
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 16
  %10 = load ptr, ptr %9, align 8, !tbaa !308, !nonnull !17, !align !200
  %11 = load ptr, ptr %10, align 8, !tbaa !4
  %12 = getelementptr inbounds nuw i8, ptr %11, i64 120
  %13 = load ptr, ptr %12, align 8
  %14 = tail call noundef ptr %13(ptr noundef nonnull align 8 dereferenceable(368) %10) #33
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %16 = load i32, ptr %15, align 8, !tbaa !76
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %198, label %18

18:                                               ; preds = %2
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3) #33
  store ptr null, ptr %3, align 8, !tbaa !289
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %4) #33
  store ptr null, ptr %4, align 8, !tbaa !289
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %5) #33
  %19 = getelementptr inbounds nuw i8, ptr %5, i64 16
  store ptr %19, ptr %5, align 8, !tbaa !19
  %20 = getelementptr inbounds nuw i8, ptr %5, i64 8
  store i32 0, ptr %20, align 8, !tbaa !76
  %21 = getelementptr inbounds nuw i8, ptr %5, i64 12
  store i32 4, ptr %21, align 4, !tbaa !77
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %6) #33
  %22 = call ptr @_ZN4llvm17MachineBasicBlock18findBranchDebugLocEv(ptr noundef nonnull align 8 dereferenceable(288) %0)
  store ptr %22, ptr %6, align 8
  %23 = load ptr, ptr %14, align 8, !tbaa !4
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 304
  %25 = load ptr, ptr %24, align 8
  %26 = call noundef zeroext i1 %25(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(8) %3, ptr noundef nonnull align 8 dereferenceable(8) %4, ptr noundef nonnull align 8 dereferenceable(16) %5, i1 noundef zeroext false) #33
  %27 = load i32, ptr %20, align 8, !tbaa !76
  %28 = icmp eq i32 %27, 0
  br i1 %28, label %29, label %93

29:                                               ; preds = %18
  %30 = load ptr, ptr %3, align 8, !tbaa !289
  %31 = icmp eq ptr %30, null
  br i1 %31, label %41, label %32

32:                                               ; preds = %29
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %34 = load ptr, ptr %33, align 8, !tbaa !327
  %35 = icmp eq ptr %34, %30
  br i1 %35, label %36, label %193

36:                                               ; preds = %32
  %37 = load ptr, ptr %14, align 8, !tbaa !4
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 320
  %39 = load ptr, ptr %38, align 8
  %40 = call noundef i32 %39(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef null) #33
  br label %193

41:                                               ; preds = %29
  %42 = icmp eq ptr %1, null
  br i1 %42, label %193, label %43

43:                                               ; preds = %41
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %45 = load ptr, ptr %44, align 8, !tbaa !19
  %46 = load i32, ptr %15, align 8, !tbaa !76
  %47 = zext i32 %46 to i64
  %48 = shl nuw nsw i64 %47, 3
  %49 = getelementptr inbounds nuw i8, ptr %45, i64 %48
  %50 = icmp eq i32 %46, 0
  br i1 %50, label %76, label %51

51:                                               ; preds = %43, %73
  %52 = phi ptr [ %74, %73 ], [ %45, %43 ]
  %53 = load ptr, ptr %52, align 8, !tbaa !289
  %54 = icmp eq ptr %53, %1
  br i1 %54, label %76, label %55

55:                                               ; preds = %51
  %56 = getelementptr inbounds nuw i8, ptr %52, i64 8
  %57 = icmp eq ptr %56, %49
  br i1 %57, label %193, label %58, !llvm.loop !596

58:                                               ; preds = %55
  %59 = load ptr, ptr %56, align 8, !tbaa !289
  %60 = icmp eq ptr %59, %1
  br i1 %60, label %76, label %61

61:                                               ; preds = %58
  %62 = getelementptr inbounds nuw i8, ptr %52, i64 16
  %63 = icmp eq ptr %62, %49
  br i1 %63, label %193, label %64, !llvm.loop !596

64:                                               ; preds = %61
  %65 = load ptr, ptr %62, align 8, !tbaa !289
  %66 = icmp eq ptr %65, %1
  br i1 %66, label %76, label %67

67:                                               ; preds = %64
  %68 = getelementptr inbounds nuw i8, ptr %52, i64 24
  %69 = icmp eq ptr %68, %49
  br i1 %69, label %193, label %70, !llvm.loop !596

70:                                               ; preds = %67
  %71 = load ptr, ptr %68, align 8, !tbaa !289
  %72 = icmp eq ptr %71, %1
  br i1 %72, label %76, label %73

73:                                               ; preds = %70
  %74 = getelementptr inbounds nuw i8, ptr %52, i64 32
  %75 = icmp eq ptr %74, %49
  br i1 %75, label %193, label %51, !llvm.loop !597

76:                                               ; preds = %51, %58, %64, %70, %43
  %77 = phi ptr [ %45, %43 ], [ %68, %70 ], [ %62, %64 ], [ %56, %58 ], [ %52, %51 ]
  %78 = icmp eq ptr %77, %49
  br i1 %78, label %193, label %79

79:                                               ; preds = %76
  %80 = getelementptr inbounds nuw i8, ptr %1, i64 216
  %81 = load i8, ptr %80, align 8, !tbaa !80, !range !16, !noundef !17
  %82 = trunc nuw i8 %81 to i1
  %83 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %84 = load ptr, ptr %83, align 8
  %85 = icmp eq ptr %84, %1
  %86 = select i1 %82, i1 true, i1 %85
  br i1 %86, label %193, label %87

87:                                               ; preds = %79
  %88 = load ptr, ptr %5, align 8, !tbaa !19
  %89 = load ptr, ptr %14, align 8, !tbaa !4
  %90 = getelementptr inbounds nuw i8, ptr %89, i64 328
  %91 = load ptr, ptr %90, align 8
  %92 = call noundef i32 %91(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef nonnull %1, ptr noundef null, ptr %88, i64 0, ptr noundef nonnull align 8 dereferenceable(8) %6, ptr noundef null) #33
  br label %193

93:                                               ; preds = %18
  %94 = load ptr, ptr %4, align 8, !tbaa !289
  %95 = icmp eq ptr %94, null
  %96 = load ptr, ptr %3, align 8, !tbaa !289
  br i1 %95, label %134, label %97

97:                                               ; preds = %93
  %98 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %99 = load ptr, ptr %98, align 8, !tbaa !327
  %100 = icmp eq ptr %99, %96
  br i1 %100, label %101, label %119

101:                                              ; preds = %97
  %102 = load ptr, ptr %14, align 8, !tbaa !4
  %103 = getelementptr inbounds nuw i8, ptr %102, i64 856
  %104 = load ptr, ptr %103, align 8
  %105 = call noundef zeroext i1 %104(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(16) %5) #33
  br i1 %105, label %193, label %106

106:                                              ; preds = %101
  %107 = load ptr, ptr %14, align 8, !tbaa !4
  %108 = getelementptr inbounds nuw i8, ptr %107, i64 320
  %109 = load ptr, ptr %108, align 8
  %110 = call noundef i32 %109(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef null) #33
  %111 = load ptr, ptr %4, align 8, !tbaa !289
  %112 = load ptr, ptr %5, align 8, !tbaa !19
  %113 = load i32, ptr %20, align 8, !tbaa !76
  %114 = zext i32 %113 to i64
  %115 = load ptr, ptr %14, align 8, !tbaa !4
  %116 = getelementptr inbounds nuw i8, ptr %115, i64 328
  %117 = load ptr, ptr %116, align 8
  %118 = call noundef i32 %117(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %111, ptr noundef null, ptr %112, i64 %114, ptr noundef nonnull align 8 dereferenceable(8) %6, ptr noundef null) #33
  br label %193

119:                                              ; preds = %97
  %120 = icmp eq ptr %99, %94
  br i1 %120, label %121, label %193

121:                                              ; preds = %119
  %122 = load ptr, ptr %14, align 8, !tbaa !4
  %123 = getelementptr inbounds nuw i8, ptr %122, i64 320
  %124 = load ptr, ptr %123, align 8
  %125 = call noundef i32 %124(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef null) #33
  %126 = load ptr, ptr %3, align 8, !tbaa !289
  %127 = load ptr, ptr %5, align 8, !tbaa !19
  %128 = load i32, ptr %20, align 8, !tbaa !76
  %129 = zext i32 %128 to i64
  %130 = load ptr, ptr %14, align 8, !tbaa !4
  %131 = getelementptr inbounds nuw i8, ptr %130, i64 328
  %132 = load ptr, ptr %131, align 8
  %133 = call noundef i32 %132(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %126, ptr noundef null, ptr %127, i64 %129, ptr noundef nonnull align 8 dereferenceable(8) %6, ptr noundef null) #33
  br label %193

134:                                              ; preds = %93
  %135 = icmp eq ptr %1, %96
  br i1 %135, label %136, label %151

136:                                              ; preds = %134
  %137 = load ptr, ptr %14, align 8, !tbaa !4
  %138 = getelementptr inbounds nuw i8, ptr %137, i64 320
  %139 = load ptr, ptr %138, align 8
  %140 = call noundef i32 %139(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef null) #33
  %141 = load ptr, ptr %3, align 8, !tbaa !289
  %142 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %143 = load ptr, ptr %142, align 8, !tbaa !327
  %144 = icmp eq ptr %143, %141
  br i1 %144, label %193, label %145

145:                                              ; preds = %136
  store i32 0, ptr %20, align 8, !tbaa !76
  %146 = load ptr, ptr %5, align 8, !tbaa !19
  %147 = load ptr, ptr %14, align 8, !tbaa !4
  %148 = getelementptr inbounds nuw i8, ptr %147, i64 328
  %149 = load ptr, ptr %148, align 8
  %150 = call noundef i32 %149(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %141, ptr noundef null, ptr %146, i64 0, ptr noundef nonnull align 8 dereferenceable(8) %6, ptr noundef null) #33
  br label %193

151:                                              ; preds = %134
  %152 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %153 = load ptr, ptr %152, align 8, !tbaa !327
  %154 = icmp eq ptr %153, %96
  br i1 %154, label %155, label %178

155:                                              ; preds = %151
  %156 = load ptr, ptr %14, align 8, !tbaa !4
  %157 = getelementptr inbounds nuw i8, ptr %156, i64 856
  %158 = load ptr, ptr %157, align 8
  %159 = call noundef zeroext i1 %158(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(16) %5) #33
  br i1 %159, label %160, label %166

160:                                              ; preds = %155
  store i32 0, ptr %20, align 8, !tbaa !76
  %161 = load ptr, ptr %5, align 8, !tbaa !19
  %162 = load ptr, ptr %14, align 8, !tbaa !4
  %163 = getelementptr inbounds nuw i8, ptr %162, i64 328
  %164 = load ptr, ptr %163, align 8
  %165 = call noundef i32 %164(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1, ptr noundef null, ptr %161, i64 0, ptr noundef nonnull align 8 dereferenceable(8) %6, ptr noundef null) #33
  br label %193

166:                                              ; preds = %155
  %167 = load ptr, ptr %14, align 8, !tbaa !4
  %168 = getelementptr inbounds nuw i8, ptr %167, i64 320
  %169 = load ptr, ptr %168, align 8
  %170 = call noundef i32 %169(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef null) #33
  %171 = load ptr, ptr %5, align 8, !tbaa !19
  %172 = load i32, ptr %20, align 8, !tbaa !76
  %173 = zext i32 %172 to i64
  %174 = load ptr, ptr %14, align 8, !tbaa !4
  %175 = getelementptr inbounds nuw i8, ptr %174, i64 328
  %176 = load ptr, ptr %175, align 8
  %177 = call noundef i32 %176(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1, ptr noundef null, ptr %171, i64 %173, ptr noundef nonnull align 8 dereferenceable(8) %6, ptr noundef null) #33
  br label %193

178:                                              ; preds = %151
  %179 = icmp eq ptr %153, %1
  br i1 %179, label %193, label %180

180:                                              ; preds = %178
  %181 = load ptr, ptr %14, align 8, !tbaa !4
  %182 = getelementptr inbounds nuw i8, ptr %181, i64 320
  %183 = load ptr, ptr %182, align 8
  %184 = call noundef i32 %183(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef null) #33
  %185 = load ptr, ptr %3, align 8, !tbaa !289
  %186 = load ptr, ptr %5, align 8, !tbaa !19
  %187 = load i32, ptr %20, align 8, !tbaa !76
  %188 = zext i32 %187 to i64
  %189 = load ptr, ptr %14, align 8, !tbaa !4
  %190 = getelementptr inbounds nuw i8, ptr %189, i64 328
  %191 = load ptr, ptr %190, align 8
  %192 = call noundef i32 %191(ptr noundef nonnull align 8 dereferenceable(112) %14, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %185, ptr noundef %1, ptr %186, i64 %188, ptr noundef nonnull align 8 dereferenceable(8) %6, ptr noundef null) #33
  br label %193

193:                                              ; preds = %73, %67, %61, %55, %166, %180, %178, %136, %145, %106, %121, %119, %101, %36, %32, %87, %41, %76, %79, %160
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %6) #33
  %194 = load ptr, ptr %5, align 8, !tbaa !19
  %195 = icmp eq ptr %194, %19
  br i1 %195, label %197, label %196

196:                                              ; preds = %193
  call void @free(ptr noundef %194) #33
  br label %197

197:                                              ; preds = %193, %196
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %5) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %4) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3) #33
  br label %198

198:                                              ; preds = %2, %197
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock18findBranchDebugLocEv(ptr noundef nonnull align 8 dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = tail call ptr @_ZN4llvm17MachineBasicBlock18getFirstTerminatorEv(ptr noundef nonnull align 8 dereferenceable(288) %0)
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %4 = icmp eq ptr %2, %3
  br i1 %4, label %113, label %5

5:                                                ; preds = %1, %39
  %6 = phi ptr [ %42, %39 ], [ %2, %1 ]
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 44
  %8 = load i32, ptr %7, align 4, !tbaa !309
  %9 = and i32 %8, 12
  %10 = icmp eq i32 %9, 0
  %11 = and i32 %8, 4
  %12 = icmp ne i32 %11, 0
  %13 = or i1 %10, %12
  br i1 %13, label %14, label %21

14:                                               ; preds = %5
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 16
  %16 = load ptr, ptr %15, align 8, !tbaa !314
  %17 = getelementptr inbounds nuw i8, ptr %16, i64 16
  %18 = load i64, ptr %17, align 8, !tbaa !315
  %19 = and i64 %18, 1024
  %20 = icmp eq i64 %19, 0
  br i1 %20, label %23, label %44

21:                                               ; preds = %5
  %22 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %6, i64 noundef 1024, i32 noundef 1) #33
  br i1 %22, label %44, label %23

23:                                               ; preds = %14, %21
  %24 = load i64, ptr %6, align 8
  %25 = and i64 %24, 4
  %26 = icmp eq i64 %25, 0
  br i1 %26, label %27, label %39

27:                                               ; preds = %23
  %28 = load i32, ptr %7, align 4, !tbaa !309
  %29 = and i32 %28, 8
  %30 = icmp eq i32 %29, 0
  br i1 %30, label %39, label %31

31:                                               ; preds = %27, %31
  %32 = phi ptr [ %34, %31 ], [ %6, %27 ]
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 8
  %34 = load ptr, ptr %33, align 8, !tbaa !75
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 44
  %36 = load i32, ptr %35, align 4, !tbaa !309
  %37 = and i32 %36, 8
  %38 = icmp eq i32 %37, 0
  br i1 %38, label %39, label %31, !llvm.loop !310

39:                                               ; preds = %31, %23, %27
  %40 = phi ptr [ %6, %23 ], [ %6, %27 ], [ %34, %31 ]
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 8
  %42 = load ptr, ptr %41, align 8, !tbaa !75
  %43 = icmp eq ptr %42, %3
  br i1 %43, label %113, label %5, !llvm.loop !598

44:                                               ; preds = %14, %21
  %45 = getelementptr inbounds nuw i8, ptr %6, i64 72
  %46 = load i64, ptr %45, align 8, !tbaa !585
  %47 = inttoptr i64 %46 to ptr
  %48 = load i64, ptr %6, align 8
  %49 = and i64 %48, 4
  %50 = icmp eq i64 %49, 0
  br i1 %50, label %51, label %63

51:                                               ; preds = %44
  %52 = load i32, ptr %7, align 4, !tbaa !309
  %53 = and i32 %52, 8
  %54 = icmp eq i32 %53, 0
  br i1 %54, label %63, label %55

55:                                               ; preds = %51, %55
  %56 = phi ptr [ %58, %55 ], [ %6, %51 ]
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 8
  %58 = load ptr, ptr %57, align 8, !tbaa !75
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 44
  %60 = load i32, ptr %59, align 4, !tbaa !309
  %61 = and i32 %60, 8
  %62 = icmp eq i32 %61, 0
  br i1 %62, label %63, label %55, !llvm.loop !310

63:                                               ; preds = %55, %44, %51
  %64 = phi ptr [ %6, %44 ], [ %6, %51 ], [ %58, %55 ]
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 8
  %66 = load ptr, ptr %65, align 8, !tbaa !75
  %67 = icmp eq ptr %66, %3
  br i1 %67, label %113, label %68

68:                                               ; preds = %63, %108
  %69 = phi ptr [ %111, %108 ], [ %66, %63 ]
  %70 = phi ptr [ %92, %108 ], [ %47, %63 ]
  %71 = getelementptr inbounds nuw i8, ptr %69, i64 44
  %72 = load i32, ptr %71, align 4, !tbaa !309
  %73 = and i32 %72, 12
  %74 = icmp eq i32 %73, 0
  %75 = and i32 %72, 4
  %76 = icmp ne i32 %75, 0
  %77 = or i1 %74, %76
  br i1 %77, label %78, label %85

78:                                               ; preds = %68
  %79 = getelementptr inbounds nuw i8, ptr %69, i64 16
  %80 = load ptr, ptr %79, align 8, !tbaa !314
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 16
  %82 = load i64, ptr %81, align 8, !tbaa !315
  %83 = and i64 %82, 1024
  %84 = icmp eq i64 %83, 0
  br i1 %84, label %91, label %87

85:                                               ; preds = %68
  %86 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %69, i64 noundef 1024, i32 noundef 1) #33
  br i1 %86, label %87, label %91

87:                                               ; preds = %78, %85
  %88 = getelementptr inbounds nuw i8, ptr %69, i64 72
  %89 = load ptr, ptr %88, align 8, !tbaa !585
  %90 = tail call ptr @_ZN4llvm8DebugLoc17getMergedLocationES0_S0_(ptr %70, ptr %89) #33
  br label %91

91:                                               ; preds = %78, %85, %87
  %92 = phi ptr [ %90, %87 ], [ %70, %85 ], [ %70, %78 ]
  %93 = load i64, ptr %69, align 8
  %94 = and i64 %93, 4
  %95 = icmp eq i64 %94, 0
  br i1 %95, label %96, label %108

96:                                               ; preds = %91
  %97 = load i32, ptr %71, align 4, !tbaa !309
  %98 = and i32 %97, 8
  %99 = icmp eq i32 %98, 0
  br i1 %99, label %108, label %100

100:                                              ; preds = %96, %100
  %101 = phi ptr [ %103, %100 ], [ %69, %96 ]
  %102 = getelementptr inbounds nuw i8, ptr %101, i64 8
  %103 = load ptr, ptr %102, align 8, !tbaa !75
  %104 = getelementptr inbounds nuw i8, ptr %103, i64 44
  %105 = load i32, ptr %104, align 4, !tbaa !309
  %106 = and i32 %105, 8
  %107 = icmp eq i32 %106, 0
  br i1 %107, label %108, label %100, !llvm.loop !310

108:                                              ; preds = %100, %91, %96
  %109 = phi ptr [ %69, %91 ], [ %69, %96 ], [ %103, %100 ]
  %110 = getelementptr inbounds nuw i8, ptr %109, i64 8
  %111 = load ptr, ptr %110, align 8, !tbaa !75
  %112 = icmp eq ptr %111, %3
  br i1 %112, label %113, label %68, !llvm.loop !599

113:                                              ; preds = %39, %108, %1, %63
  %114 = phi ptr [ %47, %63 ], [ null, %1 ], [ %92, %108 ], [ null, %39 ]
  ret ptr %114
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock17isLayoutSuccessorEPKS0_(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr noundef readnone captures(address) %1) local_unnamed_addr #14 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %4 = load ptr, ptr %3, align 8, !tbaa !327
  %5 = icmp eq ptr %4, %1
  ret i1 %5
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock11isSuccessorEPKS0_(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr noundef readnone captures(address) %1) local_unnamed_addr #10 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %4 = load ptr, ptr %3, align 8, !tbaa !19
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %6 = load i32, ptr %5, align 8, !tbaa !76
  %7 = zext i32 %6 to i64
  %8 = shl nuw nsw i64 %7, 3
  %9 = getelementptr inbounds nuw i8, ptr %4, i64 %8
  %10 = icmp eq i32 %6, 0
  br i1 %10, label %36, label %11

11:                                               ; preds = %2, %33
  %12 = phi ptr [ %34, %33 ], [ %4, %2 ]
  %13 = load ptr, ptr %12, align 8, !tbaa !289
  %14 = icmp eq ptr %13, %1
  br i1 %14, label %36, label %15

15:                                               ; preds = %11
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 8
  %17 = icmp eq ptr %16, %9
  br i1 %17, label %36, label %18, !llvm.loop !596

18:                                               ; preds = %15
  %19 = load ptr, ptr %16, align 8, !tbaa !289
  %20 = icmp eq ptr %19, %1
  br i1 %20, label %36, label %21

21:                                               ; preds = %18
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 16
  %23 = icmp eq ptr %22, %9
  br i1 %23, label %36, label %24, !llvm.loop !596

24:                                               ; preds = %21
  %25 = load ptr, ptr %22, align 8, !tbaa !289
  %26 = icmp eq ptr %25, %1
  br i1 %26, label %36, label %27

27:                                               ; preds = %24
  %28 = getelementptr inbounds nuw i8, ptr %12, i64 24
  %29 = icmp eq ptr %28, %9
  br i1 %29, label %36, label %30, !llvm.loop !596

30:                                               ; preds = %27
  %31 = load ptr, ptr %28, align 8, !tbaa !289
  %32 = icmp eq ptr %31, %1
  br i1 %32, label %36, label %33

33:                                               ; preds = %30
  %34 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %35 = icmp eq ptr %34, %9
  br i1 %35, label %36, label %11, !llvm.loop !597

36:                                               ; preds = %11, %15, %18, %21, %24, %27, %30, %33, %2
  %37 = phi ptr [ %4, %2 ], [ %12, %11 ], [ %9, %15 ], [ %16, %18 ], [ %9, %21 ], [ %22, %24 ], [ %9, %27 ], [ %28, %30 ], [ %9, %33 ]
  %38 = icmp ne ptr %37, %9
  ret i1 %38
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local void @_ZNK4llvm17MachineBasicBlock17validateSuccProbsEv(ptr noundef nonnull readnone align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #15 align 2 {
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock12addSuccessorEPS0_NS_17BranchProbabilityE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1, i32 %2) local_unnamed_addr #3 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %5 = load ptr, ptr %4, align 8, !tbaa !345
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %7 = load ptr, ptr %6, align 8, !tbaa !345
  %8 = icmp ne ptr %5, %7
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %10 = load i32, ptr %9, align 8
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %8, i1 true, i1 %11
  br i1 %12, label %13, label %81

13:                                               ; preds = %3
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 160
  %15 = load ptr, ptr %14, align 8, !tbaa !86
  %16 = icmp eq ptr %7, %15
  br i1 %16, label %19, label %17

17:                                               ; preds = %13
  store i32 %2, ptr %7, align 4, !tbaa !451
  %18 = getelementptr inbounds nuw i8, ptr %7, i64 4
  store ptr %18, ptr %6, align 8, !tbaa !600
  br label %81

19:                                               ; preds = %13
  %20 = ptrtoint ptr %7 to i64
  %21 = ptrtoint ptr %5 to i64
  %22 = sub i64 %20, %21
  %23 = ashr exact i64 %22, 2
  %24 = icmp sgt i64 %23, -1
  tail call void @llvm.assume(i1 %24)
  %25 = icmp eq i64 %22, 9223372036854775804
  br i1 %25, label %26, label %27

26:                                               ; preds = %19
  tail call void @_ZSt20__throw_length_errorPKc(ptr noundef nonnull @.str.42) #35
  unreachable

27:                                               ; preds = %19
  %28 = tail call i64 @llvm.umax.i64(i64 %23, i64 1)
  %29 = add nuw nsw i64 %28, %23
  %30 = tail call noundef i64 @llvm.umin.i64(i64 %29, i64 2305843009213693951)
  %31 = shl nuw nsw i64 %30, 2
  %32 = tail call noalias noundef nonnull ptr @_Znwm(i64 noundef %31) #36
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 %22
  store i32 %2, ptr %33, align 4, !tbaa !451
  br i1 %8, label %34, label %74

34:                                               ; preds = %27
  %35 = ptrtoint ptr %32 to i64
  %36 = add i64 %20, -4
  %37 = sub i64 %36, %21
  %38 = lshr i64 %37, 2
  %39 = add nuw nsw i64 %38, 1
  %40 = icmp ult i64 %37, 28
  %41 = sub i64 %35, %21
  %42 = icmp ult i64 %41, 32
  %43 = or i1 %40, %42
  br i1 %43, label %64, label %44

44:                                               ; preds = %34
  %45 = and i64 %39, 9223372036854775800
  %46 = shl i64 %45, 2
  %47 = getelementptr i8, ptr %32, i64 %46
  %48 = shl i64 %45, 2
  %49 = getelementptr i8, ptr %5, i64 %48
  br label %50

50:                                               ; preds = %50, %44
  %51 = phi i64 [ 0, %44 ], [ %60, %50 ]
  %52 = shl i64 %51, 2
  %53 = getelementptr i8, ptr %32, i64 %52
  %54 = shl i64 %51, 2
  %55 = getelementptr i8, ptr %5, i64 %54
  tail call void @llvm.experimental.noalias.scope.decl(metadata !601)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !604)
  %56 = getelementptr i8, ptr %55, i64 16
  %57 = load <4 x i32>, ptr %55, align 4, !tbaa !451, !alias.scope !604, !noalias !601
  %58 = load <4 x i32>, ptr %56, align 4, !tbaa !451, !alias.scope !604, !noalias !601
  %59 = getelementptr i8, ptr %53, i64 16
  store <4 x i32> %57, ptr %53, align 4, !tbaa !451, !alias.scope !601, !noalias !604
  store <4 x i32> %58, ptr %59, align 4, !tbaa !451, !alias.scope !601, !noalias !604
  %60 = add nuw i64 %51, 8
  %61 = icmp eq i64 %60, %45
  br i1 %61, label %62, label %50, !llvm.loop !606

62:                                               ; preds = %50
  %63 = icmp eq i64 %39, %45
  br i1 %63, label %74, label %64

64:                                               ; preds = %34, %62
  %65 = phi ptr [ %32, %34 ], [ %47, %62 ]
  %66 = phi ptr [ %5, %34 ], [ %49, %62 ]
  br label %67

67:                                               ; preds = %64, %67
  %68 = phi ptr [ %72, %67 ], [ %65, %64 ]
  %69 = phi ptr [ %71, %67 ], [ %66, %64 ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !601)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !604)
  %70 = load i32, ptr %69, align 4, !tbaa !451, !alias.scope !604, !noalias !601
  store i32 %70, ptr %68, align 4, !tbaa !451, !alias.scope !601, !noalias !604
  %71 = getelementptr inbounds nuw i8, ptr %69, i64 4
  %72 = getelementptr inbounds nuw i8, ptr %68, i64 4
  %73 = icmp eq ptr %71, %7
  br i1 %73, label %74, label %67, !llvm.loop !609

74:                                               ; preds = %67, %62, %27
  %75 = phi ptr [ %32, %27 ], [ %47, %62 ], [ %72, %67 ]
  %76 = icmp eq ptr %5, null
  br i1 %76, label %78, label %77

77:                                               ; preds = %74
  tail call void @_ZdlPvm(ptr noundef nonnull %5, i64 noundef %22) #34
  br label %78

78:                                               ; preds = %77, %74
  %79 = getelementptr inbounds nuw i8, ptr %75, i64 4
  store ptr %32, ptr %4, align 8, !tbaa !87
  store ptr %79, ptr %6, align 8, !tbaa !600
  %80 = getelementptr inbounds nuw %"class.llvm::BranchProbability", ptr %32, i64 %30
  store ptr %80, ptr %14, align 8, !tbaa !86
  br label %81

81:                                               ; preds = %3, %78, %17
  %82 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %83 = load i32, ptr %9, align 8, !tbaa !76
  %84 = getelementptr inbounds nuw i8, ptr %0, i64 124
  %85 = load i32, ptr %84, align 4, !tbaa !77
  %86 = icmp ult i32 %83, %85
  br i1 %86, label %88, label %87, !prof !483

87:                                               ; preds = %81
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %82, ptr noundef %1)
  br label %94

88:                                               ; preds = %81
  %89 = zext i32 %83 to i64
  %90 = load ptr, ptr %82, align 8, !tbaa !19
  %91 = getelementptr inbounds nuw ptr, ptr %90, i64 %89
  store ptr %1, ptr %91, align 1
  %92 = load i32, ptr %9, align 8, !tbaa !76
  %93 = add i32 %92, 1
  store i32 %93, ptr %9, align 8, !tbaa !76
  br label %94

94:                                               ; preds = %87, %88
  %95 = getelementptr inbounds nuw i8, ptr %1, i64 64
  %96 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %97 = load i32, ptr %96, align 8, !tbaa !76
  %98 = getelementptr inbounds nuw i8, ptr %1, i64 76
  %99 = load i32, ptr %98, align 4, !tbaa !77
  %100 = icmp ult i32 %97, %99
  br i1 %100, label %102, label %101, !prof !483

101:                                              ; preds = %94
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %95, ptr noundef nonnull %0)
  br label %108

102:                                              ; preds = %94
  %103 = zext i32 %97 to i64
  %104 = load ptr, ptr %95, align 8, !tbaa !19
  %105 = getelementptr inbounds nuw ptr, ptr %104, i64 %103
  store ptr %0, ptr %105, align 1
  %106 = load i32, ptr %96, align 8, !tbaa !76
  %107 = add i32 %106, 1
  store i32 %107, ptr %96, align 8, !tbaa !76
  br label %108

108:                                              ; preds = %101, %102
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock14addPredecessorEPS0_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 72
  %5 = load i32, ptr %4, align 8, !tbaa !76
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 76
  %7 = load i32, ptr %6, align 4, !tbaa !77
  %8 = icmp ult i32 %5, %7
  br i1 %8, label %10, label %9, !prof !483

9:                                                ; preds = %2
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %3, ptr noundef %1)
  br label %16

10:                                               ; preds = %2
  %11 = zext i32 %5 to i64
  %12 = load ptr, ptr %3, align 8, !tbaa !19
  %13 = getelementptr inbounds nuw ptr, ptr %12, i64 %11
  store ptr %1, ptr %13, align 1
  %14 = load i32, ptr %4, align 8, !tbaa !76
  %15 = add i32 %14, 1
  store i32 %15, ptr %4, align 8, !tbaa !76
  br label %16

16:                                               ; preds = %9, %10
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock23addSuccessorWithoutProbEPS0_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %4 = load ptr, ptr %3, align 8, !tbaa !87
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %6 = load ptr, ptr %5, align 8, !tbaa !600
  %7 = icmp eq ptr %6, %4
  br i1 %7, label %9, label %8

8:                                                ; preds = %2
  store ptr %4, ptr %5, align 8, !tbaa !600
  br label %9

9:                                                ; preds = %2, %8
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %12 = load i32, ptr %11, align 8, !tbaa !76
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 124
  %14 = load i32, ptr %13, align 4, !tbaa !77
  %15 = icmp ult i32 %12, %14
  br i1 %15, label %17, label %16, !prof !483

16:                                               ; preds = %9
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %10, ptr noundef %1)
  br label %23

17:                                               ; preds = %9
  %18 = zext i32 %12 to i64
  %19 = load ptr, ptr %10, align 8, !tbaa !19
  %20 = getelementptr inbounds nuw ptr, ptr %19, i64 %18
  store ptr %1, ptr %20, align 1
  %21 = load i32, ptr %11, align 8, !tbaa !76
  %22 = add i32 %21, 1
  store i32 %22, ptr %11, align 8, !tbaa !76
  br label %23

23:                                               ; preds = %16, %17
  %24 = getelementptr inbounds nuw i8, ptr %1, i64 64
  %25 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %26 = load i32, ptr %25, align 8, !tbaa !76
  %27 = getelementptr inbounds nuw i8, ptr %1, i64 76
  %28 = load i32, ptr %27, align 4, !tbaa !77
  %29 = icmp ult i32 %26, %28
  br i1 %29, label %31, label %30, !prof !483

30:                                               ; preds = %23
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %24, ptr noundef nonnull %0)
  br label %37

31:                                               ; preds = %23
  %32 = zext i32 %26 to i64
  %33 = load ptr, ptr %24, align 8, !tbaa !19
  %34 = getelementptr inbounds nuw ptr, ptr %33, i64 %32
  store ptr %0, ptr %34, align 1
  %35 = load i32, ptr %25, align 8, !tbaa !76
  %36 = add i32 %35, 1
  store i32 %36, ptr %25, align 8, !tbaa !76
  br label %37

37:                                               ; preds = %30, %31
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock14splitSuccessorEPS0_S1_b(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef readnone captures(address) %1, ptr noundef %2, i1 noundef zeroext %3) local_unnamed_addr #3 align 2 {
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %6 = load ptr, ptr %5, align 8, !tbaa !19
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %8 = load i32, ptr %7, align 8, !tbaa !76
  %9 = zext i32 %8 to i64
  %10 = shl nuw nsw i64 %9, 3
  %11 = getelementptr inbounds nuw i8, ptr %6, i64 %10
  %12 = icmp eq i32 %8, 0
  br i1 %12, label %38, label %13

13:                                               ; preds = %4, %35
  %14 = phi ptr [ %36, %35 ], [ %6, %4 ]
  %15 = load ptr, ptr %14, align 8, !tbaa !289
  %16 = icmp eq ptr %15, %1
  br i1 %16, label %38, label %17

17:                                               ; preds = %13
  %18 = getelementptr inbounds nuw i8, ptr %14, i64 8
  %19 = icmp eq ptr %18, %11
  br i1 %19, label %38, label %20, !llvm.loop !610

20:                                               ; preds = %17
  %21 = load ptr, ptr %18, align 8, !tbaa !289
  %22 = icmp eq ptr %21, %1
  br i1 %22, label %38, label %23

23:                                               ; preds = %20
  %24 = getelementptr inbounds nuw i8, ptr %14, i64 16
  %25 = icmp eq ptr %24, %11
  br i1 %25, label %38, label %26, !llvm.loop !610

26:                                               ; preds = %23
  %27 = load ptr, ptr %24, align 8, !tbaa !289
  %28 = icmp eq ptr %27, %1
  br i1 %28, label %38, label %29

29:                                               ; preds = %26
  %30 = getelementptr inbounds nuw i8, ptr %14, i64 24
  %31 = icmp eq ptr %30, %11
  br i1 %31, label %38, label %32, !llvm.loop !610

32:                                               ; preds = %29
  %33 = load ptr, ptr %30, align 8, !tbaa !289
  %34 = icmp eq ptr %33, %1
  br i1 %34, label %38, label %35

35:                                               ; preds = %32
  %36 = getelementptr inbounds nuw i8, ptr %14, i64 32
  %37 = icmp eq ptr %36, %11
  br i1 %37, label %38, label %13, !llvm.loop !611

38:                                               ; preds = %13, %17, %20, %23, %26, %29, %32, %35, %4
  %39 = phi ptr [ %6, %4 ], [ %14, %13 ], [ %11, %17 ], [ %18, %20 ], [ %11, %23 ], [ %24, %26 ], [ %11, %29 ], [ %30, %32 ], [ %11, %35 ]
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %41 = load ptr, ptr %40, align 8, !tbaa !345
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %43 = load ptr, ptr %42, align 8, !tbaa !345
  %44 = icmp eq ptr %41, %43
  br i1 %44, label %52, label %45

45:                                               ; preds = %38
  %46 = ptrtoint ptr %39 to i64
  %47 = ptrtoint ptr %6 to i64
  %48 = sub i64 %46, %47
  %49 = ashr exact i64 %48, 1
  %50 = getelementptr inbounds i8, ptr %41, i64 %49
  %51 = load i32, ptr %50, align 4, !tbaa !451
  br label %52

52:                                               ; preds = %38, %45
  %53 = phi i32 [ %51, %45 ], [ -1, %38 ]
  tail call void @_ZN4llvm17MachineBasicBlock12addSuccessorEPS0_NS_17BranchProbabilityE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %2, i32 %53)
  br i1 %3, label %54, label %268

54:                                               ; preds = %52
  %55 = load ptr, ptr %40, align 8, !tbaa !345
  %56 = load ptr, ptr %42, align 8, !tbaa !345
  %57 = icmp eq ptr %55, %56
  br i1 %57, label %268, label %58

58:                                               ; preds = %54
  %59 = ptrtoint ptr %56 to i64
  %60 = ptrtoint ptr %55 to i64
  %61 = add i64 %59, -4
  %62 = sub i64 %61, %60
  %63 = lshr i64 %62, 2
  %64 = add nuw nsw i64 %63, 1
  %65 = icmp ult i64 %62, 12
  br i1 %65, label %101, label %66

66:                                               ; preds = %58
  %67 = and i64 %64, 9223372036854775804
  %68 = shl i64 %67, 2
  %69 = getelementptr i8, ptr %55, i64 %68
  br label %70

70:                                               ; preds = %70, %66
  %71 = phi i64 [ 0, %66 ], [ %93, %70 ]
  %72 = phi <2 x i32> [ zeroinitializer, %66 ], [ %85, %70 ]
  %73 = phi <2 x i32> [ zeroinitializer, %66 ], [ %86, %70 ]
  %74 = phi <2 x i64> [ zeroinitializer, %66 ], [ %91, %70 ]
  %75 = phi <2 x i64> [ zeroinitializer, %66 ], [ %92, %70 ]
  %76 = shl i64 %71, 2
  %77 = getelementptr i8, ptr %55, i64 %76
  %78 = getelementptr i8, ptr %77, i64 8
  %79 = load <2 x i32>, ptr %77, align 4, !tbaa !349
  %80 = load <2 x i32>, ptr %78, align 4, !tbaa !349
  %81 = icmp eq <2 x i32> %79, splat (i32 -1)
  %82 = icmp eq <2 x i32> %80, splat (i32 -1)
  %83 = zext <2 x i1> %81 to <2 x i32>
  %84 = zext <2 x i1> %82 to <2 x i32>
  %85 = add <2 x i32> %72, %83
  %86 = add <2 x i32> %73, %84
  %87 = select <2 x i1> %81, <2 x i32> zeroinitializer, <2 x i32> %79
  %88 = select <2 x i1> %82, <2 x i32> zeroinitializer, <2 x i32> %80
  %89 = zext <2 x i32> %87 to <2 x i64>
  %90 = zext <2 x i32> %88 to <2 x i64>
  %91 = add <2 x i64> %74, %89
  %92 = add <2 x i64> %75, %90
  %93 = add nuw i64 %71, 4
  %94 = icmp eq i64 %93, %67
  br i1 %94, label %95, label %70, !llvm.loop !612

95:                                               ; preds = %70
  %96 = add <2 x i32> %86, %85
  %97 = tail call i32 @llvm.vector.reduce.add.v2i32(<2 x i32> %96)
  %98 = add <2 x i64> %92, %91
  %99 = tail call i64 @llvm.vector.reduce.add.v2i64(<2 x i64> %98)
  %100 = icmp eq i64 %64, %67
  br i1 %100, label %118, label %101

101:                                              ; preds = %58, %95
  %102 = phi i32 [ 0, %58 ], [ %97, %95 ]
  %103 = phi i64 [ 0, %58 ], [ %99, %95 ]
  %104 = phi ptr [ %55, %58 ], [ %69, %95 ]
  br label %105

105:                                              ; preds = %101, %105
  %106 = phi i32 [ %112, %105 ], [ %102, %101 ]
  %107 = phi i64 [ %115, %105 ], [ %103, %101 ]
  %108 = phi ptr [ %116, %105 ], [ %104, %101 ]
  %109 = load i32, ptr %108, align 4, !tbaa !349
  %110 = icmp eq i32 %109, -1
  %111 = zext i1 %110 to i32
  %112 = add i32 %106, %111
  %113 = select i1 %110, i32 0, i32 %109
  %114 = zext i32 %113 to i64
  %115 = add i64 %107, %114
  %116 = getelementptr inbounds nuw i8, ptr %108, i64 4
  %117 = icmp eq ptr %116, %56
  br i1 %117, label %118, label %105, !llvm.loop !613

118:                                              ; preds = %105, %95
  %119 = phi i32 [ %97, %95 ], [ %112, %105 ]
  %120 = phi i64 [ %99, %95 ], [ %115, %105 ]
  %121 = icmp eq i32 %119, 0
  br i1 %121, label %198, label %122

122:                                              ; preds = %118
  %123 = icmp ult i64 %120, 2147483648
  br i1 %123, label %124, label %128

124:                                              ; preds = %122
  %125 = trunc nuw nsw i64 %120 to i32
  %126 = sub nuw i32 -2147483648, %125
  %127 = udiv i32 %126, %119
  br label %128

128:                                              ; preds = %124, %122
  %129 = phi i32 [ %127, %124 ], [ 0, %122 ]
  %130 = icmp ult i64 %62, 28
  br i1 %130, label %186, label %131

131:                                              ; preds = %128
  %132 = and i64 %64, 9223372036854775800
  %133 = shl i64 %132, 2
  %134 = getelementptr i8, ptr %55, i64 %133
  %135 = getelementptr i8, ptr %55, i64 4
  %136 = getelementptr i8, ptr %55, i64 8
  %137 = getelementptr i8, ptr %55, i64 12
  %138 = getelementptr i8, ptr %55, i64 16
  %139 = getelementptr i8, ptr %55, i64 20
  %140 = getelementptr i8, ptr %55, i64 24
  %141 = getelementptr i8, ptr %55, i64 28
  br label %142

142:                                              ; preds = %181, %131
  %143 = phi i64 [ 0, %131 ], [ %182, %181 ]
  %144 = shl i64 %143, 2
  %145 = getelementptr i8, ptr %55, i64 %144
  %146 = getelementptr i8, ptr %135, i64 %144
  %147 = getelementptr i8, ptr %136, i64 %144
  %148 = getelementptr i8, ptr %137, i64 %144
  %149 = getelementptr i8, ptr %138, i64 %144
  %150 = getelementptr i8, ptr %139, i64 %144
  %151 = getelementptr i8, ptr %140, i64 %144
  %152 = getelementptr i8, ptr %141, i64 %144
  %153 = getelementptr i8, ptr %145, i64 16
  %154 = load <4 x i32>, ptr %145, align 4, !tbaa !349
  %155 = load <4 x i32>, ptr %153, align 4, !tbaa !349
  %156 = icmp eq <4 x i32> %154, splat (i32 -1)
  %157 = icmp eq <4 x i32> %155, splat (i32 -1)
  %158 = extractelement <4 x i1> %156, i64 0
  br i1 %158, label %159, label %160

159:                                              ; preds = %142
  store i32 %129, ptr %145, align 4, !tbaa !451
  br label %160

160:                                              ; preds = %159, %142
  %161 = extractelement <4 x i1> %156, i64 1
  br i1 %161, label %162, label %163

162:                                              ; preds = %160
  store i32 %129, ptr %146, align 4, !tbaa !451
  br label %163

163:                                              ; preds = %162, %160
  %164 = extractelement <4 x i1> %156, i64 2
  br i1 %164, label %165, label %166

165:                                              ; preds = %163
  store i32 %129, ptr %147, align 4, !tbaa !451
  br label %166

166:                                              ; preds = %165, %163
  %167 = extractelement <4 x i1> %156, i64 3
  br i1 %167, label %168, label %169

168:                                              ; preds = %166
  store i32 %129, ptr %148, align 4, !tbaa !451
  br label %169

169:                                              ; preds = %168, %166
  %170 = extractelement <4 x i1> %157, i64 0
  br i1 %170, label %171, label %172

171:                                              ; preds = %169
  store i32 %129, ptr %149, align 4, !tbaa !451
  br label %172

172:                                              ; preds = %171, %169
  %173 = extractelement <4 x i1> %157, i64 1
  br i1 %173, label %174, label %175

174:                                              ; preds = %172
  store i32 %129, ptr %150, align 4, !tbaa !451
  br label %175

175:                                              ; preds = %174, %172
  %176 = extractelement <4 x i1> %157, i64 2
  br i1 %176, label %177, label %178

177:                                              ; preds = %175
  store i32 %129, ptr %151, align 4, !tbaa !451
  br label %178

178:                                              ; preds = %177, %175
  %179 = extractelement <4 x i1> %157, i64 3
  br i1 %179, label %180, label %181

180:                                              ; preds = %178
  store i32 %129, ptr %152, align 4, !tbaa !451
  br label %181

181:                                              ; preds = %180, %178
  %182 = add nuw i64 %143, 8
  %183 = icmp eq i64 %182, %132
  br i1 %183, label %184, label %142, !llvm.loop !614

184:                                              ; preds = %181
  %185 = icmp eq i64 %64, %132
  br i1 %185, label %196, label %186

186:                                              ; preds = %128, %184
  %187 = phi ptr [ %55, %128 ], [ %134, %184 ]
  br label %188

188:                                              ; preds = %186, %193
  %189 = phi ptr [ %194, %193 ], [ %187, %186 ]
  %190 = load i32, ptr %189, align 4, !tbaa !349
  %191 = icmp eq i32 %190, -1
  br i1 %191, label %192, label %193

192:                                              ; preds = %188
  store i32 %129, ptr %189, align 4, !tbaa !451
  br label %193

193:                                              ; preds = %192, %188
  %194 = getelementptr inbounds nuw i8, ptr %189, i64 4
  %195 = icmp eq ptr %194, %56
  br i1 %195, label %196, label %188, !llvm.loop !615

196:                                              ; preds = %193, %184
  %197 = icmp ult i64 %120, 2147483649
  br i1 %197, label %268, label %236

198:                                              ; preds = %118
  %199 = icmp eq i64 %120, 0
  br i1 %199, label %200, label %236

200:                                              ; preds = %198
  %201 = ptrtoint ptr %56 to i64
  %202 = ptrtoint ptr %55 to i64
  %203 = sub i64 %201, %202
  %204 = lshr exact i64 %203, 2
  %205 = trunc i64 %204 to i32
  %206 = icmp eq i32 %205, -2147483648
  br i1 %206, label %212, label %207

207:                                              ; preds = %200
  %208 = lshr i64 %203, 3
  %209 = trunc i64 %208 to i32
  %210 = or i32 %209, -2147483648
  %211 = udiv i32 %210, %205
  br label %212

212:                                              ; preds = %207, %200
  %213 = phi i32 [ %211, %207 ], [ 1, %200 ]
  %214 = icmp ult i64 %62, 28
  br i1 %214, label %230, label %215

215:                                              ; preds = %212
  %216 = and i64 %64, 9223372036854775800
  %217 = shl i64 %216, 2
  %218 = getelementptr i8, ptr %55, i64 %217
  %219 = insertelement <4 x i32> poison, i32 %213, i64 0
  %220 = shufflevector <4 x i32> %219, <4 x i32> poison, <4 x i32> zeroinitializer
  br label %221

221:                                              ; preds = %221, %215
  %222 = phi i64 [ 0, %215 ], [ %226, %221 ]
  %223 = shl i64 %222, 2
  %224 = getelementptr i8, ptr %55, i64 %223
  %225 = getelementptr i8, ptr %224, i64 16
  store <4 x i32> %220, ptr %224, align 4, !tbaa !451
  store <4 x i32> %220, ptr %225, align 4, !tbaa !451
  %226 = add nuw i64 %222, 8
  %227 = icmp eq i64 %226, %216
  br i1 %227, label %228, label %221, !llvm.loop !616

228:                                              ; preds = %221
  %229 = icmp eq i64 %64, %216
  br i1 %229, label %268, label %230

230:                                              ; preds = %212, %228
  %231 = phi ptr [ %55, %212 ], [ %218, %228 ]
  br label %232

232:                                              ; preds = %230, %232
  %233 = phi ptr [ %234, %232 ], [ %231, %230 ]
  store i32 %213, ptr %233, align 4, !tbaa !451
  %234 = getelementptr inbounds nuw i8, ptr %233, i64 4
  %235 = icmp eq ptr %234, %56
  br i1 %235, label %268, label %232, !llvm.loop !617

236:                                              ; preds = %198, %196
  %237 = lshr i64 %120, 1
  %238 = and i64 %62, 4
  %239 = icmp eq i64 %238, 0
  br i1 %239, label %240, label %248

240:                                              ; preds = %236
  %241 = load i32, ptr %55, align 4, !tbaa !349
  %242 = zext i32 %241 to i64
  %243 = shl nuw nsw i64 %242, 31
  %244 = add nuw i64 %243, %237
  %245 = udiv i64 %244, %120
  %246 = trunc i64 %245 to i32
  store i32 %246, ptr %55, align 4, !tbaa !349
  %247 = getelementptr inbounds nuw i8, ptr %55, i64 4
  br label %248

248:                                              ; preds = %240, %236
  %249 = phi ptr [ %55, %236 ], [ %247, %240 ]
  %250 = icmp ult i64 %62, 4
  br i1 %250, label %268, label %251

251:                                              ; preds = %248, %251
  %252 = phi ptr [ %266, %251 ], [ %249, %248 ]
  %253 = load i32, ptr %252, align 4, !tbaa !349
  %254 = zext i32 %253 to i64
  %255 = shl nuw nsw i64 %254, 31
  %256 = add nuw i64 %255, %237
  %257 = udiv i64 %256, %120
  %258 = trunc i64 %257 to i32
  store i32 %258, ptr %252, align 4, !tbaa !349
  %259 = getelementptr inbounds nuw i8, ptr %252, i64 4
  %260 = load i32, ptr %259, align 4, !tbaa !349
  %261 = zext i32 %260 to i64
  %262 = shl nuw nsw i64 %261, 31
  %263 = add nuw i64 %262, %237
  %264 = udiv i64 %263, %120
  %265 = trunc i64 %264 to i32
  store i32 %265, ptr %259, align 4, !tbaa !349
  %266 = getelementptr inbounds nuw i8, ptr %252, i64 8
  %267 = icmp eq ptr %266, %56
  br i1 %267, label %268, label %251, !llvm.loop !618

268:                                              ; preds = %248, %251, %232, %228, %196, %54, %52
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock22getProbabilityIteratorEPPS0_(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr noundef %1) local_unnamed_addr #14 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %4 = load ptr, ptr %3, align 8, !tbaa !19
  %5 = ptrtoint ptr %1 to i64
  %6 = ptrtoint ptr %4 to i64
  %7 = sub i64 %5, %6
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %9 = load ptr, ptr %8, align 8, !tbaa !345
  %10 = ashr exact i64 %7, 1
  %11 = getelementptr inbounds i8, ptr %9, i64 %10
  ret ptr %11
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock15removeSuccessorEPS0_b(ptr noundef nonnull align 8 captures(address) dereferenceable(288) %0, ptr noundef readnone captures(address) %1, i1 noundef zeroext %2) local_unnamed_addr #9 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %5 = load ptr, ptr %4, align 8, !tbaa !19
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %7 = load i32, ptr %6, align 8, !tbaa !76
  %8 = zext i32 %7 to i64
  %9 = shl nuw nsw i64 %8, 3
  %10 = getelementptr inbounds nuw i8, ptr %5, i64 %9
  %11 = icmp eq i32 %7, 0
  br i1 %11, label %37, label %12

12:                                               ; preds = %3, %34
  %13 = phi ptr [ %35, %34 ], [ %5, %3 ]
  %14 = load ptr, ptr %13, align 8, !tbaa !289
  %15 = icmp eq ptr %14, %1
  br i1 %15, label %37, label %16

16:                                               ; preds = %12
  %17 = getelementptr inbounds nuw i8, ptr %13, i64 8
  %18 = icmp eq ptr %17, %10
  br i1 %18, label %37, label %19, !llvm.loop !610

19:                                               ; preds = %16
  %20 = load ptr, ptr %17, align 8, !tbaa !289
  %21 = icmp eq ptr %20, %1
  br i1 %21, label %37, label %22

22:                                               ; preds = %19
  %23 = getelementptr inbounds nuw i8, ptr %13, i64 16
  %24 = icmp eq ptr %23, %10
  br i1 %24, label %37, label %25, !llvm.loop !610

25:                                               ; preds = %22
  %26 = load ptr, ptr %23, align 8, !tbaa !289
  %27 = icmp eq ptr %26, %1
  br i1 %27, label %37, label %28

28:                                               ; preds = %25
  %29 = getelementptr inbounds nuw i8, ptr %13, i64 24
  %30 = icmp eq ptr %29, %10
  br i1 %30, label %37, label %31, !llvm.loop !610

31:                                               ; preds = %28
  %32 = load ptr, ptr %29, align 8, !tbaa !289
  %33 = icmp eq ptr %32, %1
  br i1 %33, label %37, label %34

34:                                               ; preds = %31
  %35 = getelementptr inbounds nuw i8, ptr %13, i64 32
  %36 = icmp eq ptr %35, %10
  br i1 %36, label %37, label %12, !llvm.loop !611

37:                                               ; preds = %12, %16, %19, %22, %25, %28, %31, %34, %3
  %38 = phi ptr [ %5, %3 ], [ %13, %12 ], [ %10, %16 ], [ %17, %19 ], [ %10, %22 ], [ %23, %25 ], [ %10, %28 ], [ %29, %31 ], [ %10, %34 ]
  %39 = tail call noundef ptr @_ZN4llvm17MachineBasicBlock15removeSuccessorEPPS0_b(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %38, i1 noundef zeroext %2)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) uwtable
define dso_local noundef ptr @_ZN4llvm17MachineBasicBlock15removeSuccessorEPPS0_b(ptr noundef nonnull align 8 captures(address) dereferenceable(288) %0, ptr noundef returned %1, i1 noundef zeroext %2) local_unnamed_addr #9 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %5 = load ptr, ptr %4, align 8, !tbaa !345
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %7 = load ptr, ptr %6, align 8, !tbaa !345
  %8 = icmp eq ptr %5, %7
  br i1 %8, label %246, label %9

9:                                                ; preds = %3
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %11 = load ptr, ptr %10, align 8, !tbaa !19
  %12 = ptrtoint ptr %1 to i64
  %13 = ptrtoint ptr %11 to i64
  %14 = sub i64 %12, %13
  %15 = ashr exact i64 %14, 1
  %16 = getelementptr inbounds i8, ptr %5, i64 %15
  %17 = getelementptr inbounds nuw i8, ptr %16, i64 4
  %18 = icmp eq ptr %17, %7
  br i1 %18, label %30, label %19

19:                                               ; preds = %9
  %20 = ptrtoint ptr %7 to i64
  %21 = ptrtoint ptr %17 to i64
  %22 = sub i64 %20, %21
  %23 = icmp sgt i64 %22, 4
  br i1 %23, label %24, label %26, !prof !483

24:                                               ; preds = %19
  tail call void @llvm.memmove.p0.p0.i64(ptr align 4 %16, ptr nonnull align 4 %17, i64 %22, i1 false)
  %25 = load ptr, ptr %6, align 8, !tbaa !600
  br label %30

26:                                               ; preds = %19
  %27 = icmp eq i64 %22, 4
  br i1 %27, label %28, label %30

28:                                               ; preds = %26
  %29 = load i32, ptr %17, align 4, !tbaa !451
  store i32 %29, ptr %16, align 4, !tbaa !451
  br label %30

30:                                               ; preds = %9, %24, %26, %28
  %31 = phi ptr [ %7, %28 ], [ %7, %26 ], [ %25, %24 ], [ %7, %9 ]
  %32 = ptrtoint ptr %31 to i64
  %33 = getelementptr inbounds i8, ptr %31, i64 -4
  store ptr %33, ptr %6, align 8, !tbaa !600
  br i1 %2, label %34, label %246

34:                                               ; preds = %30
  %35 = load ptr, ptr %4, align 8, !tbaa !345
  %36 = icmp eq ptr %35, %33
  br i1 %36, label %246, label %37

37:                                               ; preds = %34
  %38 = ptrtoint ptr %35 to i64
  %39 = add i64 %32, -8
  %40 = sub i64 %39, %38
  %41 = lshr i64 %40, 2
  %42 = add nuw nsw i64 %41, 1
  %43 = icmp ult i64 %40, 12
  br i1 %43, label %79, label %44

44:                                               ; preds = %37
  %45 = and i64 %42, 9223372036854775804
  %46 = shl i64 %45, 2
  %47 = getelementptr i8, ptr %35, i64 %46
  br label %48

48:                                               ; preds = %48, %44
  %49 = phi i64 [ 0, %44 ], [ %71, %48 ]
  %50 = phi <2 x i32> [ zeroinitializer, %44 ], [ %63, %48 ]
  %51 = phi <2 x i32> [ zeroinitializer, %44 ], [ %64, %48 ]
  %52 = phi <2 x i64> [ zeroinitializer, %44 ], [ %69, %48 ]
  %53 = phi <2 x i64> [ zeroinitializer, %44 ], [ %70, %48 ]
  %54 = shl i64 %49, 2
  %55 = getelementptr i8, ptr %35, i64 %54
  %56 = getelementptr i8, ptr %55, i64 8
  %57 = load <2 x i32>, ptr %55, align 4, !tbaa !349
  %58 = load <2 x i32>, ptr %56, align 4, !tbaa !349
  %59 = icmp eq <2 x i32> %57, splat (i32 -1)
  %60 = icmp eq <2 x i32> %58, splat (i32 -1)
  %61 = zext <2 x i1> %59 to <2 x i32>
  %62 = zext <2 x i1> %60 to <2 x i32>
  %63 = add <2 x i32> %50, %61
  %64 = add <2 x i32> %51, %62
  %65 = select <2 x i1> %59, <2 x i32> zeroinitializer, <2 x i32> %57
  %66 = select <2 x i1> %60, <2 x i32> zeroinitializer, <2 x i32> %58
  %67 = zext <2 x i32> %65 to <2 x i64>
  %68 = zext <2 x i32> %66 to <2 x i64>
  %69 = add <2 x i64> %52, %67
  %70 = add <2 x i64> %53, %68
  %71 = add nuw i64 %49, 4
  %72 = icmp eq i64 %71, %45
  br i1 %72, label %73, label %48, !llvm.loop !619

73:                                               ; preds = %48
  %74 = add <2 x i32> %64, %63
  %75 = tail call i32 @llvm.vector.reduce.add.v2i32(<2 x i32> %74)
  %76 = add <2 x i64> %70, %69
  %77 = tail call i64 @llvm.vector.reduce.add.v2i64(<2 x i64> %76)
  %78 = icmp eq i64 %42, %45
  br i1 %78, label %96, label %79

79:                                               ; preds = %37, %73
  %80 = phi i32 [ 0, %37 ], [ %75, %73 ]
  %81 = phi i64 [ 0, %37 ], [ %77, %73 ]
  %82 = phi ptr [ %35, %37 ], [ %47, %73 ]
  br label %83

83:                                               ; preds = %79, %83
  %84 = phi i32 [ %90, %83 ], [ %80, %79 ]
  %85 = phi i64 [ %93, %83 ], [ %81, %79 ]
  %86 = phi ptr [ %94, %83 ], [ %82, %79 ]
  %87 = load i32, ptr %86, align 4, !tbaa !349
  %88 = icmp eq i32 %87, -1
  %89 = zext i1 %88 to i32
  %90 = add i32 %84, %89
  %91 = select i1 %88, i32 0, i32 %87
  %92 = zext i32 %91 to i64
  %93 = add i64 %85, %92
  %94 = getelementptr inbounds nuw i8, ptr %86, i64 4
  %95 = icmp eq ptr %94, %33
  br i1 %95, label %96, label %83, !llvm.loop !620

96:                                               ; preds = %83, %73
  %97 = phi i32 [ %75, %73 ], [ %90, %83 ]
  %98 = phi i64 [ %77, %73 ], [ %93, %83 ]
  %99 = icmp eq i32 %97, 0
  br i1 %99, label %176, label %100

100:                                              ; preds = %96
  %101 = icmp ult i64 %98, 2147483648
  br i1 %101, label %102, label %106

102:                                              ; preds = %100
  %103 = trunc nuw nsw i64 %98 to i32
  %104 = sub nuw i32 -2147483648, %103
  %105 = udiv i32 %104, %97
  br label %106

106:                                              ; preds = %102, %100
  %107 = phi i32 [ %105, %102 ], [ 0, %100 ]
  %108 = icmp ult i64 %40, 28
  br i1 %108, label %164, label %109

109:                                              ; preds = %106
  %110 = and i64 %42, 9223372036854775800
  %111 = shl i64 %110, 2
  %112 = getelementptr i8, ptr %35, i64 %111
  %113 = getelementptr i8, ptr %35, i64 4
  %114 = getelementptr i8, ptr %35, i64 8
  %115 = getelementptr i8, ptr %35, i64 12
  %116 = getelementptr i8, ptr %35, i64 16
  %117 = getelementptr i8, ptr %35, i64 20
  %118 = getelementptr i8, ptr %35, i64 24
  %119 = getelementptr i8, ptr %35, i64 28
  br label %120

120:                                              ; preds = %159, %109
  %121 = phi i64 [ 0, %109 ], [ %160, %159 ]
  %122 = shl i64 %121, 2
  %123 = getelementptr i8, ptr %35, i64 %122
  %124 = getelementptr i8, ptr %113, i64 %122
  %125 = getelementptr i8, ptr %114, i64 %122
  %126 = getelementptr i8, ptr %115, i64 %122
  %127 = getelementptr i8, ptr %116, i64 %122
  %128 = getelementptr i8, ptr %117, i64 %122
  %129 = getelementptr i8, ptr %118, i64 %122
  %130 = getelementptr i8, ptr %119, i64 %122
  %131 = getelementptr i8, ptr %123, i64 16
  %132 = load <4 x i32>, ptr %123, align 4, !tbaa !349
  %133 = load <4 x i32>, ptr %131, align 4, !tbaa !349
  %134 = icmp eq <4 x i32> %132, splat (i32 -1)
  %135 = icmp eq <4 x i32> %133, splat (i32 -1)
  %136 = extractelement <4 x i1> %134, i64 0
  br i1 %136, label %137, label %138

137:                                              ; preds = %120
  store i32 %107, ptr %123, align 4, !tbaa !451
  br label %138

138:                                              ; preds = %137, %120
  %139 = extractelement <4 x i1> %134, i64 1
  br i1 %139, label %140, label %141

140:                                              ; preds = %138
  store i32 %107, ptr %124, align 4, !tbaa !451
  br label %141

141:                                              ; preds = %140, %138
  %142 = extractelement <4 x i1> %134, i64 2
  br i1 %142, label %143, label %144

143:                                              ; preds = %141
  store i32 %107, ptr %125, align 4, !tbaa !451
  br label %144

144:                                              ; preds = %143, %141
  %145 = extractelement <4 x i1> %134, i64 3
  br i1 %145, label %146, label %147

146:                                              ; preds = %144
  store i32 %107, ptr %126, align 4, !tbaa !451
  br label %147

147:                                              ; preds = %146, %144
  %148 = extractelement <4 x i1> %135, i64 0
  br i1 %148, label %149, label %150

149:                                              ; preds = %147
  store i32 %107, ptr %127, align 4, !tbaa !451
  br label %150

150:                                              ; preds = %149, %147
  %151 = extractelement <4 x i1> %135, i64 1
  br i1 %151, label %152, label %153

152:                                              ; preds = %150
  store i32 %107, ptr %128, align 4, !tbaa !451
  br label %153

153:                                              ; preds = %152, %150
  %154 = extractelement <4 x i1> %135, i64 2
  br i1 %154, label %155, label %156

155:                                              ; preds = %153
  store i32 %107, ptr %129, align 4, !tbaa !451
  br label %156

156:                                              ; preds = %155, %153
  %157 = extractelement <4 x i1> %135, i64 3
  br i1 %157, label %158, label %159

158:                                              ; preds = %156
  store i32 %107, ptr %130, align 4, !tbaa !451
  br label %159

159:                                              ; preds = %158, %156
  %160 = add nuw i64 %121, 8
  %161 = icmp eq i64 %160, %110
  br i1 %161, label %162, label %120, !llvm.loop !621

162:                                              ; preds = %159
  %163 = icmp eq i64 %42, %110
  br i1 %163, label %174, label %164

164:                                              ; preds = %106, %162
  %165 = phi ptr [ %35, %106 ], [ %112, %162 ]
  br label %166

166:                                              ; preds = %164, %171
  %167 = phi ptr [ %172, %171 ], [ %165, %164 ]
  %168 = load i32, ptr %167, align 4, !tbaa !349
  %169 = icmp eq i32 %168, -1
  br i1 %169, label %170, label %171

170:                                              ; preds = %166
  store i32 %107, ptr %167, align 4, !tbaa !451
  br label %171

171:                                              ; preds = %170, %166
  %172 = getelementptr inbounds nuw i8, ptr %167, i64 4
  %173 = icmp eq ptr %172, %33
  br i1 %173, label %174, label %166, !llvm.loop !622

174:                                              ; preds = %171, %162
  %175 = icmp ult i64 %98, 2147483649
  br i1 %175, label %246, label %214

176:                                              ; preds = %96
  %177 = icmp eq i64 %98, 0
  br i1 %177, label %178, label %214

178:                                              ; preds = %176
  %179 = ptrtoint ptr %33 to i64
  %180 = ptrtoint ptr %35 to i64
  %181 = sub i64 %179, %180
  %182 = lshr exact i64 %181, 2
  %183 = trunc i64 %182 to i32
  %184 = icmp eq i32 %183, -2147483648
  br i1 %184, label %190, label %185

185:                                              ; preds = %178
  %186 = lshr i64 %181, 3
  %187 = trunc i64 %186 to i32
  %188 = or i32 %187, -2147483648
  %189 = udiv i32 %188, %183
  br label %190

190:                                              ; preds = %185, %178
  %191 = phi i32 [ %189, %185 ], [ 1, %178 ]
  %192 = icmp ult i64 %40, 28
  br i1 %192, label %208, label %193

193:                                              ; preds = %190
  %194 = and i64 %42, 9223372036854775800
  %195 = shl i64 %194, 2
  %196 = getelementptr i8, ptr %35, i64 %195
  %197 = insertelement <4 x i32> poison, i32 %191, i64 0
  %198 = shufflevector <4 x i32> %197, <4 x i32> poison, <4 x i32> zeroinitializer
  br label %199

199:                                              ; preds = %199, %193
  %200 = phi i64 [ 0, %193 ], [ %204, %199 ]
  %201 = shl i64 %200, 2
  %202 = getelementptr i8, ptr %35, i64 %201
  %203 = getelementptr i8, ptr %202, i64 16
  store <4 x i32> %198, ptr %202, align 4, !tbaa !451
  store <4 x i32> %198, ptr %203, align 4, !tbaa !451
  %204 = add nuw i64 %200, 8
  %205 = icmp eq i64 %204, %194
  br i1 %205, label %206, label %199, !llvm.loop !623

206:                                              ; preds = %199
  %207 = icmp eq i64 %42, %194
  br i1 %207, label %246, label %208

208:                                              ; preds = %190, %206
  %209 = phi ptr [ %35, %190 ], [ %196, %206 ]
  br label %210

210:                                              ; preds = %208, %210
  %211 = phi ptr [ %212, %210 ], [ %209, %208 ]
  store i32 %191, ptr %211, align 4, !tbaa !451
  %212 = getelementptr inbounds nuw i8, ptr %211, i64 4
  %213 = icmp eq ptr %212, %33
  br i1 %213, label %246, label %210, !llvm.loop !624

214:                                              ; preds = %176, %174
  %215 = lshr i64 %98, 1
  %216 = and i64 %40, 4
  %217 = icmp eq i64 %216, 0
  br i1 %217, label %218, label %226

218:                                              ; preds = %214
  %219 = load i32, ptr %35, align 4, !tbaa !349
  %220 = zext i32 %219 to i64
  %221 = shl nuw nsw i64 %220, 31
  %222 = add nuw i64 %221, %215
  %223 = udiv i64 %222, %98
  %224 = trunc i64 %223 to i32
  store i32 %224, ptr %35, align 4, !tbaa !349
  %225 = getelementptr inbounds nuw i8, ptr %35, i64 4
  br label %226

226:                                              ; preds = %218, %214
  %227 = phi ptr [ %35, %214 ], [ %225, %218 ]
  %228 = icmp ult i64 %40, 4
  br i1 %228, label %246, label %229

229:                                              ; preds = %226, %229
  %230 = phi ptr [ %244, %229 ], [ %227, %226 ]
  %231 = load i32, ptr %230, align 4, !tbaa !349
  %232 = zext i32 %231 to i64
  %233 = shl nuw nsw i64 %232, 31
  %234 = add nuw i64 %233, %215
  %235 = udiv i64 %234, %98
  %236 = trunc i64 %235 to i32
  store i32 %236, ptr %230, align 4, !tbaa !349
  %237 = getelementptr inbounds nuw i8, ptr %230, i64 4
  %238 = load i32, ptr %237, align 4, !tbaa !349
  %239 = zext i32 %238 to i64
  %240 = shl nuw nsw i64 %239, 31
  %241 = add nuw i64 %240, %215
  %242 = udiv i64 %241, %98
  %243 = trunc i64 %242 to i32
  store i32 %243, ptr %237, align 4, !tbaa !349
  %244 = getelementptr inbounds nuw i8, ptr %230, i64 8
  %245 = icmp eq ptr %244, %33
  br i1 %245, label %246, label %229, !llvm.loop !618

246:                                              ; preds = %226, %229, %210, %206, %30, %34, %174, %3
  %247 = load ptr, ptr %1, align 8, !tbaa !289
  %248 = getelementptr inbounds nuw i8, ptr %247, i64 64
  %249 = load ptr, ptr %248, align 8, !tbaa !19, !noalias !625
  %250 = getelementptr inbounds nuw i8, ptr %247, i64 72
  %251 = load i32, ptr %250, align 8, !tbaa !76, !noalias !625
  %252 = zext i32 %251 to i64
  %253 = shl nuw nsw i64 %252, 3
  %254 = getelementptr inbounds nuw i8, ptr %249, i64 %253
  %255 = icmp eq i32 %251, 0
  br i1 %255, label %281, label %256

256:                                              ; preds = %246, %279
  %257 = phi ptr [ %276, %279 ], [ %254, %246 ]
  %258 = getelementptr inbounds i8, ptr %257, i64 -8
  %259 = load ptr, ptr %258, align 8, !tbaa !289, !noalias !634
  %260 = icmp eq ptr %259, %0
  br i1 %260, label %281, label %261

261:                                              ; preds = %256
  %262 = icmp eq ptr %258, %249
  br i1 %262, label %281, label %263, !llvm.loop !641

263:                                              ; preds = %261
  %264 = getelementptr inbounds i8, ptr %257, i64 -16
  %265 = load ptr, ptr %264, align 8, !tbaa !289, !noalias !634
  %266 = icmp eq ptr %265, %0
  br i1 %266, label %281, label %267

267:                                              ; preds = %263
  %268 = icmp eq ptr %264, %249
  br i1 %268, label %281, label %269, !llvm.loop !641

269:                                              ; preds = %267
  %270 = getelementptr inbounds i8, ptr %257, i64 -24
  %271 = load ptr, ptr %270, align 8, !tbaa !289, !noalias !634
  %272 = icmp eq ptr %271, %0
  br i1 %272, label %281, label %273

273:                                              ; preds = %269
  %274 = icmp eq ptr %270, %249
  br i1 %274, label %281, label %275, !llvm.loop !641

275:                                              ; preds = %273
  %276 = getelementptr inbounds i8, ptr %257, i64 -32
  %277 = load ptr, ptr %276, align 8, !tbaa !289, !noalias !634
  %278 = icmp eq ptr %277, %0
  br i1 %278, label %281, label %279

279:                                              ; preds = %275
  %280 = icmp eq ptr %276, %249
  br i1 %280, label %281, label %256, !llvm.loop !642

281:                                              ; preds = %279, %275, %273, %269, %267, %263, %261, %256, %246
  %282 = phi ptr [ %254, %246 ], [ %249, %279 ], [ %270, %275 ], [ %249, %273 ], [ %264, %269 ], [ %249, %267 ], [ %258, %263 ], [ %249, %261 ], [ %257, %256 ]
  %283 = getelementptr inbounds i8, ptr %282, i64 -8
  %284 = ptrtoint ptr %254 to i64
  %285 = ptrtoint ptr %282 to i64
  %286 = sub i64 %284, %285
  %287 = icmp sgt i64 %286, 8
  br i1 %287, label %288, label %290, !prof !483

288:                                              ; preds = %281
  tail call void @llvm.memmove.p0.p0.i64(ptr nonnull align 8 %283, ptr nonnull align 8 %282, i64 %286, i1 false)
  %289 = load i32, ptr %250, align 8, !tbaa !76
  br label %294

290:                                              ; preds = %281
  %291 = icmp eq i64 %286, 8
  br i1 %291, label %292, label %294

292:                                              ; preds = %290
  %293 = load ptr, ptr %282, align 8, !tbaa !289
  store ptr %293, ptr %283, align 8, !tbaa !289
  br label %294

294:                                              ; preds = %288, %290, %292
  %295 = phi i32 [ %289, %288 ], [ %251, %290 ], [ %251, %292 ]
  %296 = add i32 %295, -1
  store i32 %296, ptr %250, align 8, !tbaa !76
  %297 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %298 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %299 = load ptr, ptr %297, align 8, !tbaa !19
  %300 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %301 = load i32, ptr %300, align 8, !tbaa !76
  %302 = zext i32 %301 to i64
  %303 = getelementptr inbounds nuw ptr, ptr %299, i64 %302
  %304 = ptrtoint ptr %303 to i64
  %305 = ptrtoint ptr %298 to i64
  %306 = sub i64 %304, %305
  %307 = icmp sgt i64 %306, 8
  br i1 %307, label %308, label %310, !prof !483

308:                                              ; preds = %294
  tail call void @llvm.memmove.p0.p0.i64(ptr nonnull align 8 %1, ptr nonnull align 8 %298, i64 %306, i1 false)
  %309 = load i32, ptr %300, align 8, !tbaa !76
  br label %314

310:                                              ; preds = %294
  %311 = icmp eq i64 %306, 8
  br i1 %311, label %312, label %314

312:                                              ; preds = %310
  %313 = load ptr, ptr %298, align 8, !tbaa !289
  store ptr %313, ptr %1, align 8, !tbaa !289
  br label %314

314:                                              ; preds = %308, %310, %312
  %315 = phi i32 [ %309, %308 ], [ %301, %310 ], [ %301, %312 ]
  %316 = add i32 %315, -1
  store i32 %316, ptr %300, align 8, !tbaa !76
  ret ptr %1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock17removePredecessorEPS0_(ptr noundef nonnull align 8 captures(none) dereferenceable(288) %0, ptr noundef readnone captures(address) %1) local_unnamed_addr #9 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %4 = load ptr, ptr %3, align 8, !tbaa !19, !noalias !643
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 72
  %6 = load i32, ptr %5, align 8, !tbaa !76, !noalias !643
  %7 = zext i32 %6 to i64
  %8 = shl nuw nsw i64 %7, 3
  %9 = getelementptr inbounds nuw i8, ptr %4, i64 %8
  %10 = icmp eq i32 %6, 0
  br i1 %10, label %36, label %11

11:                                               ; preds = %2, %34
  %12 = phi ptr [ %31, %34 ], [ %9, %2 ]
  %13 = getelementptr inbounds i8, ptr %12, i64 -8
  %14 = load ptr, ptr %13, align 8, !tbaa !289, !noalias !652
  %15 = icmp eq ptr %14, %1
  br i1 %15, label %36, label %16

16:                                               ; preds = %11
  %17 = icmp eq ptr %13, %4
  br i1 %17, label %36, label %18, !llvm.loop !641

18:                                               ; preds = %16
  %19 = getelementptr inbounds i8, ptr %12, i64 -16
  %20 = load ptr, ptr %19, align 8, !tbaa !289, !noalias !652
  %21 = icmp eq ptr %20, %1
  br i1 %21, label %36, label %22

22:                                               ; preds = %18
  %23 = icmp eq ptr %19, %4
  br i1 %23, label %36, label %24, !llvm.loop !641

24:                                               ; preds = %22
  %25 = getelementptr inbounds i8, ptr %12, i64 -24
  %26 = load ptr, ptr %25, align 8, !tbaa !289, !noalias !652
  %27 = icmp eq ptr %26, %1
  br i1 %27, label %36, label %28

28:                                               ; preds = %24
  %29 = icmp eq ptr %25, %4
  br i1 %29, label %36, label %30, !llvm.loop !641

30:                                               ; preds = %28
  %31 = getelementptr inbounds i8, ptr %12, i64 -32
  %32 = load ptr, ptr %31, align 8, !tbaa !289, !noalias !652
  %33 = icmp eq ptr %32, %1
  br i1 %33, label %36, label %34

34:                                               ; preds = %30
  %35 = icmp eq ptr %31, %4
  br i1 %35, label %36, label %11, !llvm.loop !642

36:                                               ; preds = %11, %16, %18, %22, %24, %28, %30, %34, %2
  %37 = phi ptr [ %9, %2 ], [ %12, %11 ], [ %4, %16 ], [ %13, %18 ], [ %4, %22 ], [ %19, %24 ], [ %4, %28 ], [ %25, %30 ], [ %4, %34 ]
  %38 = getelementptr inbounds i8, ptr %37, i64 -8
  %39 = ptrtoint ptr %9 to i64
  %40 = ptrtoint ptr %37 to i64
  %41 = sub i64 %39, %40
  %42 = icmp sgt i64 %41, 8
  br i1 %42, label %43, label %45, !prof !483

43:                                               ; preds = %36
  tail call void @llvm.memmove.p0.p0.i64(ptr nonnull align 8 %38, ptr nonnull align 8 %37, i64 %41, i1 false)
  %44 = load i32, ptr %5, align 8, !tbaa !76
  br label %49

45:                                               ; preds = %36
  %46 = icmp eq i64 %41, 8
  br i1 %46, label %47, label %49

47:                                               ; preds = %45
  %48 = load ptr, ptr %37, align 8, !tbaa !289
  store ptr %48, ptr %38, align 8, !tbaa !289
  br label %49

49:                                               ; preds = %43, %45, %47
  %50 = phi i32 [ %44, %43 ], [ %6, %45 ], [ %6, %47 ]
  %51 = add i32 %50, -1
  store i32 %51, ptr %5, align 8, !tbaa !76
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock16replaceSuccessorEPS0_S1_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef captures(address) %1, ptr noundef %2) local_unnamed_addr #3 align 2 {
  %4 = icmp eq ptr %1, %2
  br i1 %4, label %128, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %7 = load ptr, ptr %6, align 8, !tbaa !19
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %9 = load i32, ptr %8, align 8, !tbaa !76
  %10 = zext i32 %9 to i64
  %11 = shl nuw nsw i64 %10, 3
  %12 = getelementptr inbounds nuw i8, ptr %7, i64 %11
  %13 = icmp eq i32 %9, 0
  br i1 %13, label %35, label %14

14:                                               ; preds = %5, %27
  %15 = phi ptr [ %28, %27 ], [ %12, %5 ]
  %16 = phi ptr [ %29, %27 ], [ %7, %5 ]
  %17 = phi ptr [ %23, %27 ], [ %12, %5 ]
  %18 = load ptr, ptr %16, align 8, !tbaa !289
  %19 = icmp eq ptr %18, %1
  br i1 %19, label %20, label %22

20:                                               ; preds = %14
  %21 = icmp eq ptr %15, %12
  br i1 %21, label %22, label %31

22:                                               ; preds = %20, %14
  %23 = phi ptr [ %16, %20 ], [ %17, %14 ]
  %24 = icmp eq ptr %18, %2
  br i1 %24, label %25, label %27

25:                                               ; preds = %22
  %26 = icmp eq ptr %23, %12
  br i1 %26, label %27, label %31

27:                                               ; preds = %22, %25
  %28 = phi ptr [ %16, %25 ], [ %15, %22 ]
  %29 = getelementptr inbounds nuw i8, ptr %16, i64 8
  %30 = icmp eq ptr %29, %12
  br i1 %30, label %31, label %14, !llvm.loop !659

31:                                               ; preds = %27, %20, %25
  %32 = phi ptr [ %23, %27 ], [ %16, %20 ], [ %23, %25 ]
  %33 = phi ptr [ %28, %27 ], [ %15, %20 ], [ %16, %25 ]
  %34 = icmp eq ptr %33, %12
  br i1 %34, label %35, label %100

35:                                               ; preds = %5, %31
  %36 = phi ptr [ %32, %31 ], [ %12, %5 ]
  %37 = getelementptr inbounds nuw i8, ptr %1, i64 64
  %38 = load ptr, ptr %37, align 8, !tbaa !19, !noalias !660
  %39 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %40 = load i32, ptr %39, align 8, !tbaa !76, !noalias !660
  %41 = zext i32 %40 to i64
  %42 = shl nuw nsw i64 %41, 3
  %43 = getelementptr inbounds nuw i8, ptr %38, i64 %42
  %44 = icmp eq i32 %40, 0
  br i1 %44, label %70, label %45

45:                                               ; preds = %35, %68
  %46 = phi ptr [ %65, %68 ], [ %43, %35 ]
  %47 = getelementptr inbounds i8, ptr %46, i64 -8
  %48 = load ptr, ptr %47, align 8, !tbaa !289, !noalias !669
  %49 = icmp eq ptr %48, %0
  br i1 %49, label %70, label %50

50:                                               ; preds = %45
  %51 = icmp eq ptr %47, %38
  br i1 %51, label %70, label %52, !llvm.loop !641

52:                                               ; preds = %50
  %53 = getelementptr inbounds i8, ptr %46, i64 -16
  %54 = load ptr, ptr %53, align 8, !tbaa !289, !noalias !669
  %55 = icmp eq ptr %54, %0
  br i1 %55, label %70, label %56

56:                                               ; preds = %52
  %57 = icmp eq ptr %53, %38
  br i1 %57, label %70, label %58, !llvm.loop !641

58:                                               ; preds = %56
  %59 = getelementptr inbounds i8, ptr %46, i64 -24
  %60 = load ptr, ptr %59, align 8, !tbaa !289, !noalias !669
  %61 = icmp eq ptr %60, %0
  br i1 %61, label %70, label %62

62:                                               ; preds = %58
  %63 = icmp eq ptr %59, %38
  br i1 %63, label %70, label %64, !llvm.loop !641

64:                                               ; preds = %62
  %65 = getelementptr inbounds i8, ptr %46, i64 -32
  %66 = load ptr, ptr %65, align 8, !tbaa !289, !noalias !669
  %67 = icmp eq ptr %66, %0
  br i1 %67, label %70, label %68

68:                                               ; preds = %64
  %69 = icmp eq ptr %65, %38
  br i1 %69, label %70, label %45, !llvm.loop !642

70:                                               ; preds = %68, %64, %62, %58, %56, %52, %50, %45, %35
  %71 = phi ptr [ %43, %35 ], [ %38, %68 ], [ %59, %64 ], [ %38, %62 ], [ %53, %58 ], [ %38, %56 ], [ %47, %52 ], [ %38, %50 ], [ %46, %45 ]
  %72 = getelementptr inbounds i8, ptr %71, i64 -8
  %73 = ptrtoint ptr %43 to i64
  %74 = ptrtoint ptr %71 to i64
  %75 = sub i64 %73, %74
  %76 = icmp sgt i64 %75, 8
  br i1 %76, label %77, label %79, !prof !483

77:                                               ; preds = %70
  tail call void @llvm.memmove.p0.p0.i64(ptr nonnull align 8 %72, ptr nonnull align 8 %71, i64 %75, i1 false)
  %78 = load i32, ptr %39, align 8, !tbaa !76
  br label %83

79:                                               ; preds = %70
  %80 = icmp eq i64 %75, 8
  br i1 %80, label %81, label %83

81:                                               ; preds = %79
  %82 = load ptr, ptr %71, align 8, !tbaa !289
  store ptr %82, ptr %72, align 8, !tbaa !289
  br label %83

83:                                               ; preds = %77, %79, %81
  %84 = phi i32 [ %78, %77 ], [ %40, %79 ], [ %40, %81 ]
  %85 = add i32 %84, -1
  store i32 %85, ptr %39, align 8, !tbaa !76
  %86 = getelementptr inbounds nuw i8, ptr %2, i64 64
  %87 = getelementptr inbounds nuw i8, ptr %2, i64 72
  %88 = load i32, ptr %87, align 8, !tbaa !76
  %89 = getelementptr inbounds nuw i8, ptr %2, i64 76
  %90 = load i32, ptr %89, align 4, !tbaa !77
  %91 = icmp ult i32 %88, %90
  br i1 %91, label %93, label %92, !prof !483

92:                                               ; preds = %83
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %86, ptr noundef nonnull %0)
  br label %99

93:                                               ; preds = %83
  %94 = zext i32 %88 to i64
  %95 = load ptr, ptr %86, align 8, !tbaa !19
  %96 = getelementptr inbounds nuw ptr, ptr %95, i64 %94
  store ptr %0, ptr %96, align 1
  %97 = load i32, ptr %87, align 8, !tbaa !76
  %98 = add i32 %97, 1
  store i32 %98, ptr %87, align 8, !tbaa !76
  br label %99

99:                                               ; preds = %92, %93
  store ptr %2, ptr %36, align 8, !tbaa !289
  br label %128

100:                                              ; preds = %31
  %101 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %102 = load ptr, ptr %101, align 8, !tbaa !345
  %103 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %104 = load ptr, ptr %103, align 8, !tbaa !345
  %105 = icmp eq ptr %102, %104
  br i1 %105, label %126, label %106

106:                                              ; preds = %100
  %107 = ptrtoint ptr %33 to i64
  %108 = ptrtoint ptr %7 to i64
  %109 = sub i64 %107, %108
  %110 = ashr exact i64 %109, 1
  %111 = getelementptr inbounds i8, ptr %102, i64 %110
  %112 = load i32, ptr %111, align 4, !tbaa !349
  %113 = icmp eq i32 %112, -1
  br i1 %113, label %126, label %114

114:                                              ; preds = %106
  %115 = ptrtoint ptr %32 to i64
  %116 = sub i64 %115, %108
  %117 = ashr exact i64 %116, 1
  %118 = getelementptr inbounds i8, ptr %102, i64 %117
  %119 = load i32, ptr %118, align 4, !tbaa !451
  %120 = zext i32 %112 to i64
  %121 = zext i32 %119 to i64
  %122 = add nuw nsw i64 %121, %120
  %123 = icmp samesign ugt i64 %122, 2147483648
  %124 = add i32 %119, %112
  %125 = select i1 %123, i32 -2147483648, i32 %124
  store i32 %125, ptr %111, align 4, !tbaa !349
  br label %126

126:                                              ; preds = %106, %114, %100
  %127 = tail call noundef ptr @_ZN4llvm17MachineBasicBlock15removeSuccessorEPPS0_b(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %32, i1 noundef zeroext false)
  br label %128

128:                                              ; preds = %99, %126, %3
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock13copySuccessorEPKS0_PPS0_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef readonly captures(none) %1, ptr noundef %2) local_unnamed_addr #3 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 144
  %5 = load ptr, ptr %4, align 8, !tbaa !345
  %6 = getelementptr inbounds nuw i8, ptr %1, i64 152
  %7 = load ptr, ptr %6, align 8, !tbaa !345
  %8 = icmp eq ptr %5, %7
  %9 = load ptr, ptr %2, align 8, !tbaa !289
  br i1 %8, label %51, label %10

10:                                               ; preds = %3
  %11 = getelementptr inbounds nuw i8, ptr %1, i64 112
  %12 = load ptr, ptr %11, align 8, !tbaa !19
  %13 = ptrtoint ptr %2 to i64
  %14 = ptrtoint ptr %12 to i64
  %15 = sub i64 %13, %14
  %16 = ashr exact i64 %15, 1
  %17 = getelementptr inbounds i8, ptr %5, i64 %16
  %18 = load i32, ptr %17, align 4, !tbaa !349
  %19 = icmp eq i32 %18, -1
  br i1 %19, label %30, label %49

20:                                               ; preds = %44
  %21 = sub i32 -2147483648, %45
  %22 = ptrtoint ptr %7 to i64
  %23 = ptrtoint ptr %5 to i64
  %24 = sub i64 %22, %23
  %25 = ashr exact i64 %24, 2
  %26 = icmp sgt i64 %25, -1
  tail call void @llvm.assume(i1 %26)
  %27 = trunc i64 %25 to i32
  %28 = sub i32 %27, %46
  %29 = udiv i32 %21, %28
  br label %49

30:                                               ; preds = %10, %44
  %31 = phi i32 [ %46, %44 ], [ 0, %10 ]
  %32 = phi i32 [ %45, %44 ], [ 0, %10 ]
  %33 = phi ptr [ %47, %44 ], [ %5, %10 ]
  %34 = load i32, ptr %33, align 4, !tbaa !349
  %35 = icmp eq i32 %34, -1
  br i1 %35, label %44, label %36

36:                                               ; preds = %30
  %37 = zext i32 %32 to i64
  %38 = zext i32 %34 to i64
  %39 = add nuw nsw i64 %38, %37
  %40 = icmp samesign ugt i64 %39, 2147483648
  %41 = add i32 %34, %32
  %42 = select i1 %40, i32 -2147483648, i32 %41
  %43 = add i32 %31, 1
  br label %44

44:                                               ; preds = %36, %30
  %45 = phi i32 [ %32, %30 ], [ %42, %36 ]
  %46 = phi i32 [ %31, %30 ], [ %43, %36 ]
  %47 = getelementptr inbounds nuw i8, ptr %33, i64 4
  %48 = icmp eq ptr %47, %7
  br i1 %48, label %20, label %30

49:                                               ; preds = %10, %20
  %50 = phi i32 [ %29, %20 ], [ %18, %10 ]
  tail call void @_ZN4llvm17MachineBasicBlock12addSuccessorEPS0_NS_17BranchProbabilityE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %9, i32 %50)
  br label %86

51:                                               ; preds = %3
  %52 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %53 = load ptr, ptr %52, align 8, !tbaa !87
  %54 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %55 = load ptr, ptr %54, align 8, !tbaa !600
  %56 = icmp eq ptr %55, %53
  br i1 %56, label %58, label %57

57:                                               ; preds = %51
  store ptr %53, ptr %54, align 8, !tbaa !600
  br label %58

58:                                               ; preds = %57, %51
  %59 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %60 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %61 = load i32, ptr %60, align 8, !tbaa !76
  %62 = getelementptr inbounds nuw i8, ptr %0, i64 124
  %63 = load i32, ptr %62, align 4, !tbaa !77
  %64 = icmp ult i32 %61, %63
  br i1 %64, label %66, label %65, !prof !483

65:                                               ; preds = %58
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %59, ptr noundef %9)
  br label %72

66:                                               ; preds = %58
  %67 = zext i32 %61 to i64
  %68 = load ptr, ptr %59, align 8, !tbaa !19
  %69 = getelementptr inbounds nuw ptr, ptr %68, i64 %67
  store ptr %9, ptr %69, align 1
  %70 = load i32, ptr %60, align 8, !tbaa !76
  %71 = add i32 %70, 1
  store i32 %71, ptr %60, align 8, !tbaa !76
  br label %72

72:                                               ; preds = %66, %65
  %73 = getelementptr inbounds nuw i8, ptr %9, i64 64
  %74 = getelementptr inbounds nuw i8, ptr %9, i64 72
  %75 = load i32, ptr %74, align 8, !tbaa !76
  %76 = getelementptr inbounds nuw i8, ptr %9, i64 76
  %77 = load i32, ptr %76, align 4, !tbaa !77
  %78 = icmp ult i32 %75, %77
  br i1 %78, label %80, label %79, !prof !483

79:                                               ; preds = %72
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %73, ptr noundef nonnull align 8 dereferenceable(288) %0)
  br label %86

80:                                               ; preds = %72
  %81 = zext i32 %75 to i64
  %82 = load ptr, ptr %73, align 8, !tbaa !19
  %83 = getelementptr inbounds nuw ptr, ptr %82, i64 %81
  store ptr %0, ptr %83, align 1
  %84 = load i32, ptr %74, align 8, !tbaa !76
  %85 = add i32 %84, 1
  store i32 %85, ptr %74, align 8, !tbaa !76
  br label %86

86:                                               ; preds = %80, %79, %49
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock18transferSuccessorsEPS0_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef captures(address) %1) local_unnamed_addr #3 align 2 {
  %3 = icmp eq ptr %0, %1
  br i1 %3, label %92, label %4

4:                                                ; preds = %2
  %5 = getelementptr inbounds nuw i8, ptr %1, i64 120
  %6 = load i32, ptr %5, align 8, !tbaa !76
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %92, label %8

8:                                                ; preds = %4
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 112
  %10 = getelementptr inbounds nuw i8, ptr %1, i64 144
  %11 = getelementptr inbounds nuw i8, ptr %1, i64 152
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 124
  br label %17

17:                                               ; preds = %8, %87
  %18 = load ptr, ptr %9, align 8, !tbaa !19
  %19 = load ptr, ptr %18, align 8, !tbaa !289
  %20 = load ptr, ptr %10, align 8, !tbaa !345
  %21 = load ptr, ptr %11, align 8, !tbaa !345
  %22 = icmp eq ptr %20, %21
  br i1 %22, label %25, label %23

23:                                               ; preds = %17
  %24 = load i32, ptr %20, align 4, !tbaa !451
  tail call void @_ZN4llvm17MachineBasicBlock12addSuccessorEPS0_NS_17BranchProbabilityE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %19, i32 %24)
  br label %55

25:                                               ; preds = %17
  %26 = load ptr, ptr %12, align 8, !tbaa !87
  %27 = load ptr, ptr %13, align 8, !tbaa !600
  %28 = icmp eq ptr %27, %26
  br i1 %28, label %30, label %29

29:                                               ; preds = %25
  store ptr %26, ptr %13, align 8, !tbaa !600
  br label %30

30:                                               ; preds = %29, %25
  %31 = load i32, ptr %15, align 8, !tbaa !76
  %32 = load i32, ptr %16, align 4, !tbaa !77
  %33 = icmp ult i32 %31, %32
  br i1 %33, label %35, label %34, !prof !483

34:                                               ; preds = %30
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %14, ptr noundef %19)
  br label %41

35:                                               ; preds = %30
  %36 = zext i32 %31 to i64
  %37 = load ptr, ptr %14, align 8, !tbaa !19
  %38 = getelementptr inbounds nuw ptr, ptr %37, i64 %36
  store ptr %19, ptr %38, align 1
  %39 = load i32, ptr %15, align 8, !tbaa !76
  %40 = add i32 %39, 1
  store i32 %40, ptr %15, align 8, !tbaa !76
  br label %41

41:                                               ; preds = %35, %34
  %42 = getelementptr inbounds nuw i8, ptr %19, i64 64
  %43 = getelementptr inbounds nuw i8, ptr %19, i64 72
  %44 = load i32, ptr %43, align 8, !tbaa !76
  %45 = getelementptr inbounds nuw i8, ptr %19, i64 76
  %46 = load i32, ptr %45, align 4, !tbaa !77
  %47 = icmp ult i32 %44, %46
  br i1 %47, label %49, label %48, !prof !483

48:                                               ; preds = %41
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %42, ptr noundef nonnull align 8 dereferenceable(288) %0)
  br label %55

49:                                               ; preds = %41
  %50 = zext i32 %44 to i64
  %51 = load ptr, ptr %42, align 8, !tbaa !19
  %52 = getelementptr inbounds nuw ptr, ptr %51, i64 %50
  store ptr %0, ptr %52, align 1
  %53 = load i32, ptr %43, align 8, !tbaa !76
  %54 = add i32 %53, 1
  store i32 %54, ptr %43, align 8, !tbaa !76
  br label %55

55:                                               ; preds = %49, %48, %23
  %56 = load ptr, ptr %9, align 8, !tbaa !19
  %57 = load i32, ptr %5, align 8, !tbaa !76
  %58 = zext i32 %57 to i64
  %59 = shl nuw nsw i64 %58, 3
  %60 = getelementptr inbounds nuw i8, ptr %56, i64 %59
  %61 = icmp eq i32 %57, 0
  br i1 %61, label %87, label %62

62:                                               ; preds = %55, %84
  %63 = phi ptr [ %85, %84 ], [ %56, %55 ]
  %64 = load ptr, ptr %63, align 8, !tbaa !289
  %65 = icmp eq ptr %64, %19
  br i1 %65, label %87, label %66

66:                                               ; preds = %62
  %67 = getelementptr inbounds nuw i8, ptr %63, i64 8
  %68 = icmp eq ptr %67, %60
  br i1 %68, label %87, label %69, !llvm.loop !610

69:                                               ; preds = %66
  %70 = load ptr, ptr %67, align 8, !tbaa !289
  %71 = icmp eq ptr %70, %19
  br i1 %71, label %87, label %72

72:                                               ; preds = %69
  %73 = getelementptr inbounds nuw i8, ptr %63, i64 16
  %74 = icmp eq ptr %73, %60
  br i1 %74, label %87, label %75, !llvm.loop !610

75:                                               ; preds = %72
  %76 = load ptr, ptr %73, align 8, !tbaa !289
  %77 = icmp eq ptr %76, %19
  br i1 %77, label %87, label %78

78:                                               ; preds = %75
  %79 = getelementptr inbounds nuw i8, ptr %63, i64 24
  %80 = icmp eq ptr %79, %60
  br i1 %80, label %87, label %81, !llvm.loop !610

81:                                               ; preds = %78
  %82 = load ptr, ptr %79, align 8, !tbaa !289
  %83 = icmp eq ptr %82, %19
  br i1 %83, label %87, label %84

84:                                               ; preds = %81
  %85 = getelementptr inbounds nuw i8, ptr %63, i64 32
  %86 = icmp eq ptr %85, %60
  br i1 %86, label %87, label %62, !llvm.loop !611

87:                                               ; preds = %62, %66, %69, %72, %75, %78, %81, %84, %55
  %88 = phi ptr [ %56, %55 ], [ %60, %84 ], [ %79, %81 ], [ %60, %78 ], [ %73, %75 ], [ %60, %72 ], [ %67, %69 ], [ %60, %66 ], [ %63, %62 ]
  %89 = tail call noundef ptr @_ZN4llvm17MachineBasicBlock15removeSuccessorEPPS0_b(ptr noundef nonnull align 8 dereferenceable(288) %1, ptr noundef %88, i1 noundef zeroext false)
  %90 = load i32, ptr %5, align 8, !tbaa !76
  %91 = icmp eq i32 %90, 0
  br i1 %91, label %92, label %17, !llvm.loop !676

92:                                               ; preds = %87, %4, %2
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock31transferSuccessorsAndUpdatePHIsEPS0_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef captures(address) %1) local_unnamed_addr #3 align 2 {
  %3 = icmp eq ptr %0, %1
  br i1 %3, label %393, label %4

4:                                                ; preds = %2
  %5 = getelementptr inbounds nuw i8, ptr %1, i64 120
  %6 = load i32, ptr %5, align 8, !tbaa !76
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %177, label %8

8:                                                ; preds = %4
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 112
  %10 = getelementptr inbounds nuw i8, ptr %1, i64 144
  %11 = getelementptr inbounds nuw i8, ptr %1, i64 152
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 124
  br label %17

17:                                               ; preds = %8, %174
  %18 = load ptr, ptr %9, align 8, !tbaa !19
  %19 = load ptr, ptr %18, align 8, !tbaa !289
  %20 = load ptr, ptr %10, align 8, !tbaa !345
  %21 = load ptr, ptr %11, align 8, !tbaa !345
  %22 = icmp eq ptr %20, %21
  br i1 %22, label %25, label %23

23:                                               ; preds = %17
  %24 = load i32, ptr %20, align 4, !tbaa !451
  tail call void @_ZN4llvm17MachineBasicBlock12addSuccessorEPS0_NS_17BranchProbabilityE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %19, i32 %24)
  br label %55

25:                                               ; preds = %17
  %26 = load ptr, ptr %12, align 8, !tbaa !87
  %27 = load ptr, ptr %13, align 8, !tbaa !600
  %28 = icmp eq ptr %27, %26
  br i1 %28, label %30, label %29

29:                                               ; preds = %25
  store ptr %26, ptr %13, align 8, !tbaa !600
  br label %30

30:                                               ; preds = %29, %25
  %31 = load i32, ptr %15, align 8, !tbaa !76
  %32 = load i32, ptr %16, align 4, !tbaa !77
  %33 = icmp ult i32 %31, %32
  br i1 %33, label %35, label %34, !prof !483

34:                                               ; preds = %30
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %14, ptr noundef %19)
  br label %41

35:                                               ; preds = %30
  %36 = zext i32 %31 to i64
  %37 = load ptr, ptr %14, align 8, !tbaa !19
  %38 = getelementptr inbounds nuw ptr, ptr %37, i64 %36
  store ptr %19, ptr %38, align 1
  %39 = load i32, ptr %15, align 8, !tbaa !76
  %40 = add i32 %39, 1
  store i32 %40, ptr %15, align 8, !tbaa !76
  br label %41

41:                                               ; preds = %35, %34
  %42 = getelementptr inbounds nuw i8, ptr %19, i64 64
  %43 = getelementptr inbounds nuw i8, ptr %19, i64 72
  %44 = load i32, ptr %43, align 8, !tbaa !76
  %45 = getelementptr inbounds nuw i8, ptr %19, i64 76
  %46 = load i32, ptr %45, align 4, !tbaa !77
  %47 = icmp ult i32 %44, %46
  br i1 %47, label %49, label %48, !prof !483

48:                                               ; preds = %41
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %42, ptr noundef nonnull align 8 dereferenceable(288) %0)
  br label %55

49:                                               ; preds = %41
  %50 = zext i32 %44 to i64
  %51 = load ptr, ptr %42, align 8, !tbaa !19
  %52 = getelementptr inbounds nuw ptr, ptr %51, i64 %50
  store ptr %0, ptr %52, align 1
  %53 = load i32, ptr %43, align 8, !tbaa !76
  %54 = add i32 %53, 1
  store i32 %54, ptr %43, align 8, !tbaa !76
  br label %55

55:                                               ; preds = %49, %48, %23
  %56 = load ptr, ptr %9, align 8, !tbaa !19
  %57 = load i32, ptr %5, align 8, !tbaa !76
  %58 = zext i32 %57 to i64
  %59 = shl nuw nsw i64 %58, 3
  %60 = getelementptr inbounds nuw i8, ptr %56, i64 %59
  %61 = icmp eq i32 %57, 0
  br i1 %61, label %87, label %62

62:                                               ; preds = %55, %84
  %63 = phi ptr [ %85, %84 ], [ %56, %55 ]
  %64 = load ptr, ptr %63, align 8, !tbaa !289
  %65 = icmp eq ptr %64, %19
  br i1 %65, label %87, label %66

66:                                               ; preds = %62
  %67 = getelementptr inbounds nuw i8, ptr %63, i64 8
  %68 = icmp eq ptr %67, %60
  br i1 %68, label %87, label %69, !llvm.loop !610

69:                                               ; preds = %66
  %70 = load ptr, ptr %67, align 8, !tbaa !289
  %71 = icmp eq ptr %70, %19
  br i1 %71, label %87, label %72

72:                                               ; preds = %69
  %73 = getelementptr inbounds nuw i8, ptr %63, i64 16
  %74 = icmp eq ptr %73, %60
  br i1 %74, label %87, label %75, !llvm.loop !610

75:                                               ; preds = %72
  %76 = load ptr, ptr %73, align 8, !tbaa !289
  %77 = icmp eq ptr %76, %19
  br i1 %77, label %87, label %78

78:                                               ; preds = %75
  %79 = getelementptr inbounds nuw i8, ptr %63, i64 24
  %80 = icmp eq ptr %79, %60
  br i1 %80, label %87, label %81, !llvm.loop !610

81:                                               ; preds = %78
  %82 = load ptr, ptr %79, align 8, !tbaa !289
  %83 = icmp eq ptr %82, %19
  br i1 %83, label %87, label %84

84:                                               ; preds = %81
  %85 = getelementptr inbounds nuw i8, ptr %63, i64 32
  %86 = icmp eq ptr %85, %60
  br i1 %86, label %87, label %62, !llvm.loop !611

87:                                               ; preds = %62, %66, %69, %72, %75, %78, %81, %84, %55
  %88 = phi ptr [ %56, %55 ], [ %60, %84 ], [ %79, %81 ], [ %60, %78 ], [ %73, %75 ], [ %60, %72 ], [ %67, %69 ], [ %60, %66 ], [ %63, %62 ]
  %89 = tail call noundef ptr @_ZN4llvm17MachineBasicBlock15removeSuccessorEPPS0_b(ptr noundef nonnull align 8 dereferenceable(288) %1, ptr noundef %88, i1 noundef zeroext false)
  %90 = getelementptr inbounds nuw i8, ptr %19, i64 56
  %91 = load ptr, ptr %90, align 8, !tbaa !75
  %92 = getelementptr inbounds nuw i8, ptr %19, i64 48
  %93 = icmp eq ptr %91, %92
  br i1 %93, label %174, label %94

94:                                               ; preds = %87, %98
  %95 = phi ptr [ %100, %98 ], [ %91, %87 ]
  %96 = getelementptr inbounds nuw i8, ptr %95, i64 52
  %97 = load i32, ptr %96, align 4, !tbaa !306
  switch i32 %97, label %102 [
    i32 74, label %98
    i32 0, label %98
  ]

98:                                               ; preds = %94, %94
  %99 = getelementptr inbounds nuw i8, ptr %95, i64 8
  %100 = load ptr, ptr %99, align 8, !tbaa !75
  %101 = icmp eq ptr %100, %92
  br i1 %101, label %102, label %94, !llvm.loop !307

102:                                              ; preds = %98, %94
  %103 = phi ptr [ %92, %98 ], [ %95, %94 ]
  %104 = icmp eq ptr %91, %103
  br i1 %104, label %174, label %105

105:                                              ; preds = %102, %148
  %106 = phi ptr [ %151, %148 ], [ %91, %102 ]
  %107 = getelementptr inbounds nuw i8, ptr %106, i64 40
  %108 = load i24, ptr %107, align 8
  %109 = icmp eq i24 %108, 1
  br i1 %109, label %131, label %110

110:                                              ; preds = %105
  %111 = zext i24 %108 to i32
  %112 = getelementptr inbounds nuw i8, ptr %106, i64 32
  %113 = add nsw i32 %111, -3
  %114 = icmp ult i32 %113, 2
  br i1 %114, label %121, label %115

115:                                              ; preds = %110
  %116 = lshr i32 %113, 1
  %117 = add nuw i32 %116, 1
  %118 = and i32 %117, -2
  br label %153

119:                                              ; preds = %170
  %120 = zext i32 %171 to i64
  br label %121

121:                                              ; preds = %119, %110
  %122 = phi i64 [ 2, %110 ], [ %120, %119 ]
  %123 = and i32 %113, 2
  %124 = icmp eq i32 %123, 0
  br i1 %124, label %125, label %131

125:                                              ; preds = %121
  %126 = load ptr, ptr %112, align 8, !tbaa !571
  %127 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %126, i64 %122, i32 3
  %128 = load ptr, ptr %127, align 8, !tbaa !212
  %129 = icmp eq ptr %128, %1
  br i1 %129, label %130, label %131

130:                                              ; preds = %125
  store ptr %0, ptr %127, align 8, !tbaa !212
  br label %131

131:                                              ; preds = %121, %130, %125, %105
  %132 = load i64, ptr %106, align 8
  %133 = and i64 %132, 4
  %134 = icmp eq i64 %133, 0
  br i1 %134, label %135, label %148

135:                                              ; preds = %131
  %136 = getelementptr inbounds nuw i8, ptr %106, i64 44
  %137 = load i32, ptr %136, align 4, !tbaa !309
  %138 = and i32 %137, 8
  %139 = icmp eq i32 %138, 0
  br i1 %139, label %148, label %140

140:                                              ; preds = %135, %140
  %141 = phi ptr [ %143, %140 ], [ %106, %135 ]
  %142 = getelementptr inbounds nuw i8, ptr %141, i64 8
  %143 = load ptr, ptr %142, align 8, !tbaa !75
  %144 = getelementptr inbounds nuw i8, ptr %143, i64 44
  %145 = load i32, ptr %144, align 4, !tbaa !309
  %146 = and i32 %145, 8
  %147 = icmp eq i32 %146, 0
  br i1 %147, label %148, label %140, !llvm.loop !310

148:                                              ; preds = %140, %135, %131
  %149 = phi ptr [ %106, %131 ], [ %106, %135 ], [ %143, %140 ]
  %150 = getelementptr inbounds nuw i8, ptr %149, i64 8
  %151 = load ptr, ptr %150, align 8, !tbaa !75
  %152 = icmp eq ptr %151, %103
  br i1 %152, label %174, label %105

153:                                              ; preds = %170, %115
  %154 = phi i32 [ 2, %115 ], [ %171, %170 ]
  %155 = phi i32 [ 0, %115 ], [ %172, %170 ]
  %156 = load ptr, ptr %112, align 8, !tbaa !571
  %157 = zext i32 %154 to i64
  %158 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %156, i64 %157, i32 3
  %159 = load ptr, ptr %158, align 8, !tbaa !212
  %160 = icmp eq ptr %159, %1
  br i1 %160, label %161, label %162

161:                                              ; preds = %153
  store ptr %0, ptr %158, align 8, !tbaa !212
  br label %162

162:                                              ; preds = %161, %153
  %163 = add i32 %154, 2
  %164 = load ptr, ptr %112, align 8, !tbaa !571
  %165 = zext i32 %163 to i64
  %166 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %164, i64 %165, i32 3
  %167 = load ptr, ptr %166, align 8, !tbaa !212
  %168 = icmp eq ptr %167, %1
  br i1 %168, label %169, label %170

169:                                              ; preds = %162
  store ptr %0, ptr %166, align 8, !tbaa !212
  br label %170

170:                                              ; preds = %169, %162
  %171 = add i32 %154, 4
  %172 = add i32 %155, 2
  %173 = icmp eq i32 %172, %118
  br i1 %173, label %119, label %153, !llvm.loop !677

174:                                              ; preds = %148, %87, %102
  %175 = load i32, ptr %5, align 8, !tbaa !76
  %176 = icmp eq i32 %175, 0
  br i1 %176, label %177, label %17, !llvm.loop !678

177:                                              ; preds = %174, %4
  %178 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %179 = load ptr, ptr %178, align 8, !tbaa !345
  %180 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %181 = load ptr, ptr %180, align 8, !tbaa !345
  %182 = icmp eq ptr %179, %181
  br i1 %182, label %393, label %183

183:                                              ; preds = %177
  %184 = ptrtoint ptr %181 to i64
  %185 = ptrtoint ptr %179 to i64
  %186 = add i64 %184, -4
  %187 = sub i64 %186, %185
  %188 = lshr i64 %187, 2
  %189 = add nuw nsw i64 %188, 1
  %190 = icmp ult i64 %187, 12
  br i1 %190, label %226, label %191

191:                                              ; preds = %183
  %192 = and i64 %189, 9223372036854775804
  %193 = shl i64 %192, 2
  %194 = getelementptr i8, ptr %179, i64 %193
  br label %195

195:                                              ; preds = %195, %191
  %196 = phi i64 [ 0, %191 ], [ %218, %195 ]
  %197 = phi <2 x i32> [ zeroinitializer, %191 ], [ %210, %195 ]
  %198 = phi <2 x i32> [ zeroinitializer, %191 ], [ %211, %195 ]
  %199 = phi <2 x i64> [ zeroinitializer, %191 ], [ %216, %195 ]
  %200 = phi <2 x i64> [ zeroinitializer, %191 ], [ %217, %195 ]
  %201 = shl i64 %196, 2
  %202 = getelementptr i8, ptr %179, i64 %201
  %203 = getelementptr i8, ptr %202, i64 8
  %204 = load <2 x i32>, ptr %202, align 4, !tbaa !349
  %205 = load <2 x i32>, ptr %203, align 4, !tbaa !349
  %206 = icmp eq <2 x i32> %204, splat (i32 -1)
  %207 = icmp eq <2 x i32> %205, splat (i32 -1)
  %208 = zext <2 x i1> %206 to <2 x i32>
  %209 = zext <2 x i1> %207 to <2 x i32>
  %210 = add <2 x i32> %197, %208
  %211 = add <2 x i32> %198, %209
  %212 = select <2 x i1> %206, <2 x i32> zeroinitializer, <2 x i32> %204
  %213 = select <2 x i1> %207, <2 x i32> zeroinitializer, <2 x i32> %205
  %214 = zext <2 x i32> %212 to <2 x i64>
  %215 = zext <2 x i32> %213 to <2 x i64>
  %216 = add <2 x i64> %199, %214
  %217 = add <2 x i64> %200, %215
  %218 = add nuw i64 %196, 4
  %219 = icmp eq i64 %218, %192
  br i1 %219, label %220, label %195, !llvm.loop !679

220:                                              ; preds = %195
  %221 = add <2 x i32> %211, %210
  %222 = tail call i32 @llvm.vector.reduce.add.v2i32(<2 x i32> %221)
  %223 = add <2 x i64> %217, %216
  %224 = tail call i64 @llvm.vector.reduce.add.v2i64(<2 x i64> %223)
  %225 = icmp eq i64 %189, %192
  br i1 %225, label %243, label %226

226:                                              ; preds = %183, %220
  %227 = phi i32 [ 0, %183 ], [ %222, %220 ]
  %228 = phi i64 [ 0, %183 ], [ %224, %220 ]
  %229 = phi ptr [ %179, %183 ], [ %194, %220 ]
  br label %230

230:                                              ; preds = %226, %230
  %231 = phi i32 [ %237, %230 ], [ %227, %226 ]
  %232 = phi i64 [ %240, %230 ], [ %228, %226 ]
  %233 = phi ptr [ %241, %230 ], [ %229, %226 ]
  %234 = load i32, ptr %233, align 4, !tbaa !349
  %235 = icmp eq i32 %234, -1
  %236 = zext i1 %235 to i32
  %237 = add i32 %231, %236
  %238 = select i1 %235, i32 0, i32 %234
  %239 = zext i32 %238 to i64
  %240 = add i64 %232, %239
  %241 = getelementptr inbounds nuw i8, ptr %233, i64 4
  %242 = icmp eq ptr %241, %181
  br i1 %242, label %243, label %230, !llvm.loop !680

243:                                              ; preds = %230, %220
  %244 = phi i32 [ %222, %220 ], [ %237, %230 ]
  %245 = phi i64 [ %224, %220 ], [ %240, %230 ]
  %246 = icmp eq i32 %244, 0
  br i1 %246, label %323, label %247

247:                                              ; preds = %243
  %248 = icmp ult i64 %245, 2147483648
  br i1 %248, label %249, label %253

249:                                              ; preds = %247
  %250 = trunc nuw nsw i64 %245 to i32
  %251 = sub nuw i32 -2147483648, %250
  %252 = udiv i32 %251, %244
  br label %253

253:                                              ; preds = %249, %247
  %254 = phi i32 [ %252, %249 ], [ 0, %247 ]
  %255 = icmp ult i64 %187, 28
  br i1 %255, label %311, label %256

256:                                              ; preds = %253
  %257 = and i64 %189, 9223372036854775800
  %258 = shl i64 %257, 2
  %259 = getelementptr i8, ptr %179, i64 %258
  %260 = getelementptr i8, ptr %179, i64 4
  %261 = getelementptr i8, ptr %179, i64 8
  %262 = getelementptr i8, ptr %179, i64 12
  %263 = getelementptr i8, ptr %179, i64 16
  %264 = getelementptr i8, ptr %179, i64 20
  %265 = getelementptr i8, ptr %179, i64 24
  %266 = getelementptr i8, ptr %179, i64 28
  br label %267

267:                                              ; preds = %306, %256
  %268 = phi i64 [ 0, %256 ], [ %307, %306 ]
  %269 = shl i64 %268, 2
  %270 = getelementptr i8, ptr %179, i64 %269
  %271 = getelementptr i8, ptr %260, i64 %269
  %272 = getelementptr i8, ptr %261, i64 %269
  %273 = getelementptr i8, ptr %262, i64 %269
  %274 = getelementptr i8, ptr %263, i64 %269
  %275 = getelementptr i8, ptr %264, i64 %269
  %276 = getelementptr i8, ptr %265, i64 %269
  %277 = getelementptr i8, ptr %266, i64 %269
  %278 = getelementptr i8, ptr %270, i64 16
  %279 = load <4 x i32>, ptr %270, align 4, !tbaa !349
  %280 = load <4 x i32>, ptr %278, align 4, !tbaa !349
  %281 = icmp eq <4 x i32> %279, splat (i32 -1)
  %282 = icmp eq <4 x i32> %280, splat (i32 -1)
  %283 = extractelement <4 x i1> %281, i64 0
  br i1 %283, label %284, label %285

284:                                              ; preds = %267
  store i32 %254, ptr %270, align 4, !tbaa !451
  br label %285

285:                                              ; preds = %284, %267
  %286 = extractelement <4 x i1> %281, i64 1
  br i1 %286, label %287, label %288

287:                                              ; preds = %285
  store i32 %254, ptr %271, align 4, !tbaa !451
  br label %288

288:                                              ; preds = %287, %285
  %289 = extractelement <4 x i1> %281, i64 2
  br i1 %289, label %290, label %291

290:                                              ; preds = %288
  store i32 %254, ptr %272, align 4, !tbaa !451
  br label %291

291:                                              ; preds = %290, %288
  %292 = extractelement <4 x i1> %281, i64 3
  br i1 %292, label %293, label %294

293:                                              ; preds = %291
  store i32 %254, ptr %273, align 4, !tbaa !451
  br label %294

294:                                              ; preds = %293, %291
  %295 = extractelement <4 x i1> %282, i64 0
  br i1 %295, label %296, label %297

296:                                              ; preds = %294
  store i32 %254, ptr %274, align 4, !tbaa !451
  br label %297

297:                                              ; preds = %296, %294
  %298 = extractelement <4 x i1> %282, i64 1
  br i1 %298, label %299, label %300

299:                                              ; preds = %297
  store i32 %254, ptr %275, align 4, !tbaa !451
  br label %300

300:                                              ; preds = %299, %297
  %301 = extractelement <4 x i1> %282, i64 2
  br i1 %301, label %302, label %303

302:                                              ; preds = %300
  store i32 %254, ptr %276, align 4, !tbaa !451
  br label %303

303:                                              ; preds = %302, %300
  %304 = extractelement <4 x i1> %282, i64 3
  br i1 %304, label %305, label %306

305:                                              ; preds = %303
  store i32 %254, ptr %277, align 4, !tbaa !451
  br label %306

306:                                              ; preds = %305, %303
  %307 = add nuw i64 %268, 8
  %308 = icmp eq i64 %307, %257
  br i1 %308, label %309, label %267, !llvm.loop !681

309:                                              ; preds = %306
  %310 = icmp eq i64 %189, %257
  br i1 %310, label %321, label %311

311:                                              ; preds = %253, %309
  %312 = phi ptr [ %179, %253 ], [ %259, %309 ]
  br label %313

313:                                              ; preds = %311, %318
  %314 = phi ptr [ %319, %318 ], [ %312, %311 ]
  %315 = load i32, ptr %314, align 4, !tbaa !349
  %316 = icmp eq i32 %315, -1
  br i1 %316, label %317, label %318

317:                                              ; preds = %313
  store i32 %254, ptr %314, align 4, !tbaa !451
  br label %318

318:                                              ; preds = %317, %313
  %319 = getelementptr inbounds nuw i8, ptr %314, i64 4
  %320 = icmp eq ptr %319, %181
  br i1 %320, label %321, label %313, !llvm.loop !682

321:                                              ; preds = %318, %309
  %322 = icmp ult i64 %245, 2147483649
  br i1 %322, label %393, label %361

323:                                              ; preds = %243
  %324 = icmp eq i64 %245, 0
  br i1 %324, label %325, label %361

325:                                              ; preds = %323
  %326 = ptrtoint ptr %181 to i64
  %327 = ptrtoint ptr %179 to i64
  %328 = sub i64 %326, %327
  %329 = lshr exact i64 %328, 2
  %330 = trunc i64 %329 to i32
  %331 = icmp eq i32 %330, -2147483648
  br i1 %331, label %337, label %332

332:                                              ; preds = %325
  %333 = lshr i64 %328, 3
  %334 = trunc i64 %333 to i32
  %335 = or i32 %334, -2147483648
  %336 = udiv i32 %335, %330
  br label %337

337:                                              ; preds = %332, %325
  %338 = phi i32 [ %336, %332 ], [ 1, %325 ]
  %339 = icmp ult i64 %187, 28
  br i1 %339, label %355, label %340

340:                                              ; preds = %337
  %341 = and i64 %189, 9223372036854775800
  %342 = shl i64 %341, 2
  %343 = getelementptr i8, ptr %179, i64 %342
  %344 = insertelement <4 x i32> poison, i32 %338, i64 0
  %345 = shufflevector <4 x i32> %344, <4 x i32> poison, <4 x i32> zeroinitializer
  br label %346

346:                                              ; preds = %346, %340
  %347 = phi i64 [ 0, %340 ], [ %351, %346 ]
  %348 = shl i64 %347, 2
  %349 = getelementptr i8, ptr %179, i64 %348
  %350 = getelementptr i8, ptr %349, i64 16
  store <4 x i32> %345, ptr %349, align 4, !tbaa !451
  store <4 x i32> %345, ptr %350, align 4, !tbaa !451
  %351 = add nuw i64 %347, 8
  %352 = icmp eq i64 %351, %341
  br i1 %352, label %353, label %346, !llvm.loop !683

353:                                              ; preds = %346
  %354 = icmp eq i64 %189, %341
  br i1 %354, label %393, label %355

355:                                              ; preds = %337, %353
  %356 = phi ptr [ %179, %337 ], [ %343, %353 ]
  br label %357

357:                                              ; preds = %355, %357
  %358 = phi ptr [ %359, %357 ], [ %356, %355 ]
  store i32 %338, ptr %358, align 4, !tbaa !451
  %359 = getelementptr inbounds nuw i8, ptr %358, i64 4
  %360 = icmp eq ptr %359, %181
  br i1 %360, label %393, label %357, !llvm.loop !684

361:                                              ; preds = %323, %321
  %362 = lshr i64 %245, 1
  %363 = and i64 %187, 4
  %364 = icmp eq i64 %363, 0
  br i1 %364, label %365, label %373

365:                                              ; preds = %361
  %366 = load i32, ptr %179, align 4, !tbaa !349
  %367 = zext i32 %366 to i64
  %368 = shl nuw nsw i64 %367, 31
  %369 = add nuw i64 %368, %362
  %370 = udiv i64 %369, %245
  %371 = trunc i64 %370 to i32
  store i32 %371, ptr %179, align 4, !tbaa !349
  %372 = getelementptr inbounds nuw i8, ptr %179, i64 4
  br label %373

373:                                              ; preds = %365, %361
  %374 = phi ptr [ %179, %361 ], [ %372, %365 ]
  %375 = icmp ult i64 %187, 4
  br i1 %375, label %393, label %376

376:                                              ; preds = %373, %376
  %377 = phi ptr [ %391, %376 ], [ %374, %373 ]
  %378 = load i32, ptr %377, align 4, !tbaa !349
  %379 = zext i32 %378 to i64
  %380 = shl nuw nsw i64 %379, 31
  %381 = add nuw i64 %380, %362
  %382 = udiv i64 %381, %245
  %383 = trunc i64 %382 to i32
  store i32 %383, ptr %377, align 4, !tbaa !349
  %384 = getelementptr inbounds nuw i8, ptr %377, i64 4
  %385 = load i32, ptr %384, align 4, !tbaa !349
  %386 = zext i32 %385 to i64
  %387 = shl nuw nsw i64 %386, 31
  %388 = add nuw i64 %387, %362
  %389 = udiv i64 %388, %245
  %390 = trunc i64 %389 to i32
  store i32 %390, ptr %384, align 4, !tbaa !349
  %391 = getelementptr inbounds nuw i8, ptr %377, i64 8
  %392 = icmp eq ptr %391, %181
  br i1 %392, label %393, label %376, !llvm.loop !618

393:                                              ; preds = %373, %376, %357, %353, %321, %177, %2
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock18replacePhiUsesWithEPS0_S1_(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, ptr noundef readnone captures(address) %1, ptr noundef %2) local_unnamed_addr #9 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %5 = load ptr, ptr %4, align 8, !tbaa !75
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %7 = icmp eq ptr %5, %6
  br i1 %7, label %19, label %8

8:                                                ; preds = %3, %12
  %9 = phi ptr [ %14, %12 ], [ %5, %3 ]
  %10 = getelementptr inbounds nuw i8, ptr %9, i64 52
  %11 = load i32, ptr %10, align 4, !tbaa !306
  switch i32 %11, label %16 [
    i32 74, label %12
    i32 0, label %12
  ]

12:                                               ; preds = %8, %8
  %13 = getelementptr inbounds nuw i8, ptr %9, i64 8
  %14 = load ptr, ptr %13, align 8, !tbaa !75
  %15 = icmp eq ptr %14, %6
  br i1 %15, label %16, label %8, !llvm.loop !307

16:                                               ; preds = %8, %12
  %17 = phi ptr [ %6, %12 ], [ %9, %8 ]
  %18 = icmp eq ptr %5, %17
  br i1 %18, label %19, label %20

19:                                               ; preds = %63, %3, %16
  ret void

20:                                               ; preds = %16, %63
  %21 = phi ptr [ %66, %63 ], [ %5, %16 ]
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 40
  %23 = load i24, ptr %22, align 8
  %24 = icmp eq i24 %23, 1
  br i1 %24, label %46, label %25

25:                                               ; preds = %20
  %26 = zext i24 %23 to i32
  %27 = getelementptr inbounds nuw i8, ptr %21, i64 32
  %28 = add nsw i32 %26, -3
  %29 = icmp ult i32 %28, 2
  br i1 %29, label %36, label %30

30:                                               ; preds = %25
  %31 = lshr i32 %28, 1
  %32 = add nuw i32 %31, 1
  %33 = and i32 %32, -2
  br label %68

34:                                               ; preds = %85
  %35 = zext i32 %86 to i64
  br label %36

36:                                               ; preds = %34, %25
  %37 = phi i64 [ 2, %25 ], [ %35, %34 ]
  %38 = and i32 %28, 2
  %39 = icmp eq i32 %38, 0
  br i1 %39, label %40, label %46

40:                                               ; preds = %36
  %41 = load ptr, ptr %27, align 8, !tbaa !571
  %42 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %41, i64 %37, i32 3
  %43 = load ptr, ptr %42, align 8, !tbaa !212
  %44 = icmp eq ptr %43, %1
  br i1 %44, label %45, label %46

45:                                               ; preds = %40
  store ptr %2, ptr %42, align 8, !tbaa !212
  br label %46

46:                                               ; preds = %36, %45, %40, %20
  %47 = load i64, ptr %21, align 8
  %48 = and i64 %47, 4
  %49 = icmp eq i64 %48, 0
  br i1 %49, label %50, label %63

50:                                               ; preds = %46
  %51 = getelementptr inbounds nuw i8, ptr %21, i64 44
  %52 = load i32, ptr %51, align 4, !tbaa !309
  %53 = and i32 %52, 8
  %54 = icmp eq i32 %53, 0
  br i1 %54, label %63, label %55

55:                                               ; preds = %50, %55
  %56 = phi ptr [ %58, %55 ], [ %21, %50 ]
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 8
  %58 = load ptr, ptr %57, align 8, !tbaa !75
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 44
  %60 = load i32, ptr %59, align 4, !tbaa !309
  %61 = and i32 %60, 8
  %62 = icmp eq i32 %61, 0
  br i1 %62, label %63, label %55, !llvm.loop !310

63:                                               ; preds = %55, %46, %50
  %64 = phi ptr [ %21, %46 ], [ %21, %50 ], [ %58, %55 ]
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 8
  %66 = load ptr, ptr %65, align 8, !tbaa !75
  %67 = icmp eq ptr %66, %17
  br i1 %67, label %19, label %20

68:                                               ; preds = %85, %30
  %69 = phi i32 [ 2, %30 ], [ %86, %85 ]
  %70 = phi i32 [ 0, %30 ], [ %87, %85 ]
  %71 = load ptr, ptr %27, align 8, !tbaa !571
  %72 = zext i32 %69 to i64
  %73 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %71, i64 %72, i32 3
  %74 = load ptr, ptr %73, align 8, !tbaa !212
  %75 = icmp eq ptr %74, %1
  br i1 %75, label %76, label %77

76:                                               ; preds = %68
  store ptr %2, ptr %73, align 8, !tbaa !212
  br label %77

77:                                               ; preds = %76, %68
  %78 = add i32 %69, 2
  %79 = load ptr, ptr %27, align 8, !tbaa !571
  %80 = zext i32 %78 to i64
  %81 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %79, i64 %80, i32 3
  %82 = load ptr, ptr %81, align 8, !tbaa !212
  %83 = icmp eq ptr %82, %1
  br i1 %83, label %84, label %85

84:                                               ; preds = %77
  store ptr %2, ptr %81, align 8, !tbaa !212
  br label %85

85:                                               ; preds = %84, %77
  %86 = add i32 %69, 4
  %87 = add i32 %70, 2
  %88 = icmp eq i32 %87, %33
  br i1 %88, label %34, label %68, !llvm.loop !677
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock13isPredecessorEPKS0_(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr noundef readnone captures(address) %1) local_unnamed_addr #10 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %4 = load ptr, ptr %3, align 8, !tbaa !19
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 72
  %6 = load i32, ptr %5, align 8, !tbaa !76
  %7 = zext i32 %6 to i64
  %8 = shl nuw nsw i64 %7, 3
  %9 = getelementptr inbounds nuw i8, ptr %4, i64 %8
  %10 = icmp eq i32 %6, 0
  br i1 %10, label %36, label %11

11:                                               ; preds = %2, %33
  %12 = phi ptr [ %34, %33 ], [ %4, %2 ]
  %13 = load ptr, ptr %12, align 8, !tbaa !289
  %14 = icmp eq ptr %13, %1
  br i1 %14, label %36, label %15

15:                                               ; preds = %11
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 8
  %17 = icmp eq ptr %16, %9
  br i1 %17, label %36, label %18, !llvm.loop !596

18:                                               ; preds = %15
  %19 = load ptr, ptr %16, align 8, !tbaa !289
  %20 = icmp eq ptr %19, %1
  br i1 %20, label %36, label %21

21:                                               ; preds = %18
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 16
  %23 = icmp eq ptr %22, %9
  br i1 %23, label %36, label %24, !llvm.loop !596

24:                                               ; preds = %21
  %25 = load ptr, ptr %22, align 8, !tbaa !289
  %26 = icmp eq ptr %25, %1
  br i1 %26, label %36, label %27

27:                                               ; preds = %24
  %28 = getelementptr inbounds nuw i8, ptr %12, i64 24
  %29 = icmp eq ptr %28, %9
  br i1 %29, label %36, label %30, !llvm.loop !596

30:                                               ; preds = %27
  %31 = load ptr, ptr %28, align 8, !tbaa !289
  %32 = icmp eq ptr %31, %1
  br i1 %32, label %36, label %33

33:                                               ; preds = %30
  %34 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %35 = icmp eq ptr %34, %9
  br i1 %35, label %36, label %11, !llvm.loop !597

36:                                               ; preds = %11, %15, %18, %21, %24, %27, %30, %33, %2
  %37 = phi ptr [ %4, %2 ], [ %12, %11 ], [ %9, %15 ], [ %16, %18 ], [ %9, %21 ], [ %22, %24 ], [ %9, %27 ], [ %28, %30 ], [ %9, %33 ]
  %38 = icmp ne ptr %37, %9
  ret i1 %38
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local noundef ptr @_ZNK4llvm17MachineBasicBlock18getSingleSuccessorEv(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #10 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %3 = load i32, ptr %2, align 8, !tbaa !76
  %4 = icmp eq i32 %3, 1
  br i1 %4, label %5, label %9

5:                                                ; preds = %1
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %7 = load ptr, ptr %6, align 8, !tbaa !19
  %8 = load ptr, ptr %7, align 8, !tbaa !289
  br label %9

9:                                                ; preds = %1, %5
  %10 = phi ptr [ %8, %5 ], [ null, %1 ]
  ret ptr %10
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local noundef ptr @_ZNK4llvm17MachineBasicBlock20getSinglePredecessorEv(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #10 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 72
  %3 = load i32, ptr %2, align 8, !tbaa !76
  %4 = icmp eq i32 %3, 1
  br i1 %4, label %5, label %9

5:                                                ; preds = %1
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %7 = load ptr, ptr %6, align 8, !tbaa !19
  %8 = load ptr, ptr %7, align 8, !tbaa !289
  br label %9

9:                                                ; preds = %1, %5
  %10 = phi ptr [ %8, %5 ], [ null, %1 ]
  ret ptr %10
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZN4llvm17MachineBasicBlock14getFallThroughEb(ptr noundef nonnull align 8 dereferenceable(288) %0, i1 noundef zeroext %1) local_unnamed_addr #3 align 2 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca %"class.llvm::SmallVector.426", align 8
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %7 = load ptr, ptr %6, align 8, !tbaa !327
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %9 = load ptr, ptr %8, align 8, !tbaa !74
  %10 = getelementptr inbounds nuw i8, ptr %9, i64 296
  %11 = icmp eq ptr %7, %10
  br i1 %11, label %155, label %12

12:                                               ; preds = %2
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %14 = load ptr, ptr %13, align 8, !tbaa !19
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %16 = load i32, ptr %15, align 8, !tbaa !76
  %17 = zext i32 %16 to i64
  %18 = shl nuw nsw i64 %17, 3
  %19 = getelementptr inbounds nuw i8, ptr %14, i64 %18
  %20 = icmp eq i32 %16, 0
  br i1 %20, label %46, label %21

21:                                               ; preds = %12, %43
  %22 = phi ptr [ %44, %43 ], [ %14, %12 ]
  %23 = load ptr, ptr %22, align 8, !tbaa !289
  %24 = icmp eq ptr %23, %7
  br i1 %24, label %46, label %25

25:                                               ; preds = %21
  %26 = getelementptr inbounds nuw i8, ptr %22, i64 8
  %27 = icmp eq ptr %26, %19
  br i1 %27, label %155, label %28, !llvm.loop !596

28:                                               ; preds = %25
  %29 = load ptr, ptr %26, align 8, !tbaa !289
  %30 = icmp eq ptr %29, %7
  br i1 %30, label %46, label %31

31:                                               ; preds = %28
  %32 = getelementptr inbounds nuw i8, ptr %22, i64 16
  %33 = icmp eq ptr %32, %19
  br i1 %33, label %155, label %34, !llvm.loop !596

34:                                               ; preds = %31
  %35 = load ptr, ptr %32, align 8, !tbaa !289
  %36 = icmp eq ptr %35, %7
  br i1 %36, label %46, label %37

37:                                               ; preds = %34
  %38 = getelementptr inbounds nuw i8, ptr %22, i64 24
  %39 = icmp eq ptr %38, %19
  br i1 %39, label %155, label %40, !llvm.loop !596

40:                                               ; preds = %37
  %41 = load ptr, ptr %38, align 8, !tbaa !289
  %42 = icmp eq ptr %41, %7
  br i1 %42, label %46, label %43

43:                                               ; preds = %40
  %44 = getelementptr inbounds nuw i8, ptr %22, i64 32
  %45 = icmp eq ptr %44, %19
  br i1 %45, label %155, label %21, !llvm.loop !597

46:                                               ; preds = %21, %28, %34, %40, %12
  %47 = phi ptr [ %14, %12 ], [ %38, %40 ], [ %32, %34 ], [ %26, %28 ], [ %22, %21 ]
  %48 = icmp eq ptr %47, %19
  br i1 %48, label %155, label %49

49:                                               ; preds = %46
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3) #33
  store ptr null, ptr %3, align 8, !tbaa !289
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %4) #33
  store ptr null, ptr %4, align 8, !tbaa !289
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %5) #33
  %50 = getelementptr inbounds nuw i8, ptr %5, i64 16
  store ptr %50, ptr %5, align 8, !tbaa !19
  %51 = getelementptr inbounds nuw i8, ptr %5, i64 8
  store i32 0, ptr %51, align 8, !tbaa !76
  %52 = getelementptr inbounds nuw i8, ptr %5, i64 12
  store i32 4, ptr %52, align 4, !tbaa !77
  %53 = getelementptr inbounds nuw i8, ptr %9, i64 16
  %54 = load ptr, ptr %53, align 8, !tbaa !308, !nonnull !17, !align !200
  %55 = load ptr, ptr %54, align 8, !tbaa !4
  %56 = getelementptr inbounds nuw i8, ptr %55, i64 120
  %57 = load ptr, ptr %56, align 8
  %58 = call noundef ptr %57(ptr noundef nonnull align 8 dereferenceable(368) %54) #33
  %59 = load ptr, ptr %58, align 8, !tbaa !4
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 304
  %61 = load ptr, ptr %60, align 8
  %62 = call noundef zeroext i1 %61(ptr noundef nonnull align 8 dereferenceable(112) %58, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(8) %3, ptr noundef nonnull align 8 dereferenceable(8) %4, ptr noundef nonnull align 8 dereferenceable(16) %5, i1 noundef zeroext false) #33
  br i1 %62, label %63, label %134

63:                                               ; preds = %49
  %64 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %65 = load i64, ptr %64, align 8
  %66 = and i64 %65, -8
  %67 = inttoptr i64 %66 to ptr
  %68 = icmp eq ptr %64, %67
  br i1 %68, label %133, label %69

69:                                               ; preds = %63
  %70 = load i64, ptr %67, align 8
  %71 = and i64 %70, 4
  %72 = icmp ne i64 %71, 0
  %73 = getelementptr inbounds nuw i8, ptr %67, i64 44
  %74 = load i32, ptr %73, align 4, !tbaa !309
  %75 = and i32 %74, 4
  %76 = icmp eq i32 %75, 0
  %77 = select i1 %72, i1 true, i1 %76
  br i1 %77, label %87, label %78

78:                                               ; preds = %69, %78
  %79 = phi ptr [ %82, %78 ], [ %67, %69 ]
  %80 = load i64, ptr %79, align 8
  %81 = and i64 %80, -8
  %82 = inttoptr i64 %81 to ptr
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 44
  %84 = load i32, ptr %83, align 4, !tbaa !309
  %85 = and i32 %84, 4
  %86 = icmp eq i32 %85, 0
  br i1 %86, label %87, label %78, !llvm.loop !313

87:                                               ; preds = %78, %69
  %88 = phi i32 [ %74, %69 ], [ %84, %78 ]
  %89 = phi ptr [ %67, %69 ], [ %82, %78 ]
  %90 = and i32 %88, 12
  %91 = icmp eq i32 %90, 0
  %92 = and i32 %88, 4
  %93 = icmp ne i32 %92, 0
  %94 = or i1 %91, %93
  br i1 %94, label %95, label %102

95:                                               ; preds = %87
  %96 = getelementptr inbounds nuw i8, ptr %89, i64 16
  %97 = load ptr, ptr %96, align 8, !tbaa !314
  %98 = getelementptr inbounds nuw i8, ptr %97, i64 16
  %99 = load i64, ptr %98, align 8, !tbaa !315
  %100 = and i64 %99, 256
  %101 = icmp eq i64 %100, 0
  br i1 %101, label %133, label %108

102:                                              ; preds = %87
  %103 = call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %89, i64 noundef 256, i32 noundef 1) #33
  br i1 %103, label %104, label %133

104:                                              ; preds = %102
  %105 = load i64, ptr %64, align 8
  %106 = and i64 %105, -8
  %107 = inttoptr i64 %106 to ptr
  br label %108

108:                                              ; preds = %104, %95
  %109 = phi ptr [ %107, %104 ], [ %67, %95 ]
  %110 = load i64, ptr %109, align 8
  %111 = and i64 %110, 4
  %112 = icmp eq i64 %111, 0
  br i1 %112, label %113, label %127

113:                                              ; preds = %108
  %114 = getelementptr inbounds nuw i8, ptr %109, i64 44
  %115 = load i32, ptr %114, align 4, !tbaa !309
  %116 = and i32 %115, 4
  %117 = icmp eq i32 %116, 0
  br i1 %117, label %127, label %118

118:                                              ; preds = %113, %118
  %119 = phi ptr [ %122, %118 ], [ %109, %113 ]
  %120 = load i64, ptr %119, align 8
  %121 = and i64 %120, -8
  %122 = inttoptr i64 %121 to ptr
  %123 = getelementptr inbounds nuw i8, ptr %122, i64 44
  %124 = load i32, ptr %123, align 4, !tbaa !309
  %125 = and i32 %124, 4
  %126 = icmp eq i32 %125, 0
  br i1 %126, label %127, label %118, !llvm.loop !313

127:                                              ; preds = %118, %108, %113
  %128 = phi ptr [ %109, %108 ], [ %109, %113 ], [ %122, %118 ]
  %129 = load ptr, ptr %58, align 8, !tbaa !4
  %130 = getelementptr inbounds nuw i8, ptr %129, i64 896
  %131 = load ptr, ptr %130, align 8
  %132 = call noundef zeroext i1 %131(ptr noundef nonnull align 8 dereferenceable(112) %58, ptr noundef nonnull align 8 dereferenceable(80) %128) #33
  br i1 %132, label %133, label %149

133:                                              ; preds = %95, %127, %102, %63
  br label %149

134:                                              ; preds = %49
  %135 = load ptr, ptr %3, align 8, !tbaa !289
  %136 = icmp eq ptr %135, null
  br i1 %136, label %149, label %137

137:                                              ; preds = %134
  %138 = load ptr, ptr %4, align 8
  br i1 %1, label %139, label %143

139:                                              ; preds = %137
  %140 = icmp eq ptr %135, %7
  %141 = icmp eq ptr %138, %7
  %142 = select i1 %140, i1 true, i1 %141
  br i1 %142, label %149, label %143

143:                                              ; preds = %139, %137
  %144 = load i32, ptr %51, align 8, !tbaa !76
  %145 = icmp ne i32 %144, 0
  %146 = icmp eq ptr %138, null
  %147 = select i1 %145, i1 %146, i1 false
  %148 = select i1 %147, ptr %7, ptr null
  br label %149

149:                                              ; preds = %143, %139, %134, %133, %127
  %150 = phi ptr [ %7, %133 ], [ null, %127 ], [ %7, %134 ], [ %7, %139 ], [ %148, %143 ]
  %151 = load ptr, ptr %5, align 8, !tbaa !19
  %152 = icmp eq ptr %151, %50
  br i1 %152, label %154, label %153

153:                                              ; preds = %149
  call void @free(ptr noundef %151) #33
  br label %154

154:                                              ; preds = %149, %153
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %5) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %4) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3) #33
  br label %155

155:                                              ; preds = %43, %37, %31, %25, %46, %2, %154
  %156 = phi ptr [ %150, %154 ], [ null, %2 ], [ null, %46 ], [ null, %25 ], [ null, %31 ], [ null, %37 ], [ null, %43 ]
  ret ptr %156
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef zeroext i1 @_ZN4llvm17MachineBasicBlock14canFallThroughEv(ptr noundef nonnull align 8 dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = tail call noundef ptr @_ZN4llvm17MachineBasicBlock14getFallThroughEb(ptr noundef nonnull align 8 dereferenceable(288) %0, i1 noundef zeroext true)
  %3 = icmp ne ptr %2, null
  ret i1 %3
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZN4llvm17MachineBasicBlock7splitAtERNS_12MachineInstrEbPNS_13LiveIntervalsE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef nonnull readonly align 8 captures(address) dereferenceable(80) %1, i1 noundef zeroext %2, ptr noundef %3) local_unnamed_addr #3 align 2 {
  %5 = alloca %"class.llvm::LivePhysRegs", align 8
  %6 = load i64, ptr %1, align 8
  %7 = and i64 %6, 4
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %9, label %22

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %1, i64 44
  %11 = load i32, ptr %10, align 4, !tbaa !309
  %12 = and i32 %11, 8
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %22, label %14

14:                                               ; preds = %9, %14
  %15 = phi ptr [ %17, %14 ], [ %1, %9 ]
  %16 = getelementptr inbounds nuw i8, ptr %15, i64 8
  %17 = load ptr, ptr %16, align 8, !tbaa !75
  %18 = getelementptr inbounds nuw i8, ptr %17, i64 44
  %19 = load i32, ptr %18, align 4, !tbaa !309
  %20 = and i32 %19, 8
  %21 = icmp eq i32 %20, 0
  br i1 %21, label %22, label %14, !llvm.loop !310

22:                                               ; preds = %14, %4, %9
  %23 = phi ptr [ %1, %4 ], [ %1, %9 ], [ %17, %14 ]
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 8
  %25 = load ptr, ptr %24, align 8, !tbaa !75
  %26 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %27 = icmp eq ptr %25, %26
  br i1 %27, label %178, label %28

28:                                               ; preds = %22
  %29 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %30 = load ptr, ptr %29, align 8, !tbaa !74
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %5) #33
  store ptr null, ptr %5, align 8, !tbaa !685
  %31 = getelementptr inbounds nuw i8, ptr %5, i64 8
  %32 = getelementptr inbounds nuw i8, ptr %5, i64 32
  store ptr %32, ptr %31, align 8, !tbaa !202
  %33 = getelementptr inbounds nuw i8, ptr %5, i64 16
  store i64 0, ptr %33, align 8, !tbaa !204
  %34 = getelementptr inbounds nuw i8, ptr %5, i64 24
  store i64 8, ptr %34, align 8, !tbaa !205
  %35 = getelementptr inbounds nuw i8, ptr %5, i64 48
  store ptr null, ptr %35, align 8, !tbaa !699
  %36 = getelementptr inbounds nuw i8, ptr %5, i64 56
  store i32 0, ptr %36, align 8, !tbaa !700
  br i1 %2, label %37, label %117

37:                                               ; preds = %28
  %38 = getelementptr inbounds nuw i8, ptr %30, i64 16
  %39 = load ptr, ptr %38, align 8, !tbaa !308, !nonnull !17, !align !200
  %40 = load ptr, ptr %39, align 8, !tbaa !4
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 192
  %42 = load ptr, ptr %41, align 8
  %43 = call noundef ptr %42(ptr noundef nonnull align 8 dereferenceable(368) %39) #33
  store ptr %43, ptr %5, align 8, !tbaa !685
  store i64 0, ptr %33, align 8, !tbaa !204
  %44 = getelementptr inbounds nuw i8, ptr %43, i64 16
  %45 = load i32, ptr %44, align 8, !tbaa !701
  %46 = load i32, ptr %36, align 8, !tbaa !700
  %47 = lshr i32 %46, 2
  %48 = icmp ult i32 %45, %47
  %49 = icmp ugt i32 %45, %46
  %50 = or i1 %49, %48
  br i1 %50, label %51, label %68

51:                                               ; preds = %37
  %52 = zext i32 %45 to i64
  %53 = call noalias ptr @calloc(i64 noundef %52, i64 noundef 1) #37
  %54 = icmp eq ptr %53, null
  br i1 %54, label %55, label %62

55:                                               ; preds = %51
  %56 = icmp eq i32 %45, 0
  br i1 %56, label %57, label %61

57:                                               ; preds = %55
  %58 = call noalias dereferenceable_or_null(1) ptr @malloc(i64 noundef 1) #38
  %59 = icmp eq ptr %58, null
  br i1 %59, label %60, label %62

60:                                               ; preds = %57
  call void @_ZN4llvm22report_bad_alloc_errorEPKcb(ptr noundef nonnull @.str.47, i1 noundef zeroext true) #39
  unreachable

61:                                               ; preds = %55
  call void @_ZN4llvm22report_bad_alloc_errorEPKcb(ptr noundef nonnull @.str.47, i1 noundef zeroext true) #39
  unreachable

62:                                               ; preds = %57, %51
  %63 = phi ptr [ %53, %51 ], [ %58, %57 ]
  %64 = load ptr, ptr %35, align 8, !tbaa !702
  store ptr %63, ptr %35, align 8, !tbaa !702
  %65 = icmp eq ptr %64, null
  br i1 %65, label %67, label %66

66:                                               ; preds = %62
  call void @free(ptr noundef nonnull %64) #33
  br label %67

67:                                               ; preds = %66, %62
  store i32 %45, ptr %36, align 8, !tbaa !700
  br label %68

68:                                               ; preds = %37, %67
  call void @_ZN4llvm12LivePhysRegs11addLiveOutsERKNS_17MachineBasicBlockE(ptr noundef nonnull align 8 dereferenceable(64) %5, ptr noundef nonnull align 8 dereferenceable(288) %0) #33
  %69 = load i64, ptr %26, align 8
  %70 = and i64 %69, -8
  %71 = inttoptr i64 %70 to ptr
  %72 = load i64, ptr %71, align 8
  %73 = and i64 %72, 4
  %74 = icmp eq i64 %73, 0
  br i1 %74, label %75, label %89

75:                                               ; preds = %68
  %76 = getelementptr inbounds nuw i8, ptr %71, i64 44
  %77 = load i32, ptr %76, align 4, !tbaa !309
  %78 = and i32 %77, 4
  %79 = icmp eq i32 %78, 0
  br i1 %79, label %89, label %80

80:                                               ; preds = %75, %80
  %81 = phi ptr [ %84, %80 ], [ %71, %75 ]
  %82 = load i64, ptr %81, align 8
  %83 = and i64 %82, -8
  %84 = inttoptr i64 %83 to ptr
  %85 = getelementptr inbounds nuw i8, ptr %84, i64 44
  %86 = load i32, ptr %85, align 4, !tbaa !309
  %87 = and i32 %86, 4
  %88 = icmp eq i32 %87, 0
  br i1 %88, label %89, label %80, !llvm.loop !313

89:                                               ; preds = %80, %68, %75
  %90 = phi ptr [ %71, %68 ], [ %71, %75 ], [ %84, %80 ]
  %91 = icmp eq ptr %90, %1
  br i1 %91, label %117, label %92

92:                                               ; preds = %89, %114
  %93 = phi ptr [ %115, %114 ], [ %90, %89 ]
  call void @_ZN4llvm12LivePhysRegs12stepBackwardERKNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(64) %5, ptr noundef nonnull align 8 dereferenceable(80) %93) #33
  %94 = load i64, ptr %93, align 8
  %95 = and i64 %94, -8
  %96 = inttoptr i64 %95 to ptr
  %97 = load i64, ptr %96, align 8
  %98 = and i64 %97, 4
  %99 = icmp eq i64 %98, 0
  br i1 %99, label %100, label %114

100:                                              ; preds = %92
  %101 = getelementptr inbounds nuw i8, ptr %96, i64 44
  %102 = load i32, ptr %101, align 4, !tbaa !309
  %103 = and i32 %102, 4
  %104 = icmp eq i32 %103, 0
  br i1 %104, label %114, label %105

105:                                              ; preds = %100, %105
  %106 = phi ptr [ %109, %105 ], [ %96, %100 ]
  %107 = load i64, ptr %106, align 8
  %108 = and i64 %107, -8
  %109 = inttoptr i64 %108 to ptr
  %110 = getelementptr inbounds nuw i8, ptr %109, i64 44
  %111 = load i32, ptr %110, align 4, !tbaa !309
  %112 = and i32 %111, 4
  %113 = icmp eq i32 %112, 0
  br i1 %113, label %114, label %105, !llvm.loop !313

114:                                              ; preds = %105, %92, %100
  %115 = phi ptr [ %96, %92 ], [ %96, %100 ], [ %109, %105 ]
  %116 = icmp eq ptr %115, %1
  br i1 %116, label %117, label %92, !llvm.loop !703

117:                                              ; preds = %114, %89, %28
  %118 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %119 = load ptr, ptr %118, align 8, !tbaa !21
  %120 = call noundef ptr @_ZN4llvm15MachineFunction23CreateMachineBasicBlockEPKNS_10BasicBlockESt8optionalINS_10UniqueBBIDEE(ptr noundef nonnull align 8 dereferenceable(1057) %30, ptr noundef %119, i64 undef, i8 0) #33
  %121 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %122 = load ptr, ptr %121, align 8, !tbaa !327
  call void @_ZN4llvm21ilist_callback_traitsINS_17MachineBasicBlockEE13addNodeToListEPS1_(ptr nonnull align 8 poison, ptr noundef %120)
  %123 = load ptr, ptr %122, align 8, !tbaa !595
  %124 = getelementptr inbounds nuw i8, ptr %120, i64 8
  store ptr %122, ptr %124, align 8, !tbaa !327
  store ptr %123, ptr %120, align 8, !tbaa !595
  %125 = getelementptr inbounds nuw i8, ptr %123, i64 8
  store ptr %120, ptr %125, align 8, !tbaa !327
  store ptr %120, ptr %122, align 8, !tbaa !595
  %126 = getelementptr inbounds nuw i8, ptr %120, i64 56
  %127 = load ptr, ptr %126, align 8, !tbaa !75
  %128 = getelementptr inbounds nuw i8, ptr %120, i64 40
  %129 = icmp eq ptr %127, %26
  br i1 %129, label %164, label %130

130:                                              ; preds = %117
  %131 = icmp eq ptr %120, %0
  br i1 %131, label %140, label %132

132:                                              ; preds = %130
  %133 = load ptr, ptr %128, align 8, !tbaa !83
  br label %134

134:                                              ; preds = %134, %132
  %135 = phi ptr [ %25, %132 ], [ %138, %134 ]
  %136 = getelementptr inbounds nuw i8, ptr %135, i64 24
  store ptr %133, ptr %136, align 8, !tbaa !294
  %137 = getelementptr inbounds nuw i8, ptr %135, i64 8
  %138 = load ptr, ptr %137, align 8, !tbaa !75
  %139 = icmp eq ptr %138, %26
  br i1 %139, label %140, label %134, !llvm.loop !304

140:                                              ; preds = %134, %130
  %141 = load i64, ptr %26, align 8
  %142 = and i64 %141, -8
  %143 = inttoptr i64 %142 to ptr
  %144 = load i64, ptr %25, align 8
  %145 = and i64 %144, -8
  %146 = inttoptr i64 %145 to ptr
  %147 = getelementptr inbounds nuw i8, ptr %146, i64 8
  store ptr %26, ptr %147, align 8, !tbaa !75
  %148 = load i64, ptr %25, align 8
  %149 = and i64 %148, -8
  %150 = load i64, ptr %26, align 8
  %151 = and i64 %150, 7
  %152 = or disjoint i64 %151, %149
  store i64 %152, ptr %26, align 8
  %153 = load i64, ptr %127, align 8
  %154 = and i64 %153, -8
  %155 = inttoptr i64 %154 to ptr
  %156 = getelementptr inbounds nuw i8, ptr %143, i64 8
  store ptr %127, ptr %156, align 8, !tbaa !75
  %157 = load i64, ptr %25, align 8
  %158 = and i64 %157, 7
  %159 = or disjoint i64 %158, %154
  store i64 %159, ptr %25, align 8
  %160 = getelementptr inbounds nuw i8, ptr %155, i64 8
  store ptr %25, ptr %160, align 8, !tbaa !75
  %161 = load i64, ptr %127, align 8
  %162 = and i64 %161, 7
  %163 = or disjoint i64 %162, %142
  store i64 %163, ptr %127, align 8
  br label %164

164:                                              ; preds = %117, %140
  call void @_ZN4llvm17MachineBasicBlock31transferSuccessorsAndUpdatePHIsEPS0_(ptr noundef nonnull align 8 dereferenceable(288) %120, ptr noundef nonnull %0)
  call void @_ZN4llvm17MachineBasicBlock12addSuccessorEPS0_NS_17BranchProbabilityE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef nonnull %120, i32 -1)
  br i1 %2, label %165, label %166

165:                                              ; preds = %164
  call void @_ZN4llvm10addLiveInsERNS_17MachineBasicBlockERKNS_12LivePhysRegsE(ptr noundef nonnull align 8 dereferenceable(288) %120, ptr noundef nonnull align 8 dereferenceable(64) %5) #33
  br label %166

166:                                              ; preds = %165, %164
  %167 = icmp eq ptr %3, null
  br i1 %167, label %169, label %168

168:                                              ; preds = %166
  call void @_ZN4llvm13LiveIntervals19insertMBBInMapsImplEPNS_17MachineBasicBlockEb(ptr noundef nonnull align 8 dereferenceable(424) %3, ptr noundef nonnull align 8 dereferenceable(288) %120, i1 noundef zeroext false) #33
  call void @_ZN4llvm13LiveIntervals20reassignRegMaskSlotsERNS_17MachineBasicBlockES2_(ptr noundef nonnull align 8 dereferenceable(424) %3, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(288) %120) #33
  br label %169

169:                                              ; preds = %168, %166
  %170 = load ptr, ptr %35, align 8, !tbaa !702
  %171 = icmp eq ptr %170, null
  br i1 %171, label %173, label %172

172:                                              ; preds = %169
  call void @free(ptr noundef nonnull %170) #33
  br label %173

173:                                              ; preds = %172, %169
  store ptr null, ptr %35, align 8, !tbaa !702
  %174 = load ptr, ptr %31, align 8, !tbaa !202
  %175 = icmp eq ptr %174, %32
  br i1 %175, label %177, label %176

176:                                              ; preds = %173
  call void @free(ptr noundef %174) #33
  br label %177

177:                                              ; preds = %173, %176
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %5) #33
  br label %178

178:                                              ; preds = %22, %177
  %179 = phi ptr [ %120, %177 ], [ %0, %22 ]
  ret ptr %179
}

declare void @_ZN4llvm12LivePhysRegs11addLiveOutsERKNS_17MachineBasicBlockE(ptr noundef nonnull align 8 dereferenceable(64), ptr noundef nonnull align 8 dereferenceable(288)) local_unnamed_addr #4

declare void @_ZN4llvm12LivePhysRegs12stepBackwardERKNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(64), ptr noundef nonnull align 8 dereferenceable(80)) local_unnamed_addr #4

declare noundef ptr @_ZN4llvm15MachineFunction23CreateMachineBasicBlockEPKNS_10BasicBlockESt8optionalINS_10UniqueBBIDEE(ptr noundef nonnull align 8 dereferenceable(1057), ptr noundef, i64, i8) local_unnamed_addr #4

declare void @_ZN4llvm10addLiveInsERNS_17MachineBasicBlockERKNS_12LivePhysRegsE(ptr noundef nonnull align 8 dereferenceable(288), ptr noundef nonnull align 8 dereferenceable(64)) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZN4llvm17MachineBasicBlock17SplitCriticalEdgeEPS0_PNS_4PassEPNS_15AnalysisManagerINS_15MachineFunctionEJEEEPSt6vectorINS_15SparseBitVectorILj128EEESaISA_EEPNS_21MachineDomTreeUpdaterE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1, ptr noundef readonly captures(address_is_null) %2, ptr noundef readonly captures(none) %3, ptr noundef %4, ptr noundef %5) local_unnamed_addr #3 align 2 {
  %7 = alloca %"struct.llvm::MachineBasicBlock::SplitCriticalEdgeAnalyses", align 16
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %9 = load ptr, ptr %8, align 8, !tbaa !74
  %10 = icmp eq ptr %2, null
  br i1 %10, label %31, label %11

11:                                               ; preds = %6
  %12 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %13 = load ptr, ptr %12, align 8, !tbaa !704
  %14 = tail call noundef ptr @_ZNK4llvm16AnalysisResolver22getAnalysisIfAvailableEPKv(ptr noundef nonnull align 8 dereferenceable(32) %13, ptr noundef nonnull @_ZN4llvm24LiveIntervalsWrapperPass2IDE) #33
  %15 = load ptr, ptr %12, align 8, !tbaa !704
  %16 = tail call noundef ptr @_ZNK4llvm16AnalysisResolver22getAnalysisIfAvailableEPKv(ptr noundef nonnull align 8 dereferenceable(32) %15, ptr noundef nonnull @_ZN4llvm22SlotIndexesWrapperPass2IDE) #33
  %17 = insertelement <2 x ptr> poison, ptr %14, i64 0
  %18 = insertelement <2 x ptr> %17, ptr %16, i64 1
  %19 = icmp eq <2 x ptr> %18, zeroinitializer
  %20 = getelementptr i8, <2 x ptr> %18, i64 56
  %21 = select <2 x i1> %19, <2 x ptr> zeroinitializer, <2 x ptr> %20
  %22 = load ptr, ptr %12, align 8, !tbaa !704
  %23 = tail call noundef ptr @_ZNK4llvm16AnalysisResolver22getAnalysisIfAvailableEPKv(ptr noundef nonnull align 8 dereferenceable(32) %22, ptr noundef nonnull @_ZN4llvm24LiveVariablesWrapperPass2IDE) #33
  %24 = load ptr, ptr %12, align 8, !tbaa !704
  %25 = tail call noundef ptr @_ZNK4llvm16AnalysisResolver22getAnalysisIfAvailableEPKv(ptr noundef nonnull align 8 dereferenceable(32) %24, ptr noundef nonnull @_ZN4llvm26MachineLoopInfoWrapperPass2IDE) #33
  %26 = insertelement <2 x ptr> poison, ptr %23, i64 0
  %27 = insertelement <2 x ptr> %26, ptr %25, i64 1
  %28 = icmp eq <2 x ptr> %27, zeroinitializer
  %29 = getelementptr i8, <2 x ptr> %27, i64 56
  %30 = select <2 x i1> %28, <2 x ptr> zeroinitializer, <2 x ptr> %29
  br label %301

31:                                               ; preds = %6
  %32 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %33 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %34 = load i32, ptr %33, align 8, !tbaa !708, !noalias !711
  %35 = icmp eq i32 %34, 0
  %36 = load ptr, ptr %32, align 8, !tbaa !716, !noalias !717
  %37 = getelementptr inbounds nuw i8, ptr %3, i64 56
  %38 = load ptr, ptr %37, align 8, !tbaa !720, !noalias !711
  %39 = getelementptr inbounds nuw i8, ptr %3, i64 68
  %40 = load i32, ptr %39, align 4, !tbaa !721, !noalias !711
  br i1 %35, label %87, label %41

41:                                               ; preds = %31
  %42 = add i32 %40, -1
  %43 = mul i64 ptrtoint (ptr @_ZN4llvm21LiveIntervalsAnalysis3KeyE to i64), -4658895280553007687
  %44 = lshr i64 %43, 31
  %45 = xor i64 %44, %43
  %46 = ptrtoint ptr %9 to i64
  %47 = mul i64 %46, -4658895280553007687
  %48 = lshr i64 %47, 31
  %49 = xor i64 %48, %47
  %50 = shl i64 %45, 32
  %51 = and i64 %49, 4294967295
  %52 = or disjoint i64 %51, %50
  %53 = mul i64 %52, -4658895280553007687
  %54 = lshr i64 %53, 31
  %55 = xor i64 %54, %53
  %56 = trunc i64 %55 to i32
  %57 = and i32 %42, %56
  %58 = zext i32 %57 to i64
  %59 = lshr i64 %58, 5
  %60 = getelementptr inbounds nuw i32, ptr %38, i64 %59
  %61 = load i32, ptr %60, align 4, !tbaa !451, !noalias !711
  %62 = and i32 %57, 31
  %63 = shl nuw i32 1, %62
  %64 = and i32 %61, %63
  %65 = icmp eq i32 %64, 0
  br i1 %65, label %87, label %66, !prof !480

66:                                               ; preds = %41, %76
  %67 = phi i64 [ %79, %76 ], [ %58, %41 ]
  %68 = phi i32 [ %78, %76 ], [ %57, %41 ]
  %69 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %67
  %70 = load ptr, ptr %69, align 8, !tbaa !722, !noalias !711
  %71 = icmp eq ptr %70, @_ZN4llvm21LiveIntervalsAnalysis3KeyE
  %72 = getelementptr inbounds nuw i8, ptr %69, i64 8
  %73 = load ptr, ptr %72, align 8, !noalias !711
  %74 = icmp eq ptr %9, %73
  %75 = select i1 %71, i1 %74, i1 false
  br i1 %75, label %90, label %76, !prof !483

76:                                               ; preds = %66
  %77 = add i32 %68, 1
  %78 = and i32 %77, %42
  %79 = zext i32 %78 to i64
  %80 = lshr i64 %79, 5
  %81 = getelementptr inbounds nuw i32, ptr %38, i64 %80
  %82 = load i32, ptr %81, align 4, !tbaa !451, !noalias !711
  %83 = and i32 %78, 31
  %84 = shl nuw i32 1, %83
  %85 = and i32 %82, %84
  %86 = icmp eq i32 %85, 0
  br i1 %86, label %87, label %66, !prof !484

87:                                               ; preds = %76, %41, %31
  %88 = zext i32 %40 to i64
  %89 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %88
  br label %92

90:                                               ; preds = %66
  %91 = zext i32 %40 to i64
  br label %92

92:                                               ; preds = %90, %87
  %93 = phi i64 [ %91, %90 ], [ %88, %87 ]
  %94 = phi ptr [ %69, %90 ], [ %89, %87 ]
  %95 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %93
  %96 = icmp eq ptr %94, %95
  br i1 %96, label %100, label %97

97:                                               ; preds = %92
  %98 = getelementptr inbounds nuw i8, ptr %94, i64 16
  %99 = load ptr, ptr %98, align 8, !tbaa !725
  br label %100

100:                                              ; preds = %92, %97
  %101 = phi ptr [ %99, %97 ], [ null, %92 ]
  %102 = icmp eq ptr %101, null
  %103 = getelementptr inbounds nuw i8, ptr %101, i64 16
  %104 = select i1 %102, ptr null, ptr %103
  br i1 %35, label %151, label %105

105:                                              ; preds = %100
  %106 = add i32 %40, -1
  %107 = mul i64 ptrtoint (ptr @_ZN4llvm19SlotIndexesAnalysis3KeyE to i64), -4658895280553007687
  %108 = lshr i64 %107, 31
  %109 = xor i64 %108, %107
  %110 = ptrtoint ptr %9 to i64
  %111 = mul i64 %110, -4658895280553007687
  %112 = lshr i64 %111, 31
  %113 = xor i64 %112, %111
  %114 = shl i64 %109, 32
  %115 = and i64 %113, 4294967295
  %116 = or disjoint i64 %115, %114
  %117 = mul i64 %116, -4658895280553007687
  %118 = lshr i64 %117, 31
  %119 = xor i64 %118, %117
  %120 = trunc i64 %119 to i32
  %121 = and i32 %106, %120
  %122 = zext i32 %121 to i64
  %123 = lshr i64 %122, 5
  %124 = getelementptr inbounds nuw i32, ptr %38, i64 %123
  %125 = load i32, ptr %124, align 4, !tbaa !451, !noalias !728
  %126 = and i32 %121, 31
  %127 = shl nuw i32 1, %126
  %128 = and i32 %125, %127
  %129 = icmp eq i32 %128, 0
  br i1 %129, label %151, label %130, !prof !480

130:                                              ; preds = %105, %140
  %131 = phi i64 [ %143, %140 ], [ %122, %105 ]
  %132 = phi i32 [ %142, %140 ], [ %121, %105 ]
  %133 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %131
  %134 = load ptr, ptr %133, align 8, !tbaa !722, !noalias !728
  %135 = icmp eq ptr %134, @_ZN4llvm19SlotIndexesAnalysis3KeyE
  %136 = getelementptr inbounds nuw i8, ptr %133, i64 8
  %137 = load ptr, ptr %136, align 8, !noalias !728
  %138 = icmp eq ptr %9, %137
  %139 = select i1 %135, i1 %138, i1 false
  br i1 %139, label %154, label %140, !prof !483

140:                                              ; preds = %130
  %141 = add i32 %132, 1
  %142 = and i32 %141, %106
  %143 = zext i32 %142 to i64
  %144 = lshr i64 %143, 5
  %145 = getelementptr inbounds nuw i32, ptr %38, i64 %144
  %146 = load i32, ptr %145, align 4, !tbaa !451, !noalias !728
  %147 = and i32 %142, 31
  %148 = shl nuw i32 1, %147
  %149 = and i32 %146, %148
  %150 = icmp eq i32 %149, 0
  br i1 %150, label %151, label %130, !prof !484

151:                                              ; preds = %140, %105, %100
  %152 = zext i32 %40 to i64
  %153 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %152
  br label %156

154:                                              ; preds = %130
  %155 = zext i32 %40 to i64
  br label %156

156:                                              ; preds = %154, %151
  %157 = phi i64 [ %155, %154 ], [ %152, %151 ]
  %158 = phi ptr [ %133, %154 ], [ %153, %151 ]
  %159 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %157
  %160 = icmp eq ptr %158, %159
  br i1 %160, label %164, label %161

161:                                              ; preds = %156
  %162 = getelementptr inbounds nuw i8, ptr %158, i64 16
  %163 = load ptr, ptr %162, align 8, !tbaa !725
  br label %164

164:                                              ; preds = %156, %161
  %165 = phi ptr [ %163, %161 ], [ null, %156 ]
  %166 = icmp eq ptr %165, null
  %167 = getelementptr inbounds nuw i8, ptr %165, i64 16
  %168 = select i1 %166, ptr null, ptr %167
  br i1 %35, label %215, label %169

169:                                              ; preds = %164
  %170 = add i32 %40, -1
  %171 = mul i64 ptrtoint (ptr @_ZN4llvm21LiveVariablesAnalysis3KeyE to i64), -4658895280553007687
  %172 = lshr i64 %171, 31
  %173 = xor i64 %172, %171
  %174 = ptrtoint ptr %9 to i64
  %175 = mul i64 %174, -4658895280553007687
  %176 = lshr i64 %175, 31
  %177 = xor i64 %176, %175
  %178 = shl i64 %173, 32
  %179 = and i64 %177, 4294967295
  %180 = or disjoint i64 %179, %178
  %181 = mul i64 %180, -4658895280553007687
  %182 = lshr i64 %181, 31
  %183 = xor i64 %182, %181
  %184 = trunc i64 %183 to i32
  %185 = and i32 %170, %184
  %186 = zext i32 %185 to i64
  %187 = lshr i64 %186, 5
  %188 = getelementptr inbounds nuw i32, ptr %38, i64 %187
  %189 = load i32, ptr %188, align 4, !tbaa !451, !noalias !733
  %190 = and i32 %185, 31
  %191 = shl nuw i32 1, %190
  %192 = and i32 %189, %191
  %193 = icmp eq i32 %192, 0
  br i1 %193, label %215, label %194, !prof !480

194:                                              ; preds = %169, %204
  %195 = phi i64 [ %207, %204 ], [ %186, %169 ]
  %196 = phi i32 [ %206, %204 ], [ %185, %169 ]
  %197 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %195
  %198 = load ptr, ptr %197, align 8, !tbaa !722, !noalias !733
  %199 = icmp eq ptr %198, @_ZN4llvm21LiveVariablesAnalysis3KeyE
  %200 = getelementptr inbounds nuw i8, ptr %197, i64 8
  %201 = load ptr, ptr %200, align 8, !noalias !733
  %202 = icmp eq ptr %9, %201
  %203 = select i1 %199, i1 %202, i1 false
  br i1 %203, label %218, label %204, !prof !483

204:                                              ; preds = %194
  %205 = add i32 %196, 1
  %206 = and i32 %205, %170
  %207 = zext i32 %206 to i64
  %208 = lshr i64 %207, 5
  %209 = getelementptr inbounds nuw i32, ptr %38, i64 %208
  %210 = load i32, ptr %209, align 4, !tbaa !451, !noalias !733
  %211 = and i32 %206, 31
  %212 = shl nuw i32 1, %211
  %213 = and i32 %210, %212
  %214 = icmp eq i32 %213, 0
  br i1 %214, label %215, label %194, !prof !484

215:                                              ; preds = %204, %169, %164
  %216 = zext i32 %40 to i64
  %217 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %216
  br label %220

218:                                              ; preds = %194
  %219 = zext i32 %40 to i64
  br label %220

220:                                              ; preds = %218, %215
  %221 = phi i64 [ %219, %218 ], [ %216, %215 ]
  %222 = phi ptr [ %197, %218 ], [ %217, %215 ]
  %223 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %221
  %224 = icmp eq ptr %222, %223
  br i1 %224, label %228, label %225

225:                                              ; preds = %220
  %226 = getelementptr inbounds nuw i8, ptr %222, i64 16
  %227 = load ptr, ptr %226, align 8, !tbaa !725
  br label %228

228:                                              ; preds = %220, %225
  %229 = phi ptr [ %227, %225 ], [ null, %220 ]
  %230 = icmp eq ptr %229, null
  %231 = getelementptr inbounds nuw i8, ptr %229, i64 16
  %232 = select i1 %230, ptr null, ptr %231
  br i1 %35, label %279, label %233

233:                                              ; preds = %228
  %234 = add i32 %40, -1
  %235 = mul i64 ptrtoint (ptr @_ZN4llvm19MachineLoopAnalysis3KeyE to i64), -4658895280553007687
  %236 = lshr i64 %235, 31
  %237 = xor i64 %236, %235
  %238 = ptrtoint ptr %9 to i64
  %239 = mul i64 %238, -4658895280553007687
  %240 = lshr i64 %239, 31
  %241 = xor i64 %240, %239
  %242 = shl i64 %237, 32
  %243 = and i64 %241, 4294967295
  %244 = or disjoint i64 %243, %242
  %245 = mul i64 %244, -4658895280553007687
  %246 = lshr i64 %245, 31
  %247 = xor i64 %246, %245
  %248 = trunc i64 %247 to i32
  %249 = and i32 %234, %248
  %250 = zext i32 %249 to i64
  %251 = lshr i64 %250, 5
  %252 = getelementptr inbounds nuw i32, ptr %38, i64 %251
  %253 = load i32, ptr %252, align 4, !tbaa !451, !noalias !738
  %254 = and i32 %249, 31
  %255 = shl nuw i32 1, %254
  %256 = and i32 %253, %255
  %257 = icmp eq i32 %256, 0
  br i1 %257, label %279, label %258, !prof !480

258:                                              ; preds = %233, %268
  %259 = phi i64 [ %271, %268 ], [ %250, %233 ]
  %260 = phi i32 [ %270, %268 ], [ %249, %233 ]
  %261 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %259
  %262 = load ptr, ptr %261, align 8, !tbaa !722, !noalias !738
  %263 = icmp eq ptr %262, @_ZN4llvm19MachineLoopAnalysis3KeyE
  %264 = getelementptr inbounds nuw i8, ptr %261, i64 8
  %265 = load ptr, ptr %264, align 8, !noalias !738
  %266 = icmp eq ptr %9, %265
  %267 = select i1 %263, i1 %266, i1 false
  br i1 %267, label %282, label %268, !prof !483

268:                                              ; preds = %258
  %269 = add i32 %260, 1
  %270 = and i32 %269, %234
  %271 = zext i32 %270 to i64
  %272 = lshr i64 %271, 5
  %273 = getelementptr inbounds nuw i32, ptr %38, i64 %272
  %274 = load i32, ptr %273, align 4, !tbaa !451, !noalias !738
  %275 = and i32 %270, 31
  %276 = shl nuw i32 1, %275
  %277 = and i32 %274, %276
  %278 = icmp eq i32 %277, 0
  br i1 %278, label %279, label %258, !prof !484

279:                                              ; preds = %268, %233, %228
  %280 = zext i32 %40 to i64
  %281 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %280
  br label %284

282:                                              ; preds = %258
  %283 = zext i32 %40 to i64
  br label %284

284:                                              ; preds = %282, %279
  %285 = phi i64 [ %283, %282 ], [ %280, %279 ]
  %286 = phi ptr [ %261, %282 ], [ %281, %279 ]
  %287 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair.807", ptr %36, i64 %285
  %288 = icmp eq ptr %286, %287
  br i1 %288, label %292, label %289

289:                                              ; preds = %284
  %290 = getelementptr inbounds nuw i8, ptr %286, i64 16
  %291 = load ptr, ptr %290, align 8, !tbaa !725
  br label %292

292:                                              ; preds = %289, %284
  %293 = phi ptr [ %291, %289 ], [ null, %284 ]
  %294 = icmp eq ptr %293, null
  %295 = getelementptr inbounds nuw i8, ptr %293, i64 16
  %296 = select i1 %294, ptr null, ptr %295
  %297 = insertelement <2 x ptr> poison, ptr %104, i64 0
  %298 = insertelement <2 x ptr> %297, ptr %168, i64 1
  %299 = insertelement <2 x ptr> poison, ptr %232, i64 0
  %300 = insertelement <2 x ptr> %299, ptr %296, i64 1
  br label %301

301:                                              ; preds = %11, %292
  %302 = phi <2 x ptr> [ %298, %292 ], [ %21, %11 ]
  %303 = phi <2 x ptr> [ %300, %292 ], [ %30, %11 ]
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %7) #33
  store <2 x ptr> %302, ptr %7, align 16, !tbaa !743
  %304 = getelementptr inbounds nuw i8, ptr %7, i64 16
  store <2 x ptr> %303, ptr %304, align 16, !tbaa !743
  %305 = call noundef ptr @_ZN4llvm17MachineBasicBlock17SplitCriticalEdgeEPS0_RKNS0_25SplitCriticalEdgeAnalysesEPSt6vectorINS_15SparseBitVectorILj128EEESaIS7_EEPNS_21MachineDomTreeUpdaterE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1, ptr noundef nonnull align 8 dereferenceable(32) %7, ptr noundef %4, ptr noundef %5)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %7) #33
  ret ptr %305
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZN4llvm17MachineBasicBlock17SplitCriticalEdgeEPS0_RKNS0_25SplitCriticalEdgeAnalysesEPSt6vectorINS_15SparseBitVectorILj128EEESaIS7_EEPNS_21MachineDomTreeUpdaterE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1, ptr noundef nonnull readonly align 8 captures(none) dereferenceable(32) %2, ptr noundef %3, ptr noundef %4) local_unnamed_addr #3 align 2 {
  %6 = alloca %"class.llvm::SmallVector.278", align 8
  %7 = alloca %"class.llvm::SmallVector.278", align 8
  %8 = alloca %class.SlotIndexUpdateDelegate, align 8
  %9 = alloca %class.SlotIndexUpdateDelegate, align 8
  %10 = alloca %"class.llvm::SmallVector.426", align 8
  %11 = alloca %"class.llvm::DebugLoc", align 8
  %12 = alloca %"class.llvm::DebugLoc", align 8
  %13 = alloca %"class.llvm::SmallSet", align 8
  %14 = alloca %"class.llvm::Register", align 4
  %15 = alloca %"struct.std::pair.538", align 8
  %16 = alloca %"struct.llvm::LiveRange::Segment", align 8
  %17 = alloca %"struct.llvm::LiveRange::Segment", align 8
  %18 = alloca %"struct.llvm::LiveRange::Segment", align 8
  %19 = alloca %"struct.llvm::LiveRange::Segment", align 8
  %20 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %21 = load ptr, ptr %20, align 8, !tbaa !744
  %22 = tail call noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock20canSplitCriticalEdgeEPKS0_PKNS_15MachineLoopInfoE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1, ptr noundef %21)
  br i1 %22, label %23, label %1124

23:                                               ; preds = %5
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %25 = load ptr, ptr %24, align 8, !tbaa !74
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 296
  %27 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %28 = load ptr, ptr %27, align 8, !tbaa !327
  %29 = icmp eq ptr %28, %26
  %30 = select i1 %29, ptr null, ptr %28
  %31 = tail call noundef ptr @_ZN4llvm15MachineFunction23CreateMachineBasicBlockEPKNS_10BasicBlockESt8optionalINS_10UniqueBBIDEE(ptr noundef nonnull align 8 dereferenceable(1057) %25, ptr noundef null, i64 undef, i8 0) #33
  %32 = getelementptr inbounds nuw i8, ptr %1, i64 28
  %33 = load i32, ptr %32, align 4, !tbaa !73
  %34 = getelementptr inbounds nuw i8, ptr %31, i64 28
  store i32 %33, ptr %34, align 4, !tbaa !73
  %35 = tail call ptr @_ZN4llvm17MachineBasicBlock18getFirstTerminatorEv(ptr noundef nonnull align 8 dereferenceable(288) %0)
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %37 = icmp eq ptr %35, %36
  br i1 %37, label %55, label %38

38:                                               ; preds = %23
  %39 = load ptr, ptr %24, align 8, !tbaa !74
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 16
  %41 = load ptr, ptr %40, align 8, !tbaa !308, !nonnull !17, !align !200
  %42 = load ptr, ptr %41, align 8, !tbaa !4
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 120
  %44 = load ptr, ptr %43, align 8
  %45 = tail call noundef ptr %44(ptr noundef nonnull align 8 dereferenceable(368) %41) #33
  %46 = load ptr, ptr %45, align 8, !tbaa !4
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 464
  %48 = load ptr, ptr %47, align 8
  %49 = tail call noundef i32 %48(ptr noundef nonnull align 8 dereferenceable(112) %45, ptr noundef nonnull align 8 dereferenceable(80) %35) #33
  %50 = icmp sgt i32 %49, -1
  br i1 %50, label %51, label %55

51:                                               ; preds = %38
  %52 = getelementptr inbounds nuw i8, ptr %25, i64 64
  %53 = load ptr, ptr %52, align 8, !tbaa !750
  %54 = tail call noundef zeroext i1 @_ZN4llvm20MachineJumpTableInfo21ReplaceMBBInJumpTableEjPNS_17MachineBasicBlockES2_(ptr noundef nonnull align 8 dereferenceable(32) %53, i32 noundef %49, ptr noundef nonnull %1, ptr noundef nonnull %31) #33
  br label %55

55:                                               ; preds = %23, %51, %38
  %56 = phi i1 [ true, %51 ], [ false, %38 ], [ false, %23 ]
  %57 = load ptr, ptr %27, align 8, !tbaa !327
  tail call void @_ZN4llvm21ilist_callback_traitsINS_17MachineBasicBlockEE13addNodeToListEPS1_(ptr nonnull align 8 poison, ptr noundef nonnull %31)
  %58 = load ptr, ptr %57, align 8, !tbaa !595
  %59 = getelementptr inbounds nuw i8, ptr %31, i64 8
  store ptr %57, ptr %59, align 8, !tbaa !327
  store ptr %58, ptr %31, align 8, !tbaa !595
  %60 = getelementptr inbounds nuw i8, ptr %58, i64 8
  store ptr %31, ptr %60, align 8, !tbaa !327
  store ptr %31, ptr %57, align 8, !tbaa !595
  %61 = load ptr, ptr %2, align 8, !tbaa !751
  %62 = icmp eq ptr %61, null
  br i1 %62, label %64, label %63

63:                                               ; preds = %55
  tail call void @_ZN4llvm13LiveIntervals19insertMBBInMapsImplEPNS_17MachineBasicBlockEb(ptr noundef nonnull align 8 dereferenceable(424) %61, ptr noundef nonnull %31, i1 noundef zeroext true) #33
  br label %69

64:                                               ; preds = %55
  %65 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %66 = load ptr, ptr %65, align 8, !tbaa !752
  %67 = icmp eq ptr %66, null
  br i1 %67, label %69, label %68

68:                                               ; preds = %64
  tail call void @_ZN4llvm11SlotIndexes15insertMBBInMapsEPNS_17MachineBasicBlockE(ptr noundef nonnull align 8 dereferenceable(416) %66, ptr noundef nonnull %31)
  br label %69

69:                                               ; preds = %64, %68, %63
  %70 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %71 = load ptr, ptr %70, align 8, !tbaa !753
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %6) #33
  %72 = getelementptr inbounds nuw i8, ptr %6, i64 16
  store ptr %72, ptr %6, align 8, !tbaa !19
  %73 = getelementptr inbounds nuw i8, ptr %6, i64 8
  store i32 0, ptr %73, align 8, !tbaa !76
  %74 = getelementptr inbounds nuw i8, ptr %6, i64 12
  store i32 4, ptr %74, align 4, !tbaa !77
  %75 = icmp eq ptr %71, null
  br i1 %75, label %200, label %76

76:                                               ; preds = %69
  %77 = call ptr @_ZN4llvm17MachineBasicBlock23getFirstInstrTerminatorEv(ptr noundef nonnull align 8 dereferenceable(288) %0)
  %78 = icmp eq ptr %77, %36
  br i1 %78, label %200, label %79

79:                                               ; preds = %76, %102
  %80 = phi ptr [ %104, %102 ], [ %77, %76 ]
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 32
  %82 = load ptr, ptr %81, align 8, !tbaa !571, !noalias !754
  %83 = getelementptr inbounds nuw i8, ptr %80, i64 40
  %84 = load i24, ptr %83, align 8, !noalias !754
  %85 = zext i24 %84 to i64
  %86 = call noundef i32 @_ZNK4llvm12MachineInstr18getNumExplicitDefsEv(ptr noundef nonnull align 8 dereferenceable(80) %80) #33, !noalias !754
  %87 = zext i32 %86 to i64
  %88 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %82, i64 %87
  %89 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %82, i64 %85
  %90 = icmp samesign eq i64 %87, %85
  br i1 %90, label %99, label %91

91:                                               ; preds = %79, %96
  %92 = phi ptr [ %97, %96 ], [ %88, %79 ]
  %93 = load i32, ptr %92, align 8, !noalias !757
  %94 = and i32 %93, 16777471
  %95 = icmp eq i32 %94, 0
  br i1 %95, label %99, label %96

96:                                               ; preds = %91
  %97 = getelementptr inbounds nuw i8, ptr %92, i64 32
  %98 = icmp eq ptr %97, %89
  br i1 %98, label %102, label %91, !llvm.loop !760

99:                                               ; preds = %91, %79
  %100 = phi ptr [ %88, %79 ], [ %92, %91 ]
  %101 = icmp eq ptr %100, %89
  br i1 %101, label %102, label %106

102:                                              ; preds = %96, %187, %198, %195, %99
  %103 = getelementptr inbounds nuw i8, ptr %80, i64 8
  %104 = load ptr, ptr %103, align 8, !tbaa !75
  %105 = icmp eq ptr %104, %36
  br i1 %105, label %200, label %79

106:                                              ; preds = %99, %198
  %107 = phi ptr [ %191, %198 ], [ %100, %99 ]
  %108 = getelementptr inbounds nuw i8, ptr %107, i64 4
  %109 = load i32, ptr %108, align 4, !tbaa !212
  %110 = icmp eq i32 %109, 0
  br i1 %110, label %187, label %111

111:                                              ; preds = %106
  %112 = load i32, ptr %107, align 8
  %113 = and i32 %112, 352321536
  %114 = icmp eq i32 %113, 67108864
  br i1 %114, label %115, label %187

115:                                              ; preds = %111
  %116 = icmp ult i32 %109, 1073741824
  br i1 %116, label %173, label %117

117:                                              ; preds = %115
  %118 = call noundef nonnull align 8 dereferenceable(56) ptr @_ZN4llvm13LiveVariables10getVarInfoENS_8RegisterE(ptr noundef nonnull align 8 dereferenceable(200) %71, i32 %109) #33
  %119 = getelementptr inbounds nuw i8, ptr %118, i64 32
  %120 = load ptr, ptr %119, align 8, !tbaa !761
  %121 = getelementptr inbounds nuw i8, ptr %118, i64 40
  %122 = load ptr, ptr %121, align 8, !tbaa !761
  %123 = icmp eq ptr %120, %122
  br i1 %123, label %149, label %124

124:                                              ; preds = %117, %146
  %125 = phi ptr [ %147, %146 ], [ %120, %117 ]
  %126 = load ptr, ptr %125, align 8, !tbaa !481
  %127 = icmp eq ptr %126, %80
  br i1 %127, label %149, label %128

128:                                              ; preds = %124
  %129 = getelementptr inbounds nuw i8, ptr %125, i64 8
  %130 = icmp eq ptr %129, %122
  br i1 %130, label %187, label %131, !llvm.loop !763

131:                                              ; preds = %128
  %132 = load ptr, ptr %129, align 8, !tbaa !481
  %133 = icmp eq ptr %132, %80
  br i1 %133, label %149, label %134

134:                                              ; preds = %131
  %135 = getelementptr inbounds nuw i8, ptr %125, i64 16
  %136 = icmp eq ptr %135, %122
  br i1 %136, label %187, label %137, !llvm.loop !763

137:                                              ; preds = %134
  %138 = load ptr, ptr %135, align 8, !tbaa !481
  %139 = icmp eq ptr %138, %80
  br i1 %139, label %149, label %140

140:                                              ; preds = %137
  %141 = getelementptr inbounds nuw i8, ptr %125, i64 24
  %142 = icmp eq ptr %141, %122
  br i1 %142, label %187, label %143, !llvm.loop !763

143:                                              ; preds = %140
  %144 = load ptr, ptr %141, align 8, !tbaa !481
  %145 = icmp eq ptr %144, %80
  br i1 %145, label %149, label %146

146:                                              ; preds = %143
  %147 = getelementptr inbounds nuw i8, ptr %125, i64 32
  %148 = icmp eq ptr %147, %122
  br i1 %148, label %187, label %124, !llvm.loop !764

149:                                              ; preds = %143, %137, %131, %124, %117
  %150 = phi ptr [ %120, %117 ], [ %125, %124 ], [ %129, %131 ], [ %135, %137 ], [ %141, %143 ]
  %151 = icmp eq ptr %150, %122
  br i1 %151, label %187, label %152

152:                                              ; preds = %149
  %153 = ptrtoint ptr %150 to i64
  %154 = ptrtoint ptr %120 to i64
  %155 = sub i64 %153, %154
  %156 = getelementptr inbounds i8, ptr %120, i64 %155
  %157 = getelementptr inbounds nuw i8, ptr %156, i64 8
  %158 = icmp eq ptr %157, %122
  br i1 %158, label %170, label %159

159:                                              ; preds = %152
  %160 = ptrtoint ptr %122 to i64
  %161 = ptrtoint ptr %157 to i64
  %162 = sub i64 %160, %161
  %163 = icmp sgt i64 %162, 8
  br i1 %163, label %164, label %166, !prof !483

164:                                              ; preds = %159
  call void @llvm.memmove.p0.p0.i64(ptr align 8 %156, ptr nonnull align 8 %157, i64 %162, i1 false)
  %165 = load ptr, ptr %121, align 8, !tbaa !765
  br label %170

166:                                              ; preds = %159
  %167 = icmp eq i64 %162, 8
  br i1 %167, label %168, label %170

168:                                              ; preds = %166
  %169 = load ptr, ptr %157, align 8, !tbaa !481
  store ptr %169, ptr %156, align 8, !tbaa !481
  br label %170

170:                                              ; preds = %152, %164, %166, %168
  %171 = phi ptr [ %122, %168 ], [ %122, %166 ], [ %165, %164 ], [ %122, %152 ]
  %172 = getelementptr inbounds i8, ptr %171, i64 -8
  store ptr %172, ptr %121, align 8, !tbaa !765
  br label %173

173:                                              ; preds = %170, %115
  %174 = load i32, ptr %73, align 8, !tbaa !76
  %175 = load i32, ptr %74, align 4, !tbaa !77
  %176 = icmp ult i32 %174, %175
  br i1 %176, label %178, label %177, !prof !483

177:                                              ; preds = %173
  call void @_ZN4llvm23SmallVectorTemplateBaseINS_8RegisterELb1EE15growAndPushBackES1_(ptr noundef nonnull align 8 dereferenceable(16) %6, i32 %109)
  br label %184

178:                                              ; preds = %173
  %179 = zext i32 %174 to i64
  %180 = load ptr, ptr %6, align 8, !tbaa !19
  %181 = getelementptr inbounds nuw %"class.llvm::Register", ptr %180, i64 %179
  store i32 %109, ptr %181, align 1
  %182 = load i32, ptr %73, align 8, !tbaa !76
  %183 = add i32 %182, 1
  store i32 %183, ptr %73, align 8, !tbaa !76
  br label %184

184:                                              ; preds = %177, %178
  %185 = load i32, ptr %107, align 8
  %186 = and i32 %185, -67108865
  store i32 %186, ptr %107, align 8
  br label %187

187:                                              ; preds = %128, %134, %140, %146, %149, %184, %111, %106
  %188 = getelementptr inbounds nuw i8, ptr %107, i64 32
  %189 = icmp eq ptr %188, %89
  br i1 %189, label %102, label %190

190:                                              ; preds = %187, %195
  %191 = phi ptr [ %196, %195 ], [ %188, %187 ]
  %192 = load i32, ptr %191, align 8
  %193 = and i32 %192, 16777471
  %194 = icmp eq i32 %193, 0
  br i1 %194, label %198, label %195

195:                                              ; preds = %190
  %196 = getelementptr inbounds nuw i8, ptr %191, i64 32
  %197 = icmp eq ptr %196, %89
  br i1 %197, label %102, label %190, !llvm.loop !760

198:                                              ; preds = %190
  %199 = icmp eq ptr %191, %89
  br i1 %199, label %102, label %106

200:                                              ; preds = %102, %76, %69
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %7) #33
  %201 = getelementptr inbounds nuw i8, ptr %7, i64 16
  store ptr %201, ptr %7, align 8, !tbaa !19
  %202 = getelementptr inbounds nuw i8, ptr %7, i64 8
  store i32 0, ptr %202, align 8, !tbaa !76
  %203 = getelementptr inbounds nuw i8, ptr %7, i64 12
  store i32 4, ptr %203, align 4, !tbaa !77
  br i1 %62, label %276, label %204

204:                                              ; preds = %200
  %205 = call ptr @_ZN4llvm17MachineBasicBlock23getFirstInstrTerminatorEv(ptr noundef nonnull align 8 dereferenceable(288) %0)
  %206 = icmp eq ptr %205, %36
  br i1 %206, label %276, label %207

207:                                              ; preds = %204, %217
  %208 = phi ptr [ %219, %217 ], [ %205, %204 ]
  %209 = getelementptr inbounds nuw i8, ptr %208, i64 32
  %210 = load ptr, ptr %209, align 8, !tbaa !571
  %211 = getelementptr inbounds nuw i8, ptr %208, i64 40
  %212 = load i24, ptr %211, align 8
  %213 = zext i24 %212 to i64
  %214 = shl nuw nsw i64 %213, 5
  %215 = getelementptr inbounds nuw i8, ptr %210, i64 %214
  %216 = icmp eq i24 %212, 0
  br i1 %216, label %217, label %221

217:                                              ; preds = %273, %207
  %218 = getelementptr inbounds nuw i8, ptr %208, i64 8
  %219 = load ptr, ptr %218, align 8, !tbaa !75
  %220 = icmp eq ptr %219, %36
  br i1 %220, label %276, label %207

221:                                              ; preds = %207, %273
  %222 = phi ptr [ %274, %273 ], [ %210, %207 ]
  %223 = load i32, ptr %222, align 8
  %224 = and i32 %223, 255
  %225 = icmp eq i32 %224, 0
  br i1 %225, label %226, label %273

226:                                              ; preds = %221
  %227 = getelementptr inbounds nuw i8, ptr %222, i64 4
  %228 = load i32, ptr %227, align 4, !tbaa !212
  %229 = icmp eq i32 %228, 0
  br i1 %229, label %273, label %230

230:                                              ; preds = %226
  %231 = load ptr, ptr %7, align 8, !tbaa !19
  %232 = load i32, ptr %202, align 8, !tbaa !76
  %233 = zext i32 %232 to i64
  %234 = shl nuw nsw i64 %233, 2
  %235 = getelementptr inbounds nuw i8, ptr %231, i64 %234
  %236 = icmp eq i32 %232, 0
  br i1 %236, label %262, label %237

237:                                              ; preds = %230, %259
  %238 = phi ptr [ %260, %259 ], [ %231, %230 ]
  %239 = load i32, ptr %238, align 4, !tbaa !767
  %240 = icmp eq i32 %239, %228
  br i1 %240, label %262, label %241

241:                                              ; preds = %237
  %242 = getelementptr inbounds nuw i8, ptr %238, i64 4
  %243 = icmp eq ptr %242, %235
  br i1 %243, label %265, label %244, !llvm.loop !769

244:                                              ; preds = %241
  %245 = load i32, ptr %242, align 4, !tbaa !767
  %246 = icmp eq i32 %245, %228
  br i1 %246, label %262, label %247

247:                                              ; preds = %244
  %248 = getelementptr inbounds nuw i8, ptr %238, i64 8
  %249 = icmp eq ptr %248, %235
  br i1 %249, label %265, label %250, !llvm.loop !769

250:                                              ; preds = %247
  %251 = load i32, ptr %248, align 4, !tbaa !767
  %252 = icmp eq i32 %251, %228
  br i1 %252, label %262, label %253

253:                                              ; preds = %250
  %254 = getelementptr inbounds nuw i8, ptr %238, i64 12
  %255 = icmp eq ptr %254, %235
  br i1 %255, label %265, label %256, !llvm.loop !769

256:                                              ; preds = %253
  %257 = load i32, ptr %254, align 4, !tbaa !767
  %258 = icmp eq i32 %257, %228
  br i1 %258, label %262, label %259

259:                                              ; preds = %256
  %260 = getelementptr inbounds nuw i8, ptr %238, i64 16
  %261 = icmp eq ptr %260, %235
  br i1 %261, label %265, label %237, !llvm.loop !770

262:                                              ; preds = %237, %244, %250, %256, %230
  %263 = phi ptr [ %231, %230 ], [ %254, %256 ], [ %248, %250 ], [ %242, %244 ], [ %238, %237 ]
  %264 = icmp eq ptr %263, %235
  br i1 %264, label %265, label %273

265:                                              ; preds = %241, %247, %253, %259, %262
  %266 = load i32, ptr %203, align 4, !tbaa !77
  %267 = icmp ult i32 %232, %266
  br i1 %267, label %269, label %268, !prof !483

268:                                              ; preds = %265
  call void @_ZN4llvm23SmallVectorTemplateBaseINS_8RegisterELb1EE15growAndPushBackES1_(ptr noundef nonnull align 8 dereferenceable(16) %7, i32 %228)
  br label %273

269:                                              ; preds = %265
  %270 = getelementptr inbounds nuw %"class.llvm::Register", ptr %231, i64 %233
  store i32 %228, ptr %270, align 1
  %271 = load i32, ptr %202, align 8, !tbaa !76
  %272 = add i32 %271, 1
  store i32 %272, ptr %202, align 8, !tbaa !76
  br label %273

273:                                              ; preds = %262, %268, %269, %221, %226
  %274 = getelementptr inbounds nuw i8, ptr %222, i64 32
  %275 = icmp eq ptr %274, %215
  br i1 %275, label %217, label %221

276:                                              ; preds = %217, %204, %200
  call void @_ZN4llvm17MachineBasicBlock22ReplaceUsesOfBlockWithEPS0_S1_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef nonnull %1, ptr noundef nonnull %31)
  %277 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %278 = load ptr, ptr %277, align 8, !tbaa !752
  br i1 %56, label %324, label %279

279:                                              ; preds = %276
  %280 = icmp eq ptr %1, %30
  %281 = select i1 %280, ptr %31, ptr %30
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %8) #33
  store ptr getelementptr inbounds nuw inrange(-16, 48) (i8, ptr @_ZTV23SlotIndexUpdateDelegate, i64 16), ptr %8, align 8, !tbaa !4
  %282 = getelementptr inbounds nuw i8, ptr %8, i64 8
  store ptr %25, ptr %282, align 8, !tbaa !771
  %283 = getelementptr inbounds nuw i8, ptr %8, i64 16
  store ptr %278, ptr %283, align 8, !tbaa !772
  %284 = getelementptr inbounds nuw i8, ptr %8, i64 24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %284, i8 0, i64 24, i1 false)
  %285 = getelementptr inbounds nuw i8, ptr %8, i64 48
  %286 = getelementptr inbounds nuw i8, ptr %8, i64 64
  store ptr %286, ptr %285, align 8, !tbaa !19
  %287 = getelementptr inbounds nuw i8, ptr %8, i64 56
  store i32 0, ptr %287, align 8, !tbaa !76
  %288 = getelementptr inbounds nuw i8, ptr %8, i64 60
  store i32 2, ptr %288, align 4, !tbaa !77
  %289 = getelementptr inbounds nuw i8, ptr %25, i64 640
  store ptr %8, ptr %289, align 8, !tbaa !786
  call void @_ZN4llvm17MachineBasicBlock16updateTerminatorEPS0_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %281)
  store ptr getelementptr inbounds nuw inrange(-16, 48) (i8, ptr @_ZTV23SlotIndexUpdateDelegate, i64 16), ptr %8, align 8, !tbaa !4
  %290 = load ptr, ptr %282, align 8, !tbaa !787, !nonnull !17, !align !200
  %291 = getelementptr inbounds nuw i8, ptr %290, i64 640
  store ptr null, ptr %291, align 8, !tbaa !786
  %292 = load ptr, ptr %285, align 8, !tbaa !19
  %293 = load i32, ptr %287, align 8, !tbaa !76
  %294 = zext i32 %293 to i64
  %295 = shl nuw nsw i64 %294, 3
  %296 = getelementptr inbounds nuw i8, ptr %292, i64 %295
  %297 = icmp eq i32 %293, 0
  br i1 %297, label %300, label %316

298:                                              ; preds = %316
  %299 = load ptr, ptr %285, align 8, !tbaa !19
  br label %300

300:                                              ; preds = %298, %279
  %301 = phi ptr [ %299, %298 ], [ %292, %279 ]
  %302 = icmp eq ptr %301, %286
  br i1 %302, label %304, label %303

303:                                              ; preds = %300
  call void @free(ptr noundef %301) #33
  br label %304

304:                                              ; preds = %303, %300
  %305 = getelementptr inbounds nuw i8, ptr %8, i64 44
  %306 = load i32, ptr %305, align 4, !tbaa !788
  %307 = icmp eq i32 %306, 0
  br i1 %307, label %323, label %308

308:                                              ; preds = %304
  %309 = load ptr, ptr %284, align 8, !tbaa !789
  %310 = zext i32 %306 to i64
  %311 = shl nuw nsw i64 %310, 3
  %312 = add nuw nsw i64 %310, 31
  %313 = lshr i64 %312, 3
  %314 = and i64 %313, 1073741820
  %315 = add nuw nsw i64 %314, %311
  call void @_ZN4llvm17deallocate_bufferEPvmm(ptr noundef %309, i64 noundef %315, i64 noundef 8) #33
  br label %323

316:                                              ; preds = %279, %316
  %317 = phi ptr [ %321, %316 ], [ %292, %279 ]
  %318 = load ptr, ptr %317, align 8, !tbaa !481
  %319 = load ptr, ptr %283, align 8, !tbaa !772
  %320 = call i64 @_ZN4llvm11SlotIndexes24insertMachineInstrInMapsERNS_12MachineInstrEb(ptr noundef nonnull align 8 dereferenceable(416) %319, ptr noundef nonnull align 8 dereferenceable(80) %318, i1 noundef zeroext false)
  %321 = getelementptr inbounds nuw i8, ptr %317, i64 8
  %322 = icmp eq ptr %321, %296
  br i1 %322, label %298, label %316

323:                                              ; preds = %304, %308
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %8) #33
  br label %324

324:                                              ; preds = %323, %276
  call void @_ZN4llvm17MachineBasicBlock12addSuccessorEPS0_NS_17BranchProbabilityE(ptr noundef nonnull align 8 dereferenceable(288) %31, ptr noundef nonnull %1, i32 -1)
  %325 = load ptr, ptr %59, align 8, !tbaa !327
  %326 = icmp eq ptr %325, %1
  br i1 %326, label %402, label %327

327:                                              ; preds = %324
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %9) #33
  store ptr getelementptr inbounds nuw inrange(-16, 48) (i8, ptr @_ZTV23SlotIndexUpdateDelegate, i64 16), ptr %9, align 8, !tbaa !4
  %328 = getelementptr inbounds nuw i8, ptr %9, i64 8
  store ptr %25, ptr %328, align 8, !tbaa !771
  %329 = getelementptr inbounds nuw i8, ptr %9, i64 16
  store ptr %278, ptr %329, align 8, !tbaa !772
  %330 = getelementptr inbounds nuw i8, ptr %9, i64 24
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %330, i8 0, i64 24, i1 false)
  %331 = getelementptr inbounds nuw i8, ptr %9, i64 48
  %332 = getelementptr inbounds nuw i8, ptr %9, i64 64
  store ptr %332, ptr %331, align 8, !tbaa !19
  %333 = getelementptr inbounds nuw i8, ptr %9, i64 56
  store i32 0, ptr %333, align 8, !tbaa !76
  %334 = getelementptr inbounds nuw i8, ptr %9, i64 60
  store i32 2, ptr %334, align 4, !tbaa !77
  %335 = getelementptr inbounds nuw i8, ptr %25, i64 640
  store ptr %9, ptr %335, align 8, !tbaa !786
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %10) #33
  %336 = getelementptr inbounds nuw i8, ptr %10, i64 16
  store ptr %336, ptr %10, align 8, !tbaa !19
  %337 = getelementptr inbounds nuw i8, ptr %10, i64 8
  store i32 0, ptr %337, align 8, !tbaa !76
  %338 = getelementptr inbounds nuw i8, ptr %10, i64 12
  store i32 4, ptr %338, align 4, !tbaa !77
  %339 = load ptr, ptr %24, align 8, !tbaa !74
  %340 = getelementptr inbounds nuw i8, ptr %339, i64 16
  %341 = load ptr, ptr %340, align 8, !tbaa !308, !nonnull !17, !align !200
  %342 = load ptr, ptr %341, align 8, !tbaa !4
  %343 = getelementptr inbounds nuw i8, ptr %342, i64 120
  %344 = load ptr, ptr %343, align 8
  %345 = call noundef ptr %344(ptr noundef nonnull align 8 dereferenceable(368) %341) #33
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %11) #33
  store ptr null, ptr %11, align 8, !tbaa !790
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %12) #33
  %346 = call ptr @_ZN4llvm17MachineBasicBlock18findBranchDebugLocEv(ptr noundef nonnull align 8 dereferenceable(288) %0)
  store ptr %346, ptr %12, align 8
  %347 = icmp eq ptr %346, null
  br i1 %347, label %356, label %348

348:                                              ; preds = %327
  %349 = call noundef i32 @_ZNK4llvm8DebugLoc7getLineEv(ptr noundef nonnull align 8 dereferenceable(8) %12) #33
  %350 = icmp eq i32 %349, 0
  br i1 %350, label %351, label %354

351:                                              ; preds = %348
  %352 = call noundef i32 @_ZNK4llvm8DebugLoc6getColEv(ptr noundef nonnull align 8 dereferenceable(8) %12) #33
  %353 = icmp eq i32 %352, 0
  br i1 %353, label %356, label %354

354:                                              ; preds = %351, %348
  %355 = load i64, ptr %12, align 8, !tbaa !585
  store i64 %355, ptr %11, align 8, !tbaa !585
  br label %356

356:                                              ; preds = %354, %351, %327
  %357 = load ptr, ptr %10, align 8, !tbaa !19
  %358 = load i32, ptr %337, align 8, !tbaa !76
  %359 = zext i32 %358 to i64
  %360 = load ptr, ptr %345, align 8, !tbaa !4
  %361 = getelementptr inbounds nuw i8, ptr %360, i64 328
  %362 = load ptr, ptr %361, align 8
  %363 = call noundef i32 %362(ptr noundef nonnull align 8 dereferenceable(112) %345, ptr noundef nonnull align 8 dereferenceable(288) %31, ptr noundef nonnull %1, ptr noundef null, ptr %357, i64 %359, ptr noundef nonnull align 8 dereferenceable(8) %11, ptr noundef null) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %12) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %11) #33
  %364 = load ptr, ptr %10, align 8, !tbaa !19
  %365 = icmp eq ptr %364, %336
  br i1 %365, label %367, label %366

366:                                              ; preds = %356
  call void @free(ptr noundef %364) #33
  br label %367

367:                                              ; preds = %356, %366
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %10) #33
  store ptr getelementptr inbounds nuw inrange(-16, 48) (i8, ptr @_ZTV23SlotIndexUpdateDelegate, i64 16), ptr %9, align 8, !tbaa !4
  %368 = load ptr, ptr %328, align 8, !tbaa !787, !nonnull !17, !align !200
  %369 = getelementptr inbounds nuw i8, ptr %368, i64 640
  store ptr null, ptr %369, align 8, !tbaa !786
  %370 = load ptr, ptr %331, align 8, !tbaa !19
  %371 = load i32, ptr %333, align 8, !tbaa !76
  %372 = zext i32 %371 to i64
  %373 = shl nuw nsw i64 %372, 3
  %374 = getelementptr inbounds nuw i8, ptr %370, i64 %373
  %375 = icmp eq i32 %371, 0
  br i1 %375, label %378, label %394

376:                                              ; preds = %394
  %377 = load ptr, ptr %331, align 8, !tbaa !19
  br label %378

378:                                              ; preds = %376, %367
  %379 = phi ptr [ %377, %376 ], [ %370, %367 ]
  %380 = icmp eq ptr %379, %332
  br i1 %380, label %382, label %381

381:                                              ; preds = %378
  call void @free(ptr noundef %379) #33
  br label %382

382:                                              ; preds = %381, %378
  %383 = getelementptr inbounds nuw i8, ptr %9, i64 44
  %384 = load i32, ptr %383, align 4, !tbaa !788
  %385 = icmp eq i32 %384, 0
  br i1 %385, label %401, label %386

386:                                              ; preds = %382
  %387 = load ptr, ptr %330, align 8, !tbaa !789
  %388 = zext i32 %384 to i64
  %389 = shl nuw nsw i64 %388, 3
  %390 = add nuw nsw i64 %388, 31
  %391 = lshr i64 %390, 3
  %392 = and i64 %391, 1073741820
  %393 = add nuw nsw i64 %392, %389
  call void @_ZN4llvm17deallocate_bufferEPvmm(ptr noundef %387, i64 noundef %393, i64 noundef 8) #33
  br label %401

394:                                              ; preds = %367, %394
  %395 = phi ptr [ %399, %394 ], [ %370, %367 ]
  %396 = load ptr, ptr %395, align 8, !tbaa !481
  %397 = load ptr, ptr %329, align 8, !tbaa !772
  %398 = call i64 @_ZN4llvm11SlotIndexes24insertMachineInstrInMapsERNS_12MachineInstrEb(ptr noundef nonnull align 8 dereferenceable(416) %397, ptr noundef nonnull align 8 dereferenceable(80) %396, i1 noundef zeroext false)
  %399 = getelementptr inbounds nuw i8, ptr %395, i64 8
  %400 = icmp eq ptr %399, %374
  br i1 %400, label %376, label %394

401:                                              ; preds = %382, %386
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %9) #33
  br label %402

402:                                              ; preds = %401, %324
  %403 = getelementptr inbounds nuw i8, ptr %1, i64 56
  %404 = load ptr, ptr %403, align 8, !tbaa !75
  %405 = getelementptr inbounds nuw i8, ptr %1, i64 48
  %406 = icmp eq ptr %404, %405
  br i1 %406, label %487, label %407

407:                                              ; preds = %402, %411
  %408 = phi ptr [ %413, %411 ], [ %404, %402 ]
  %409 = getelementptr inbounds nuw i8, ptr %408, i64 52
  %410 = load i32, ptr %409, align 4, !tbaa !306
  switch i32 %410, label %415 [
    i32 74, label %411
    i32 0, label %411
  ]

411:                                              ; preds = %407, %407
  %412 = getelementptr inbounds nuw i8, ptr %408, i64 8
  %413 = load ptr, ptr %412, align 8, !tbaa !75
  %414 = icmp eq ptr %413, %405
  br i1 %414, label %415, label %407, !llvm.loop !307

415:                                              ; preds = %411, %407
  %416 = phi ptr [ %405, %411 ], [ %408, %407 ]
  %417 = icmp eq ptr %404, %416
  br i1 %417, label %487, label %418

418:                                              ; preds = %415, %461
  %419 = phi ptr [ %464, %461 ], [ %404, %415 ]
  %420 = getelementptr inbounds nuw i8, ptr %419, i64 40
  %421 = load i24, ptr %420, align 8
  %422 = icmp eq i24 %421, 1
  br i1 %422, label %444, label %423

423:                                              ; preds = %418
  %424 = zext i24 %421 to i32
  %425 = getelementptr inbounds nuw i8, ptr %419, i64 32
  %426 = add nsw i32 %424, -3
  %427 = icmp ult i32 %426, 2
  br i1 %427, label %434, label %428

428:                                              ; preds = %423
  %429 = lshr i32 %426, 1
  %430 = add nuw i32 %429, 1
  %431 = and i32 %430, -2
  br label %466

432:                                              ; preds = %483
  %433 = zext i32 %484 to i64
  br label %434

434:                                              ; preds = %432, %423
  %435 = phi i64 [ 2, %423 ], [ %433, %432 ]
  %436 = and i32 %426, 2
  %437 = icmp eq i32 %436, 0
  br i1 %437, label %438, label %444

438:                                              ; preds = %434
  %439 = load ptr, ptr %425, align 8, !tbaa !571
  %440 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %439, i64 %435, i32 3
  %441 = load ptr, ptr %440, align 8, !tbaa !212
  %442 = icmp eq ptr %441, %0
  br i1 %442, label %443, label %444

443:                                              ; preds = %438
  store ptr %31, ptr %440, align 8, !tbaa !212
  br label %444

444:                                              ; preds = %434, %443, %438, %418
  %445 = load i64, ptr %419, align 8
  %446 = and i64 %445, 4
  %447 = icmp eq i64 %446, 0
  br i1 %447, label %448, label %461

448:                                              ; preds = %444
  %449 = getelementptr inbounds nuw i8, ptr %419, i64 44
  %450 = load i32, ptr %449, align 4, !tbaa !309
  %451 = and i32 %450, 8
  %452 = icmp eq i32 %451, 0
  br i1 %452, label %461, label %453

453:                                              ; preds = %448, %453
  %454 = phi ptr [ %456, %453 ], [ %419, %448 ]
  %455 = getelementptr inbounds nuw i8, ptr %454, i64 8
  %456 = load ptr, ptr %455, align 8, !tbaa !75
  %457 = getelementptr inbounds nuw i8, ptr %456, i64 44
  %458 = load i32, ptr %457, align 4, !tbaa !309
  %459 = and i32 %458, 8
  %460 = icmp eq i32 %459, 0
  br i1 %460, label %461, label %453, !llvm.loop !310

461:                                              ; preds = %453, %448, %444
  %462 = phi ptr [ %419, %444 ], [ %419, %448 ], [ %456, %453 ]
  %463 = getelementptr inbounds nuw i8, ptr %462, i64 8
  %464 = load ptr, ptr %463, align 8, !tbaa !75
  %465 = icmp eq ptr %464, %416
  br i1 %465, label %487, label %418

466:                                              ; preds = %483, %428
  %467 = phi i32 [ 2, %428 ], [ %484, %483 ]
  %468 = phi i32 [ 0, %428 ], [ %485, %483 ]
  %469 = load ptr, ptr %425, align 8, !tbaa !571
  %470 = zext i32 %467 to i64
  %471 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %469, i64 %470, i32 3
  %472 = load ptr, ptr %471, align 8, !tbaa !212
  %473 = icmp eq ptr %472, %0
  br i1 %473, label %474, label %475

474:                                              ; preds = %466
  store ptr %31, ptr %471, align 8, !tbaa !212
  br label %475

475:                                              ; preds = %474, %466
  %476 = add i32 %467, 2
  %477 = load ptr, ptr %425, align 8, !tbaa !571
  %478 = zext i32 %476 to i64
  %479 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %477, i64 %478, i32 3
  %480 = load ptr, ptr %479, align 8, !tbaa !212
  %481 = icmp eq ptr %480, %0
  br i1 %481, label %482, label %483

482:                                              ; preds = %475
  store ptr %31, ptr %479, align 8, !tbaa !212
  br label %483

483:                                              ; preds = %482, %475
  %484 = add i32 %467, 4
  %485 = add i32 %468, 2
  %486 = icmp eq i32 %485, %431
  br i1 %486, label %432, label %466, !llvm.loop !677

487:                                              ; preds = %461, %402, %415
  %488 = getelementptr inbounds nuw i8, ptr %1, i64 184
  %489 = load ptr, ptr %488, align 8, !tbaa !379
  %490 = getelementptr inbounds nuw i8, ptr %1, i64 192
  %491 = load ptr, ptr %490, align 8, !tbaa !379
  %492 = icmp eq ptr %489, %491
  br i1 %492, label %498, label %493

493:                                              ; preds = %487
  %494 = getelementptr inbounds nuw i8, ptr %31, i64 184
  %495 = getelementptr inbounds nuw i8, ptr %31, i64 192
  %496 = getelementptr inbounds nuw i8, ptr %31, i64 200
  %497 = load ptr, ptr %495, align 8, !tbaa !527
  br label %510

498:                                              ; preds = %548, %487
  %499 = getelementptr inbounds nuw i8, ptr %25, i64 16
  %500 = load ptr, ptr %499, align 8, !tbaa !308, !nonnull !17, !align !200
  %501 = load ptr, ptr %500, align 8, !tbaa !4
  %502 = getelementptr inbounds nuw i8, ptr %501, i64 192
  %503 = load ptr, ptr %502, align 8
  %504 = call noundef ptr %503(ptr noundef nonnull align 8 dereferenceable(368) %500) #33
  br i1 %75, label %612, label %505

505:                                              ; preds = %498
  %506 = load i32, ptr %73, align 8, !tbaa !76
  %507 = icmp eq i32 %506, 0
  br i1 %507, label %608, label %508

508:                                              ; preds = %505
  %509 = getelementptr inbounds nuw i8, ptr %0, i64 56
  br label %552

510:                                              ; preds = %493, %548
  %511 = phi ptr [ %497, %493 ], [ %549, %548 ]
  %512 = phi ptr [ %489, %493 ], [ %550, %548 ]
  %513 = load ptr, ptr %496, align 8, !tbaa !84
  %514 = icmp eq ptr %511, %513
  br i1 %514, label %518, label %515

515:                                              ; preds = %510
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %511, ptr noundef nonnull align 8 dereferenceable(16) %512, i64 16, i1 false), !tbaa.struct !526
  %516 = load ptr, ptr %495, align 8, !tbaa !527
  %517 = getelementptr inbounds nuw i8, ptr %516, i64 16
  store ptr %517, ptr %495, align 8, !tbaa !527
  br label %548

518:                                              ; preds = %510
  %519 = load ptr, ptr %494, align 8, !tbaa !85
  %520 = ptrtoint ptr %511 to i64
  %521 = ptrtoint ptr %519 to i64
  %522 = sub i64 %520, %521
  %523 = ashr exact i64 %522, 4
  %524 = icmp sgt i64 %523, -1
  call void @llvm.assume(i1 %524)
  %525 = icmp eq i64 %522, 9223372036854775792
  br i1 %525, label %526, label %527

526:                                              ; preds = %518
  call void @_ZSt20__throw_length_errorPKc(ptr noundef nonnull @.str.42) #35
  unreachable

527:                                              ; preds = %518
  %528 = call i64 @llvm.umax.i64(i64 %523, i64 1)
  %529 = add nuw nsw i64 %528, %523
  %530 = call noundef i64 @llvm.umin.i64(i64 %529, i64 576460752303423487)
  %531 = shl nuw nsw i64 %530, 4
  %532 = call noalias noundef nonnull ptr @_Znwm(i64 noundef %531) #36
  %533 = getelementptr inbounds nuw i8, ptr %532, i64 %522
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %533, ptr noundef nonnull align 8 dereferenceable(16) %512, i64 16, i1 false), !tbaa.struct !526
  %534 = icmp eq ptr %519, %511
  br i1 %534, label %541, label %535

535:                                              ; preds = %527, %535
  %536 = phi ptr [ %539, %535 ], [ %532, %527 ]
  %537 = phi ptr [ %538, %535 ], [ %519, %527 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %536, ptr noundef nonnull align 8 dereferenceable(16) %537, i64 16, i1 false), !tbaa.struct !526, !alias.scope !791
  %538 = getelementptr inbounds nuw i8, ptr %537, i64 16
  %539 = getelementptr inbounds nuw i8, ptr %536, i64 16
  %540 = icmp eq ptr %538, %511
  br i1 %540, label %541, label %535, !llvm.loop !584

541:                                              ; preds = %535, %527
  %542 = phi ptr [ %532, %527 ], [ %539, %535 ]
  %543 = icmp eq ptr %519, null
  br i1 %543, label %545, label %544

544:                                              ; preds = %541
  call void @_ZdlPvm(ptr noundef nonnull %519, i64 noundef %522) #34
  br label %545

545:                                              ; preds = %544, %541
  %546 = getelementptr inbounds nuw i8, ptr %542, i64 16
  store ptr %532, ptr %494, align 8, !tbaa !85
  store ptr %546, ptr %495, align 8, !tbaa !527
  %547 = getelementptr inbounds nuw %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %532, i64 %530
  store ptr %547, ptr %496, align 8, !tbaa !84
  br label %548

548:                                              ; preds = %515, %545
  %549 = phi ptr [ %517, %515 ], [ %546, %545 ]
  %550 = getelementptr inbounds nuw i8, ptr %512, i64 16
  %551 = icmp eq ptr %550, %491
  br i1 %551, label %498, label %510

552:                                              ; preds = %508, %605
  %553 = phi i32 [ %506, %508 ], [ %606, %605 ]
  %554 = load ptr, ptr %6, align 8, !tbaa !19
  %555 = zext i32 %553 to i64
  %556 = getelementptr inbounds nuw %"class.llvm::Register", ptr %554, i64 %555
  %557 = getelementptr inbounds i8, ptr %556, i64 -4
  %558 = load i32, ptr %557, align 4, !tbaa !451
  %559 = add i32 %553, -1
  store i32 %559, ptr %73, align 8, !tbaa !76
  %560 = load ptr, ptr %509, align 8, !tbaa !75
  br label %561

561:                                              ; preds = %564, %552
  %562 = phi ptr [ %36, %552 ], [ %567, %564 ]
  %563 = icmp eq ptr %562, %560
  br i1 %563, label %605, label %564

564:                                              ; preds = %561
  %565 = load i64, ptr %562, align 8
  %566 = and i64 %565, -8
  %567 = inttoptr i64 %566 to ptr
  %568 = call noundef zeroext i1 @_ZN4llvm12MachineInstr17addRegisterKilledENS_8RegisterEPKNS_18TargetRegisterInfoEb(ptr noundef nonnull align 8 dereferenceable(80) %567, i32 %558, ptr noundef %504, i1 noundef zeroext false) #33
  br i1 %568, label %569, label %561, !llvm.loop !795

569:                                              ; preds = %564
  %570 = icmp slt i32 %558, 0
  br i1 %570, label %571, label %605

571:                                              ; preds = %569
  %572 = call noundef nonnull align 8 dereferenceable(56) ptr @_ZN4llvm13LiveVariables10getVarInfoENS_8RegisterE(ptr noundef nonnull align 8 dereferenceable(200) %71, i32 %558) #33
  %573 = getelementptr inbounds nuw i8, ptr %572, i64 32
  %574 = getelementptr inbounds nuw i8, ptr %572, i64 40
  %575 = load ptr, ptr %574, align 8, !tbaa !765
  %576 = getelementptr inbounds nuw i8, ptr %572, i64 48
  %577 = load ptr, ptr %576, align 8, !tbaa !796
  %578 = icmp eq ptr %575, %577
  br i1 %578, label %581, label %579

579:                                              ; preds = %571
  store ptr %567, ptr %575, align 8, !tbaa !481
  %580 = getelementptr inbounds nuw i8, ptr %575, i64 8
  store ptr %580, ptr %574, align 8, !tbaa !765
  br label %605

581:                                              ; preds = %571
  %582 = load ptr, ptr %573, align 8, !tbaa !797
  %583 = ptrtoint ptr %575 to i64
  %584 = ptrtoint ptr %582 to i64
  %585 = sub i64 %583, %584
  %586 = ashr exact i64 %585, 3
  %587 = icmp sgt i64 %586, -1
  call void @llvm.assume(i1 %587)
  %588 = icmp eq i64 %585, 9223372036854775800
  br i1 %588, label %589, label %590

589:                                              ; preds = %581
  call void @_ZSt20__throw_length_errorPKc(ptr noundef nonnull @.str.42) #35
  unreachable

590:                                              ; preds = %581
  %591 = call i64 @llvm.umax.i64(i64 %586, i64 1)
  %592 = add nuw nsw i64 %591, %586
  %593 = call noundef i64 @llvm.umin.i64(i64 %592, i64 1152921504606846975)
  %594 = shl nuw nsw i64 %593, 3
  %595 = call noalias noundef nonnull ptr @_Znwm(i64 noundef %594) #36
  %596 = getelementptr inbounds i8, ptr %595, i64 %585
  store ptr %567, ptr %596, align 8, !tbaa !481
  %597 = icmp sgt i64 %585, 0
  br i1 %597, label %598, label %599

598:                                              ; preds = %590
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %595, ptr align 8 %582, i64 %585, i1 false)
  br label %599

599:                                              ; preds = %598, %590
  %600 = icmp eq ptr %582, null
  br i1 %600, label %602, label %601

601:                                              ; preds = %599
  call void @_ZdlPvm(ptr noundef nonnull %582, i64 noundef %585) #34
  br label %602

602:                                              ; preds = %601, %599
  %603 = getelementptr inbounds nuw i8, ptr %596, i64 8
  store ptr %595, ptr %573, align 8, !tbaa !797
  store ptr %603, ptr %574, align 8, !tbaa !765
  %604 = getelementptr inbounds nuw ptr, ptr %595, i64 %593
  store ptr %604, ptr %576, align 8, !tbaa !796
  br label %605

605:                                              ; preds = %561, %602, %579, %569
  %606 = load i32, ptr %73, align 8, !tbaa !76
  %607 = icmp eq i32 %606, 0
  br i1 %607, label %608, label %552, !llvm.loop !798

608:                                              ; preds = %605, %505
  %609 = icmp eq ptr %3, null
  br i1 %609, label %611, label %610

610:                                              ; preds = %608
  call void @_ZN4llvm13LiveVariables11addNewBlockEPNS_17MachineBasicBlockES2_S2_RSt6vectorINS_15SparseBitVectorILj128EEESaIS5_EE(ptr noundef nonnull align 8 dereferenceable(200) %71, ptr noundef nonnull %31, ptr noundef nonnull %0, ptr noundef nonnull %1, ptr noundef nonnull align 1 %3) #33
  br label %612

611:                                              ; preds = %608
  call void @_ZN4llvm13LiveVariables11addNewBlockEPNS_17MachineBasicBlockES2_S2_(ptr noundef nonnull align 8 dereferenceable(200) %71, ptr noundef nonnull %31, ptr noundef nonnull %0, ptr noundef nonnull %1) #33
  br label %612

612:                                              ; preds = %610, %611, %498
  br i1 %62, label %1067, label %613

613:                                              ; preds = %612
  %614 = load ptr, ptr %59, align 8, !tbaa !327
  %615 = load ptr, ptr %24, align 8, !tbaa !74
  %616 = getelementptr inbounds nuw i8, ptr %615, i64 296
  %617 = icmp eq ptr %614, %616
  %618 = getelementptr inbounds nuw i8, ptr %278, i64 128
  %619 = getelementptr inbounds nuw i8, ptr %0, i64 220
  %620 = load i32, ptr %619, align 4, !tbaa !292
  %621 = sext i32 %620 to i64
  %622 = load ptr, ptr %618, align 8, !tbaa !19
  %623 = getelementptr inbounds nuw %"struct.std::pair.781", ptr %622, i64 %621, i32 1
  %624 = load i64, ptr %623, align 8, !tbaa !212
  %625 = trunc i64 %624 to i32
  %626 = lshr i32 %625, 1
  %627 = and i32 %626, 3
  %628 = icmp eq i32 %627, 0
  %629 = and i64 %624, -8
  br i1 %628, label %630, label %635

630:                                              ; preds = %613
  %631 = inttoptr i64 %629 to ptr
  %632 = load ptr, ptr %631, align 8, !tbaa !595
  %633 = ptrtoint ptr %632 to i64
  %634 = or i64 %633, 6
  br label %640

635:                                              ; preds = %613
  %636 = add nsw i32 %627, -1
  %637 = zext nneg i32 %636 to i64
  %638 = shl nuw nsw i64 %637, 1
  %639 = or i64 %638, %629
  br label %640

640:                                              ; preds = %630, %635
  %641 = phi i64 [ %634, %630 ], [ %639, %635 ]
  %642 = getelementptr inbounds nuw i8, ptr %31, i64 220
  %643 = load i32, ptr %642, align 4, !tbaa !292
  %644 = sext i32 %643 to i64
  %645 = getelementptr inbounds nuw %"struct.std::pair.781", ptr %622, i64 %644, i32 1
  %646 = load i64, ptr %645, align 8, !tbaa !212
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %13) #33
  %647 = getelementptr inbounds nuw i8, ptr %13, i64 16
  store ptr %647, ptr %13, align 8, !tbaa !19
  %648 = getelementptr inbounds nuw i8, ptr %13, i64 8
  store i32 0, ptr %648, align 8, !tbaa !76
  %649 = getelementptr inbounds nuw i8, ptr %13, i64 12
  store i32 8, ptr %649, align 4, !tbaa !77
  %650 = getelementptr inbounds nuw i8, ptr %13, i64 56
  store i32 0, ptr %650, align 8, !tbaa !799
  %651 = getelementptr inbounds nuw i8, ptr %13, i64 64
  store ptr null, ptr %651, align 8, !tbaa !804
  %652 = getelementptr inbounds nuw i8, ptr %13, i64 72
  store ptr %650, ptr %652, align 8, !tbaa !805
  %653 = getelementptr inbounds nuw i8, ptr %13, i64 80
  store ptr %650, ptr %653, align 8, !tbaa !806
  %654 = getelementptr inbounds nuw i8, ptr %13, i64 88
  store i64 0, ptr %654, align 8, !tbaa !807
  %655 = load ptr, ptr %403, align 8, !tbaa !75
  %656 = icmp eq ptr %655, %405
  br i1 %656, label %678, label %657

657:                                              ; preds = %640
  %658 = getelementptr inbounds nuw i8, ptr %61, i64 144
  %659 = getelementptr inbounds nuw i8, ptr %61, i64 136
  %660 = getelementptr inbounds nuw i8, ptr %61, i64 152
  %661 = getelementptr inbounds nuw i8, ptr %61, i64 148
  %662 = and i64 %641, -8
  %663 = inttoptr i64 %662 to ptr
  %664 = getelementptr inbounds nuw i8, ptr %663, i64 24
  %665 = trunc i64 %641 to i32
  %666 = lshr i32 %665, 1
  %667 = and i32 %666, 3
  %668 = getelementptr inbounds nuw i8, ptr %16, i64 8
  %669 = getelementptr inbounds nuw i8, ptr %16, i64 16
  %670 = getelementptr inbounds nuw i8, ptr %17, i64 8
  %671 = getelementptr inbounds nuw i8, ptr %17, i64 16
  br label %672

672:                                              ; preds = %657, %707
  %673 = phi ptr [ %655, %657 ], [ %709, %707 ]
  %674 = getelementptr inbounds nuw i8, ptr %673, i64 52
  %675 = load i32, ptr %674, align 4, !tbaa !306
  switch i32 %675, label %676 [
    i32 74, label %700
    i32 0, label %700
  ]

676:                                              ; preds = %672, %707
  %677 = load ptr, ptr %24, align 8, !tbaa !74
  br label %678

678:                                              ; preds = %676, %640
  %679 = phi ptr [ %677, %676 ], [ %615, %640 ]
  %680 = getelementptr inbounds nuw i8, ptr %679, i64 32
  %681 = load ptr, ptr %680, align 8, !tbaa !293
  %682 = getelementptr inbounds nuw i8, ptr %681, i64 56
  %683 = load i32, ptr %682, align 8, !tbaa !76
  %684 = icmp eq i32 %683, 0
  br i1 %684, label %831, label %685

685:                                              ; preds = %678
  %686 = getelementptr inbounds nuw i8, ptr %61, i64 144
  %687 = getelementptr inbounds nuw i8, ptr %61, i64 136
  %688 = and i64 %641, -8
  %689 = inttoptr i64 %688 to ptr
  %690 = getelementptr inbounds nuw i8, ptr %689, i64 24
  %691 = trunc i64 %641 to i32
  %692 = lshr i32 %691, 1
  %693 = and i32 %692, 3
  %694 = getelementptr inbounds nuw i8, ptr %61, i64 32
  %695 = getelementptr inbounds nuw i8, ptr %1, i64 220
  %696 = getelementptr inbounds nuw i8, ptr %18, i64 8
  %697 = getelementptr inbounds nuw i8, ptr %18, i64 16
  %698 = getelementptr inbounds nuw i8, ptr %19, i64 8
  %699 = getelementptr inbounds nuw i8, ptr %19, i64 16
  br label %844

700:                                              ; preds = %672, %672
  %701 = getelementptr inbounds nuw i8, ptr %673, i64 40
  %702 = load i24, ptr %701, align 8
  %703 = zext i24 %702 to i32
  %704 = icmp eq i24 %702, 1
  br i1 %704, label %707, label %705

705:                                              ; preds = %700
  %706 = getelementptr inbounds nuw i8, ptr %673, i64 32
  br label %711

707:                                              ; preds = %828, %700
  %708 = getelementptr inbounds nuw i8, ptr %673, i64 8
  %709 = load ptr, ptr %708, align 8, !tbaa !75
  %710 = icmp eq ptr %709, %405
  br i1 %710, label %676, label %672, !llvm.loop !808

711:                                              ; preds = %705, %828
  %712 = phi i32 [ 1, %705 ], [ %829, %828 ]
  %713 = add i32 %712, 1
  %714 = load ptr, ptr %706, align 8, !tbaa !571
  %715 = zext i32 %713 to i64
  %716 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %714, i64 %715, i32 3
  %717 = load ptr, ptr %716, align 8, !tbaa !212
  %718 = icmp eq ptr %717, %31
  br i1 %718, label %719, label %828

719:                                              ; preds = %711
  %720 = zext i32 %712 to i64
  %721 = getelementptr inbounds nuw %"class.llvm::MachineOperand", ptr %714, i64 %720
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %14) #33
  %722 = getelementptr inbounds nuw i8, ptr %721, i64 4
  %723 = load i32, ptr %722, align 4, !tbaa !212
  store i32 %723, ptr %14, align 4
  call void @_ZN4llvm8SmallSetINS_8RegisterELj8ESt4lessIS1_EE10insertImplIRKS1_EESt4pairINS_16SmallSetIteratorIS1_Lj8ES3_EEbEOT_(ptr dead_on_unwind nonnull writable sret(%"struct.std::pair.538") align 8 %15, ptr noundef nonnull align 8 dereferenceable(96) %13, ptr noundef nonnull align 4 dereferenceable(4) %14)
  %724 = load i32, ptr %721, align 8
  %725 = and i32 %724, 268435456
  %726 = icmp eq i32 %725, 0
  br i1 %726, label %727, label %827

727:                                              ; preds = %719
  %728 = load i32, ptr %14, align 4, !tbaa !451
  %729 = and i32 %728, 2147483647
  %730 = load i32, ptr %658, align 8, !tbaa !76
  %731 = icmp ugt i32 %730, %729
  br i1 %731, label %732, label %738

732:                                              ; preds = %727
  %733 = zext nneg i32 %729 to i64
  %734 = load ptr, ptr %659, align 8, !tbaa !19
  %735 = getelementptr inbounds nuw ptr, ptr %734, i64 %733
  %736 = load ptr, ptr %735, align 8, !tbaa !809
  %737 = icmp eq ptr %736, null
  br i1 %737, label %784, label %790

738:                                              ; preds = %727
  %739 = add nuw i32 %729, 1
  %740 = zext i32 %739 to i64
  %741 = zext nneg i32 %730 to i64
  %742 = load ptr, ptr %660, align 8, !tbaa !811
  %743 = sub nsw i64 %740, %741
  %744 = load i32, ptr %661, align 4, !tbaa !77
  %745 = icmp ult i32 %729, %744
  br i1 %745, label %749, label %746, !prof !483

746:                                              ; preds = %738
  call void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(25) %659, ptr noundef nonnull %660, i64 noundef %740, i64 noundef 8) #33
  %747 = load i32, ptr %658, align 8, !tbaa !76
  %748 = zext i32 %747 to i64
  br label %749

749:                                              ; preds = %746, %738
  %750 = phi i64 [ %741, %738 ], [ %748, %746 ]
  %751 = phi i32 [ %730, %738 ], [ %747, %746 ]
  %752 = load ptr, ptr %659, align 8, !tbaa !19
  %753 = getelementptr inbounds nuw ptr, ptr %752, i64 %750
  %754 = icmp ult i64 %743, 4
  br i1 %754, label %771, label %755

755:                                              ; preds = %749
  %756 = and i64 %743, -4
  %757 = and i64 %743, 3
  %758 = shl nsw i64 %756, 3
  %759 = getelementptr i8, ptr %753, i64 %758
  %760 = insertelement <2 x ptr> poison, ptr %742, i64 0
  %761 = shufflevector <2 x ptr> %760, <2 x ptr> poison, <2 x i32> zeroinitializer
  br label %762

762:                                              ; preds = %762, %755
  %763 = phi i64 [ 0, %755 ], [ %767, %762 ]
  %764 = shl i64 %763, 3
  %765 = getelementptr i8, ptr %753, i64 %764
  %766 = getelementptr i8, ptr %765, i64 16
  store <2 x ptr> %761, ptr %765, align 8, !tbaa !809
  store <2 x ptr> %761, ptr %766, align 8, !tbaa !809
  %767 = add nuw i64 %763, 4
  %768 = icmp eq i64 %767, %756
  br i1 %768, label %769, label %762, !llvm.loop !817

769:                                              ; preds = %762
  %770 = icmp eq i64 %743, %756
  br i1 %770, label %780, label %771

771:                                              ; preds = %749, %769
  %772 = phi i64 [ %743, %749 ], [ %757, %769 ]
  %773 = phi ptr [ %753, %749 ], [ %759, %769 ]
  br label %774

774:                                              ; preds = %771, %774
  %775 = phi i64 [ %777, %774 ], [ %772, %771 ]
  %776 = phi ptr [ %778, %774 ], [ %773, %771 ]
  %777 = add i64 %775, -1
  store ptr %742, ptr %776, align 8, !tbaa !809
  %778 = getelementptr inbounds nuw i8, ptr %776, i64 8
  %779 = icmp eq i64 %777, 0
  br i1 %779, label %780, label %774, !llvm.loop !818

780:                                              ; preds = %774, %769
  %781 = trunc nuw i64 %743 to i32
  %782 = add i32 %751, %781
  store i32 %782, ptr %658, align 8, !tbaa !76
  %783 = zext nneg i32 %729 to i64
  br label %784

784:                                              ; preds = %780, %732
  %785 = phi i64 [ %783, %780 ], [ %733, %732 ]
  %786 = phi ptr [ %752, %780 ], [ %734, %732 ]
  %787 = getelementptr inbounds nuw ptr, ptr %786, i64 %785
  %788 = call noundef nonnull align 8 dereferenceable(120) ptr @_ZN4llvm13LiveIntervals14createIntervalENS_8RegisterE(i32 %728) #33
  store ptr %788, ptr %787, align 8, !tbaa !809
  %789 = call noundef zeroext i1 @_ZN4llvm13LiveIntervals22computeVirtRegIntervalERNS_12LiveIntervalE(ptr noundef nonnull align 8 dereferenceable(424) %61, ptr noundef nonnull align 8 dereferenceable(120) %788) #33
  br label %790

790:                                              ; preds = %732, %784
  %791 = phi ptr [ %788, %784 ], [ %736, %732 ]
  %792 = call noundef ptr @_ZN4llvm9LiveRange4findENS_9SlotIndexE(ptr noundef nonnull align 8 dereferenceable(104) %791, i64 %641) #33
  %793 = load ptr, ptr %791, align 8, !tbaa !19
  %794 = getelementptr inbounds nuw i8, ptr %791, i64 8
  %795 = load i32, ptr %794, align 8, !tbaa !76
  %796 = zext i32 %795 to i64
  %797 = getelementptr inbounds nuw %"struct.llvm::LiveRange::Segment", ptr %793, i64 %796
  %798 = icmp eq ptr %792, %797
  br i1 %798, label %815, label %799

799:                                              ; preds = %790
  %800 = load i64, ptr %792, align 8
  %801 = and i64 %800, -8
  %802 = inttoptr i64 %801 to ptr
  %803 = getelementptr inbounds nuw i8, ptr %802, i64 24
  %804 = load i32, ptr %803, align 8, !tbaa !819
  %805 = trunc i64 %800 to i32
  %806 = lshr i32 %805, 1
  %807 = and i32 %806, 3
  %808 = or i32 %807, %804
  %809 = load i32, ptr %664, align 8, !tbaa !819
  %810 = or i32 %809, %667
  %811 = icmp ugt i32 %808, %810
  br i1 %811, label %815, label %812

812:                                              ; preds = %799
  %813 = getelementptr inbounds nuw i8, ptr %792, i64 16
  %814 = load ptr, ptr %813, align 8, !tbaa !823
  br label %815

815:                                              ; preds = %790, %799, %812
  %816 = phi ptr [ %814, %812 ], [ null, %790 ], [ null, %799 ]
  store i64 %624, ptr %16, align 8, !tbaa !212
  store i64 %646, ptr %668, align 8, !tbaa !212
  store ptr %816, ptr %669, align 8, !tbaa !823
  %817 = call noundef ptr @_ZN4llvm9LiveRange10addSegmentENS0_7SegmentE(ptr noundef nonnull align 8 dereferenceable(104) %791, ptr noundef nonnull byval(%"struct.llvm::LiveRange::Segment") align 8 %16) #33
  %818 = getelementptr inbounds nuw i8, ptr %791, i64 104
  %819 = load ptr, ptr %818, align 8, !tbaa !829
  %820 = icmp eq ptr %819, null
  br i1 %820, label %827, label %821

821:                                              ; preds = %815, %821
  %822 = phi ptr [ %825, %821 ], [ %819, %815 ]
  store i64 %624, ptr %17, align 8, !tbaa !212
  store i64 %646, ptr %670, align 8, !tbaa !212
  store ptr %816, ptr %671, align 8, !tbaa !823
  %823 = call noundef ptr @_ZN4llvm9LiveRange10addSegmentENS0_7SegmentE(ptr noundef nonnull align 8 dereferenceable(104) %822, ptr noundef nonnull byval(%"struct.llvm::LiveRange::Segment") align 8 %17) #33
  %824 = getelementptr inbounds nuw i8, ptr %822, i64 104
  %825 = load ptr, ptr %824, align 8, !tbaa !829
  %826 = icmp eq ptr %825, null
  br i1 %826, label %827, label %821

827:                                              ; preds = %821, %815, %719
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %14) #33
  br label %828

828:                                              ; preds = %827, %711
  %829 = add i32 %712, 2
  %830 = icmp eq i32 %829, %703
  br i1 %830, label %707, label %711, !llvm.loop !831

831:                                              ; preds = %1026, %678
  %832 = call ptr @_ZN4llvm17MachineBasicBlock18getFirstTerminatorEv(ptr noundef nonnull align 8 dereferenceable(288) %0)
  %833 = load ptr, ptr %7, align 8, !tbaa !19
  %834 = load i32, ptr %202, align 8, !tbaa !76
  %835 = zext i32 %834 to i64
  call void @_ZN4llvm13LiveIntervals22repairIntervalsInRangeEPNS_17MachineBasicBlockENS_26MachineInstrBundleIteratorINS_12MachineInstrELb0EEES5_NS_8ArrayRefINS_8RegisterEEE(ptr noundef nonnull align 8 dereferenceable(424) %61, ptr noundef nonnull %0, ptr %832, ptr nonnull %36, ptr %833, i64 %835) #33
  %836 = load ptr, ptr %7, align 8, !tbaa !19
  %837 = load i32, ptr %202, align 8, !tbaa !76
  %838 = zext i32 %837 to i64
  %839 = shl nuw nsw i64 %838, 2
  %840 = getelementptr inbounds nuw i8, ptr %836, i64 %839
  %841 = icmp eq i32 %837, 0
  br i1 %841, label %1029, label %842

842:                                              ; preds = %831
  %843 = getelementptr inbounds nuw i8, ptr %61, i64 16
  br label %1036

844:                                              ; preds = %685, %1026
  %845 = phi i32 [ 0, %685 ], [ %1027, %1026 ]
  %846 = or i32 %845, -2147483648
  %847 = load i64, ptr %654, align 8, !tbaa !807
  %848 = icmp eq i64 %847, 0
  br i1 %848, label %849, label %867

849:                                              ; preds = %844
  %850 = load ptr, ptr %13, align 8, !tbaa !19
  %851 = load i32, ptr %648, align 8, !tbaa !76
  %852 = zext i32 %851 to i64
  %853 = shl nuw nsw i64 %852, 2
  %854 = getelementptr inbounds nuw i8, ptr %850, i64 %853
  %855 = icmp eq i32 %851, 0
  br i1 %855, label %863, label %856

856:                                              ; preds = %849, %860
  %857 = phi ptr [ %861, %860 ], [ %850, %849 ]
  %858 = load i32, ptr %857, align 4, !tbaa !767
  %859 = icmp eq i32 %858, %846
  br i1 %859, label %863, label %860

860:                                              ; preds = %856
  %861 = getelementptr inbounds nuw i8, ptr %857, i64 4
  %862 = icmp eq ptr %861, %854
  br i1 %862, label %863, label %856, !llvm.loop !832

863:                                              ; preds = %860, %856, %849
  %864 = phi ptr [ %854, %849 ], [ %857, %856 ], [ %854, %860 ]
  %865 = getelementptr inbounds nuw %"class.llvm::Register", ptr %850, i64 %852
  %866 = icmp eq ptr %864, %865
  br i1 %866, label %888, label %1026

867:                                              ; preds = %844
  %868 = load ptr, ptr %651, align 8, !tbaa !804
  %869 = icmp eq ptr %868, null
  br i1 %869, label %888, label %870

870:                                              ; preds = %867, %870
  %871 = phi ptr [ %879, %870 ], [ %868, %867 ]
  %872 = phi ptr [ %876, %870 ], [ %650, %867 ]
  %873 = getelementptr inbounds nuw i8, ptr %871, i64 32
  %874 = load i32, ptr %873, align 4, !tbaa !767
  %875 = icmp ult i32 %874, %846
  %876 = select i1 %875, ptr %872, ptr %871
  %877 = select i1 %875, i64 24, i64 16
  %878 = getelementptr inbounds nuw i8, ptr %871, i64 %877
  %879 = load ptr, ptr %878, align 8, !tbaa !833
  %880 = icmp eq ptr %879, null
  br i1 %880, label %881, label %870, !llvm.loop !834

881:                                              ; preds = %870
  %882 = icmp eq ptr %876, %650
  br i1 %882, label %888, label %883

883:                                              ; preds = %881
  %884 = select i1 %875, ptr %872, ptr %871
  %885 = getelementptr inbounds nuw i8, ptr %884, i64 32
  %886 = load i32, ptr %885, align 4, !tbaa !767
  %887 = icmp ult i32 %846, %886
  br i1 %887, label %888, label %1026

888:                                              ; preds = %867, %881, %863, %883
  %889 = and i32 %845, 2147483647
  %890 = load i32, ptr %686, align 8, !tbaa !76
  %891 = icmp ugt i32 %890, %889
  br i1 %891, label %892, label %1026

892:                                              ; preds = %888
  %893 = zext nneg i32 %889 to i64
  %894 = load ptr, ptr %687, align 8, !tbaa !19
  %895 = getelementptr inbounds nuw ptr, ptr %894, i64 %893
  %896 = load ptr, ptr %895, align 8, !tbaa !809
  %897 = icmp eq ptr %896, null
  br i1 %897, label %1026, label %898

898:                                              ; preds = %892
  %899 = call noundef ptr @_ZN4llvm9LiveRange4findENS_9SlotIndexE(ptr noundef nonnull align 8 dereferenceable(104) %896, i64 %641) #33
  %900 = load ptr, ptr %896, align 8, !tbaa !19
  %901 = getelementptr inbounds nuw i8, ptr %896, i64 8
  %902 = load i32, ptr %901, align 8, !tbaa !76
  %903 = zext i32 %902 to i64
  %904 = getelementptr inbounds nuw %"struct.llvm::LiveRange::Segment", ptr %900, i64 %903
  %905 = icmp eq ptr %899, %904
  br i1 %905, label %1026, label %906

906:                                              ; preds = %898
  %907 = load i64, ptr %899, align 8
  %908 = and i64 %907, -8
  %909 = inttoptr i64 %908 to ptr
  %910 = getelementptr inbounds nuw i8, ptr %909, i64 24
  %911 = load i32, ptr %910, align 8, !tbaa !819
  %912 = trunc i64 %907 to i32
  %913 = lshr i32 %912, 1
  %914 = and i32 %913, 3
  %915 = or i32 %914, %911
  %916 = load i32, ptr %690, align 8, !tbaa !819
  %917 = or i32 %916, %693
  %918 = icmp ugt i32 %915, %917
  br i1 %918, label %1026, label %919

919:                                              ; preds = %906
  %920 = load ptr, ptr %694, align 8, !tbaa !835
  %921 = getelementptr inbounds nuw i8, ptr %920, i64 128
  %922 = load i32, ptr %695, align 4, !tbaa !292
  %923 = sext i32 %922 to i64
  %924 = load ptr, ptr %921, align 8, !tbaa !19
  %925 = getelementptr inbounds nuw %"struct.std::pair.781", ptr %924, i64 %923
  %926 = load i64, ptr %925, align 8, !tbaa !212
  %927 = call noundef ptr @_ZN4llvm9LiveRange4findENS_9SlotIndexE(ptr noundef nonnull align 8 dereferenceable(104) %896, i64 %926) #33
  %928 = load ptr, ptr %896, align 8, !tbaa !19
  %929 = load i32, ptr %901, align 8, !tbaa !76
  %930 = zext i32 %929 to i64
  %931 = getelementptr inbounds nuw %"struct.llvm::LiveRange::Segment", ptr %928, i64 %930
  %932 = icmp eq ptr %927, %931
  br i1 %932, label %1014, label %933

933:                                              ; preds = %919
  %934 = load i64, ptr %927, align 8
  %935 = and i64 %934, -8
  %936 = inttoptr i64 %935 to ptr
  %937 = getelementptr inbounds nuw i8, ptr %936, i64 24
  %938 = load i32, ptr %937, align 8, !tbaa !819
  %939 = trunc i64 %934 to i32
  %940 = lshr i32 %939, 1
  %941 = and i32 %940, 3
  %942 = or i32 %941, %938
  %943 = and i64 %926, -8
  %944 = inttoptr i64 %943 to ptr
  %945 = getelementptr inbounds nuw i8, ptr %944, i64 24
  %946 = load i32, ptr %945, align 8, !tbaa !819
  %947 = trunc i64 %926 to i32
  %948 = lshr i32 %947, 1
  %949 = and i32 %948, 3
  %950 = or i32 %946, %949
  %951 = icmp ule i32 %942, %950
  %952 = and i1 %617, %951
  br i1 %952, label %953, label %1014

953:                                              ; preds = %933
  %954 = call noundef ptr @_ZN4llvm9LiveRange4findENS_9SlotIndexE(ptr noundef nonnull align 8 dereferenceable(104) %896, i64 %641) #33
  %955 = load ptr, ptr %896, align 8, !tbaa !19
  %956 = load i32, ptr %901, align 8, !tbaa !76
  %957 = zext i32 %956 to i64
  %958 = getelementptr inbounds nuw %"struct.llvm::LiveRange::Segment", ptr %955, i64 %957
  %959 = icmp eq ptr %954, %958
  br i1 %959, label %976, label %960

960:                                              ; preds = %953
  %961 = load i64, ptr %954, align 8
  %962 = and i64 %961, -8
  %963 = inttoptr i64 %962 to ptr
  %964 = getelementptr inbounds nuw i8, ptr %963, i64 24
  %965 = load i32, ptr %964, align 8, !tbaa !819
  %966 = trunc i64 %961 to i32
  %967 = lshr i32 %966, 1
  %968 = and i32 %967, 3
  %969 = or i32 %968, %965
  %970 = load i32, ptr %690, align 8, !tbaa !819
  %971 = or i32 %970, %693
  %972 = icmp ugt i32 %969, %971
  br i1 %972, label %976, label %973

973:                                              ; preds = %960
  %974 = getelementptr inbounds nuw i8, ptr %954, i64 16
  %975 = load ptr, ptr %974, align 8, !tbaa !823
  br label %976

976:                                              ; preds = %953, %960, %973
  %977 = phi ptr [ %975, %973 ], [ null, %953 ], [ null, %960 ]
  store i64 %624, ptr %18, align 8, !tbaa !212
  store i64 %646, ptr %696, align 8, !tbaa !212
  store ptr %977, ptr %697, align 8, !tbaa !823
  %978 = call noundef ptr @_ZN4llvm9LiveRange10addSegmentENS0_7SegmentE(ptr noundef nonnull align 8 dereferenceable(104) %896, ptr noundef nonnull byval(%"struct.llvm::LiveRange::Segment") align 8 %18) #33
  %979 = getelementptr inbounds nuw i8, ptr %896, i64 104
  %980 = load ptr, ptr %979, align 8, !tbaa !829
  %981 = icmp eq ptr %980, null
  br i1 %981, label %1026, label %982

982:                                              ; preds = %976, %1010
  %983 = phi ptr [ %1012, %1010 ], [ %980, %976 ]
  %984 = call noundef ptr @_ZN4llvm9LiveRange4findENS_9SlotIndexE(ptr noundef nonnull align 8 dereferenceable(104) %983, i64 %641) #33
  %985 = load ptr, ptr %983, align 8, !tbaa !19
  %986 = getelementptr inbounds nuw i8, ptr %983, i64 8
  %987 = load i32, ptr %986, align 8, !tbaa !76
  %988 = zext i32 %987 to i64
  %989 = getelementptr inbounds nuw %"struct.llvm::LiveRange::Segment", ptr %985, i64 %988
  %990 = icmp eq ptr %984, %989
  br i1 %990, label %1010, label %991

991:                                              ; preds = %982
  %992 = load i64, ptr %984, align 8
  %993 = and i64 %992, -8
  %994 = inttoptr i64 %993 to ptr
  %995 = getelementptr inbounds nuw i8, ptr %994, i64 24
  %996 = load i32, ptr %995, align 8, !tbaa !819
  %997 = trunc i64 %992 to i32
  %998 = lshr i32 %997, 1
  %999 = and i32 %998, 3
  %1000 = or i32 %999, %996
  %1001 = load i32, ptr %690, align 8, !tbaa !819
  %1002 = or i32 %1001, %693
  %1003 = icmp ugt i32 %1000, %1002
  br i1 %1003, label %1010, label %1004

1004:                                             ; preds = %991
  %1005 = getelementptr inbounds nuw i8, ptr %984, i64 16
  %1006 = load ptr, ptr %1005, align 8, !tbaa !823
  %1007 = icmp eq ptr %1006, null
  br i1 %1007, label %1010, label %1008

1008:                                             ; preds = %1004
  store i64 %624, ptr %19, align 8, !tbaa !212
  store i64 %646, ptr %698, align 8, !tbaa !212
  store ptr %1006, ptr %699, align 8, !tbaa !823
  %1009 = call noundef ptr @_ZN4llvm9LiveRange10addSegmentENS0_7SegmentE(ptr noundef nonnull align 8 dereferenceable(104) %983, ptr noundef nonnull byval(%"struct.llvm::LiveRange::Segment") align 8 %19) #33
  br label %1010

1010:                                             ; preds = %991, %982, %1008, %1004
  %1011 = getelementptr inbounds nuw i8, ptr %983, i64 104
  %1012 = load ptr, ptr %1011, align 8, !tbaa !829
  %1013 = icmp eq ptr %1012, null
  br i1 %1013, label %1026, label %982

1014:                                             ; preds = %919, %933
  %1015 = phi i1 [ %951, %933 ], [ false, %919 ]
  %1016 = or i1 %617, %1015
  br i1 %1016, label %1026, label %1017

1017:                                             ; preds = %1014
  call void @_ZN4llvm9LiveRange13removeSegmentENS_9SlotIndexES1_b(ptr noundef nonnull align 8 dereferenceable(104) %896, i64 %624, i64 %646, i1 noundef zeroext false) #33
  %1018 = getelementptr inbounds nuw i8, ptr %896, i64 104
  %1019 = load ptr, ptr %1018, align 8, !tbaa !829
  %1020 = icmp eq ptr %1019, null
  br i1 %1020, label %1026, label %1021

1021:                                             ; preds = %1017, %1021
  %1022 = phi ptr [ %1024, %1021 ], [ %1019, %1017 ]
  call void @_ZN4llvm9LiveRange13removeSegmentENS_9SlotIndexES1_b(ptr noundef nonnull align 8 dereferenceable(104) %1022, i64 %624, i64 %646, i1 noundef zeroext false) #33
  %1023 = getelementptr inbounds nuw i8, ptr %1022, i64 104
  %1024 = load ptr, ptr %1023, align 8, !tbaa !829
  %1025 = icmp eq ptr %1024, null
  br i1 %1025, label %1026, label %1021

1026:                                             ; preds = %1010, %1021, %863, %976, %1017, %898, %888, %906, %1014, %883, %892
  %1027 = add nuw i32 %845, 1
  %1028 = icmp eq i32 %1027, %683
  br i1 %1028, label %831, label %844, !llvm.loop !865

1029:                                             ; preds = %1064, %831
  %1030 = getelementptr inbounds nuw i8, ptr %13, i64 48
  %1031 = load ptr, ptr %651, align 8, !tbaa !804
  call void @_ZNSt8_Rb_treeIN4llvm8RegisterES1_St9_IdentityIS1_ESt4lessIS1_ESaIS1_EE8_M_eraseEPSt13_Rb_tree_nodeIS1_E(ptr noundef nonnull align 8 dereferenceable(48) %1030, ptr noundef %1031)
  %1032 = load ptr, ptr %13, align 8, !tbaa !19
  %1033 = icmp eq ptr %1032, %647
  br i1 %1033, label %1035, label %1034

1034:                                             ; preds = %1029
  call void @free(ptr noundef %1032) #33
  br label %1035

1035:                                             ; preds = %1029, %1034
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %13) #33
  br label %1067

1036:                                             ; preds = %842, %1064
  %1037 = phi ptr [ %836, %842 ], [ %1065, %1064 ]
  %1038 = load i32, ptr %1037, align 4, !tbaa !451
  %1039 = add i32 %1038, -1
  %1040 = icmp ult i32 %1039, 1073741823
  br i1 %1040, label %1041, label %1064

1041:                                             ; preds = %1036
  %1042 = load ptr, ptr %843, align 8, !tbaa !866
  %1043 = getelementptr inbounds nuw i8, ptr %1042, i64 56
  %1044 = load ptr, ptr %1043, align 8, !tbaa !528, !noalias !867
  %1045 = icmp eq ptr %1044, null
  br i1 %1045, label %1064, label %1046

1046:                                             ; preds = %1041
  %1047 = getelementptr inbounds nuw i8, ptr %1042, i64 8
  %1048 = load ptr, ptr %1047, align 8, !tbaa !545, !noalias !867
  %1049 = zext nneg i32 %1038 to i64
  %1050 = getelementptr inbounds nuw %"struct.llvm::MCRegisterDesc", ptr %1048, i64 %1049, i32 4
  %1051 = load i32, ptr %1050, align 4, !tbaa !870, !noalias !867
  %1052 = lshr i32 %1051, 12
  %1053 = zext nneg i32 %1052 to i64
  %1054 = getelementptr inbounds nuw i16, ptr %1044, i64 %1053
  %1055 = and i32 %1051, 4095
  br label %1056

1056:                                             ; preds = %1056, %1046
  %1057 = phi ptr [ %1059, %1056 ], [ %1054, %1046 ]
  %1058 = phi i32 [ %1062, %1056 ], [ %1055, %1046 ]
  call void @_ZN4llvm13LiveIntervals13removeRegUnitENS_9MCRegUnitE(ptr noundef nonnull align 8 dereferenceable(424) %61, i32 noundef %1058)
  %1059 = getelementptr inbounds nuw i8, ptr %1057, i64 2
  %1060 = load i16, ptr %1057, align 2, !tbaa !552
  %1061 = sext i16 %1060 to i32
  %1062 = add i32 %1058, %1061
  %1063 = icmp eq i16 %1060, 0
  br i1 %1063, label %1064, label %1056

1064:                                             ; preds = %1056, %1041, %1036
  %1065 = getelementptr inbounds nuw i8, ptr %1037, i64 4
  %1066 = icmp eq ptr %1065, %840
  br i1 %1066, label %1029, label %1036

1067:                                             ; preds = %1035, %612
  %1068 = icmp eq ptr %4, null
  br i1 %1068, label %1070, label %1069

1069:                                             ; preds = %1067
  call void @_ZN4llvm21GenericDomTreeUpdaterINS_21MachineDomTreeUpdaterENS_20MachineDominatorTreeENS_24MachinePostDominatorTreeEE17splitCriticalEdgeEPNS_17MachineBasicBlockES6_S6_(ptr noundef nonnull align 8 dereferenceable(658) %4, ptr noundef nonnull %0, ptr noundef nonnull %1, ptr noundef nonnull %31) #33
  br label %1070

1070:                                             ; preds = %1069, %1067
  %1071 = load ptr, ptr %20, align 8, !tbaa !744
  %1072 = icmp eq ptr %1071, null
  br i1 %1072, label %1115, label %1073

1073:                                             ; preds = %1070
  %1074 = getelementptr inbounds nuw i8, ptr %0, i64 220
  %1075 = load i32, ptr %1074, align 4, !tbaa !292
  %1076 = getelementptr inbounds nuw i8, ptr %1071, i64 8
  %1077 = load i32, ptr %1076, align 8, !tbaa !76
  %1078 = icmp ugt i32 %1077, %1075
  br i1 %1078, label %1079, label %1115

1079:                                             ; preds = %1073
  %1080 = zext i32 %1075 to i64
  %1081 = load ptr, ptr %1071, align 8, !tbaa !19
  %1082 = getelementptr inbounds nuw ptr, ptr %1081, i64 %1080
  %1083 = load ptr, ptr %1082, align 8, !tbaa !871
  %1084 = icmp eq ptr %1083, null
  br i1 %1084, label %1115, label %1085

1085:                                             ; preds = %1079
  %1086 = getelementptr inbounds nuw i8, ptr %1, i64 220
  %1087 = load i32, ptr %1086, align 4, !tbaa !292
  %1088 = icmp ugt i32 %1077, %1087
  br i1 %1088, label %1089, label %1115

1089:                                             ; preds = %1085
  %1090 = zext i32 %1087 to i64
  %1091 = getelementptr inbounds nuw ptr, ptr %1081, i64 %1090
  %1092 = load ptr, ptr %1091, align 8, !tbaa !871
  %1093 = icmp eq ptr %1092, null
  br i1 %1093, label %1115, label %1094

1094:                                             ; preds = %1089
  %1095 = icmp eq ptr %1083, %1092
  br i1 %1095, label %1113, label %1096

1096:                                             ; preds = %1094, %1096
  %1097 = phi ptr [ %1098, %1096 ], [ %1092, %1094 ]
  %1098 = load ptr, ptr %1097, align 8, !tbaa !873
  %1099 = icmp eq ptr %1098, %1083
  %1100 = icmp eq ptr %1098, null
  %1101 = or i1 %1099, %1100
  br i1 %1101, label %1102, label %1096, !llvm.loop !881

1102:                                             ; preds = %1096
  br i1 %1099, label %1113, label %1103

1103:                                             ; preds = %1102, %1103
  %1104 = phi ptr [ %1105, %1103 ], [ %1083, %1102 ]
  %1105 = load ptr, ptr %1104, align 8, !tbaa !873
  %1106 = icmp eq ptr %1105, %1092
  %1107 = icmp eq ptr %1105, null
  %1108 = or i1 %1106, %1107
  br i1 %1108, label %1109, label %1103, !llvm.loop !881

1109:                                             ; preds = %1103
  br i1 %1106, label %1113, label %1110

1110:                                             ; preds = %1109
  %1111 = load ptr, ptr %1092, align 8, !tbaa !873
  %1112 = icmp eq ptr %1111, null
  br i1 %1112, label %1115, label %1113

1113:                                             ; preds = %1110, %1109, %1102, %1094
  %1114 = phi ptr [ %1092, %1094 ], [ %1083, %1102 ], [ %1092, %1109 ], [ %1111, %1110 ]
  call void @_ZN4llvm8LoopBaseINS_17MachineBasicBlockENS_11MachineLoopEE19addBasicBlockToLoopEPS1_RNS_12LoopInfoBaseIS1_S2_EE(ptr noundef nonnull align 8 dereferenceable(56) %1114, ptr noundef nonnull %31, ptr noundef nonnull align 8 dereferenceable(192) %1071) #33
  br label %1115

1115:                                             ; preds = %1113, %1085, %1073, %1079, %1110, %1089, %1070
  %1116 = load ptr, ptr %7, align 8, !tbaa !19
  %1117 = icmp eq ptr %1116, %201
  br i1 %1117, label %1119, label %1118

1118:                                             ; preds = %1115
  call void @free(ptr noundef %1116) #33
  br label %1119

1119:                                             ; preds = %1115, %1118
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %7) #33
  %1120 = load ptr, ptr %6, align 8, !tbaa !19
  %1121 = icmp eq ptr %1120, %72
  br i1 %1121, label %1123, label %1122

1122:                                             ; preds = %1119
  call void @free(ptr noundef %1120) #33
  br label %1123

1123:                                             ; preds = %1119, %1122
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %6) #33
  br label %1124

1124:                                             ; preds = %5, %1123
  %1125 = phi ptr [ %31, %1123 ], [ null, %5 ]
  ret ptr %1125
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock20canSplitCriticalEdgeEPKS0_PKNS_15MachineLoopInfoE(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef readonly captures(address) %1, ptr noundef readonly captures(address_is_null) %2) local_unnamed_addr #3 align 2 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca %"class.llvm::SmallVector.426", align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca %"class.llvm::SmallVector.426", align 8
  %10 = getelementptr inbounds nuw i8, ptr %1, i64 216
  %11 = load i8, ptr %10, align 8, !tbaa !80, !range !16, !noundef !17
  %12 = trunc nuw i8 %11 to i1
  br i1 %12, label %164, label %13

13:                                               ; preds = %3
  %14 = getelementptr inbounds nuw i8, ptr %1, i64 262
  %15 = load i8, ptr %14, align 2, !tbaa !328, !range !16, !noundef !17
  %16 = trunc nuw i8 %15 to i1
  br i1 %16, label %164, label %17

17:                                               ; preds = %13
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %19 = load ptr, ptr %18, align 8, !tbaa !74
  %20 = getelementptr inbounds nuw i8, ptr %19, i64 8
  %21 = load ptr, ptr %20, align 8, !tbaa !882, !nonnull !17, !align !200
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 1128
  %23 = load i8, ptr %22, align 8
  %24 = and i8 %23, 1
  %25 = icmp eq i8 %24, 0
  br i1 %25, label %45, label %26

26:                                               ; preds = %17
  %27 = icmp eq ptr %2, null
  br i1 %27, label %164, label %28

28:                                               ; preds = %26
  %29 = getelementptr inbounds nuw i8, ptr %1, i64 220
  %30 = load i32, ptr %29, align 4, !tbaa !292
  %31 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %32 = load i32, ptr %31, align 8, !tbaa !76
  %33 = icmp ugt i32 %32, %30
  br i1 %33, label %34, label %164

34:                                               ; preds = %28
  %35 = zext i32 %30 to i64
  %36 = load ptr, ptr %2, align 8, !tbaa !19
  %37 = getelementptr inbounds nuw ptr, ptr %36, i64 %35
  %38 = load ptr, ptr %37, align 8, !tbaa !871
  %39 = icmp eq ptr %38, null
  br i1 %39, label %164, label %40

40:                                               ; preds = %34
  %41 = getelementptr inbounds nuw i8, ptr %38, i64 32
  %42 = load ptr, ptr %41, align 8, !tbaa !212
  %43 = load ptr, ptr %42, align 8, !tbaa !289
  %44 = icmp eq ptr %43, %1
  br i1 %44, label %45, label %164

45:                                               ; preds = %40, %17
  %46 = tail call ptr @_ZN4llvm17MachineBasicBlock18getFirstTerminatorEv(ptr noundef nonnull align 8 dereferenceable(288) %0)
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %48 = icmp eq ptr %46, %47
  br i1 %48, label %138, label %49

49:                                               ; preds = %45
  %50 = load ptr, ptr %18, align 8, !tbaa !74
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 16
  %52 = load ptr, ptr %51, align 8, !tbaa !308, !nonnull !17, !align !200
  %53 = load ptr, ptr %52, align 8, !tbaa !4
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 120
  %55 = load ptr, ptr %54, align 8
  %56 = tail call noundef ptr %55(ptr noundef nonnull align 8 dereferenceable(368) %52) #33
  %57 = load ptr, ptr %56, align 8, !tbaa !4
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 464
  %59 = load ptr, ptr %58, align 8
  %60 = tail call noundef i32 %59(ptr noundef nonnull align 8 dereferenceable(112) %56, ptr noundef nonnull align 8 dereferenceable(80) %46) #33
  %61 = icmp sgt i32 %60, -1
  br i1 %61, label %62, label %138

62:                                               ; preds = %49
  %63 = getelementptr inbounds nuw i8, ptr %19, i64 64
  %64 = load ptr, ptr %63, align 8, !tbaa !750
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 8
  %66 = zext nneg i32 %60 to i64
  %67 = load ptr, ptr %65, align 8, !tbaa !883
  %68 = getelementptr inbounds nuw %"struct.llvm::MachineJumpTableEntry", ptr %67, i64 %66
  %69 = load ptr, ptr %68, align 8, !tbaa !886
  %70 = getelementptr inbounds nuw i8, ptr %68, i64 8
  %71 = load ptr, ptr %70, align 8, !tbaa !886
  %72 = icmp eq ptr %69, %71
  br i1 %72, label %138, label %76

73:                                               ; preds = %76
  %74 = getelementptr inbounds nuw i8, ptr %77, i64 8
  %75 = icmp eq ptr %74, %71
  br i1 %75, label %138, label %76

76:                                               ; preds = %62, %73
  %77 = phi ptr [ %74, %73 ], [ %69, %62 ]
  %78 = load ptr, ptr %77, align 8, !tbaa !289
  %79 = icmp eq ptr %78, null
  br i1 %79, label %73, label %80

80:                                               ; preds = %76
  %81 = getelementptr inbounds nuw i8, ptr %19, i64 16
  %82 = load ptr, ptr %81, align 8, !tbaa !308, !nonnull !17, !align !200
  %83 = load ptr, ptr %82, align 8, !tbaa !4
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 120
  %85 = load ptr, ptr %84, align 8
  %86 = tail call noundef ptr %85(ptr noundef nonnull align 8 dereferenceable(368) %82) #33
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %6) #33
  %87 = getelementptr inbounds nuw i8, ptr %6, i64 16
  store ptr %87, ptr %6, align 8, !tbaa !19
  %88 = getelementptr inbounds nuw i8, ptr %6, i64 8
  store i32 0, ptr %88, align 8, !tbaa !76
  %89 = getelementptr inbounds nuw i8, ptr %6, i64 12
  store i32 4, ptr %89, align 4, !tbaa !77
  %90 = getelementptr inbounds nuw i8, ptr %78, i64 64
  %91 = load ptr, ptr %90, align 8, !tbaa !19
  %92 = getelementptr inbounds nuw i8, ptr %78, i64 72
  %93 = load i32, ptr %92, align 8, !tbaa !76
  %94 = zext i32 %93 to i64
  %95 = shl nuw nsw i64 %94, 3
  %96 = getelementptr inbounds nuw i8, ptr %91, i64 %95
  %97 = icmp eq i32 %93, 0
  br i1 %97, label %132, label %98

98:                                               ; preds = %80, %128
  %99 = phi ptr [ %129, %128 ], [ %91, %80 ]
  %100 = load ptr, ptr %99, align 8, !tbaa !289
  %101 = icmp eq ptr %100, %0
  br i1 %101, label %128, label %102

102:                                              ; preds = %98
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %7) #33
  store ptr null, ptr %7, align 8, !tbaa !289
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %8) #33
  store ptr null, ptr %8, align 8, !tbaa !289
  store i32 0, ptr %88, align 8, !tbaa !76
  %103 = load ptr, ptr %86, align 8, !tbaa !4
  %104 = getelementptr inbounds nuw i8, ptr %103, i64 304
  %105 = load ptr, ptr %104, align 8
  %106 = call noundef zeroext i1 %105(ptr noundef nonnull align 8 dereferenceable(112) %86, ptr noundef nonnull align 8 dereferenceable(288) %100, ptr noundef nonnull align 8 dereferenceable(8) %7, ptr noundef nonnull align 8 dereferenceable(8) %8, ptr noundef nonnull align 8 dereferenceable(16) %6, i1 noundef zeroext false) #33
  br i1 %106, label %107, label %127

107:                                              ; preds = %102
  %108 = call ptr @_ZN4llvm17MachineBasicBlock18getFirstTerminatorEv(ptr noundef nonnull align 8 dereferenceable(288) %100)
  %109 = getelementptr inbounds nuw i8, ptr %100, i64 48
  %110 = icmp eq ptr %108, %109
  br i1 %110, label %131, label %111

111:                                              ; preds = %107
  %112 = getelementptr inbounds nuw i8, ptr %100, i64 32
  %113 = load ptr, ptr %112, align 8, !tbaa !74
  %114 = getelementptr inbounds nuw i8, ptr %113, i64 16
  %115 = load ptr, ptr %114, align 8, !tbaa !308, !nonnull !17, !align !200
  %116 = load ptr, ptr %115, align 8, !tbaa !4
  %117 = getelementptr inbounds nuw i8, ptr %116, i64 120
  %118 = load ptr, ptr %117, align 8
  %119 = call noundef ptr %118(ptr noundef nonnull align 8 dereferenceable(368) %115) #33
  %120 = load ptr, ptr %119, align 8, !tbaa !4
  %121 = getelementptr inbounds nuw i8, ptr %120, i64 464
  %122 = load ptr, ptr %121, align 8
  %123 = call noundef i32 %122(ptr noundef nonnull align 8 dereferenceable(112) %119, ptr noundef nonnull align 8 dereferenceable(80) %108) #33
  %124 = icmp sgt i32 %123, -1
  br i1 %124, label %125, label %131

125:                                              ; preds = %111
  %126 = icmp eq i32 %123, %60
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %8) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #33
  br i1 %126, label %132, label %128

127:                                              ; preds = %102
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %8) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #33
  br label %128

128:                                              ; preds = %127, %125, %98
  %129 = getelementptr inbounds nuw i8, ptr %99, i64 8
  %130 = icmp eq ptr %129, %96
  br i1 %130, label %132, label %98

131:                                              ; preds = %111, %107
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %8) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #33
  br label %132

132:                                              ; preds = %128, %125, %131, %80
  %133 = phi i1 [ true, %131 ], [ false, %80 ], [ false, %128 ], [ true, %125 ]
  %134 = load ptr, ptr %6, align 8, !tbaa !19
  %135 = icmp eq ptr %134, %87
  br i1 %135, label %137, label %136

136:                                              ; preds = %132
  call void @free(ptr noundef %134) #33
  br label %137

137:                                              ; preds = %132, %136
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %6) #33
  br i1 %133, label %138, label %164

138:                                              ; preds = %73, %62, %45, %137, %49
  %139 = getelementptr inbounds nuw i8, ptr %19, i64 16
  %140 = load ptr, ptr %139, align 8, !tbaa !308, !nonnull !17, !align !200
  %141 = load ptr, ptr %140, align 8, !tbaa !4
  %142 = getelementptr inbounds nuw i8, ptr %141, i64 120
  %143 = load ptr, ptr %142, align 8
  %144 = call noundef ptr %143(ptr noundef nonnull align 8 dereferenceable(368) %140) #33
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %9) #33
  %145 = getelementptr inbounds nuw i8, ptr %9, i64 16
  store ptr %145, ptr %9, align 8, !tbaa !19
  %146 = getelementptr inbounds nuw i8, ptr %9, i64 8
  store i32 0, ptr %146, align 8, !tbaa !76
  %147 = getelementptr inbounds nuw i8, ptr %9, i64 12
  store i32 4, ptr %147, align 4, !tbaa !77
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %4) #33
  store ptr null, ptr %4, align 8, !tbaa !289
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #33
  store ptr null, ptr %5, align 8, !tbaa !289
  %148 = load ptr, ptr %144, align 8, !tbaa !4
  %149 = getelementptr inbounds nuw i8, ptr %148, i64 304
  %150 = load ptr, ptr %149, align 8
  %151 = call noundef zeroext i1 %150(ptr noundef nonnull align 8 dereferenceable(112) %144, ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(8) %4, ptr noundef nonnull align 8 dereferenceable(8) %5, ptr noundef nonnull align 8 dereferenceable(16) %9, i1 noundef zeroext false) #33
  %152 = load ptr, ptr %4, align 8, !tbaa !289
  %153 = load ptr, ptr %5, align 8, !tbaa !289
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %4) #33
  br i1 %151, label %158, label %154

154:                                              ; preds = %138
  %155 = icmp eq ptr %152, null
  %156 = icmp ne ptr %152, %153
  %157 = select i1 %155, i1 true, i1 %156
  br label %158

158:                                              ; preds = %154, %138
  %159 = phi i1 [ false, %138 ], [ %157, %154 ]
  %160 = load ptr, ptr %9, align 8, !tbaa !19
  %161 = icmp eq ptr %160, %145
  br i1 %161, label %163, label %162

162:                                              ; preds = %158
  call void @free(ptr noundef %160) #33
  br label %163

163:                                              ; preds = %158, %162
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %9) #33
  br label %164

164:                                              ; preds = %28, %26, %34, %40, %137, %163, %13, %3
  %165 = phi i1 [ false, %3 ], [ false, %13 ], [ false, %26 ], [ false, %34 ], [ false, %40 ], [ %159, %163 ], [ true, %137 ], [ false, %28 ]
  ret i1 %165
}

declare noundef zeroext i1 @_ZN4llvm20MachineJumpTableInfo21ReplaceMBBInJumpTableEjPNS_17MachineBasicBlockES2_(ptr noundef nonnull align 8 dereferenceable(32), i32 noundef, ptr noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm11SlotIndexes15insertMBBInMapsEPNS_17MachineBasicBlockE(ptr noundef nonnull align 8 dereferenceable(416) %0, ptr noundef %1) local_unnamed_addr #3 comdat align 2 {
  %3 = load ptr, ptr %1, align 8, !tbaa !595
  %4 = load ptr, ptr %0, align 8, !tbaa !887
  %5 = ptrtoint ptr %4 to i64
  %6 = add i64 %5, 32
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %8 = load i64, ptr %7, align 8, !tbaa !888
  %9 = icmp ult i64 %6, %8
  br i1 %9, label %10, label %12, !prof !483

10:                                               ; preds = %2
  %11 = inttoptr i64 %6 to ptr
  store ptr %11, ptr %0, align 8, !tbaa !887
  br label %14

12:                                               ; preds = %2
  %13 = tail call noundef nonnull ptr @_ZN4llvm20BumpPtrAllocatorImplINS_15MallocAllocatorELm4096ELm4096ELm128ELm8EE12AllocateSlowEmmNS_5AlignE(ptr noundef nonnull align 8 dereferenceable(416) %0, i64 noundef 32, i64 noundef 32, i8 3)
  br label %14

14:                                               ; preds = %10, %12
  %15 = phi ptr [ %4, %10 ], [ %13, %12 ]
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 128
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 220
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %15, i8 0, i64 28, i1 false)
  %18 = load i32, ptr %17, align 4, !tbaa !292
  %19 = sext i32 %18 to i64
  %20 = load ptr, ptr %16, align 8, !tbaa !19
  %21 = getelementptr inbounds nuw %"struct.std::pair.781", ptr %20, i64 %19, i32 1
  %22 = load i64, ptr %21, align 8, !tbaa !212
  %23 = and i64 %22, -8
  %24 = getelementptr inbounds nuw i8, ptr %1, i64 48
  %25 = load i64, ptr %24, align 8
  %26 = and i64 %25, -8
  %27 = inttoptr i64 %26 to ptr
  %28 = icmp eq ptr %24, %27
  br i1 %28, label %37, label %29

29:                                               ; preds = %14
  %30 = getelementptr inbounds nuw i8, ptr %1, i64 56
  %31 = load ptr, ptr %30, align 8, !tbaa !75
  %32 = tail call i64 @_ZNK4llvm11SlotIndexes19getInstructionIndexERKNS_12MachineInstrEb(ptr noundef nonnull align 8 dereferenceable(416) %0, ptr noundef nonnull align 8 dereferenceable(80) %31, i1 noundef zeroext false)
  %33 = and i64 %32, -8
  %34 = load i32, ptr %17, align 4, !tbaa !292
  %35 = load ptr, ptr %16, align 8, !tbaa !19
  %36 = sext i32 %34 to i64
  br label %37

37:                                               ; preds = %14, %29
  %38 = phi i64 [ %19, %14 ], [ %36, %29 ]
  %39 = phi ptr [ %20, %14 ], [ %35, %29 ]
  %40 = phi i64 [ %23, %14 ], [ %33, %29 ]
  %41 = inttoptr i64 %40 to ptr
  %42 = load ptr, ptr %41, align 8, !tbaa !595
  %43 = getelementptr inbounds nuw i8, ptr %15, i64 8
  store ptr %41, ptr %43, align 8, !tbaa !327
  store ptr %42, ptr %15, align 8, !tbaa !595
  %44 = getelementptr inbounds nuw i8, ptr %42, i64 8
  store ptr %15, ptr %44, align 8, !tbaa !327
  store ptr %15, ptr %41, align 8, !tbaa !595
  %45 = ptrtoint ptr %15 to i64
  %46 = and i64 %45, -7
  %47 = getelementptr inbounds nuw %"struct.std::pair.781", ptr %39, i64 %38, i32 1
  store i64 %46, ptr %47, align 8, !tbaa !212
  %48 = getelementptr inbounds nuw i8, ptr %0, i64 136
  %49 = load i32, ptr %48, align 8, !tbaa !76
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 140
  %51 = load i32, ptr %50, align 4, !tbaa !77
  %52 = icmp ult i32 %49, %51
  br i1 %52, label %54, label %53, !prof !483

53:                                               ; preds = %37
  tail call void @_ZN4llvm23SmallVectorTemplateBaseISt4pairINS_9SlotIndexES2_ELb1EE15growAndPushBackES3_(ptr noundef nonnull align 8 dereferenceable(16) %16, i64 %46, i64 %23)
  br label %61

54:                                               ; preds = %37
  %55 = zext i32 %49 to i64
  %56 = load ptr, ptr %16, align 8, !tbaa !19
  %57 = getelementptr inbounds nuw %"struct.std::pair.781", ptr %56, i64 %55
  store i64 %46, ptr %57, align 1
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 8
  store i64 %23, ptr %58, align 1
  %59 = load i32, ptr %48, align 8, !tbaa !76
  %60 = add i32 %59, 1
  store i32 %60, ptr %48, align 8, !tbaa !76
  br label %61

61:                                               ; preds = %53, %54
  %62 = getelementptr inbounds nuw i8, ptr %0, i64 272
  %63 = getelementptr inbounds nuw i8, ptr %0, i64 280
  %64 = load i32, ptr %63, align 8, !tbaa !76
  %65 = getelementptr inbounds nuw i8, ptr %0, i64 284
  %66 = load i32, ptr %65, align 4, !tbaa !77
  %67 = icmp ult i32 %64, %66
  br i1 %67, label %69, label %68, !prof !483

68:                                               ; preds = %61
  tail call void @_ZN4llvm23SmallVectorTemplateBaseISt4pairINS_9SlotIndexEPNS_17MachineBasicBlockEELb1EE15growAndPushBackES5_(ptr noundef nonnull align 8 dereferenceable(16) %62, i64 %46, ptr nonnull %1)
  br label %76

69:                                               ; preds = %61
  %70 = zext i32 %64 to i64
  %71 = load ptr, ptr %62, align 8, !tbaa !19
  %72 = getelementptr inbounds nuw %"struct.std::pair.815", ptr %71, i64 %70
  store i64 %46, ptr %72, align 1
  %73 = getelementptr inbounds nuw i8, ptr %72, i64 8
  store ptr %1, ptr %73, align 1
  %74 = load i32, ptr %63, align 8, !tbaa !76
  %75 = add i32 %74, 1
  store i32 %75, ptr %63, align 8, !tbaa !76
  br label %76

76:                                               ; preds = %68, %69
  tail call void @_ZN4llvm11SlotIndexes15renumberIndexesENS_14ilist_iteratorINS_12ilist_detail12node_optionsINS_14IndexListEntryELb0ELb0EvLb0EvEELb0ELb0EEE(ptr noundef nonnull align 8 dereferenceable(416) %0, ptr nonnull %15) #33
  %77 = load i32, ptr %63, align 8, !tbaa !76
  %78 = icmp eq i32 %77, 0
  br i1 %78, label %87, label %79

79:                                               ; preds = %76
  %80 = zext i32 %77 to i64
  %81 = shl nuw nsw i64 %80, 4
  %82 = load ptr, ptr %62, align 8, !tbaa !19
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 %81
  %84 = tail call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %80, i1 true)
  %85 = shl nuw nsw i64 %84, 1
  %86 = xor i64 %85, 126
  tail call void @_ZSt16__introsort_loopIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEElNS1_10less_firstEEvT_S8_T0_T1_(ptr noundef %82, ptr noundef nonnull %83, i64 noundef %86)
  tail call void @_ZSt22__final_insertion_sortIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEENS1_10less_firstEEvT_S8_T0_(ptr noundef %82, ptr noundef nonnull %83)
  br label %87

87:                                               ; preds = %76, %79
  ret void
}

declare noundef nonnull align 8 dereferenceable(56) ptr @_ZN4llvm13LiveVariables10getVarInfoENS_8RegisterE(ptr noundef nonnull align 8 dereferenceable(200), i32) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock22ReplaceUsesOfBlockWithEPS0_S1_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef captures(address) %1, ptr noundef %2) local_unnamed_addr #3 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %6 = load ptr, ptr %5, align 8, !tbaa !75
  %7 = icmp eq ptr %4, %6
  br i1 %7, label %82, label %11

8:                                                ; preds = %56, %79, %32
  %9 = load ptr, ptr %5, align 8, !tbaa !75
  %10 = icmp eq ptr %9, %15
  br i1 %10, label %82, label %11, !llvm.loop !889

11:                                               ; preds = %3, %8
  %12 = phi ptr [ %15, %8 ], [ %4, %3 ]
  %13 = load i64, ptr %12, align 8
  %14 = and i64 %13, -8
  %15 = inttoptr i64 %14 to ptr
  %16 = getelementptr inbounds nuw i8, ptr %15, i64 44
  %17 = load i32, ptr %16, align 4, !tbaa !309
  %18 = and i32 %17, 12
  %19 = icmp eq i32 %18, 0
  %20 = and i32 %17, 4
  %21 = icmp ne i32 %20, 0
  %22 = or i1 %19, %21
  br i1 %22, label %23, label %30

23:                                               ; preds = %11
  %24 = getelementptr inbounds nuw i8, ptr %15, i64 16
  %25 = load ptr, ptr %24, align 8, !tbaa !314
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 16
  %27 = load i64, ptr %26, align 8, !tbaa !315
  %28 = and i64 %27, 512
  %29 = icmp eq i64 %28, 0
  br i1 %29, label %82, label %32

30:                                               ; preds = %11
  %31 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %15, i64 noundef 512, i32 noundef 1) #33
  br i1 %31, label %32, label %82

32:                                               ; preds = %23, %30
  %33 = getelementptr inbounds nuw i8, ptr %15, i64 32
  %34 = load ptr, ptr %33, align 8, !tbaa !571
  %35 = getelementptr inbounds nuw i8, ptr %15, i64 40
  %36 = load i24, ptr %35, align 8
  %37 = zext i24 %36 to i64
  %38 = shl nuw nsw i64 %37, 5
  %39 = getelementptr inbounds nuw i8, ptr %34, i64 %38
  %40 = icmp eq i24 %36, 0
  br i1 %40, label %8, label %41

41:                                               ; preds = %32
  %42 = add nsw i64 %38, -32
  %43 = and i64 %42, 32
  %44 = icmp eq i64 %43, 0
  br i1 %44, label %45, label %56

45:                                               ; preds = %41
  %46 = load i32, ptr %34, align 8
  %47 = and i32 %46, 255
  %48 = icmp eq i32 %47, 4
  br i1 %48, label %49, label %54

49:                                               ; preds = %45
  %50 = getelementptr inbounds nuw i8, ptr %34, i64 16
  %51 = load ptr, ptr %50, align 8, !tbaa !212
  %52 = icmp eq ptr %51, %1
  br i1 %52, label %53, label %54

53:                                               ; preds = %49
  store ptr %2, ptr %50, align 8, !tbaa !212
  br label %54

54:                                               ; preds = %53, %49, %45
  %55 = getelementptr inbounds nuw i8, ptr %34, i64 32
  br label %56

56:                                               ; preds = %54, %41
  %57 = phi ptr [ %34, %41 ], [ %55, %54 ]
  %58 = icmp eq i64 %42, 0
  br i1 %58, label %8, label %59

59:                                               ; preds = %56, %79
  %60 = phi ptr [ %80, %79 ], [ %57, %56 ]
  %61 = load i32, ptr %60, align 8
  %62 = and i32 %61, 255
  %63 = icmp eq i32 %62, 4
  br i1 %63, label %64, label %69

64:                                               ; preds = %59
  %65 = getelementptr inbounds nuw i8, ptr %60, i64 16
  %66 = load ptr, ptr %65, align 8, !tbaa !212
  %67 = icmp eq ptr %66, %1
  br i1 %67, label %68, label %69

68:                                               ; preds = %64
  store ptr %2, ptr %65, align 8, !tbaa !212
  br label %69

69:                                               ; preds = %68, %64, %59
  %70 = getelementptr inbounds nuw i8, ptr %60, i64 32
  %71 = load i32, ptr %70, align 8
  %72 = and i32 %71, 255
  %73 = icmp eq i32 %72, 4
  br i1 %73, label %74, label %79

74:                                               ; preds = %69
  %75 = getelementptr inbounds nuw i8, ptr %60, i64 48
  %76 = load ptr, ptr %75, align 8, !tbaa !212
  %77 = icmp eq ptr %76, %1
  br i1 %77, label %78, label %79

78:                                               ; preds = %74
  store ptr %2, ptr %75, align 8, !tbaa !212
  br label %79

79:                                               ; preds = %78, %74, %69
  %80 = getelementptr inbounds nuw i8, ptr %60, i64 64
  %81 = icmp eq ptr %80, %39
  br i1 %81, label %8, label %59

82:                                               ; preds = %8, %30, %23, %3
  tail call void @_ZN4llvm17MachineBasicBlock16replaceSuccessorEPS0_S1_(ptr noundef nonnull align 8 dereferenceable(288) %0, ptr noundef %1, ptr noundef %2)
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZN23SlotIndexUpdateDelegateD2Ev(ptr noundef nonnull align 8 dereferenceable(80) %0) unnamed_addr #3 comdat align 2 {
  store ptr getelementptr inbounds nuw inrange(-16, 48) (i8, ptr @_ZTV23SlotIndexUpdateDelegate, i64 16), ptr %0, align 8, !tbaa !4
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load ptr, ptr %2, align 8, !tbaa !787, !nonnull !17, !align !200
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 640
  store ptr null, ptr %4, align 8, !tbaa !786
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %7 = load ptr, ptr %6, align 8, !tbaa !19
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %9 = load i32, ptr %8, align 8, !tbaa !76
  %10 = zext i32 %9 to i64
  %11 = shl nuw nsw i64 %10, 3
  %12 = getelementptr inbounds nuw i8, ptr %7, i64 %11
  %13 = icmp eq i32 %9, 0
  br i1 %13, label %18, label %14

14:                                               ; preds = %1
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 16
  br label %36

16:                                               ; preds = %36
  %17 = load ptr, ptr %6, align 8, !tbaa !19
  br label %18

18:                                               ; preds = %16, %1
  %19 = phi ptr [ %17, %16 ], [ %7, %1 ]
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %21 = icmp eq ptr %19, %20
  br i1 %21, label %23, label %22

22:                                               ; preds = %18
  tail call void @free(ptr noundef %19) #33
  br label %23

23:                                               ; preds = %22, %18
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 44
  %25 = load i32, ptr %24, align 4, !tbaa !788
  %26 = icmp eq i32 %25, 0
  br i1 %26, label %35, label %27

27:                                               ; preds = %23
  %28 = load ptr, ptr %5, align 8, !tbaa !789
  %29 = zext i32 %25 to i64
  %30 = shl nuw nsw i64 %29, 3
  %31 = add nuw nsw i64 %29, 31
  %32 = lshr i64 %31, 3
  %33 = and i64 %32, 1073741820
  %34 = add nuw nsw i64 %33, %30
  tail call void @_ZN4llvm17deallocate_bufferEPvmm(ptr noundef %28, i64 noundef %34, i64 noundef 8) #33
  store i32 0, ptr %24, align 4, !tbaa !788
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %5, i8 0, i64 16, i1 false)
  br label %35

35:                                               ; preds = %23, %27
  ret void

36:                                               ; preds = %14, %36
  %37 = phi ptr [ %7, %14 ], [ %41, %36 ]
  %38 = load ptr, ptr %37, align 8, !tbaa !481
  %39 = load ptr, ptr %15, align 8, !tbaa !772
  %40 = tail call i64 @_ZN4llvm11SlotIndexes24insertMachineInstrInMapsERNS_12MachineInstrEb(ptr noundef nonnull align 8 dereferenceable(416) %39, ptr noundef nonnull align 8 dereferenceable(80) %38, i1 noundef zeroext false)
  %41 = getelementptr inbounds nuw i8, ptr %37, i64 8
  %42 = icmp eq ptr %41, %12
  br i1 %42, label %16, label %36
}

declare noundef i32 @_ZNK4llvm8DebugLoc7getLineEv(ptr noundef nonnull align 8 dereferenceable(8)) local_unnamed_addr #4

declare noundef i32 @_ZNK4llvm8DebugLoc6getColEv(ptr noundef nonnull align 8 dereferenceable(8)) local_unnamed_addr #4

declare noundef zeroext i1 @_ZN4llvm12MachineInstr17addRegisterKilledENS_8RegisterEPKNS_18TargetRegisterInfoEb(ptr noundef nonnull align 8 dereferenceable(80), i32, ptr noundef, i1 noundef zeroext) local_unnamed_addr #4

declare void @_ZN4llvm13LiveVariables11addNewBlockEPNS_17MachineBasicBlockES2_S2_RSt6vectorINS_15SparseBitVectorILj128EEESaIS5_EE(ptr noundef nonnull align 8 dereferenceable(200), ptr noundef, ptr noundef, ptr noundef, ptr noundef nonnull align 1) local_unnamed_addr #4

declare void @_ZN4llvm13LiveVariables11addNewBlockEPNS_17MachineBasicBlockES2_S2_(ptr noundef nonnull align 8 dereferenceable(200), ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #4

declare noundef ptr @_ZN4llvm9LiveRange10addSegmentENS0_7SegmentE(ptr noundef nonnull align 8 dereferenceable(104), ptr noundef byval(%"struct.llvm::LiveRange::Segment") align 8) local_unnamed_addr #4

declare void @_ZN4llvm9LiveRange13removeSegmentENS_9SlotIndexES1_b(ptr noundef nonnull align 8 dereferenceable(104), i64, i64, i1 noundef zeroext) local_unnamed_addr #4

declare void @_ZN4llvm13LiveIntervals22repairIntervalsInRangeEPNS_17MachineBasicBlockENS_26MachineInstrBundleIteratorINS_12MachineInstrELb0EEES5_NS_8ArrayRefINS_8RegisterEEE(ptr noundef nonnull align 8 dereferenceable(424), ptr noundef, ptr, ptr, ptr, i64) local_unnamed_addr #4

declare void @_ZN4llvm21GenericDomTreeUpdaterINS_21MachineDomTreeUpdaterENS_20MachineDominatorTreeENS_24MachinePostDominatorTreeEE17splitCriticalEdgeEPNS_17MachineBasicBlockES6_S6_(ptr noundef nonnull align 8 dereferenceable(658), ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #4

declare void @_ZN4llvm8LoopBaseINS_17MachineBasicBlockENS_11MachineLoopEE19addBasicBlockToLoopEPS1_RNS_12LoopInfoBaseIS1_S2_EE(ptr noundef nonnull align 8 dereferenceable(56), ptr noundef, ptr noundef nonnull align 8 dereferenceable(192)) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock5eraseENS_14ilist_iteratorINS_12ilist_detail12node_optionsINS_12MachineInstrELb1ELb1EvLb0EvEELb0ELb0EEE(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 44
  %4 = load i32, ptr %3, align 4, !tbaa !309
  %5 = and i32 %4, 12
  %6 = icmp eq i32 %5, 8
  br i1 %6, label %7, label %9

7:                                                ; preds = %2
  tail call void @_ZN4llvm12MachineInstr16unbundleFromSuccEv(ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  %8 = load i32, ptr %3, align 4, !tbaa !309
  br label %9

9:                                                ; preds = %7, %2
  %10 = phi i32 [ %8, %7 ], [ %4, %2 ]
  %11 = and i32 %10, 12
  %12 = icmp eq i32 %11, 4
  br i1 %12, label %13, label %14

13:                                               ; preds = %9
  tail call void @_ZN4llvm12MachineInstr16unbundleFromPredEv(ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  br label %14

14:                                               ; preds = %9, %13
  %15 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %16 = load ptr, ptr %15, align 8, !tbaa !75
  %17 = tail call noundef ptr @_ZNK4llvm12MachineInstr5getMFEv(ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  %18 = icmp eq ptr %17, null
  br i1 %18, label %22, label %19

19:                                               ; preds = %14
  tail call void @_ZN4llvm15MachineFunction13handleRemovalERNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057) %17, ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  %20 = getelementptr inbounds nuw i8, ptr %17, i64 32
  %21 = load ptr, ptr %20, align 8, !tbaa !293
  tail call void @_ZN4llvm12MachineInstr29removeRegOperandsFromUseListsERNS_19MachineRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80) %1, ptr noundef nonnull align 8 dereferenceable(520) %21) #33
  br label %22

22:                                               ; preds = %14, %19
  %23 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %24 = getelementptr inbounds nuw i8, ptr %1, i64 24
  store ptr null, ptr %24, align 8, !tbaa !294
  %25 = load i64, ptr %1, align 8
  %26 = and i64 %25, -8
  %27 = inttoptr i64 %26 to ptr
  %28 = load ptr, ptr %15, align 8, !tbaa !75
  %29 = load i64, ptr %28, align 8
  %30 = and i64 %29, 7
  %31 = or disjoint i64 %30, %26
  store i64 %31, ptr %28, align 8
  %32 = getelementptr inbounds nuw i8, ptr %27, i64 8
  store ptr %28, ptr %32, align 8, !tbaa !75
  %33 = load i64, ptr %1, align 8
  %34 = and i64 %33, 7
  store i64 %34, ptr %1, align 8
  store ptr null, ptr %15, align 8, !tbaa !75
  %35 = load ptr, ptr %23, align 8, !tbaa !83
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 32
  %37 = load ptr, ptr %36, align 8, !tbaa !74
  tail call void @_ZN4llvm15MachineFunction18deleteMachineInstrEPNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057) %37, ptr noundef nonnull %1) #33
  ret ptr %16
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZN4llvm17MachineBasicBlock12remove_instrEPNS_12MachineInstrE(ptr noundef nonnull readnone align 8 captures(none) dereferenceable(288) %0, ptr noundef returned %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 44
  %4 = load i32, ptr %3, align 4, !tbaa !309
  %5 = and i32 %4, 12
  %6 = icmp eq i32 %5, 8
  br i1 %6, label %7, label %9

7:                                                ; preds = %2
  tail call void @_ZN4llvm12MachineInstr16unbundleFromSuccEv(ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  %8 = load i32, ptr %3, align 4, !tbaa !309
  br label %9

9:                                                ; preds = %7, %2
  %10 = phi i32 [ %8, %7 ], [ %4, %2 ]
  %11 = and i32 %10, 12
  %12 = icmp eq i32 %11, 4
  br i1 %12, label %13, label %15

13:                                               ; preds = %9
  tail call void @_ZN4llvm12MachineInstr16unbundleFromPredEv(ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  %14 = load i32, ptr %3, align 4, !tbaa !309
  br label %15

15:                                               ; preds = %9, %13
  %16 = phi i32 [ %10, %9 ], [ %14, %13 ]
  %17 = and i32 %16, -13
  store i32 %17, ptr %3, align 4, !tbaa !309
  %18 = tail call noundef ptr @_ZNK4llvm12MachineInstr5getMFEv(ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  %19 = icmp eq ptr %18, null
  br i1 %19, label %23, label %20

20:                                               ; preds = %15
  tail call void @_ZN4llvm15MachineFunction13handleRemovalERNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057) %18, ptr noundef nonnull align 8 dereferenceable(80) %1) #33
  %21 = getelementptr inbounds nuw i8, ptr %18, i64 32
  %22 = load ptr, ptr %21, align 8, !tbaa !293
  tail call void @_ZN4llvm12MachineInstr29removeRegOperandsFromUseListsERNS_19MachineRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80) %1, ptr noundef nonnull align 8 dereferenceable(520) %22) #33
  br label %23

23:                                               ; preds = %15, %20
  %24 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %25 = getelementptr inbounds nuw i8, ptr %1, i64 24
  store ptr null, ptr %25, align 8, !tbaa !294
  %26 = load i64, ptr %1, align 8
  %27 = and i64 %26, -8
  %28 = inttoptr i64 %27 to ptr
  %29 = load ptr, ptr %24, align 8, !tbaa !75
  %30 = load i64, ptr %29, align 8
  %31 = and i64 %30, 7
  %32 = or disjoint i64 %31, %27
  store i64 %32, ptr %29, align 8
  %33 = getelementptr inbounds nuw i8, ptr %28, i64 8
  store ptr %29, ptr %33, align 8, !tbaa !75
  %34 = load i64, ptr %1, align 8
  %35 = and i64 %34, 7
  store i64 %35, ptr %1, align 8
  store ptr null, ptr %24, align 8, !tbaa !75
  ret ptr %1
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZN4llvm17MachineBasicBlock6insertENS_14ilist_iteratorINS_12ilist_detail12node_optionsINS_12MachineInstrELb1ELb1EvLb0EvEELb0ELb0EEEPS4_(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, ptr %1, ptr noundef returned initializes((24, 32)) %2) local_unnamed_addr #3 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %5 = icmp eq ptr %1, %4
  br i1 %5, label %15, label %6

6:                                                ; preds = %3
  %7 = getelementptr inbounds nuw i8, ptr %1, i64 44
  %8 = load i32, ptr %7, align 4, !tbaa !309
  %9 = and i32 %8, 4
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %15, label %11

11:                                               ; preds = %6
  %12 = getelementptr inbounds nuw i8, ptr %2, i64 44
  %13 = load i32, ptr %12, align 4, !tbaa !309
  %14 = or i32 %13, 12
  store i32 %14, ptr %12, align 4, !tbaa !309
  br label %15

15:                                               ; preds = %3, %11, %6
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %17 = load ptr, ptr %16, align 8, !tbaa !83
  %18 = getelementptr inbounds nuw i8, ptr %2, i64 24
  store ptr %17, ptr %18, align 8, !tbaa !294
  %19 = getelementptr inbounds nuw i8, ptr %17, i64 32
  %20 = load ptr, ptr %19, align 8, !tbaa !74
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 32
  %22 = load ptr, ptr %21, align 8, !tbaa !293
  tail call void @_ZN4llvm12MachineInstr24addRegOperandsToUseListsERNS_19MachineRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80) %2, ptr noundef nonnull align 8 dereferenceable(520) %22) #33
  tail call void @_ZN4llvm15MachineFunction15handleInsertionERNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057) %20, ptr noundef nonnull align 8 dereferenceable(80) %2) #33
  %23 = load i64, ptr %1, align 8
  %24 = and i64 %23, -8
  %25 = inttoptr i64 %24 to ptr
  %26 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store ptr %1, ptr %26, align 8, !tbaa !75
  %27 = load i64, ptr %2, align 8
  %28 = and i64 %27, 7
  %29 = or disjoint i64 %28, %24
  store i64 %29, ptr %2, align 8
  %30 = getelementptr inbounds nuw i8, ptr %25, i64 8
  store ptr %2, ptr %30, align 8, !tbaa !75
  %31 = load i64, ptr %1, align 8
  %32 = ptrtoint ptr %2 to i64
  %33 = and i64 %31, 7
  %34 = or disjoint i64 %33, %32
  store i64 %34, ptr %1, align 8
  ret ptr %2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local noundef nonnull ptr @_ZN4llvm17MachineBasicBlock16removeFromParentEv(ptr noundef nonnull returned align 8 captures(ret: address, provenance) dereferenceable(288) initializes((220, 224)) %0) local_unnamed_addr #8 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %4 = load ptr, ptr %3, align 8, !tbaa !327
  %5 = load ptr, ptr %2, align 8, !tbaa !74
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %7 = load i32, ptr %6, align 8, !tbaa !72
  %8 = getelementptr inbounds nuw i8, ptr %5, i64 88
  %9 = zext i32 %7 to i64
  %10 = load ptr, ptr %8, align 8, !tbaa !290
  %11 = getelementptr inbounds nuw ptr, ptr %10, i64 %9
  store ptr null, ptr %11, align 8, !tbaa !289
  store i32 -1, ptr %6, align 8, !tbaa !72
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 220
  store i32 -1, ptr %12, align 4, !tbaa !292
  %13 = load ptr, ptr %0, align 8, !tbaa !595
  store ptr %13, ptr %4, align 8, !tbaa !595
  %14 = getelementptr inbounds nuw i8, ptr %13, i64 8
  store ptr %4, ptr %14, align 8, !tbaa !327
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(288) %0, i8 0, i64 16, i1 false)
  ret ptr %0
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock15eraseFromParentEv(ptr noundef nonnull align 8 dereferenceable(288) initializes((220, 224)) %0) local_unnamed_addr #3 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %3 = load ptr, ptr %2, align 8, !tbaa !74
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 296
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8, !tbaa !327
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %8 = load i32, ptr %7, align 8, !tbaa !72
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 88
  %10 = zext i32 %8 to i64
  %11 = load ptr, ptr %9, align 8, !tbaa !290
  %12 = getelementptr inbounds nuw ptr, ptr %11, i64 %10
  store ptr null, ptr %12, align 8, !tbaa !289
  store i32 -1, ptr %7, align 8, !tbaa !72
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 220
  store i32 -1, ptr %13, align 4, !tbaa !292
  %14 = load ptr, ptr %0, align 8, !tbaa !595
  store ptr %14, ptr %6, align 8, !tbaa !595
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 8
  store ptr %6, ptr %15, align 8, !tbaa !327
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(288) %0, i8 0, i64 16, i1 false)
  tail call void @_ZN4llvm18ilist_alloc_traitsINS_17MachineBasicBlockEE10deleteNodeEPS1_(ptr noundef nonnull align 8 dereferenceable(16) %4, ptr noundef nonnull %0) #33
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock12findDebugLocENS_14ilist_iteratorINS_12ilist_detail12node_optionsINS_12MachineInstrELb1ELb1EvLb0EvEELb0ELb0EEE(ptr noundef nonnull readnone align 8 captures(address) dereferenceable(288) %0, ptr readonly captures(address) %1) local_unnamed_addr #10 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %4 = icmp eq ptr %1, %3
  br i1 %4, label %13, label %5

5:                                                ; preds = %2, %9
  %6 = phi ptr [ %11, %9 ], [ %1, %2 ]
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 52
  %8 = load i32, ptr %7, align 4, !tbaa !306
  switch i32 %8, label %13 [
    i32 25, label %9
    i32 18, label %9
    i32 17, label %9
    i32 16, label %9
    i32 15, label %9
    i32 14, label %9
  ]

9:                                                ; preds = %5, %5, %5, %5, %5, %5
  %10 = getelementptr inbounds nuw i8, ptr %6, i64 8
  %11 = load ptr, ptr %10, align 8, !tbaa !75
  %12 = icmp eq ptr %11, %3
  br i1 %12, label %13, label %5, !llvm.loop !890

13:                                               ; preds = %5, %9, %2
  %14 = phi ptr [ %1, %2 ], [ %11, %9 ], [ %6, %5 ]
  %15 = icmp eq ptr %14, %3
  br i1 %15, label %20, label %16

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %14, i64 72
  %18 = load i64, ptr %17, align 8, !tbaa !585
  %19 = inttoptr i64 %18 to ptr
  br label %20

20:                                               ; preds = %13, %16
  %21 = phi ptr [ %19, %16 ], [ null, %13 ]
  ret ptr %21
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock13rfindDebugLocENS_14ilist_iteratorINS_12ilist_detail12node_optionsINS_12MachineInstrELb1ELb1EvLb0EvEELb1ELb0EEE(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, ptr readonly captures(address) %1) local_unnamed_addr #10 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %4 = icmp eq ptr %1, %3
  br i1 %4, label %5, label %20

5:                                                ; preds = %2
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %7 = load ptr, ptr %6, align 8, !tbaa !75
  %8 = icmp eq ptr %7, %1
  br i1 %8, label %17, label %9

9:                                                ; preds = %5, %13
  %10 = phi ptr [ %15, %13 ], [ %7, %5 ]
  %11 = getelementptr inbounds nuw i8, ptr %10, i64 52
  %12 = load i32, ptr %11, align 4, !tbaa !306
  switch i32 %12, label %17 [
    i32 25, label %13
    i32 18, label %13
    i32 17, label %13
    i32 16, label %13
    i32 15, label %13
    i32 14, label %13
  ]

13:                                               ; preds = %9, %9, %9, %9, %9, %9
  %14 = getelementptr inbounds nuw i8, ptr %10, i64 8
  %15 = load ptr, ptr %14, align 8, !tbaa !75
  %16 = icmp eq ptr %15, %1
  br i1 %16, label %17, label %9, !llvm.loop !890

17:                                               ; preds = %13, %9, %5
  %18 = phi ptr [ %7, %5 ], [ %10, %9 ], [ %15, %13 ]
  %19 = icmp eq ptr %18, %1
  br i1 %19, label %44, label %39

20:                                               ; preds = %2
  %21 = load i64, ptr %3, align 8
  %22 = and i64 %21, -8
  %23 = inttoptr i64 %22 to ptr
  %24 = icmp eq ptr %1, %23
  br i1 %24, label %33, label %25

25:                                               ; preds = %20, %29
  %26 = phi ptr [ %31, %29 ], [ %1, %20 ]
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 52
  %28 = load i32, ptr %27, align 4, !tbaa !306
  switch i32 %28, label %33 [
    i32 25, label %29
    i32 18, label %29
    i32 17, label %29
    i32 16, label %29
    i32 15, label %29
    i32 14, label %29
  ]

29:                                               ; preds = %25, %25, %25, %25, %25, %25
  %30 = getelementptr inbounds nuw i8, ptr %26, i64 8
  %31 = load ptr, ptr %30, align 8, !tbaa !75
  %32 = icmp eq ptr %31, %23
  br i1 %32, label %33, label %25, !llvm.loop !891

33:                                               ; preds = %25, %29, %20
  %34 = phi ptr [ %1, %20 ], [ %31, %29 ], [ %26, %25 ]
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 52
  %36 = load i32, ptr %35, align 4, !tbaa !306
  %37 = add i32 %36, -14
  %38 = icmp ult i32 %37, 5
  br i1 %38, label %44, label %39

39:                                               ; preds = %33, %17
  %40 = phi ptr [ %18, %17 ], [ %34, %33 ]
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 72
  %42 = load i64, ptr %41, align 8, !tbaa !585
  %43 = inttoptr i64 %42 to ptr
  br label %44

44:                                               ; preds = %39, %33, %17
  %45 = phi ptr [ null, %17 ], [ null, %33 ], [ %43, %39 ]
  ret ptr %45
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock16findPrevDebugLocENS_14ilist_iteratorINS_12ilist_detail12node_optionsINS_12MachineInstrELb1ELb1EvLb0EvEELb0ELb0EEE(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr readonly captures(address) %1) local_unnamed_addr #10 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %4 = load ptr, ptr %3, align 8, !tbaa !75
  %5 = icmp eq ptr %1, %4
  br i1 %5, label %30, label %6

6:                                                ; preds = %2
  %7 = load i64, ptr %1, align 8
  %8 = and i64 %7, -8
  %9 = inttoptr i64 %8 to ptr
  %10 = icmp eq ptr %4, %9
  br i1 %10, label %20, label %11

11:                                               ; preds = %6, %15
  %12 = phi ptr [ %18, %15 ], [ %9, %6 ]
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 52
  %14 = load i32, ptr %13, align 4, !tbaa !306
  switch i32 %14, label %20 [
    i32 25, label %15
    i32 18, label %15
    i32 17, label %15
    i32 16, label %15
    i32 15, label %15
    i32 14, label %15
  ]

15:                                               ; preds = %11, %11, %11, %11, %11, %11
  %16 = load i64, ptr %12, align 8
  %17 = and i64 %16, -8
  %18 = inttoptr i64 %17 to ptr
  %19 = icmp eq ptr %4, %18
  br i1 %19, label %20, label %11, !llvm.loop !892

20:                                               ; preds = %11, %15, %6
  %21 = phi ptr [ %9, %6 ], [ %12, %11 ], [ %18, %15 ]
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 52
  %23 = load i32, ptr %22, align 4, !tbaa !306
  %24 = add i32 %23, -14
  %25 = icmp ult i32 %24, 5
  br i1 %25, label %30, label %26

26:                                               ; preds = %20
  %27 = getelementptr inbounds nuw i8, ptr %21, i64 72
  %28 = load i64, ptr %27, align 8, !tbaa !585
  %29 = inttoptr i64 %28 to ptr
  br label %30

30:                                               ; preds = %20, %2, %26
  %31 = phi ptr [ %29, %26 ], [ null, %2 ], [ null, %20 ]
  ret ptr %31
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable
define dso_local ptr @_ZN4llvm17MachineBasicBlock17rfindPrevDebugLocENS_14ilist_iteratorINS_12ilist_detail12node_optionsINS_12MachineInstrELb1ELb1EvLb0EvEELb1ELb0EEE(ptr noundef nonnull readnone align 8 captures(address) dereferenceable(288) %0, ptr readonly captures(address) %1) local_unnamed_addr #10 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %4 = icmp eq ptr %1, %3
  br i1 %4, label %26, label %5

5:                                                ; preds = %2
  %6 = load i64, ptr %1, align 8
  %7 = and i64 %6, -8
  %8 = inttoptr i64 %7 to ptr
  %9 = icmp eq ptr %3, %8
  br i1 %9, label %19, label %10

10:                                               ; preds = %5, %14
  %11 = phi ptr [ %17, %14 ], [ %8, %5 ]
  %12 = getelementptr inbounds nuw i8, ptr %11, i64 52
  %13 = load i32, ptr %12, align 4, !tbaa !306
  switch i32 %13, label %19 [
    i32 25, label %14
    i32 18, label %14
    i32 17, label %14
    i32 16, label %14
    i32 15, label %14
    i32 14, label %14
  ]

14:                                               ; preds = %10, %10, %10, %10, %10, %10
  %15 = load i64, ptr %11, align 8
  %16 = and i64 %15, -8
  %17 = inttoptr i64 %16 to ptr
  %18 = icmp eq ptr %3, %17
  br i1 %18, label %19, label %10, !llvm.loop !893

19:                                               ; preds = %10, %14, %5
  %20 = phi ptr [ %8, %5 ], [ %11, %10 ], [ %17, %14 ]
  %21 = icmp eq ptr %20, %3
  br i1 %21, label %26, label %22

22:                                               ; preds = %19
  %23 = getelementptr inbounds nuw i8, ptr %20, i64 72
  %24 = load i64, ptr %23, align 8, !tbaa !585
  %25 = inttoptr i64 %24 to ptr
  br label %26

26:                                               ; preds = %19, %2, %22
  %27 = phi ptr [ %25, %22 ], [ null, %2 ], [ null, %19 ]
  ret ptr %27
}

declare ptr @_ZN4llvm8DebugLoc17getMergedLocationES0_S0_(ptr, ptr) local_unnamed_addr #4

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local ptr @_ZNK4llvm17MachineBasicBlock22getProbabilityIteratorEPKPS0_(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr noundef %1) local_unnamed_addr #14 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %4 = load ptr, ptr %3, align 8, !tbaa !19
  %5 = ptrtoint ptr %1 to i64
  %6 = ptrtoint ptr %4 to i64
  %7 = sub i64 %5, %6
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %9 = load ptr, ptr %8, align 8, !tbaa !345
  %10 = ashr exact i64 %7, 1
  %11 = getelementptr inbounds i8, ptr %9, i64 %10
  ret ptr %11
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock29canPredictBranchProbabilitiesEv(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #3 align 2 {
  %2 = alloca %"class.llvm::SmallVector.667", align 8
  %3 = alloca %"class.llvm::SmallVector.667", align 8
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %5 = load i32, ptr %4, align 8, !tbaa !76
  %6 = icmp ult i32 %5, 2
  br i1 %6, label %506, label %7

7:                                                ; preds = %1
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %9 = load ptr, ptr %8, align 8, !tbaa !345
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %11 = load ptr, ptr %10, align 8, !tbaa !345
  %12 = icmp eq ptr %9, %11
  br i1 %12, label %506, label %13

13:                                               ; preds = %7
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %2) #33
  %14 = getelementptr inbounds nuw i8, ptr %2, i64 16
  store ptr %14, ptr %2, align 8, !tbaa !19
  %15 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store i32 0, ptr %15, align 8, !tbaa !76
  %16 = getelementptr inbounds nuw i8, ptr %2, i64 12
  store i32 8, ptr %16, align 4, !tbaa !77
  %17 = ptrtoint ptr %11 to i64
  %18 = ptrtoint ptr %9 to i64
  %19 = sub i64 %17, %18
  %20 = ashr exact i64 %19, 2
  %21 = icmp ugt i64 %20, 8
  br i1 %21, label %22, label %25

22:                                               ; preds = %13
  call void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(48) %2, ptr noundef nonnull %14, i64 noundef %20, i64 noundef 4) #33
  %23 = load i32, ptr %15, align 8, !tbaa !76
  %24 = load ptr, ptr %2, align 8, !tbaa !19
  br label %25

25:                                               ; preds = %22, %13
  %26 = phi ptr [ %14, %13 ], [ %24, %22 ]
  %27 = phi i32 [ 0, %13 ], [ %23, %22 ]
  %28 = icmp sgt i64 %19, 0
  br i1 %28, label %29, label %34, !prof !483

29:                                               ; preds = %25
  %30 = zext i32 %27 to i64
  %31 = getelementptr inbounds nuw %"class.llvm::BranchProbability", ptr %26, i64 %30
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %31, ptr align 4 %9, i64 %19, i1 false)
  %32 = load i32, ptr %15, align 8, !tbaa !76
  %33 = load ptr, ptr %2, align 8, !tbaa !19
  br label %34

34:                                               ; preds = %25, %29
  %35 = phi ptr [ %26, %25 ], [ %33, %29 ]
  %36 = phi i32 [ %27, %25 ], [ %32, %29 ]
  %37 = trunc i64 %20 to i32
  %38 = add i32 %36, %37
  store i32 %38, ptr %15, align 8, !tbaa !76
  %39 = zext i32 %38 to i64
  %40 = shl nuw nsw i64 %39, 2
  %41 = getelementptr inbounds nuw i8, ptr %35, i64 %40
  %42 = icmp eq i32 %38, 0
  br i1 %42, label %87, label %43

43:                                               ; preds = %34
  %44 = add nsw i64 %40, -4
  %45 = lshr exact i64 %44, 2
  %46 = add nuw nsw i64 %45, 1
  %47 = icmp ult i64 %44, 12
  br i1 %47, label %83, label %48

48:                                               ; preds = %43
  %49 = and i64 %46, 9223372036854775804
  %50 = shl i64 %49, 2
  %51 = getelementptr i8, ptr %35, i64 %50
  br label %52

52:                                               ; preds = %52, %48
  %53 = phi i64 [ 0, %48 ], [ %75, %52 ]
  %54 = phi <2 x i32> [ zeroinitializer, %48 ], [ %67, %52 ]
  %55 = phi <2 x i32> [ zeroinitializer, %48 ], [ %68, %52 ]
  %56 = phi <2 x i64> [ zeroinitializer, %48 ], [ %73, %52 ]
  %57 = phi <2 x i64> [ zeroinitializer, %48 ], [ %74, %52 ]
  %58 = shl i64 %53, 2
  %59 = getelementptr i8, ptr %35, i64 %58
  %60 = getelementptr i8, ptr %59, i64 8
  %61 = load <2 x i32>, ptr %59, align 4, !tbaa !349
  %62 = load <2 x i32>, ptr %60, align 4, !tbaa !349
  %63 = icmp eq <2 x i32> %61, splat (i32 -1)
  %64 = icmp eq <2 x i32> %62, splat (i32 -1)
  %65 = zext <2 x i1> %63 to <2 x i32>
  %66 = zext <2 x i1> %64 to <2 x i32>
  %67 = add <2 x i32> %54, %65
  %68 = add <2 x i32> %55, %66
  %69 = select <2 x i1> %63, <2 x i32> zeroinitializer, <2 x i32> %61
  %70 = select <2 x i1> %64, <2 x i32> zeroinitializer, <2 x i32> %62
  %71 = zext <2 x i32> %69 to <2 x i64>
  %72 = zext <2 x i32> %70 to <2 x i64>
  %73 = add <2 x i64> %56, %71
  %74 = add <2 x i64> %57, %72
  %75 = add nuw i64 %53, 4
  %76 = icmp eq i64 %75, %49
  br i1 %76, label %77, label %52, !llvm.loop !894

77:                                               ; preds = %52
  %78 = add <2 x i32> %68, %67
  %79 = call i32 @llvm.vector.reduce.add.v2i32(<2 x i32> %78)
  %80 = add <2 x i64> %74, %73
  %81 = call i64 @llvm.vector.reduce.add.v2i64(<2 x i64> %80)
  %82 = icmp eq i64 %46, %49
  br i1 %82, label %104, label %83

83:                                               ; preds = %43, %77
  %84 = phi i32 [ 0, %43 ], [ %79, %77 ]
  %85 = phi i64 [ 0, %43 ], [ %81, %77 ]
  %86 = phi ptr [ %35, %43 ], [ %51, %77 ]
  br label %91

87:                                               ; preds = %34
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %3) #33
  %88 = getelementptr inbounds nuw i8, ptr %3, i64 16
  store ptr %88, ptr %3, align 8, !tbaa !19
  %89 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store i32 0, ptr %89, align 8, !tbaa !76
  %90 = getelementptr inbounds nuw i8, ptr %3, i64 12
  store i32 8, ptr %90, align 4, !tbaa !77
  br label %473

91:                                               ; preds = %83, %91
  %92 = phi i32 [ %98, %91 ], [ %84, %83 ]
  %93 = phi i64 [ %101, %91 ], [ %85, %83 ]
  %94 = phi ptr [ %102, %91 ], [ %86, %83 ]
  %95 = load i32, ptr %94, align 4, !tbaa !349
  %96 = icmp eq i32 %95, -1
  %97 = zext i1 %96 to i32
  %98 = add i32 %92, %97
  %99 = select i1 %96, i32 0, i32 %95
  %100 = zext i32 %99 to i64
  %101 = add i64 %93, %100
  %102 = getelementptr inbounds nuw i8, ptr %94, i64 4
  %103 = icmp eq ptr %102, %41
  br i1 %103, label %104, label %91, !llvm.loop !895

104:                                              ; preds = %91, %77
  %105 = phi i32 [ %79, %77 ], [ %98, %91 ]
  %106 = phi i64 [ %81, %77 ], [ %101, %91 ]
  %107 = icmp eq i32 %105, 0
  br i1 %107, label %184, label %108

108:                                              ; preds = %104
  %109 = icmp ult i64 %106, 2147483648
  br i1 %109, label %110, label %114

110:                                              ; preds = %108
  %111 = trunc nuw nsw i64 %106 to i32
  %112 = sub nuw i32 -2147483648, %111
  %113 = udiv i32 %112, %105
  br label %114

114:                                              ; preds = %110, %108
  %115 = phi i32 [ %113, %110 ], [ 0, %108 ]
  %116 = icmp ult i64 %44, 28
  br i1 %116, label %172, label %117

117:                                              ; preds = %114
  %118 = and i64 %46, 9223372036854775800
  %119 = shl i64 %118, 2
  %120 = getelementptr i8, ptr %35, i64 %119
  %121 = getelementptr i8, ptr %35, i64 4
  %122 = getelementptr i8, ptr %35, i64 8
  %123 = getelementptr i8, ptr %35, i64 12
  %124 = getelementptr i8, ptr %35, i64 16
  %125 = getelementptr i8, ptr %35, i64 20
  %126 = getelementptr i8, ptr %35, i64 24
  %127 = getelementptr i8, ptr %35, i64 28
  br label %128

128:                                              ; preds = %167, %117
  %129 = phi i64 [ 0, %117 ], [ %168, %167 ]
  %130 = shl i64 %129, 2
  %131 = getelementptr i8, ptr %35, i64 %130
  %132 = getelementptr i8, ptr %121, i64 %130
  %133 = getelementptr i8, ptr %122, i64 %130
  %134 = getelementptr i8, ptr %123, i64 %130
  %135 = getelementptr i8, ptr %124, i64 %130
  %136 = getelementptr i8, ptr %125, i64 %130
  %137 = getelementptr i8, ptr %126, i64 %130
  %138 = getelementptr i8, ptr %127, i64 %130
  %139 = getelementptr i8, ptr %131, i64 16
  %140 = load <4 x i32>, ptr %131, align 4, !tbaa !349
  %141 = load <4 x i32>, ptr %139, align 4, !tbaa !349
  %142 = icmp eq <4 x i32> %140, splat (i32 -1)
  %143 = icmp eq <4 x i32> %141, splat (i32 -1)
  %144 = extractelement <4 x i1> %142, i64 0
  br i1 %144, label %145, label %146

145:                                              ; preds = %128
  store i32 %115, ptr %131, align 4, !tbaa !451
  br label %146

146:                                              ; preds = %145, %128
  %147 = extractelement <4 x i1> %142, i64 1
  br i1 %147, label %148, label %149

148:                                              ; preds = %146
  store i32 %115, ptr %132, align 4, !tbaa !451
  br label %149

149:                                              ; preds = %148, %146
  %150 = extractelement <4 x i1> %142, i64 2
  br i1 %150, label %151, label %152

151:                                              ; preds = %149
  store i32 %115, ptr %133, align 4, !tbaa !451
  br label %152

152:                                              ; preds = %151, %149
  %153 = extractelement <4 x i1> %142, i64 3
  br i1 %153, label %154, label %155

154:                                              ; preds = %152
  store i32 %115, ptr %134, align 4, !tbaa !451
  br label %155

155:                                              ; preds = %154, %152
  %156 = extractelement <4 x i1> %143, i64 0
  br i1 %156, label %157, label %158

157:                                              ; preds = %155
  store i32 %115, ptr %135, align 4, !tbaa !451
  br label %158

158:                                              ; preds = %157, %155
  %159 = extractelement <4 x i1> %143, i64 1
  br i1 %159, label %160, label %161

160:                                              ; preds = %158
  store i32 %115, ptr %136, align 4, !tbaa !451
  br label %161

161:                                              ; preds = %160, %158
  %162 = extractelement <4 x i1> %143, i64 2
  br i1 %162, label %163, label %164

163:                                              ; preds = %161
  store i32 %115, ptr %137, align 4, !tbaa !451
  br label %164

164:                                              ; preds = %163, %161
  %165 = extractelement <4 x i1> %143, i64 3
  br i1 %165, label %166, label %167

166:                                              ; preds = %164
  store i32 %115, ptr %138, align 4, !tbaa !451
  br label %167

167:                                              ; preds = %166, %164
  %168 = add nuw i64 %129, 8
  %169 = icmp eq i64 %168, %118
  br i1 %169, label %170, label %128, !llvm.loop !896

170:                                              ; preds = %167
  %171 = icmp eq i64 %46, %118
  br i1 %171, label %182, label %172

172:                                              ; preds = %114, %170
  %173 = phi ptr [ %35, %114 ], [ %120, %170 ]
  br label %174

174:                                              ; preds = %172, %179
  %175 = phi ptr [ %180, %179 ], [ %173, %172 ]
  %176 = load i32, ptr %175, align 4, !tbaa !349
  %177 = icmp eq i32 %176, -1
  br i1 %177, label %178, label %179

178:                                              ; preds = %174
  store i32 %115, ptr %175, align 4, !tbaa !451
  br label %179

179:                                              ; preds = %178, %174
  %180 = getelementptr inbounds nuw i8, ptr %175, i64 4
  %181 = icmp eq ptr %180, %41
  br i1 %181, label %182, label %174, !llvm.loop !897

182:                                              ; preds = %179, %170
  %183 = icmp ugt i64 %106, 2147483648
  br i1 %183, label %186, label %248

184:                                              ; preds = %104
  %185 = icmp eq i64 %106, 0
  br i1 %185, label %201, label %186

186:                                              ; preds = %184, %182
  %187 = lshr i64 %106, 1
  %188 = and i64 %44, 4
  %189 = icmp eq i64 %188, 0
  br i1 %189, label %190, label %198

190:                                              ; preds = %186
  %191 = load i32, ptr %35, align 4, !tbaa !349
  %192 = zext i32 %191 to i64
  %193 = shl nuw nsw i64 %192, 31
  %194 = add nuw i64 %193, %187
  %195 = udiv i64 %194, %106
  %196 = trunc i64 %195 to i32
  store i32 %196, ptr %35, align 4, !tbaa !349
  %197 = getelementptr inbounds nuw i8, ptr %35, i64 4
  br label %198

198:                                              ; preds = %190, %186
  %199 = phi ptr [ %35, %186 ], [ %197, %190 ]
  %200 = icmp eq i64 %44, 0
  br i1 %200, label %248, label %231

201:                                              ; preds = %184
  %202 = icmp eq i32 %38, -2147483648
  br i1 %202, label %207, label %203

203:                                              ; preds = %201
  %204 = lshr i32 %38, 1
  %205 = or disjoint i32 %204, -2147483648
  %206 = udiv i32 %205, %38
  br label %207

207:                                              ; preds = %203, %201
  %208 = phi i32 [ %206, %203 ], [ 1, %201 ]
  %209 = icmp ult i64 %44, 28
  br i1 %209, label %225, label %210

210:                                              ; preds = %207
  %211 = and i64 %46, 9223372036854775800
  %212 = shl i64 %211, 2
  %213 = getelementptr i8, ptr %35, i64 %212
  %214 = insertelement <4 x i32> poison, i32 %208, i64 0
  %215 = shufflevector <4 x i32> %214, <4 x i32> poison, <4 x i32> zeroinitializer
  br label %216

216:                                              ; preds = %216, %210
  %217 = phi i64 [ 0, %210 ], [ %221, %216 ]
  %218 = shl i64 %217, 2
  %219 = getelementptr i8, ptr %35, i64 %218
  %220 = getelementptr i8, ptr %219, i64 16
  store <4 x i32> %215, ptr %219, align 4, !tbaa !451
  store <4 x i32> %215, ptr %220, align 4, !tbaa !451
  %221 = add nuw i64 %217, 8
  %222 = icmp eq i64 %221, %211
  br i1 %222, label %223, label %216, !llvm.loop !898

223:                                              ; preds = %216
  %224 = icmp eq i64 %46, %211
  br i1 %224, label %248, label %225

225:                                              ; preds = %207, %223
  %226 = phi ptr [ %35, %207 ], [ %213, %223 ]
  br label %227

227:                                              ; preds = %225, %227
  %228 = phi ptr [ %229, %227 ], [ %226, %225 ]
  store i32 %208, ptr %228, align 4, !tbaa !451
  %229 = getelementptr inbounds nuw i8, ptr %228, i64 4
  %230 = icmp eq ptr %229, %41
  br i1 %230, label %248, label %227, !llvm.loop !899

231:                                              ; preds = %198, %231
  %232 = phi ptr [ %246, %231 ], [ %199, %198 ]
  %233 = load i32, ptr %232, align 4, !tbaa !349
  %234 = zext i32 %233 to i64
  %235 = shl nuw nsw i64 %234, 31
  %236 = add nuw i64 %235, %187
  %237 = udiv i64 %236, %106
  %238 = trunc i64 %237 to i32
  store i32 %238, ptr %232, align 4, !tbaa !349
  %239 = getelementptr inbounds nuw i8, ptr %232, i64 4
  %240 = load i32, ptr %239, align 4, !tbaa !349
  %241 = zext i32 %240 to i64
  %242 = shl nuw nsw i64 %241, 31
  %243 = add nuw i64 %242, %187
  %244 = udiv i64 %243, %106
  %245 = trunc i64 %244 to i32
  store i32 %245, ptr %239, align 4, !tbaa !349
  %246 = getelementptr inbounds nuw i8, ptr %232, i64 8
  %247 = icmp eq ptr %246, %41
  br i1 %247, label %248, label %231, !llvm.loop !900

248:                                              ; preds = %198, %231, %227, %223, %182
  %249 = load i32, ptr %15, align 8, !tbaa !76
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %3) #33
  %250 = zext i32 %249 to i64
  %251 = getelementptr inbounds nuw i8, ptr %3, i64 16
  store ptr %251, ptr %3, align 8, !tbaa !19
  %252 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store i32 0, ptr %252, align 8, !tbaa !76
  %253 = getelementptr inbounds nuw i8, ptr %3, i64 12
  store i32 8, ptr %253, align 4, !tbaa !77
  %254 = icmp eq i32 %249, 0
  br i1 %254, label %473, label %255

255:                                              ; preds = %248
  %256 = icmp ugt i32 %249, 8
  br i1 %256, label %257, label %263

257:                                              ; preds = %255
  call void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(48) %3, ptr noundef nonnull %251, i64 noundef %250, i64 noundef 4) #33
  %258 = load i32, ptr %252, align 8, !tbaa !76
  %259 = icmp eq i32 %249, %258
  %260 = load ptr, ptr %3, align 8, !tbaa !19
  br i1 %259, label %269, label %261

261:                                              ; preds = %257
  %262 = zext i32 %258 to i64
  br label %263

263:                                              ; preds = %261, %255
  %264 = phi ptr [ %260, %261 ], [ %251, %255 ]
  %265 = phi i64 [ %262, %261 ], [ 0, %255 ]
  %266 = getelementptr %"class.llvm::BranchProbability", ptr %264, i64 %265
  %267 = sub nsw i64 %250, %265
  %268 = shl nsw i64 %267, 2
  call void @llvm.memset.p0.i64(ptr align 4 %266, i8 -1, i64 %268, i1 false), !tbaa !349
  br label %269

269:                                              ; preds = %257, %263
  %270 = phi ptr [ %260, %257 ], [ %264, %263 ]
  store i32 %249, ptr %252, align 8, !tbaa !76
  %271 = shl nuw nsw i64 %250, 2
  %272 = getelementptr inbounds nuw i8, ptr %270, i64 %271
  %273 = add nsw i64 %271, -4
  %274 = lshr exact i64 %273, 2
  %275 = add nuw nsw i64 %274, 1
  %276 = icmp ult i64 %273, 12
  br i1 %276, label %312, label %277

277:                                              ; preds = %269
  %278 = and i64 %275, 9223372036854775804
  %279 = shl i64 %278, 2
  %280 = getelementptr i8, ptr %270, i64 %279
  br label %281

281:                                              ; preds = %281, %277
  %282 = phi i64 [ 0, %277 ], [ %304, %281 ]
  %283 = phi <2 x i32> [ zeroinitializer, %277 ], [ %296, %281 ]
  %284 = phi <2 x i32> [ zeroinitializer, %277 ], [ %297, %281 ]
  %285 = phi <2 x i64> [ zeroinitializer, %277 ], [ %302, %281 ]
  %286 = phi <2 x i64> [ zeroinitializer, %277 ], [ %303, %281 ]
  %287 = shl i64 %282, 2
  %288 = getelementptr i8, ptr %270, i64 %287
  %289 = getelementptr i8, ptr %288, i64 8
  %290 = load <2 x i32>, ptr %288, align 4, !tbaa !349
  %291 = load <2 x i32>, ptr %289, align 4, !tbaa !349
  %292 = icmp eq <2 x i32> %290, splat (i32 -1)
  %293 = icmp eq <2 x i32> %291, splat (i32 -1)
  %294 = zext <2 x i1> %292 to <2 x i32>
  %295 = zext <2 x i1> %293 to <2 x i32>
  %296 = add <2 x i32> %283, %294
  %297 = add <2 x i32> %284, %295
  %298 = select <2 x i1> %292, <2 x i32> zeroinitializer, <2 x i32> %290
  %299 = select <2 x i1> %293, <2 x i32> zeroinitializer, <2 x i32> %291
  %300 = zext <2 x i32> %298 to <2 x i64>
  %301 = zext <2 x i32> %299 to <2 x i64>
  %302 = add <2 x i64> %285, %300
  %303 = add <2 x i64> %286, %301
  %304 = add nuw i64 %282, 4
  %305 = icmp eq i64 %304, %278
  br i1 %305, label %306, label %281, !llvm.loop !901

306:                                              ; preds = %281
  %307 = add <2 x i32> %297, %296
  %308 = call i32 @llvm.vector.reduce.add.v2i32(<2 x i32> %307)
  %309 = add <2 x i64> %303, %302
  %310 = call i64 @llvm.vector.reduce.add.v2i64(<2 x i64> %309)
  %311 = icmp eq i64 %275, %278
  br i1 %311, label %329, label %312

312:                                              ; preds = %269, %306
  %313 = phi i32 [ 0, %269 ], [ %308, %306 ]
  %314 = phi i64 [ 0, %269 ], [ %310, %306 ]
  %315 = phi ptr [ %270, %269 ], [ %280, %306 ]
  br label %316

316:                                              ; preds = %312, %316
  %317 = phi i32 [ %323, %316 ], [ %313, %312 ]
  %318 = phi i64 [ %326, %316 ], [ %314, %312 ]
  %319 = phi ptr [ %327, %316 ], [ %315, %312 ]
  %320 = load i32, ptr %319, align 4, !tbaa !349
  %321 = icmp eq i32 %320, -1
  %322 = zext i1 %321 to i32
  %323 = add i32 %317, %322
  %324 = select i1 %321, i32 0, i32 %320
  %325 = zext i32 %324 to i64
  %326 = add i64 %318, %325
  %327 = getelementptr inbounds nuw i8, ptr %319, i64 4
  %328 = icmp eq ptr %327, %272
  br i1 %328, label %329, label %316, !llvm.loop !902

329:                                              ; preds = %316, %306
  %330 = phi i32 [ %308, %306 ], [ %323, %316 ]
  %331 = phi i64 [ %310, %306 ], [ %326, %316 ]
  %332 = icmp eq i32 %330, 0
  br i1 %332, label %409, label %333

333:                                              ; preds = %329
  %334 = icmp ult i64 %331, 2147483648
  br i1 %334, label %335, label %339

335:                                              ; preds = %333
  %336 = trunc nuw nsw i64 %331 to i32
  %337 = sub nuw i32 -2147483648, %336
  %338 = udiv i32 %337, %330
  br label %339

339:                                              ; preds = %335, %333
  %340 = phi i32 [ %338, %335 ], [ 0, %333 ]
  %341 = icmp ult i64 %273, 28
  br i1 %341, label %397, label %342

342:                                              ; preds = %339
  %343 = and i64 %275, 9223372036854775800
  %344 = shl i64 %343, 2
  %345 = getelementptr i8, ptr %270, i64 %344
  %346 = getelementptr i8, ptr %270, i64 4
  %347 = getelementptr i8, ptr %270, i64 8
  %348 = getelementptr i8, ptr %270, i64 12
  %349 = getelementptr i8, ptr %270, i64 16
  %350 = getelementptr i8, ptr %270, i64 20
  %351 = getelementptr i8, ptr %270, i64 24
  %352 = getelementptr i8, ptr %270, i64 28
  br label %353

353:                                              ; preds = %392, %342
  %354 = phi i64 [ 0, %342 ], [ %393, %392 ]
  %355 = shl i64 %354, 2
  %356 = getelementptr i8, ptr %270, i64 %355
  %357 = getelementptr i8, ptr %346, i64 %355
  %358 = getelementptr i8, ptr %347, i64 %355
  %359 = getelementptr i8, ptr %348, i64 %355
  %360 = getelementptr i8, ptr %349, i64 %355
  %361 = getelementptr i8, ptr %350, i64 %355
  %362 = getelementptr i8, ptr %351, i64 %355
  %363 = getelementptr i8, ptr %352, i64 %355
  %364 = getelementptr i8, ptr %356, i64 16
  %365 = load <4 x i32>, ptr %356, align 4, !tbaa !349
  %366 = load <4 x i32>, ptr %364, align 4, !tbaa !349
  %367 = icmp eq <4 x i32> %365, splat (i32 -1)
  %368 = icmp eq <4 x i32> %366, splat (i32 -1)
  %369 = extractelement <4 x i1> %367, i64 0
  br i1 %369, label %370, label %371

370:                                              ; preds = %353
  store i32 %340, ptr %356, align 4, !tbaa !451
  br label %371

371:                                              ; preds = %370, %353
  %372 = extractelement <4 x i1> %367, i64 1
  br i1 %372, label %373, label %374

373:                                              ; preds = %371
  store i32 %340, ptr %357, align 4, !tbaa !451
  br label %374

374:                                              ; preds = %373, %371
  %375 = extractelement <4 x i1> %367, i64 2
  br i1 %375, label %376, label %377

376:                                              ; preds = %374
  store i32 %340, ptr %358, align 4, !tbaa !451
  br label %377

377:                                              ; preds = %376, %374
  %378 = extractelement <4 x i1> %367, i64 3
  br i1 %378, label %379, label %380

379:                                              ; preds = %377
  store i32 %340, ptr %359, align 4, !tbaa !451
  br label %380

380:                                              ; preds = %379, %377
  %381 = extractelement <4 x i1> %368, i64 0
  br i1 %381, label %382, label %383

382:                                              ; preds = %380
  store i32 %340, ptr %360, align 4, !tbaa !451
  br label %383

383:                                              ; preds = %382, %380
  %384 = extractelement <4 x i1> %368, i64 1
  br i1 %384, label %385, label %386

385:                                              ; preds = %383
  store i32 %340, ptr %361, align 4, !tbaa !451
  br label %386

386:                                              ; preds = %385, %383
  %387 = extractelement <4 x i1> %368, i64 2
  br i1 %387, label %388, label %389

388:                                              ; preds = %386
  store i32 %340, ptr %362, align 4, !tbaa !451
  br label %389

389:                                              ; preds = %388, %386
  %390 = extractelement <4 x i1> %368, i64 3
  br i1 %390, label %391, label %392

391:                                              ; preds = %389
  store i32 %340, ptr %363, align 4, !tbaa !451
  br label %392

392:                                              ; preds = %391, %389
  %393 = add nuw i64 %354, 8
  %394 = icmp eq i64 %393, %343
  br i1 %394, label %395, label %353, !llvm.loop !903

395:                                              ; preds = %392
  %396 = icmp eq i64 %275, %343
  br i1 %396, label %407, label %397

397:                                              ; preds = %339, %395
  %398 = phi ptr [ %270, %339 ], [ %345, %395 ]
  br label %399

399:                                              ; preds = %397, %404
  %400 = phi ptr [ %405, %404 ], [ %398, %397 ]
  %401 = load i32, ptr %400, align 4, !tbaa !349
  %402 = icmp eq i32 %401, -1
  br i1 %402, label %403, label %404

403:                                              ; preds = %399
  store i32 %340, ptr %400, align 4, !tbaa !451
  br label %404

404:                                              ; preds = %403, %399
  %405 = getelementptr inbounds nuw i8, ptr %400, i64 4
  %406 = icmp eq ptr %405, %272
  br i1 %406, label %407, label %399, !llvm.loop !904

407:                                              ; preds = %404, %395
  %408 = icmp ugt i64 %331, 2147483648
  br i1 %408, label %411, label %473

409:                                              ; preds = %329
  %410 = icmp eq i64 %331, 0
  br i1 %410, label %426, label %411

411:                                              ; preds = %409, %407
  %412 = lshr i64 %331, 1
  %413 = and i64 %273, 4
  %414 = icmp eq i64 %413, 0
  br i1 %414, label %415, label %423

415:                                              ; preds = %411
  %416 = load i32, ptr %270, align 4, !tbaa !349
  %417 = zext i32 %416 to i64
  %418 = shl nuw nsw i64 %417, 31
  %419 = add nuw i64 %418, %412
  %420 = udiv i64 %419, %331
  %421 = trunc i64 %420 to i32
  store i32 %421, ptr %270, align 4, !tbaa !349
  %422 = getelementptr inbounds nuw i8, ptr %270, i64 4
  br label %423

423:                                              ; preds = %415, %411
  %424 = phi ptr [ %270, %411 ], [ %422, %415 ]
  %425 = icmp eq i64 %273, 0
  br i1 %425, label %473, label %456

426:                                              ; preds = %409
  %427 = icmp eq i32 %249, -2147483648
  br i1 %427, label %432, label %428

428:                                              ; preds = %426
  %429 = lshr i32 %249, 1
  %430 = or disjoint i32 %429, -2147483648
  %431 = udiv i32 %430, %249
  br label %432

432:                                              ; preds = %428, %426
  %433 = phi i32 [ %431, %428 ], [ 1, %426 ]
  %434 = icmp ult i64 %273, 28
  br i1 %434, label %450, label %435

435:                                              ; preds = %432
  %436 = and i64 %275, 9223372036854775800
  %437 = shl i64 %436, 2
  %438 = getelementptr i8, ptr %270, i64 %437
  %439 = insertelement <4 x i32> poison, i32 %433, i64 0
  %440 = shufflevector <4 x i32> %439, <4 x i32> poison, <4 x i32> zeroinitializer
  br label %441

441:                                              ; preds = %441, %435
  %442 = phi i64 [ 0, %435 ], [ %446, %441 ]
  %443 = shl i64 %442, 2
  %444 = getelementptr i8, ptr %270, i64 %443
  %445 = getelementptr i8, ptr %444, i64 16
  store <4 x i32> %440, ptr %444, align 4, !tbaa !451
  store <4 x i32> %440, ptr %445, align 4, !tbaa !451
  %446 = add nuw i64 %442, 8
  %447 = icmp eq i64 %446, %436
  br i1 %447, label %448, label %441, !llvm.loop !905

448:                                              ; preds = %441
  %449 = icmp eq i64 %275, %436
  br i1 %449, label %473, label %450

450:                                              ; preds = %432, %448
  %451 = phi ptr [ %270, %432 ], [ %438, %448 ]
  br label %452

452:                                              ; preds = %450, %452
  %453 = phi ptr [ %454, %452 ], [ %451, %450 ]
  store i32 %433, ptr %453, align 4, !tbaa !451
  %454 = getelementptr inbounds nuw i8, ptr %453, i64 4
  %455 = icmp eq ptr %454, %272
  br i1 %455, label %473, label %452, !llvm.loop !906

456:                                              ; preds = %423, %456
  %457 = phi ptr [ %471, %456 ], [ %424, %423 ]
  %458 = load i32, ptr %457, align 4, !tbaa !349
  %459 = zext i32 %458 to i64
  %460 = shl nuw nsw i64 %459, 31
  %461 = add nuw i64 %460, %412
  %462 = udiv i64 %461, %331
  %463 = trunc i64 %462 to i32
  store i32 %463, ptr %457, align 4, !tbaa !349
  %464 = getelementptr inbounds nuw i8, ptr %457, i64 4
  %465 = load i32, ptr %464, align 4, !tbaa !349
  %466 = zext i32 %465 to i64
  %467 = shl nuw nsw i64 %466, 31
  %468 = add nuw i64 %467, %412
  %469 = udiv i64 %468, %331
  %470 = trunc i64 %469 to i32
  store i32 %470, ptr %464, align 4, !tbaa !349
  %471 = getelementptr inbounds nuw i8, ptr %457, i64 8
  %472 = icmp eq ptr %471, %272
  br i1 %472, label %473, label %456, !llvm.loop !900

473:                                              ; preds = %423, %456, %452, %448, %248, %87, %407
  %474 = phi ptr [ %252, %407 ], [ %89, %87 ], [ %252, %248 ], [ %252, %448 ], [ %252, %452 ], [ %252, %456 ], [ %252, %423 ]
  %475 = phi ptr [ %251, %407 ], [ %88, %87 ], [ %251, %248 ], [ %251, %448 ], [ %251, %452 ], [ %251, %456 ], [ %251, %423 ]
  %476 = phi ptr [ %270, %407 ], [ %88, %87 ], [ %251, %248 ], [ %270, %448 ], [ %270, %452 ], [ %270, %456 ], [ %270, %423 ]
  %477 = load ptr, ptr %2, align 8, !tbaa !19
  %478 = load i32, ptr %15, align 8, !tbaa !76
  %479 = zext i32 %478 to i64
  %480 = shl nuw nsw i64 %479, 2
  %481 = getelementptr inbounds nuw i8, ptr %477, i64 %480
  %482 = load i32, ptr %474, align 8, !tbaa !76
  %483 = icmp eq i32 %478, %482
  br i1 %483, label %484, label %496

484:                                              ; preds = %473
  %485 = icmp eq i32 %478, 0
  br i1 %485, label %496, label %486

486:                                              ; preds = %484, %486
  %487 = phi ptr [ %493, %486 ], [ %476, %484 ]
  %488 = phi ptr [ %492, %486 ], [ %477, %484 ]
  %489 = load i32, ptr %487, align 4, !tbaa !451
  %490 = load i32, ptr %488, align 4, !tbaa !349
  %491 = icmp eq i32 %490, %489
  %492 = getelementptr inbounds nuw i8, ptr %488, i64 4
  %493 = getelementptr inbounds nuw i8, ptr %487, i64 4
  %494 = icmp ne ptr %492, %481
  %495 = select i1 %491, i1 %494, i1 false
  br i1 %495, label %486, label %496, !llvm.loop !907

496:                                              ; preds = %486, %473, %484
  %497 = phi i1 [ false, %473 ], [ true, %484 ], [ %491, %486 ]
  %498 = icmp eq ptr %476, %475
  br i1 %498, label %501, label %499

499:                                              ; preds = %496
  call void @free(ptr noundef %476) #33
  %500 = load ptr, ptr %2, align 8, !tbaa !19
  br label %501

501:                                              ; preds = %496, %499
  %502 = phi ptr [ %477, %496 ], [ %500, %499 ]
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %3) #33
  %503 = icmp eq ptr %502, %14
  br i1 %503, label %505, label %504

504:                                              ; preds = %501
  call void @free(ptr noundef %502) #33
  br label %505

505:                                              ; preds = %501, %504
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %2) #33
  br label %506

506:                                              ; preds = %7, %1, %505
  %507 = phi i1 [ %497, %505 ], [ true, %1 ], [ true, %7 ]
  ret i1 %507
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: readwrite, inaccessiblemem: none) uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock18setSuccProbabilityEPPS0_NS_17BranchProbabilityE(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr noundef %1, i32 %2) local_unnamed_addr #16 align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 144
  %5 = load ptr, ptr %4, align 8, !tbaa !345
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 152
  %7 = load ptr, ptr %6, align 8, !tbaa !345
  %8 = icmp eq ptr %5, %7
  br i1 %8, label %17, label %9

9:                                                ; preds = %3
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %11 = load ptr, ptr %10, align 8, !tbaa !19
  %12 = ptrtoint ptr %1 to i64
  %13 = ptrtoint ptr %11 to i64
  %14 = sub i64 %12, %13
  %15 = ashr exact i64 %14, 1
  %16 = getelementptr inbounds i8, ptr %5, i64 %15
  store i32 %2, ptr %16, align 4, !tbaa !451
  br label %17

17:                                               ; preds = %3, %9
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef range(i32 0, 3) i32 @_ZNK4llvm17MachineBasicBlock23computeRegisterLivenessEPKNS_18TargetRegisterInfoENS_10MCRegisterENS_26MachineInstrBundleIteratorIKNS_12MachineInstrELb0EEEj(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, ptr noundef %1, i32 %2, ptr %3, i32 noundef %4) local_unnamed_addr #3 align 2 {
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %7 = icmp ne ptr %3, %6
  %8 = icmp ne i32 %4, 0
  %9 = and i1 %7, %8
  br i1 %9, label %10, label %48

10:                                               ; preds = %5, %41
  %11 = phi i32 [ %24, %41 ], [ %4, %5 ]
  %12 = phi ptr [ %44, %41 ], [ %3, %5 ]
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 52
  %14 = load i32, ptr %13, align 4, !tbaa !306
  switch i32 %14, label %15 [
    i32 25, label %23
    i32 18, label %23
    i32 17, label %23
    i32 16, label %23
    i32 15, label %23
    i32 14, label %23
  ]

15:                                               ; preds = %10
  %16 = tail call i64 @_ZN4llvm22AnalyzePhysRegInBundleERKNS_12MachineInstrENS_8RegisterEPKNS_18TargetRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80) %12, i32 %2, ptr noundef %1) #33
  %17 = and i64 %16, 16777216
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %19, label %217

19:                                               ; preds = %15
  %20 = add i32 %11, -1
  %21 = and i64 %16, 65537
  %22 = icmp eq i64 %21, 0
  br i1 %22, label %23, label %217

23:                                               ; preds = %10, %10, %10, %10, %10, %10, %19
  %24 = phi i32 [ %11, %10 ], [ %20, %19 ], [ %11, %10 ], [ %11, %10 ], [ %11, %10 ], [ %11, %10 ], [ %11, %10 ]
  %25 = load i64, ptr %12, align 8
  %26 = and i64 %25, 4
  %27 = icmp eq i64 %26, 0
  br i1 %27, label %28, label %41

28:                                               ; preds = %23
  %29 = getelementptr inbounds nuw i8, ptr %12, i64 44
  %30 = load i32, ptr %29, align 4, !tbaa !309
  %31 = and i32 %30, 8
  %32 = icmp eq i32 %31, 0
  br i1 %32, label %41, label %33

33:                                               ; preds = %28, %33
  %34 = phi ptr [ %36, %33 ], [ %12, %28 ]
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 8
  %36 = load ptr, ptr %35, align 8, !tbaa !75
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 44
  %38 = load i32, ptr %37, align 4, !tbaa !309
  %39 = and i32 %38, 8
  %40 = icmp eq i32 %39, 0
  br i1 %40, label %41, label %33, !llvm.loop !908

41:                                               ; preds = %33, %23, %28
  %42 = phi ptr [ %12, %23 ], [ %12, %28 ], [ %36, %33 ]
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 8
  %44 = load ptr, ptr %43, align 8, !tbaa !75
  %45 = icmp ne ptr %44, %6
  %46 = icmp ne i32 %24, 0
  %47 = select i1 %45, i1 %46, i1 false
  br i1 %47, label %10, label %48, !llvm.loop !909

48:                                               ; preds = %41, %5
  %49 = phi ptr [ %3, %5 ], [ %44, %41 ]
  %50 = icmp eq ptr %49, %6
  br i1 %50, label %51, label %87

51:                                               ; preds = %48
  %52 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %53 = load ptr, ptr %52, align 8, !tbaa !19
  %54 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %55 = load i32, ptr %54, align 8, !tbaa !76
  %56 = zext i32 %55 to i64
  %57 = shl nuw nsw i64 %56, 3
  %58 = getelementptr inbounds nuw i8, ptr %53, i64 %57
  %59 = icmp eq i32 %55, 0
  br i1 %59, label %217, label %60

60:                                               ; preds = %51
  %61 = add i32 %2, -1
  %62 = icmp ult i32 %61, 1073741823
  br label %63

63:                                               ; preds = %60, %84
  %64 = phi ptr [ %53, %60 ], [ %85, %84 ]
  %65 = load ptr, ptr %64, align 8, !tbaa !289
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 184
  %67 = load ptr, ptr %66, align 8, !tbaa !379
  %68 = getelementptr inbounds nuw i8, ptr %65, i64 192
  %69 = load ptr, ptr %68, align 8, !tbaa !379
  %70 = icmp eq ptr %67, %69
  br i1 %70, label %84, label %71

71:                                               ; preds = %63, %81
  %72 = phi ptr [ %82, %81 ], [ %67, %63 ]
  %73 = load i32, ptr %72, align 8, !tbaa !451
  %74 = icmp eq i32 %73, %2
  br i1 %74, label %217, label %75

75:                                               ; preds = %71
  %76 = add i32 %73, -1
  %77 = icmp ult i32 %76, 1073741823
  %78 = and i1 %62, %77
  br i1 %78, label %79, label %81

79:                                               ; preds = %75
  %80 = tail call noundef zeroext i1 @_ZNK4llvm14MCRegisterInfo11regsOverlapENS_10MCRegisterES1_(ptr noundef nonnull align 8 dereferenceable(316) %1, i32 %73, i32 %2) #33
  br i1 %80, label %217, label %81

81:                                               ; preds = %75, %79
  %82 = getelementptr inbounds nuw i8, ptr %72, i64 16
  %83 = icmp eq ptr %82, %69
  br i1 %83, label %84, label %71

84:                                               ; preds = %81, %63
  %85 = getelementptr inbounds nuw i8, ptr %64, i64 8
  %86 = icmp eq ptr %85, %58
  br i1 %86, label %217, label %63

87:                                               ; preds = %48
  %88 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %89 = load ptr, ptr %88, align 8, !tbaa !75
  %90 = icmp eq ptr %3, %89
  br i1 %90, label %195, label %91

91:                                               ; preds = %87, %140
  %92 = phi ptr [ %141, %140 ], [ %89, %87 ]
  %93 = phi ptr [ %116, %140 ], [ %3, %87 ]
  %94 = phi i32 [ %142, %140 ], [ %4, %87 ]
  %95 = load i64, ptr %93, align 8
  %96 = and i64 %95, -8
  %97 = inttoptr i64 %96 to ptr
  %98 = load i64, ptr %97, align 8
  %99 = and i64 %98, 4
  %100 = icmp eq i64 %99, 0
  br i1 %100, label %101, label %115

101:                                              ; preds = %91
  %102 = getelementptr inbounds nuw i8, ptr %97, i64 44
  %103 = load i32, ptr %102, align 4, !tbaa !309
  %104 = and i32 %103, 4
  %105 = icmp eq i32 %104, 0
  br i1 %105, label %115, label %106

106:                                              ; preds = %101, %106
  %107 = phi ptr [ %110, %106 ], [ %97, %101 ]
  %108 = load i64, ptr %107, align 8
  %109 = and i64 %108, -8
  %110 = inttoptr i64 %109 to ptr
  %111 = getelementptr inbounds nuw i8, ptr %110, i64 44
  %112 = load i32, ptr %111, align 4, !tbaa !309
  %113 = and i32 %112, 4
  %114 = icmp eq i32 %113, 0
  br i1 %114, label %115, label %106, !llvm.loop !329

115:                                              ; preds = %106, %91, %101
  %116 = phi ptr [ %97, %91 ], [ %97, %101 ], [ %110, %106 ]
  %117 = getelementptr inbounds nuw i8, ptr %116, i64 52
  %118 = load i32, ptr %117, align 4, !tbaa !306
  switch i32 %118, label %119 [
    i32 25, label %140
    i32 18, label %140
    i32 17, label %140
    i32 16, label %140
    i32 15, label %140
    i32 14, label %140
  ]

119:                                              ; preds = %115
  %120 = add i32 %94, -1
  %121 = tail call i64 @_ZN4llvm22AnalyzePhysRegInBundleERKNS_12MachineInstrENS_8RegisterEPKNS_18TargetRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80) %116, i32 %2, ptr noundef %1) #33
  %122 = and i64 %121, 1099511627776
  %123 = icmp eq i64 %122, 0
  br i1 %123, label %124, label %217

124:                                              ; preds = %119
  %125 = and i64 %121, 256
  %126 = icmp eq i64 %125, 0
  br i1 %126, label %132, label %127

127:                                              ; preds = %124
  %128 = and i64 %121, 281474976710656
  %129 = icmp eq i64 %128, 0
  br i1 %129, label %217, label %130

130:                                              ; preds = %127
  %131 = load ptr, ptr %88, align 8, !tbaa !75
  br label %146

132:                                              ; preds = %124
  %133 = and i64 %121, 72057594037927937
  %134 = icmp eq i64 %133, 0
  br i1 %134, label %135, label %217

135:                                              ; preds = %132
  %136 = and i64 %121, 16777216
  %137 = icmp eq i64 %136, 0
  br i1 %137, label %138, label %217

138:                                              ; preds = %135
  %139 = load ptr, ptr %88, align 8, !tbaa !75
  br label %140

140:                                              ; preds = %138, %115, %115, %115, %115, %115, %115
  %141 = phi ptr [ %92, %115 ], [ %139, %138 ], [ %92, %115 ], [ %92, %115 ], [ %92, %115 ], [ %92, %115 ], [ %92, %115 ]
  %142 = phi i32 [ %94, %115 ], [ %120, %138 ], [ %94, %115 ], [ %94, %115 ], [ %94, %115 ], [ %94, %115 ], [ %94, %115 ]
  %143 = icmp ne ptr %116, %141
  %144 = icmp ne i32 %142, 0
  %145 = select i1 %143, i1 %144, i1 false
  br i1 %145, label %91, label %146, !llvm.loop !910

146:                                              ; preds = %140, %130
  %147 = phi ptr [ %131, %130 ], [ %141, %140 ]
  %148 = icmp eq ptr %116, %147
  br i1 %148, label %195, label %149

149:                                              ; preds = %146, %190
  %150 = phi ptr [ %191, %190 ], [ %116, %146 ]
  %151 = load i64, ptr %150, align 8
  %152 = and i64 %151, -8
  %153 = inttoptr i64 %152 to ptr
  %154 = load i64, ptr %153, align 8
  %155 = and i64 %154, 4
  %156 = icmp eq i64 %155, 0
  br i1 %156, label %157, label %171

157:                                              ; preds = %149
  %158 = getelementptr inbounds nuw i8, ptr %153, i64 44
  %159 = load i32, ptr %158, align 4, !tbaa !309
  %160 = and i32 %159, 4
  %161 = icmp eq i32 %160, 0
  br i1 %161, label %171, label %162

162:                                              ; preds = %157, %162
  %163 = phi ptr [ %166, %162 ], [ %153, %157 ]
  %164 = load i64, ptr %163, align 8
  %165 = and i64 %164, -8
  %166 = inttoptr i64 %165 to ptr
  %167 = getelementptr inbounds nuw i8, ptr %166, i64 44
  %168 = load i32, ptr %167, align 4, !tbaa !309
  %169 = and i32 %168, 4
  %170 = icmp eq i32 %169, 0
  br i1 %170, label %171, label %162, !llvm.loop !329

171:                                              ; preds = %162, %157, %149
  %172 = phi ptr [ %153, %149 ], [ %153, %157 ], [ %166, %162 ]
  %173 = getelementptr inbounds nuw i8, ptr %172, i64 52
  %174 = load i32, ptr %173, align 4, !tbaa !306
  switch i32 %174, label %193 [
    i32 25, label %175
    i32 18, label %175
    i32 17, label %175
    i32 16, label %175
    i32 15, label %175
    i32 14, label %175
  ]

175:                                              ; preds = %171, %171, %171, %171, %171, %171
  br i1 %156, label %176, label %190

176:                                              ; preds = %175
  %177 = getelementptr inbounds nuw i8, ptr %153, i64 44
  %178 = load i32, ptr %177, align 4, !tbaa !309
  %179 = and i32 %178, 4
  %180 = icmp eq i32 %179, 0
  br i1 %180, label %190, label %181

181:                                              ; preds = %176, %181
  %182 = phi ptr [ %185, %181 ], [ %153, %176 ]
  %183 = load i64, ptr %182, align 8
  %184 = and i64 %183, -8
  %185 = inttoptr i64 %184 to ptr
  %186 = getelementptr inbounds nuw i8, ptr %185, i64 44
  %187 = load i32, ptr %186, align 4, !tbaa !309
  %188 = and i32 %187, 4
  %189 = icmp eq i32 %188, 0
  br i1 %189, label %190, label %181, !llvm.loop !329

190:                                              ; preds = %181, %175, %176
  %191 = phi ptr [ %153, %175 ], [ %153, %176 ], [ %185, %181 ]
  %192 = icmp eq ptr %191, %147
  br i1 %192, label %195, label %149, !llvm.loop !911

193:                                              ; preds = %171
  %194 = icmp eq ptr %150, %147
  br i1 %194, label %195, label %217

195:                                              ; preds = %190, %87, %146, %193
  %196 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %197 = load ptr, ptr %196, align 8, !tbaa !379
  %198 = getelementptr inbounds nuw i8, ptr %0, i64 192
  %199 = load ptr, ptr %198, align 8, !tbaa !379
  %200 = icmp eq ptr %197, %199
  br i1 %200, label %217, label %201

201:                                              ; preds = %195
  %202 = add i32 %2, -1
  %203 = icmp ult i32 %202, 1073741823
  br label %204

204:                                              ; preds = %201, %214
  %205 = phi ptr [ %197, %201 ], [ %215, %214 ]
  %206 = load i32, ptr %205, align 8, !tbaa !451
  %207 = icmp eq i32 %206, %2
  br i1 %207, label %217, label %208

208:                                              ; preds = %204
  %209 = add i32 %206, -1
  %210 = icmp ult i32 %209, 1073741823
  %211 = and i1 %203, %210
  br i1 %211, label %212, label %214

212:                                              ; preds = %208
  %213 = tail call noundef zeroext i1 @_ZNK4llvm14MCRegisterInfo11regsOverlapENS_10MCRegisterES1_(ptr noundef nonnull align 8 dereferenceable(316) %1, i32 %206, i32 %2) #33
  br i1 %213, label %217, label %214

214:                                              ; preds = %208, %212
  %215 = getelementptr inbounds nuw i8, ptr %205, i64 16
  %216 = icmp eq ptr %215, %199
  br i1 %216, label %217, label %204

217:                                              ; preds = %15, %19, %135, %132, %119, %212, %204, %214, %84, %79, %71, %195, %51, %127, %193
  %218 = phi i32 [ 2, %193 ], [ 0, %127 ], [ 1, %51 ], [ 1, %195 ], [ 0, %71 ], [ 0, %79 ], [ 1, %84 ], [ 0, %212 ], [ 0, %204 ], [ 1, %214 ], [ 1, %119 ], [ 1, %132 ], [ 0, %135 ], [ 0, %15 ], [ 1, %19 ]
  ret i32 %218
}

declare i64 @_ZN4llvm22AnalyzePhysRegInBundleERKNS_12MachineInstrENS_8RegisterEPKNS_18TargetRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80), i32, ptr noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZNK4llvm17MachineBasicBlock19getBeginClobberMaskEPKNS_18TargetRegisterInfoE(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0, ptr noundef %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 235
  %4 = load i8, ptr %3, align 1, !tbaa !492, !range !16, !noundef !17
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %6, label %11

6:                                                ; preds = %2
  %7 = load ptr, ptr %1, align 8, !tbaa !4
  %8 = getelementptr inbounds nuw i8, ptr %7, i64 88
  %9 = load ptr, ptr %8, align 8
  %10 = tail call noundef ptr %9(ptr noundef nonnull align 8 dereferenceable(316) %1) #33
  br label %11

11:                                               ; preds = %2, %6
  %12 = phi ptr [ %10, %6 ], [ null, %2 ]
  ret ptr %12
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local noundef ptr @_ZNK4llvm17MachineBasicBlock17getEndClobberMaskEPKNS_18TargetRegisterInfoE(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, ptr noundef %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %4 = load i64, ptr %3, align 8
  %5 = and i64 %4, -8
  %6 = inttoptr i64 %5 to ptr
  %7 = icmp eq ptr %3, %6
  br i1 %7, label %52, label %8

8:                                                ; preds = %2
  %9 = load i64, ptr %6, align 8
  %10 = and i64 %9, 4
  %11 = icmp ne i64 %10, 0
  %12 = getelementptr inbounds nuw i8, ptr %6, i64 44
  %13 = load i32, ptr %12, align 4, !tbaa !309
  %14 = and i32 %13, 4
  %15 = icmp eq i32 %14, 0
  %16 = select i1 %11, i1 true, i1 %15
  br i1 %16, label %26, label %17

17:                                               ; preds = %8, %17
  %18 = phi ptr [ %21, %17 ], [ %6, %8 ]
  %19 = load i64, ptr %18, align 8
  %20 = and i64 %19, -8
  %21 = inttoptr i64 %20 to ptr
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 44
  %23 = load i32, ptr %22, align 4, !tbaa !309
  %24 = and i32 %23, 4
  %25 = icmp eq i32 %24, 0
  br i1 %25, label %26, label %17, !llvm.loop !329

26:                                               ; preds = %17, %8
  %27 = phi i32 [ %13, %8 ], [ %23, %17 ]
  %28 = phi ptr [ %6, %8 ], [ %21, %17 ]
  %29 = and i32 %27, 12
  %30 = icmp eq i32 %29, 0
  %31 = and i32 %27, 4
  %32 = icmp ne i32 %31, 0
  %33 = or i1 %30, %32
  br i1 %33, label %34, label %41

34:                                               ; preds = %26
  %35 = getelementptr inbounds nuw i8, ptr %28, i64 16
  %36 = load ptr, ptr %35, align 8, !tbaa !314
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 16
  %38 = load i64, ptr %37, align 8, !tbaa !315
  %39 = and i64 %38, 32
  %40 = icmp eq i64 %39, 0
  br i1 %40, label %52, label %43

41:                                               ; preds = %26
  %42 = tail call noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80) %28, i64 noundef 32, i32 noundef 1) #33
  br i1 %42, label %43, label %52

43:                                               ; preds = %34, %41
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %45 = load i32, ptr %44, align 8, !tbaa !76
  %46 = icmp eq i32 %45, 0
  br i1 %46, label %52, label %47

47:                                               ; preds = %43
  %48 = load ptr, ptr %1, align 8, !tbaa !4
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 88
  %50 = load ptr, ptr %49, align 8
  %51 = tail call noundef ptr %50(ptr noundef nonnull align 8 dereferenceable(316) %1) #33
  br label %52

52:                                               ; preds = %2, %34, %41, %43, %47
  %53 = phi ptr [ %51, %47 ], [ null, %43 ], [ null, %41 ], [ null, %34 ], [ null, %2 ]
  ret ptr %53
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock12clearLiveInsEv(ptr noundef nonnull align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #17 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %3 = load ptr, ptr %2, align 8, !tbaa !85
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 192
  %5 = load ptr, ptr %4, align 8, !tbaa !527
  %6 = icmp eq ptr %5, %3
  br i1 %6, label %8, label %7

7:                                                ; preds = %1
  store ptr %3, ptr %4, align 8, !tbaa !527
  br label %8

8:                                                ; preds = %1, %7
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock12clearLiveInsERSt6vectorINS0_16RegisterMaskPairESaIS2_EE(ptr noundef nonnull align 8 captures(none) dereferenceable(288) %0, ptr noundef nonnull align 8 captures(none) dereferenceable(24) %1) local_unnamed_addr #17 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 200
  %5 = load ptr, ptr %4, align 8, !tbaa !84
  %6 = load <2 x ptr>, ptr %1, align 8, !tbaa !379
  %7 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %8 = load <2 x ptr>, ptr %3, align 8, !tbaa !379
  store <2 x ptr> %6, ptr %3, align 8, !tbaa !379
  %9 = load ptr, ptr %7, align 8, !tbaa !84
  store ptr %9, ptr %4, align 8, !tbaa !84
  store <2 x ptr> %8, ptr %1, align 8, !tbaa !379
  store ptr %5, ptr %7, align 8, !tbaa !84
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local ptr @_ZNK4llvm17MachineBasicBlock12livein_beginEv(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %0) local_unnamed_addr #14 align 2 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 184
  %3 = load ptr, ptr %2, align 8, !tbaa !379
  ret ptr %3
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZNK4llvm17MachineBasicBlock13liveout_beginEv(ptr dead_on_unwind noalias writable writeonly sret(%"class.llvm::MachineBasicBlock::liveout_iterator") align 8 captures(none) initializes((0, 32)) %0, ptr noundef nonnull readonly align 8 captures(none) dereferenceable(288) %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %4 = load ptr, ptr %3, align 8, !tbaa !74
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 16
  %6 = load ptr, ptr %5, align 8, !tbaa !308, !nonnull !17, !align !200
  %7 = load ptr, ptr %6, align 8, !tbaa !4
  %8 = getelementptr inbounds nuw i8, ptr %7, i64 136
  %9 = load ptr, ptr %8, align 8
  %10 = tail call noundef ptr %9(ptr noundef nonnull align 8 dereferenceable(368) %6) #33
  %11 = load ptr, ptr %4, align 8, !tbaa !275, !nonnull !17, !align !200
  %12 = getelementptr inbounds nuw i8, ptr %11, i64 2
  %13 = load i16, ptr %12, align 2, !tbaa !912
  %14 = and i16 %13, 8
  %15 = icmp eq i16 %14, 0
  br i1 %15, label %42, label %16

16:                                               ; preds = %2
  %17 = tail call noundef ptr @_ZNK4llvm8Function16getPersonalityFnEv(ptr noundef nonnull align 8 dereferenceable(140) %11) #33
  %18 = load ptr, ptr %4, align 8, !tbaa !275, !nonnull !17, !align !200
  %19 = getelementptr inbounds nuw i8, ptr %18, i64 40
  %20 = load ptr, ptr %19, align 8, !tbaa !276
  %21 = tail call noundef i32 @_ZNK4llvm6Module17getExceptionModelEv(ptr noundef nonnull align 8 dereferenceable(1440) %20) #33
  %22 = icmp eq i32 %21, 0
  br i1 %22, label %23, label %32

23:                                               ; preds = %16
  %24 = getelementptr inbounds nuw i8, ptr %10, i64 8
  %25 = load ptr, ptr %24, align 8, !tbaa !913, !nonnull !17, !align !200
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 1380
  %27 = load i32, ptr %26, align 4, !tbaa !935
  %28 = icmp eq i32 %27, 0
  br i1 %28, label %29, label %32

29:                                               ; preds = %23
  %30 = getelementptr inbounds nuw i8, ptr %25, i64 928
  %31 = tail call noundef i32 @_ZNK4llvm6Triple27getDefaultExceptionHandlingEv(ptr noundef nonnull align 8 dereferenceable(56) %30) #33
  br label %32

32:                                               ; preds = %29, %23, %16
  %33 = phi i32 [ %21, %16 ], [ %31, %29 ], [ %27, %23 ]
  %34 = load ptr, ptr %10, align 8, !tbaa !4
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 856
  %36 = load ptr, ptr %35, align 8
  %37 = tail call i32 %36(ptr noundef nonnull align 8 dereferenceable(511459) %10, i32 noundef %33, ptr noundef %17) #33
  %38 = load ptr, ptr %10, align 8, !tbaa !4
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 864
  %40 = load ptr, ptr %39, align 8
  %41 = tail call i32 %40(ptr noundef nonnull align 8 dereferenceable(511459) %10, i32 noundef %33, ptr noundef %17) #33
  br label %42

42:                                               ; preds = %32, %2
  %43 = phi i32 [ %41, %32 ], [ 0, %2 ]
  %44 = phi i32 [ %37, %32 ], [ 0, %2 ]
  store i32 %44, ptr %0, align 8, !tbaa !451
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 4
  store i32 %43, ptr %45, align 4, !tbaa !451
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %47 = getelementptr inbounds nuw i8, ptr %1, i64 112
  %48 = load ptr, ptr %47, align 8, !tbaa !19
  store ptr %48, ptr %46, align 8, !tbaa !1035
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %50 = getelementptr inbounds nuw i8, ptr %1, i64 120
  %51 = load i32, ptr %50, align 8, !tbaa !76
  %52 = zext i32 %51 to i64
  %53 = shl nuw nsw i64 %52, 3
  %54 = getelementptr inbounds nuw i8, ptr %48, i64 %53
  store ptr %54, ptr %49, align 8, !tbaa !1038
  %55 = getelementptr inbounds nuw i8, ptr %0, i64 24
  store ptr null, ptr %55, align 8, !tbaa !1039
  %56 = icmp eq i32 %51, 0
  br i1 %56, label %124, label %57

57:                                               ; preds = %42
  %58 = load ptr, ptr %48, align 8, !tbaa !289
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 184
  %60 = load ptr, ptr %59, align 8, !tbaa !379
  store ptr %60, ptr %55, align 8, !tbaa !379
  %61 = getelementptr inbounds nuw i8, ptr %58, i64 192
  %62 = load ptr, ptr %61, align 8, !tbaa !379
  %63 = icmp eq ptr %60, %62
  br i1 %63, label %64, label %76

64:                                               ; preds = %57, %68
  %65 = phi ptr [ %66, %68 ], [ %48, %57 ]
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 8
  %67 = icmp eq ptr %66, %54
  br i1 %67, label %122, label %68

68:                                               ; preds = %64
  %69 = load ptr, ptr %66, align 8, !tbaa !289
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 184
  %71 = load ptr, ptr %70, align 8, !tbaa !379
  %72 = getelementptr inbounds nuw i8, ptr %69, i64 192
  %73 = load ptr, ptr %72, align 8, !tbaa !379
  %74 = icmp eq ptr %71, %73
  br i1 %74, label %64, label %75, !llvm.loop !1040

75:                                               ; preds = %68
  store ptr %66, ptr %46, align 8, !tbaa !1035
  store ptr %71, ptr %55, align 8, !tbaa !379
  br label %76

76:                                               ; preds = %75, %57
  %77 = phi ptr [ %71, %75 ], [ %60, %57 ]
  %78 = phi ptr [ %69, %75 ], [ %58, %57 ]
  %79 = phi ptr [ %66, %75 ], [ %48, %57 ]
  %80 = getelementptr inbounds nuw i8, ptr %78, i64 216
  %81 = load i8, ptr %80, align 8, !tbaa !80, !range !16, !noundef !17
  %82 = trunc nuw i8 %81 to i1
  br i1 %82, label %83, label %124

83:                                               ; preds = %76
  %84 = load i32, ptr %77, align 4, !tbaa !522
  %85 = icmp eq i32 %84, %44
  %86 = icmp eq i32 %84, %43
  %87 = select i1 %85, i1 true, i1 %86
  br i1 %87, label %88, label %124

88:                                               ; preds = %83, %117
  %89 = phi ptr [ %110, %117 ], [ %79, %83 ]
  %90 = phi ptr [ %111, %117 ], [ %78, %83 ]
  %91 = phi ptr [ %112, %117 ], [ %79, %83 ]
  %92 = phi ptr [ %113, %117 ], [ %77, %83 ]
  %93 = getelementptr inbounds nuw i8, ptr %92, i64 16
  store ptr %93, ptr %55, align 8, !tbaa !1039
  %94 = getelementptr inbounds nuw i8, ptr %90, i64 192
  %95 = load ptr, ptr %94, align 8, !tbaa !379
  %96 = icmp eq ptr %93, %95
  br i1 %96, label %97, label %109

97:                                               ; preds = %88, %101
  %98 = phi ptr [ %99, %101 ], [ %91, %88 ]
  %99 = getelementptr inbounds nuw i8, ptr %98, i64 8
  %100 = icmp eq ptr %99, %54
  br i1 %100, label %122, label %101

101:                                              ; preds = %97
  %102 = load ptr, ptr %99, align 8, !tbaa !289
  %103 = getelementptr inbounds nuw i8, ptr %102, i64 184
  %104 = load ptr, ptr %103, align 8, !tbaa !379
  %105 = getelementptr inbounds nuw i8, ptr %102, i64 192
  %106 = load ptr, ptr %105, align 8, !tbaa !379
  %107 = icmp eq ptr %104, %106
  br i1 %107, label %97, label %108, !llvm.loop !1040

108:                                              ; preds = %101
  store ptr %104, ptr %55, align 8, !tbaa !379
  br label %109

109:                                              ; preds = %108, %88
  %110 = phi ptr [ %99, %108 ], [ %89, %88 ]
  %111 = phi ptr [ %102, %108 ], [ %90, %88 ]
  %112 = phi ptr [ %99, %108 ], [ %91, %88 ]
  %113 = phi ptr [ %104, %108 ], [ %93, %88 ]
  %114 = getelementptr inbounds nuw i8, ptr %111, i64 216
  %115 = load i8, ptr %114, align 8, !tbaa !80, !range !16, !noundef !17
  %116 = trunc nuw i8 %115 to i1
  br i1 %116, label %117, label %122

117:                                              ; preds = %109
  %118 = load i32, ptr %113, align 4, !tbaa !522
  %119 = icmp eq i32 %118, %44
  %120 = icmp eq i32 %118, %43
  %121 = select i1 %119, i1 true, i1 %120
  br i1 %121, label %88, label %122, !llvm.loop !1041

122:                                              ; preds = %64, %109, %117, %97
  %123 = phi ptr [ %54, %97 ], [ %110, %117 ], [ %110, %109 ], [ %54, %64 ]
  store ptr %123, ptr %46, align 8
  br label %124

124:                                              ; preds = %122, %42, %76, %83
  ret void
}

declare noundef ptr @_ZNK4llvm8Function16getPersonalityFnEv(ptr noundef nonnull align 8 dereferenceable(140)) local_unnamed_addr #4

declare noundef i32 @_ZNK4llvm6Module17getExceptionModelEv(ptr noundef nonnull align 8 dereferenceable(1440)) local_unnamed_addr #4

; Function Attrs: mustprogress nofree norecurse nosync nounwind memory(read, inaccessiblemem: write) uwtable
define dso_local noundef zeroext i1 @_ZNK4llvm17MachineBasicBlock26sizeWithoutDebugLargerThanEj(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, i32 noundef %1) local_unnamed_addr #11 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %4 = load ptr, ptr %3, align 8, !tbaa !75
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %6 = icmp eq ptr %4, %5
  br i1 %6, label %33, label %7

7:                                                ; preds = %2, %28
  %8 = phi ptr [ %31, %28 ], [ %4, %2 ]
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 52
  %10 = load i32, ptr %9, align 4, !tbaa !306, !noalias !1042
  switch i32 %10, label %33 [
    i32 25, label %11
    i32 18, label %11
    i32 17, label %11
    i32 16, label %11
    i32 15, label %11
    i32 14, label %11
  ]

11:                                               ; preds = %7, %7, %7, %7, %7, %7
  %12 = load i64, ptr %8, align 8, !noalias !1042
  %13 = and i64 %12, 4
  %14 = icmp eq i64 %13, 0
  br i1 %14, label %15, label %28

15:                                               ; preds = %11
  %16 = getelementptr inbounds nuw i8, ptr %8, i64 44
  %17 = load i32, ptr %16, align 4, !tbaa !309, !noalias !1042
  %18 = and i32 %17, 8
  %19 = icmp eq i32 %18, 0
  br i1 %19, label %28, label %20

20:                                               ; preds = %15, %20
  %21 = phi ptr [ %23, %20 ], [ %8, %15 ]
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 8
  %23 = load ptr, ptr %22, align 8, !tbaa !75, !noalias !1042
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 44
  %25 = load i32, ptr %24, align 4, !tbaa !309, !noalias !1042
  %26 = and i32 %25, 8
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %28, label %20, !llvm.loop !908

28:                                               ; preds = %20, %15, %11
  %29 = phi ptr [ %8, %11 ], [ %8, %15 ], [ %23, %20 ]
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 8
  %31 = load ptr, ptr %30, align 8, !tbaa !75, !noalias !1042
  %32 = icmp eq ptr %31, %5
  br i1 %32, label %33, label %7, !llvm.loop !1047

33:                                               ; preds = %7, %28, %2
  %34 = phi ptr [ %4, %2 ], [ %8, %7 ], [ %31, %28 ]
  %35 = icmp eq ptr %34, %5
  br i1 %35, label %93, label %36

36:                                               ; preds = %33, %90
  %37 = phi i32 [ %39, %90 ], [ 0, %33 ]
  %38 = phi ptr [ %91, %90 ], [ %34, %33 ]
  %39 = add i32 %37, 1
  %40 = icmp ugt i32 %39, %1
  br i1 %40, label %93, label %41

41:                                               ; preds = %36
  %42 = icmp ne ptr %38, null
  tail call void @llvm.assume(i1 %42)
  %43 = load i64, ptr %38, align 8
  %44 = and i64 %43, 4
  %45 = icmp eq i64 %44, 0
  br i1 %45, label %46, label %59

46:                                               ; preds = %41
  %47 = getelementptr inbounds nuw i8, ptr %38, i64 44
  %48 = load i32, ptr %47, align 4, !tbaa !309
  %49 = and i32 %48, 8
  %50 = icmp eq i32 %49, 0
  br i1 %50, label %59, label %51

51:                                               ; preds = %46, %51
  %52 = phi ptr [ %54, %51 ], [ %38, %46 ]
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 8
  %54 = load ptr, ptr %53, align 8, !tbaa !75
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 44
  %56 = load i32, ptr %55, align 4, !tbaa !309
  %57 = and i32 %56, 8
  %58 = icmp eq i32 %57, 0
  br i1 %58, label %59, label %51, !llvm.loop !908

59:                                               ; preds = %51, %46, %41
  %60 = phi ptr [ %38, %41 ], [ %38, %46 ], [ %54, %51 ]
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 8
  %62 = load ptr, ptr %61, align 8, !tbaa !75
  %63 = icmp eq ptr %62, %5
  br i1 %63, label %90, label %64

64:                                               ; preds = %59, %85
  %65 = phi ptr [ %88, %85 ], [ %62, %59 ]
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 52
  %67 = load i32, ptr %66, align 4, !tbaa !306
  switch i32 %67, label %90 [
    i32 25, label %68
    i32 18, label %68
    i32 17, label %68
    i32 16, label %68
    i32 15, label %68
    i32 14, label %68
  ]

68:                                               ; preds = %64, %64, %64, %64, %64, %64
  %69 = load i64, ptr %65, align 8
  %70 = and i64 %69, 4
  %71 = icmp eq i64 %70, 0
  br i1 %71, label %72, label %85

72:                                               ; preds = %68
  %73 = getelementptr inbounds nuw i8, ptr %65, i64 44
  %74 = load i32, ptr %73, align 4, !tbaa !309
  %75 = and i32 %74, 8
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %85, label %77

77:                                               ; preds = %72, %77
  %78 = phi ptr [ %80, %77 ], [ %65, %72 ]
  %79 = getelementptr inbounds nuw i8, ptr %78, i64 8
  %80 = load ptr, ptr %79, align 8, !tbaa !75
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 44
  %82 = load i32, ptr %81, align 4, !tbaa !309
  %83 = and i32 %82, 8
  %84 = icmp eq i32 %83, 0
  br i1 %84, label %85, label %77, !llvm.loop !908

85:                                               ; preds = %77, %72, %68
  %86 = phi ptr [ %65, %68 ], [ %65, %72 ], [ %80, %77 ]
  %87 = getelementptr inbounds nuw i8, ptr %86, i64 8
  %88 = load ptr, ptr %87, align 8, !tbaa !75
  %89 = icmp eq ptr %88, %5
  br i1 %89, label %90, label %64, !llvm.loop !1047

90:                                               ; preds = %64, %85, %59
  %91 = phi ptr [ %62, %59 ], [ %65, %64 ], [ %88, %85 ]
  %92 = icmp eq ptr %91, %5
  br i1 %92, label %93, label %36, !llvm.loop !1048

93:                                               ; preds = %36, %90, %33
  %94 = phi i1 [ false, %33 ], [ %40, %90 ], [ %40, %36 ]
  ret i1 %94
}

; Function Attrs: mustprogress nounwind uwtable
define dso_local void @_ZN4llvm17MachineBasicBlock38removePHIsIncomingValuesForPredecessorERKS0_(ptr noundef nonnull readonly align 8 captures(address) dereferenceable(288) %0, ptr noundef nonnull align 8 dereferenceable(288) %1) local_unnamed_addr #3 align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %4 = load ptr, ptr %3, align 8, !tbaa !75
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %6 = icmp eq ptr %4, %5
  br i1 %6, label %18, label %7

7:                                                ; preds = %2, %11
  %8 = phi ptr [ %13, %11 ], [ %4, %2 ]
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 52
  %10 = load i32, ptr %9, align 4, !tbaa !306
  switch i32 %10, label %15 [
    i32 74, label %11
    i32 0, label %11
  ]

11:                                               ; preds = %7, %7
  %12 = getelementptr inbounds nuw i8, ptr %8, i64 8
  %13 = load ptr, ptr %12, align 8, !tbaa !75
  %14 = icmp eq ptr %13, %5
  br i1 %14, label %15, label %7, !llvm.loop !307

15:                                               ; preds = %7, %11
  %16 = phi ptr [ %5, %11 ], [ %8, %7 ]
  %17 = icmp eq ptr %4, %16
  br i1 %17, label %18, label %19

18:                                               ; preds = %38, %2, %15
  ret void

19:                                               ; preds = %15, %38
  %20 = phi ptr [ %41, %38 ], [ %4, %15 ]
  %21 = tail call noundef i32 @_ZN4llvm12MachineInstr25removePHIIncomingValueForERKNS_17MachineBasicBlockE(ptr noundef nonnull align 8 dereferenceable(80) %20, ptr noundef nonnull align 8 dereferenceable(288) %1) #33
  %22 = load i64, ptr %20, align 8
  %23 = and i64 %22, 4
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %25, label %38

25:                                               ; preds = %19
  %26 = getelementptr inbounds nuw i8, ptr %20, i64 44
  %27 = load i32, ptr %26, align 4, !tbaa !309
  %28 = and i32 %27, 8
  %29 = icmp eq i32 %28, 0
  br i1 %29, label %38, label %30

30:                                               ; preds = %25, %30
  %31 = phi ptr [ %33, %30 ], [ %20, %25 ]
  %32 = getelementptr inbounds nuw i8, ptr %31, i64 8
  %33 = load ptr, ptr %32, align 8, !tbaa !75
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 44
  %35 = load i32, ptr %34, align 4, !tbaa !309
  %36 = and i32 %35, 8
  %37 = icmp eq i32 %36, 0
  br i1 %37, label %38, label %30, !llvm.loop !310

38:                                               ; preds = %30, %19, %25
  %39 = phi ptr [ %20, %19 ], [ %20, %25 ], [ %33, %30 ]
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 8
  %41 = load ptr, ptr %40, align 8, !tbaa !75
  %42 = icmp eq ptr %41, %16
  br i1 %42, label %18, label %19
}

declare noundef i32 @_ZN4llvm12MachineInstr25removePHIIncomingValueForERKNS_17MachineBasicBlockE(ptr noundef nonnull align 8 dereferenceable(80), ptr noundef nonnull align 8 dereferenceable(288)) local_unnamed_addr #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare ptr @llvm.invariant.start.p0(i64 immarg, ptr captures(none)) #0

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr noundef captures(none)) local_unnamed_addr #18

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden ptr @_ZN4llvm11iplist_implINS_12simple_ilistINS_12MachineInstrEJNS_23ilist_sentinel_trackingILb1EEEEEENS_12ilist_traitsIS2_EEE5eraseENS_14ilist_iteratorINS_12ilist_detail12node_optionsIS2_Lb1ELb1EvLb0EvEELb0ELb0EEESD_(ptr noundef nonnull align 8 dereferenceable(24) %0, ptr %1, ptr %2) local_unnamed_addr #3 comdat align 2 {
  %4 = icmp eq ptr %1, %2
  br i1 %4, label %30, label %5

5:                                                ; preds = %3, %14
  %6 = phi ptr [ %8, %14 ], [ %1, %3 ]
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 8
  %8 = load ptr, ptr %7, align 8, !tbaa !75
  %9 = tail call noundef ptr @_ZNK4llvm12MachineInstr5getMFEv(ptr noundef nonnull align 8 dereferenceable(80) %6) #33
  %10 = icmp eq ptr %9, null
  br i1 %10, label %14, label %11

11:                                               ; preds = %5
  tail call void @_ZN4llvm15MachineFunction13handleRemovalERNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057) %9, ptr noundef nonnull align 8 dereferenceable(80) %6) #33
  %12 = getelementptr inbounds nuw i8, ptr %9, i64 32
  %13 = load ptr, ptr %12, align 8, !tbaa !293
  tail call void @_ZN4llvm12MachineInstr29removeRegOperandsFromUseListsERNS_19MachineRegisterInfoE(ptr noundef nonnull align 8 dereferenceable(80) %6, ptr noundef nonnull align 8 dereferenceable(520) %13) #33
  br label %14

14:                                               ; preds = %5, %11
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 24
  store ptr null, ptr %15, align 8, !tbaa !294
  %16 = load i64, ptr %6, align 8
  %17 = and i64 %16, -8
  %18 = inttoptr i64 %17 to ptr
  %19 = load ptr, ptr %7, align 8, !tbaa !75
  %20 = load i64, ptr %19, align 8
  %21 = and i64 %20, 7
  %22 = or disjoint i64 %21, %17
  store i64 %22, ptr %19, align 8
  %23 = getelementptr inbounds nuw i8, ptr %18, i64 8
  store ptr %19, ptr %23, align 8, !tbaa !75
  %24 = load i64, ptr %6, align 8
  %25 = and i64 %24, 7
  store i64 %25, ptr %6, align 8
  store ptr null, ptr %7, align 8, !tbaa !75
  %26 = load ptr, ptr %0, align 8, !tbaa !83
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 32
  %28 = load ptr, ptr %27, align 8, !tbaa !74
  tail call void @_ZN4llvm15MachineFunction18deleteMachineInstrEPNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(1057) %28, ptr noundef nonnull %6) #33
  %29 = icmp eq ptr %8, %2
  br i1 %29, label %30, label %5, !llvm.loop !1049

30:                                               ; preds = %14, %3
  ret ptr %2
}

declare void @_ZN4llvm11raw_ostream16SetBufferAndModeEPcmNS0_10BufferKindE(ptr noundef nonnull align 8 dereferenceable(48), ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #19

; Function Attrs: cold noreturn
declare void @_ZSt20__throw_length_errorPKc(ptr noundef) local_unnamed_addr #20

; Function Attrs: nobuiltin allocsize(0)
declare noalias noundef nonnull ptr @_Znwm(i64 noundef) local_unnamed_addr #21

; Function Attrs: nobuiltin nounwind
declare void @_ZdlPvm(ptr noundef, i64 noundef) local_unnamed_addr #22

declare noundef ptr @_ZNK4llvm12MachineInstr5getMFEv(ptr noundef nonnull align 8 dereferenceable(80)) local_unnamed_addr #4

declare noundef zeroext i1 @_ZNK4llvm12MachineInstr19hasPropertyInBundleEmNS0_9QueryTypeE(ptr noundef nonnull align 8 dereferenceable(80), i64 noundef, i32 noundef) local_unnamed_addr #4

declare noundef nonnull align 8 dereferenceable(32) ptr @_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm(ptr noundef nonnull align 8 dereferenceable(32), ptr noundef, i64 noundef) local_unnamed_addr #4

declare void @_ZNK4llvm9SlotIndex5printERNS_11raw_ostreamE(ptr noundef nonnull align 8 dereferenceable(8), ptr noundef nonnull align 8 dereferenceable(48)) local_unnamed_addr #4

declare noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48), i8 noundef zeroext) local_unnamed_addr #4

; Function Attrs: cold noreturn
declare void @_ZSt25__throw_bad_function_callv() local_unnamed_addr #20

declare noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48), ptr noundef, i64 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_13PrintLaneMaskENS0_11LaneBitmaskEEUlS2_E_E9_M_invokeERKSt9_Any_dataS2_(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(48) %1) #3 comdat align 2 {
  %3 = alloca %class.anon.788, align 8
  %4 = alloca %"class.llvm::format_object.784", align 8
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4)
  %5 = load i64, ptr %0, align 8, !tbaa !452
  store ptr @.str.44, ptr %4, align 8, !tbaa !458, !alias.scope !1050
  %6 = getelementptr inbounds nuw i8, ptr %4, i64 8
  store i64 %5, ptr %6, align 8, !tbaa !466, !alias.scope !1050
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3) #33
  store ptr %4, ptr %3, align 8, !tbaa !467
  %7 = ptrtoint ptr %3 to i64
  %8 = call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsENS_12function_refIFiPcmEEE(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr nonnull @_ZN4llvm12function_refIFiPcmEE11callback_fnIZNS_lsIJmEEERNS_11raw_ostreamES7_NS_13format_objectIJDpT_EEEEUlS1_mE_EEilS1_m, i64 %7) #33
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3) #33
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4)
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden noundef zeroext i1 @_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_13PrintLaneMaskENS0_11LaneBitmaskEEUlS2_E_E10_M_managerERSt9_Any_dataRKS7_St18_Manager_operation(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(16) %1, i32 noundef %2) #3 comdat align 2 {
  switch i32 %2, label %8 [
    i32 1, label %4
    i32 0, label %5
    i32 2, label %6
  ]

4:                                                ; preds = %3
  store ptr %1, ptr %0, align 8, !tbaa !743
  br label %8

5:                                                ; preds = %3
  store ptr null, ptr %0, align 8, !tbaa !1053
  br label %8

6:                                                ; preds = %3
  %7 = load i64, ptr %1, align 8, !tbaa !454
  store i64 %7, ptr %0, align 8, !tbaa !454
  br label %8

8:                                                ; preds = %3, %6, %5, %4
  ret i1 false
}

declare noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsENS_12function_refIFiPcmEEE(ptr noundef nonnull align 8 dereferenceable(48), ptr, i64) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden noundef i32 @_ZN4llvm12function_refIFiPcmEE11callback_fnIZNS_lsIJmEEERNS_11raw_ostreamES7_NS_13format_objectIJDpT_EEEEUlS1_mE_EEilS1_m(i64 noundef %0, ptr noundef %1, i64 noundef %2) #3 comdat align 2 {
  %4 = inttoptr i64 %0 to ptr
  %5 = load ptr, ptr %4, align 8, !tbaa !1055, !nonnull !17, !align !200
  %6 = and i64 %2, 4294967295
  %7 = load ptr, ptr %5, align 8, !tbaa !458
  %8 = getelementptr inbounds nuw i8, ptr %5, i64 8
  %9 = load i64, ptr %8, align 8, !tbaa !454
  %10 = tail call noundef i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef %1, i64 noundef %6, ptr noundef %7, i64 noundef %9) #33
  ret i32 %10
}

; Function Attrs: nofree nounwind
declare noundef i32 @snprintf(ptr noalias noundef writeonly captures(none), i64 noundef, ptr noundef readonly captures(none), ...) local_unnamed_addr #23

declare noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEl(ptr noundef nonnull align 8 dereferenceable(48), i64 noundef) local_unnamed_addr #4

declare noundef i32 @_ZN4llvm17ModuleSlotTracker12getLocalSlotEPKNS_5ValueE(ptr noundef nonnull align 8 dereferenceable(112), ptr noundef) local_unnamed_addr #4

declare noundef ptr @_ZNK4llvm10BasicBlock9getModuleEv(ptr noundef nonnull align 8 dereferenceable(80)) local_unnamed_addr #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #12

declare noundef ptr @_ZN4llvm15MachineFunction18CreateMachineInstrERKNS_11MCInstrDescENS_8DebugLocEb(ptr noundef nonnull align 8 dereferenceable(1057), ptr noundef nonnull align 8 dereferenceable(32), ptr, i1 noundef zeroext) local_unnamed_addr #4

declare void @_ZN4llvm12MachineInstr13setPCSectionsERNS_15MachineFunctionEPNS_6MDNodeE(ptr noundef nonnull align 8 dereferenceable(80), ptr noundef nonnull align 8 dereferenceable(1057), ptr noundef) local_unnamed_addr #4

declare void @_ZN4llvm12MachineInstr15setMMRAMetadataERNS_15MachineFunctionEPNS_6MDNodeE(ptr noundef nonnull align 8 dereferenceable(80), ptr noundef nonnull align 8 dereferenceable(1057), ptr noundef) local_unnamed_addr #4

declare void @_ZN4llvm12MachineInstr21setDeactivationSymbolERNS_15MachineFunctionEPNS_5ValueE(ptr noundef nonnull align 8 dereferenceable(80), ptr noundef nonnull align 8 dereferenceable(1057), ptr noundef) local_unnamed_addr #4

declare void @_ZN4llvm12MachineInstr10addOperandERNS_15MachineFunctionERKNS_14MachineOperandE(ptr noundef nonnull align 8 dereferenceable(80), ptr noundef nonnull align 8 dereferenceable(1057), ptr noundef nonnull align 8 dereferenceable(32)) local_unnamed_addr #4

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #24

; Function Attrs: noreturn
declare void @_ZN4llvm22report_bad_alloc_errorEPKcb(ptr noundef, i1 noundef zeroext) local_unnamed_addr #25

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #26

declare void @_ZN4llvm13LiveIntervals19insertMBBInMapsImplEPNS_17MachineBasicBlockEb(ptr noundef nonnull align 8 dereferenceable(424), ptr noundef, i1 noundef zeroext) local_unnamed_addr #4

declare void @_ZN4llvm13LiveIntervals20reassignRegMaskSlotsERNS_17MachineBasicBlockES2_(ptr noundef nonnull align 8 dereferenceable(424), ptr noundef nonnull align 8 dereferenceable(288), ptr noundef nonnull align 8 dereferenceable(288)) local_unnamed_addr #4

declare noundef ptr @_ZNK4llvm16AnalysisResolver22getAnalysisIfAvailableEPKv(ptr noundef nonnull align 8 dereferenceable(32), ptr noundef) local_unnamed_addr #4

declare void @_ZN4llvm11SlotIndexes15renumberIndexesENS_14ilist_iteratorINS_12ilist_detail12node_optionsINS_14IndexListEntryELb0ELb0EvLb0EvEELb0ELb0EEE(ptr noundef nonnull align 8 dereferenceable(416), ptr) local_unnamed_addr #4

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden noundef nonnull ptr @_ZN4llvm20BumpPtrAllocatorImplINS_15MallocAllocatorELm4096ELm4096ELm128ELm8EE12AllocateSlowEmmNS_5AlignE(ptr noundef nonnull align 8 dereferenceable(80) %0, i64 noundef %1, i64 noundef %2, i8 %3) local_unnamed_addr #27 comdat align 2 {
  %5 = zext nneg i8 %3 to i64
  %6 = shl nuw i64 1, %5
  %7 = add i64 %6, -1
  %8 = add i64 %7, %2
  %9 = icmp ugt i64 %8, 4096
  br i1 %9, label %10, label %32

10:                                               ; preds = %4
  %11 = tail call noalias noundef nonnull ptr @_ZN4llvm15allocate_bufferEmm(i64 noundef %8, i64 noundef 16) #33
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 72
  %14 = load i32, ptr %13, align 8, !tbaa !76
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 76
  %16 = load i32, ptr %15, align 4, !tbaa !77
  %17 = icmp ult i32 %14, %16
  br i1 %17, label %19, label %18, !prof !483

18:                                               ; preds = %10
  tail call void @_ZN4llvm23SmallVectorTemplateBaseISt4pairIPvmELb1EE15growAndPushBackES3_(ptr noundef nonnull align 8 dereferenceable(16) %12, ptr nonnull %11, i64 %8)
  br label %26

19:                                               ; preds = %10
  %20 = zext i32 %14 to i64
  %21 = load ptr, ptr %12, align 8, !tbaa !19
  %22 = getelementptr inbounds nuw %"struct.std::pair.817", ptr %21, i64 %20
  store ptr %11, ptr %22, align 1
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 8
  store i64 %8, ptr %23, align 1
  %24 = load i32, ptr %13, align 8, !tbaa !76
  %25 = add i32 %24, 1
  store i32 %25, ptr %13, align 8, !tbaa !76
  br label %26

26:                                               ; preds = %18, %19
  %27 = ptrtoint ptr %11 to i64
  %28 = add i64 %7, %27
  %29 = sub i64 0, %6
  %30 = and i64 %28, %29
  %31 = inttoptr i64 %30 to ptr
  br label %62

32:                                               ; preds = %4
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %34 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %35 = load i32, ptr %34, align 8, !tbaa !76
  %36 = lshr i32 %35, 7
  %37 = tail call i32 @llvm.umin.i32(i32 %36, i32 30)
  %38 = zext nneg i32 %37 to i64
  %39 = shl nuw nsw i64 4096, %38
  %40 = tail call noalias noundef nonnull ptr @_ZN4llvm15allocate_bufferEmm(i64 noundef %39, i64 noundef 16) #33
  %41 = load i32, ptr %34, align 8, !tbaa !76
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 28
  %43 = load i32, ptr %42, align 4, !tbaa !77
  %44 = icmp ult i32 %41, %43
  br i1 %44, label %46, label %45, !prof !483

45:                                               ; preds = %32
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPvLb1EE15growAndPushBackES1_(ptr noundef nonnull align 8 dereferenceable(16) %33, ptr noundef nonnull %40)
  br label %52

46:                                               ; preds = %32
  %47 = zext i32 %41 to i64
  %48 = load ptr, ptr %33, align 8, !tbaa !19
  %49 = getelementptr inbounds nuw ptr, ptr %48, i64 %47
  store ptr %40, ptr %49, align 1
  %50 = load i32, ptr %34, align 8, !tbaa !76
  %51 = add i32 %50, 1
  store i32 %51, ptr %34, align 8, !tbaa !76
  br label %52

52:                                               ; preds = %45, %46
  %53 = ptrtoint ptr %40 to i64
  %54 = add i64 %53, 1
  %55 = add i64 %54, %39
  %56 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store i64 %55, ptr %56, align 8, !tbaa !888
  %57 = add i64 %7, %53
  %58 = sub i64 0, %6
  %59 = and i64 %57, %58
  %60 = inttoptr i64 %59 to ptr
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 %2
  store ptr %61, ptr %0, align 8, !tbaa !887
  br label %62

62:                                               ; preds = %52, %26
  %63 = phi ptr [ %31, %26 ], [ %60, %52 ]
  ret ptr %63
}

declare noalias noundef nonnull ptr @_ZN4llvm15allocate_bufferEmm(i64 noundef, i64 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm23SmallVectorTemplateBaseISt4pairIPvmELb1EE15growAndPushBackES3_(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr %1, i64 %2) local_unnamed_addr #27 comdat align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8, !tbaa !76
  %6 = zext i32 %5 to i64
  %7 = add nuw nsw i64 %6, 1
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull %8, i64 noundef %7, i64 noundef 16) #33
  %9 = load ptr, ptr %0, align 8, !tbaa !19
  %10 = load i32, ptr %4, align 8, !tbaa !76
  %11 = zext i32 %10 to i64
  %12 = getelementptr inbounds nuw %"struct.std::pair.817", ptr %9, i64 %11
  store ptr %1, ptr %12, align 1
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 8
  store i64 %2, ptr %13, align 1
  %14 = load i32, ptr %4, align 8, !tbaa !76
  %15 = add i32 %14, 1
  store i32 %15, ptr %4, align 8, !tbaa !76
  ret void
}

declare void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(16), ptr noundef, i64 noundef, i64 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm23SmallVectorTemplateBaseIPvLb1EE15growAndPushBackES1_(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef %1) local_unnamed_addr #27 comdat align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %4 = load i32, ptr %3, align 8, !tbaa !76
  %5 = zext i32 %4 to i64
  %6 = add nuw nsw i64 %5, 1
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull %7, i64 noundef %6, i64 noundef 8) #33
  %8 = load ptr, ptr %0, align 8, !tbaa !19
  %9 = load i32, ptr %3, align 8, !tbaa !76
  %10 = zext i32 %9 to i64
  %11 = getelementptr inbounds nuw ptr, ptr %8, i64 %10
  store ptr %1, ptr %11, align 1
  %12 = load i32, ptr %3, align 8, !tbaa !76
  %13 = add i32 %12, 1
  store i32 %13, ptr %3, align 8, !tbaa !76
  ret void
}

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm23SmallVectorTemplateBaseISt4pairINS_9SlotIndexES2_ELb1EE15growAndPushBackES3_(ptr noundef nonnull align 8 dereferenceable(16) %0, i64 %1, i64 %2) local_unnamed_addr #27 comdat align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8, !tbaa !76
  %6 = zext i32 %5 to i64
  %7 = add nuw nsw i64 %6, 1
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull %8, i64 noundef %7, i64 noundef 16) #33
  %9 = load ptr, ptr %0, align 8, !tbaa !19
  %10 = load i32, ptr %4, align 8, !tbaa !76
  %11 = zext i32 %10 to i64
  %12 = getelementptr inbounds nuw %"struct.std::pair.781", ptr %9, i64 %11
  store i64 %1, ptr %12, align 1
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 8
  store i64 %2, ptr %13, align 1
  %14 = load i32, ptr %4, align 8, !tbaa !76
  %15 = add i32 %14, 1
  store i32 %15, ptr %4, align 8, !tbaa !76
  ret void
}

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm23SmallVectorTemplateBaseISt4pairINS_9SlotIndexEPNS_17MachineBasicBlockEELb1EE15growAndPushBackES5_(ptr noundef nonnull align 8 dereferenceable(16) %0, i64 %1, ptr %2) local_unnamed_addr #27 comdat align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8, !tbaa !76
  %6 = zext i32 %5 to i64
  %7 = add nuw nsw i64 %6, 1
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull %8, i64 noundef %7, i64 noundef 16) #33
  %9 = load ptr, ptr %0, align 8, !tbaa !19
  %10 = load i32, ptr %4, align 8, !tbaa !76
  %11 = zext i32 %10 to i64
  %12 = getelementptr inbounds nuw %"struct.std::pair.815", ptr %9, i64 %11
  store i64 %1, ptr %12, align 1
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 8
  store ptr %2, ptr %13, align 1
  %14 = load i32, ptr %4, align 8, !tbaa !76
  %15 = add i32 %14, 1
  store i32 %15, ptr %4, align 8, !tbaa !76
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr void @_ZSt16__introsort_loopIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEElNS1_10less_firstEEvT_S8_T0_T1_(ptr noundef %0, ptr noundef %1, i64 noundef %2) local_unnamed_addr #3 comdat {
  %4 = ptrtoint ptr %0 to i64
  %5 = ptrtoint ptr %1 to i64
  %6 = sub i64 %5, %4
  %7 = icmp sgt i64 %6, 256
  br i1 %7, label %8, label %95

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 16
  br label %10

10:                                               ; preds = %8, %90
  %11 = phi i64 [ %6, %8 ], [ %93, %90 ]
  %12 = phi ptr [ %1, %8 ], [ %58, %90 ]
  %13 = phi i64 [ %2, %8 ], [ %91, %90 ]
  %14 = icmp eq i64 %13, 0
  br i1 %14, label %15, label %41

15:                                               ; preds = %10
  %16 = lshr exact i64 %11, 4
  %17 = add nsw i64 %16, -2
  %18 = lshr i64 %17, 1
  br label %19

19:                                               ; preds = %19, %15
  %20 = phi i64 [ %18, %15 ], [ %26, %19 ]
  %21 = getelementptr inbounds nuw %"struct.std::pair.815", ptr %0, i64 %20
  %22 = load i64, ptr %21, align 8
  %23 = getelementptr inbounds nuw i8, ptr %21, i64 8
  %24 = load ptr, ptr %23, align 8
  tail call void @_ZSt13__adjust_heapIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEElS5_NS1_10less_firstEEvT_T0_S9_T1_T2_(ptr noundef %0, i64 noundef %20, i64 noundef %16, i64 %22, ptr %24)
  %25 = icmp eq i64 %20, 0
  %26 = add nsw i64 %20, -1
  br i1 %25, label %27, label %19, !llvm.loop !1057

27:                                               ; preds = %19
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 8
  br label %29

29:                                               ; preds = %29, %27
  %30 = phi ptr [ %12, %27 ], [ %31, %29 ]
  %31 = getelementptr inbounds i8, ptr %30, i64 -16
  %32 = load i64, ptr %31, align 8
  %33 = getelementptr inbounds i8, ptr %30, i64 -8
  %34 = load ptr, ptr %33, align 8
  %35 = load i64, ptr %0, align 8, !tbaa !212
  store i64 %35, ptr %31, align 8, !tbaa !212
  %36 = load ptr, ptr %28, align 8, !tbaa !289
  store ptr %36, ptr %33, align 8, !tbaa !1058
  %37 = ptrtoint ptr %31 to i64
  %38 = sub i64 %37, %4
  %39 = ashr exact i64 %38, 4
  tail call void @_ZSt13__adjust_heapIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEElS5_NS1_10less_firstEEvT_T0_S9_T1_T2_(ptr noundef nonnull %0, i64 noundef 0, i64 noundef %39, i64 %32, ptr %34)
  %40 = icmp sgt i64 %38, 16
  br i1 %40, label %29, label %95, !llvm.loop !1060

41:                                               ; preds = %10
  %42 = lshr i64 %11, 5
  %43 = getelementptr inbounds nuw %"struct.std::pair.815", ptr %0, i64 %42
  %44 = getelementptr inbounds i8, ptr %12, i64 -16
  tail call void @_ZSt22__move_median_to_firstIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEENS1_10less_firstEEvT_S8_S8_S8_T0_(ptr noundef %0, ptr noundef nonnull %9, ptr noundef %43, ptr noundef nonnull %44)
  br label %45

45:                                               ; preds = %85, %41
  %46 = phi ptr [ %12, %41 ], [ %72, %85 ]
  %47 = phi ptr [ %9, %41 ], [ %69, %85 ]
  %48 = load i64, ptr %0, align 8, !tbaa !212
  %49 = and i64 %48, -8
  %50 = inttoptr i64 %49 to ptr
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 24
  %52 = load i32, ptr %51, align 8, !tbaa !819
  %53 = trunc i64 %48 to i32
  %54 = lshr i32 %53, 1
  %55 = and i32 %54, 3
  %56 = or i32 %55, %52
  br label %57

57:                                               ; preds = %57, %45
  %58 = phi ptr [ %47, %45 ], [ %69, %57 ]
  %59 = load i64, ptr %58, align 8
  %60 = and i64 %59, -8
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 24
  %63 = load i32, ptr %62, align 8, !tbaa !819
  %64 = trunc i64 %59 to i32
  %65 = lshr i32 %64, 1
  %66 = and i32 %65, 3
  %67 = or i32 %66, %63
  %68 = icmp ult i32 %67, %56
  %69 = getelementptr inbounds nuw i8, ptr %58, i64 16
  br i1 %68, label %57, label %70, !llvm.loop !1061

70:                                               ; preds = %57, %70
  %71 = phi ptr [ %72, %70 ], [ %46, %57 ]
  %72 = getelementptr inbounds i8, ptr %71, i64 -16
  %73 = load i64, ptr %72, align 8, !tbaa !212
  %74 = and i64 %73, -8
  %75 = inttoptr i64 %74 to ptr
  %76 = getelementptr inbounds nuw i8, ptr %75, i64 24
  %77 = load i32, ptr %76, align 8, !tbaa !819
  %78 = trunc i64 %73 to i32
  %79 = lshr i32 %78, 1
  %80 = and i32 %79, 3
  %81 = or i32 %80, %77
  %82 = icmp ult i32 %56, %81
  br i1 %82, label %70, label %83, !llvm.loop !1062

83:                                               ; preds = %70
  %84 = icmp ult ptr %58, %72
  br i1 %84, label %85, label %90

85:                                               ; preds = %83
  store i64 %73, ptr %58, align 8, !tbaa !212
  store i64 %59, ptr %72, align 8, !tbaa !212
  %86 = getelementptr inbounds nuw i8, ptr %58, i64 8
  %87 = getelementptr inbounds i8, ptr %71, i64 -8
  %88 = load ptr, ptr %86, align 8, !tbaa !289
  %89 = load ptr, ptr %87, align 8, !tbaa !289
  store ptr %89, ptr %86, align 8, !tbaa !289
  store ptr %88, ptr %87, align 8, !tbaa !289
  br label %45, !llvm.loop !1063

90:                                               ; preds = %83
  %91 = add nsw i64 %13, -1
  tail call void @_ZSt16__introsort_loopIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEElNS1_10less_firstEEvT_S8_T0_T1_(ptr noundef nonnull %58, ptr noundef %12, i64 noundef %91)
  %92 = ptrtoint ptr %58 to i64
  %93 = sub i64 %92, %4
  %94 = icmp sgt i64 %93, 256
  br i1 %94, label %10, label %95, !llvm.loop !1064

95:                                               ; preds = %90, %29, %3
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr void @_ZSt22__final_insertion_sortIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEENS1_10less_firstEEvT_S8_T0_(ptr noundef %0, ptr noundef %1) local_unnamed_addr #3 comdat {
  %3 = ptrtoint ptr %1 to i64
  %4 = ptrtoint ptr %0 to i64
  %5 = sub i64 %3, %4
  %6 = icmp sgt i64 %5, 256
  br i1 %6, label %7, label %176

7:                                                ; preds = %2
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 8
  br label %9

9:                                                ; preds = %120, %7
  %10 = phi i64 [ %123, %120 ], [ 0, %7 ]
  %11 = phi i64 [ %121, %120 ], [ 16, %7 ]
  %12 = phi ptr [ %13, %120 ], [ %0, %7 ]
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 %11
  %14 = load i64, ptr %0, align 8, !tbaa !212
  %15 = load i64, ptr %13, align 8
  %16 = and i64 %15, -8
  %17 = inttoptr i64 %16 to ptr
  %18 = getelementptr inbounds nuw i8, ptr %17, i64 24
  %19 = load i32, ptr %18, align 8, !tbaa !819
  %20 = trunc i64 %15 to i32
  %21 = lshr i32 %20, 1
  %22 = and i32 %21, 3
  %23 = or i32 %22, %19
  %24 = and i64 %14, -8
  %25 = inttoptr i64 %24 to ptr
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 24
  %27 = load i32, ptr %26, align 8, !tbaa !819
  %28 = trunc i64 %14 to i32
  %29 = lshr i32 %28, 1
  %30 = and i32 %29, 3
  %31 = or i32 %27, %30
  %32 = icmp ult i32 %23, %31
  %33 = getelementptr inbounds nuw i8, ptr %12, i64 24
  %34 = load ptr, ptr %33, align 8
  br i1 %32, label %35, label %86

35:                                               ; preds = %9
  %36 = add i64 %10, 1
  %37 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %38 = and i64 %36, 3
  %39 = and i64 %10, 3
  %40 = icmp eq i64 %39, 3
  br i1 %40, label %53, label %41

41:                                               ; preds = %35, %41
  %42 = phi ptr [ %46, %41 ], [ %37, %35 ]
  %43 = phi ptr [ %45, %41 ], [ %13, %35 ]
  %44 = phi i64 [ %51, %41 ], [ 0, %35 ]
  %45 = getelementptr inbounds i8, ptr %43, i64 -16
  %46 = getelementptr inbounds i8, ptr %42, i64 -16
  %47 = load i64, ptr %45, align 8, !tbaa !212
  store i64 %47, ptr %46, align 8, !tbaa !212
  %48 = getelementptr inbounds i8, ptr %43, i64 -8
  %49 = load ptr, ptr %48, align 8, !tbaa !289
  %50 = getelementptr inbounds i8, ptr %42, i64 -8
  store ptr %49, ptr %50, align 8, !tbaa !1058
  %51 = add i64 %44, 1
  %52 = icmp eq i64 %51, %38
  br i1 %52, label %53, label %41, !llvm.loop !1065

53:                                               ; preds = %41, %35
  %54 = phi ptr [ %37, %35 ], [ %46, %41 ]
  %55 = phi ptr [ %13, %35 ], [ %45, %41 ]
  %56 = icmp ult i64 %10, 3
  br i1 %56, label %85, label %57

57:                                               ; preds = %53, %57
  %58 = phi ptr [ %79, %57 ], [ %54, %53 ]
  %59 = phi ptr [ %78, %57 ], [ %55, %53 ]
  %60 = getelementptr inbounds i8, ptr %59, i64 -16
  %61 = getelementptr inbounds i8, ptr %58, i64 -16
  %62 = load i64, ptr %60, align 8, !tbaa !212
  store i64 %62, ptr %61, align 8, !tbaa !212
  %63 = getelementptr inbounds i8, ptr %59, i64 -8
  %64 = load ptr, ptr %63, align 8, !tbaa !289
  %65 = getelementptr inbounds i8, ptr %58, i64 -8
  store ptr %64, ptr %65, align 8, !tbaa !1058
  %66 = getelementptr inbounds i8, ptr %59, i64 -32
  %67 = getelementptr inbounds i8, ptr %58, i64 -32
  %68 = load i64, ptr %66, align 8, !tbaa !212
  store i64 %68, ptr %67, align 8, !tbaa !212
  %69 = getelementptr inbounds i8, ptr %59, i64 -24
  %70 = load ptr, ptr %69, align 8, !tbaa !289
  %71 = getelementptr inbounds i8, ptr %58, i64 -24
  store ptr %70, ptr %71, align 8, !tbaa !1058
  %72 = getelementptr inbounds i8, ptr %59, i64 -48
  %73 = getelementptr inbounds i8, ptr %58, i64 -48
  %74 = load i64, ptr %72, align 8, !tbaa !212
  store i64 %74, ptr %73, align 8, !tbaa !212
  %75 = getelementptr inbounds i8, ptr %59, i64 -40
  %76 = load ptr, ptr %75, align 8, !tbaa !289
  %77 = getelementptr inbounds i8, ptr %58, i64 -40
  store ptr %76, ptr %77, align 8, !tbaa !1058
  %78 = getelementptr inbounds i8, ptr %59, i64 -64
  %79 = getelementptr inbounds i8, ptr %58, i64 -64
  %80 = load i64, ptr %78, align 8, !tbaa !212
  store i64 %80, ptr %79, align 8, !tbaa !212
  %81 = getelementptr inbounds i8, ptr %59, i64 -56
  %82 = load ptr, ptr %81, align 8, !tbaa !289
  %83 = getelementptr inbounds i8, ptr %58, i64 -56
  store ptr %82, ptr %83, align 8, !tbaa !1058
  %84 = icmp eq ptr %0, %78
  br i1 %84, label %85, label %57, !llvm.loop !1066

85:                                               ; preds = %57, %53
  store i64 %15, ptr %0, align 8, !tbaa !212
  store ptr %34, ptr %8, align 8, !tbaa !1058
  br label %120

86:                                               ; preds = %9
  %87 = load i64, ptr %12, align 8, !tbaa !212
  %88 = and i64 %87, -8
  %89 = inttoptr i64 %88 to ptr
  %90 = getelementptr inbounds nuw i8, ptr %89, i64 24
  %91 = load i32, ptr %90, align 8, !tbaa !819
  %92 = trunc i64 %87 to i32
  %93 = lshr i32 %92, 1
  %94 = and i32 %93, 3
  %95 = or i32 %94, %91
  %96 = icmp ult i32 %23, %95
  br i1 %96, label %97, label %117

97:                                               ; preds = %86, %97
  %98 = phi i64 [ %105, %97 ], [ %87, %86 ]
  %99 = phi ptr [ %104, %97 ], [ %12, %86 ]
  %100 = phi ptr [ %99, %97 ], [ %13, %86 ]
  store i64 %98, ptr %100, align 8, !tbaa !212
  %101 = getelementptr inbounds i8, ptr %100, i64 -8
  %102 = load ptr, ptr %101, align 8, !tbaa !289
  %103 = getelementptr inbounds nuw i8, ptr %100, i64 8
  store ptr %102, ptr %103, align 8, !tbaa !1058
  %104 = getelementptr inbounds i8, ptr %99, i64 -16
  %105 = load i64, ptr %104, align 8, !tbaa !212
  %106 = load i32, ptr %18, align 8, !tbaa !819
  %107 = or i32 %106, %22
  %108 = and i64 %105, -8
  %109 = inttoptr i64 %108 to ptr
  %110 = getelementptr inbounds nuw i8, ptr %109, i64 24
  %111 = load i32, ptr %110, align 8, !tbaa !819
  %112 = trunc i64 %105 to i32
  %113 = lshr i32 %112, 1
  %114 = and i32 %113, 3
  %115 = or i32 %114, %111
  %116 = icmp ult i32 %107, %115
  br i1 %116, label %97, label %117, !llvm.loop !1067

117:                                              ; preds = %97, %86
  %118 = phi ptr [ %13, %86 ], [ %99, %97 ]
  store i64 %15, ptr %118, align 8, !tbaa !212
  %119 = getelementptr inbounds nuw i8, ptr %118, i64 8
  store ptr %34, ptr %119, align 8, !tbaa !1058
  br label %120

120:                                              ; preds = %117, %85
  %121 = add nuw nsw i64 %11, 16
  %122 = icmp eq i64 %121, 256
  %123 = add i64 %10, 1
  br i1 %122, label %124, label %9, !llvm.loop !1068

124:                                              ; preds = %120
  %125 = getelementptr inbounds nuw i8, ptr %0, i64 256
  %126 = icmp eq ptr %125, %1
  br i1 %126, label %297, label %127

127:                                              ; preds = %124, %171
  %128 = phi ptr [ %174, %171 ], [ %125, %124 ]
  %129 = load i64, ptr %128, align 8
  %130 = getelementptr inbounds nuw i8, ptr %128, i64 8
  %131 = load ptr, ptr %130, align 8
  %132 = and i64 %129, -8
  %133 = inttoptr i64 %132 to ptr
  %134 = getelementptr inbounds nuw i8, ptr %133, i64 24
  %135 = trunc i64 %129 to i32
  %136 = lshr i32 %135, 1
  %137 = and i32 %136, 3
  %138 = getelementptr inbounds i8, ptr %128, i64 -16
  %139 = load i64, ptr %138, align 8, !tbaa !212
  %140 = load i32, ptr %134, align 8, !tbaa !819
  %141 = or i32 %140, %137
  %142 = and i64 %139, -8
  %143 = inttoptr i64 %142 to ptr
  %144 = getelementptr inbounds nuw i8, ptr %143, i64 24
  %145 = load i32, ptr %144, align 8, !tbaa !819
  %146 = trunc i64 %139 to i32
  %147 = lshr i32 %146, 1
  %148 = and i32 %147, 3
  %149 = or i32 %148, %145
  %150 = icmp ult i32 %141, %149
  br i1 %150, label %151, label %171

151:                                              ; preds = %127, %151
  %152 = phi i64 [ %159, %151 ], [ %139, %127 ]
  %153 = phi ptr [ %158, %151 ], [ %138, %127 ]
  %154 = phi ptr [ %153, %151 ], [ %128, %127 ]
  store i64 %152, ptr %154, align 8, !tbaa !212
  %155 = getelementptr inbounds i8, ptr %154, i64 -8
  %156 = load ptr, ptr %155, align 8, !tbaa !289
  %157 = getelementptr inbounds nuw i8, ptr %154, i64 8
  store ptr %156, ptr %157, align 8, !tbaa !1058
  %158 = getelementptr inbounds i8, ptr %153, i64 -16
  %159 = load i64, ptr %158, align 8, !tbaa !212
  %160 = load i32, ptr %134, align 8, !tbaa !819
  %161 = or i32 %160, %137
  %162 = and i64 %159, -8
  %163 = inttoptr i64 %162 to ptr
  %164 = getelementptr inbounds nuw i8, ptr %163, i64 24
  %165 = load i32, ptr %164, align 8, !tbaa !819
  %166 = trunc i64 %159 to i32
  %167 = lshr i32 %166, 1
  %168 = and i32 %167, 3
  %169 = or i32 %168, %165
  %170 = icmp ult i32 %161, %169
  br i1 %170, label %151, label %171, !llvm.loop !1067

171:                                              ; preds = %151, %127
  %172 = phi ptr [ %128, %127 ], [ %153, %151 ]
  store i64 %129, ptr %172, align 8, !tbaa !212
  %173 = getelementptr inbounds nuw i8, ptr %172, i64 8
  store ptr %131, ptr %173, align 8, !tbaa !1058
  %174 = getelementptr inbounds nuw i8, ptr %128, i64 16
  %175 = icmp eq ptr %174, %1
  br i1 %175, label %297, label %127, !llvm.loop !1069

176:                                              ; preds = %2
  %177 = icmp eq ptr %0, %1
  br i1 %177, label %297, label %178

178:                                              ; preds = %176
  %179 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %180 = icmp eq ptr %179, %1
  br i1 %180, label %297, label %181

181:                                              ; preds = %178
  %182 = getelementptr inbounds nuw i8, ptr %0, i64 8
  br label %183

183:                                              ; preds = %293, %181
  %184 = phi i64 [ %296, %293 ], [ 0, %181 ]
  %185 = phi ptr [ %294, %293 ], [ %179, %181 ]
  %186 = phi ptr [ %185, %293 ], [ %0, %181 ]
  %187 = load i64, ptr %0, align 8, !tbaa !212
  %188 = load i64, ptr %185, align 8
  %189 = and i64 %188, -8
  %190 = inttoptr i64 %189 to ptr
  %191 = getelementptr inbounds nuw i8, ptr %190, i64 24
  %192 = load i32, ptr %191, align 8, !tbaa !819
  %193 = trunc i64 %188 to i32
  %194 = lshr i32 %193, 1
  %195 = and i32 %194, 3
  %196 = or i32 %195, %192
  %197 = and i64 %187, -8
  %198 = inttoptr i64 %197 to ptr
  %199 = getelementptr inbounds nuw i8, ptr %198, i64 24
  %200 = load i32, ptr %199, align 8, !tbaa !819
  %201 = trunc i64 %187 to i32
  %202 = lshr i32 %201, 1
  %203 = and i32 %202, 3
  %204 = or i32 %200, %203
  %205 = icmp ult i32 %196, %204
  %206 = getelementptr inbounds nuw i8, ptr %186, i64 24
  %207 = load ptr, ptr %206, align 8
  br i1 %205, label %208, label %259

208:                                              ; preds = %183
  %209 = add i64 %184, 1
  %210 = getelementptr inbounds nuw i8, ptr %186, i64 32
  %211 = and i64 %209, 3
  %212 = and i64 %184, 3
  %213 = icmp eq i64 %212, 3
  br i1 %213, label %226, label %214

214:                                              ; preds = %208, %214
  %215 = phi ptr [ %219, %214 ], [ %210, %208 ]
  %216 = phi ptr [ %218, %214 ], [ %185, %208 ]
  %217 = phi i64 [ %224, %214 ], [ 0, %208 ]
  %218 = getelementptr inbounds i8, ptr %216, i64 -16
  %219 = getelementptr inbounds i8, ptr %215, i64 -16
  %220 = load i64, ptr %218, align 8, !tbaa !212
  store i64 %220, ptr %219, align 8, !tbaa !212
  %221 = getelementptr inbounds i8, ptr %216, i64 -8
  %222 = load ptr, ptr %221, align 8, !tbaa !289
  %223 = getelementptr inbounds i8, ptr %215, i64 -8
  store ptr %222, ptr %223, align 8, !tbaa !1058
  %224 = add i64 %217, 1
  %225 = icmp eq i64 %224, %211
  br i1 %225, label %226, label %214, !llvm.loop !1070

226:                                              ; preds = %214, %208
  %227 = phi ptr [ %210, %208 ], [ %219, %214 ]
  %228 = phi ptr [ %185, %208 ], [ %218, %214 ]
  %229 = icmp ult i64 %184, 3
  br i1 %229, label %258, label %230

230:                                              ; preds = %226, %230
  %231 = phi ptr [ %252, %230 ], [ %227, %226 ]
  %232 = phi ptr [ %251, %230 ], [ %228, %226 ]
  %233 = getelementptr inbounds i8, ptr %232, i64 -16
  %234 = getelementptr inbounds i8, ptr %231, i64 -16
  %235 = load i64, ptr %233, align 8, !tbaa !212
  store i64 %235, ptr %234, align 8, !tbaa !212
  %236 = getelementptr inbounds i8, ptr %232, i64 -8
  %237 = load ptr, ptr %236, align 8, !tbaa !289
  %238 = getelementptr inbounds i8, ptr %231, i64 -8
  store ptr %237, ptr %238, align 8, !tbaa !1058
  %239 = getelementptr inbounds i8, ptr %232, i64 -32
  %240 = getelementptr inbounds i8, ptr %231, i64 -32
  %241 = load i64, ptr %239, align 8, !tbaa !212
  store i64 %241, ptr %240, align 8, !tbaa !212
  %242 = getelementptr inbounds i8, ptr %232, i64 -24
  %243 = load ptr, ptr %242, align 8, !tbaa !289
  %244 = getelementptr inbounds i8, ptr %231, i64 -24
  store ptr %243, ptr %244, align 8, !tbaa !1058
  %245 = getelementptr inbounds i8, ptr %232, i64 -48
  %246 = getelementptr inbounds i8, ptr %231, i64 -48
  %247 = load i64, ptr %245, align 8, !tbaa !212
  store i64 %247, ptr %246, align 8, !tbaa !212
  %248 = getelementptr inbounds i8, ptr %232, i64 -40
  %249 = load ptr, ptr %248, align 8, !tbaa !289
  %250 = getelementptr inbounds i8, ptr %231, i64 -40
  store ptr %249, ptr %250, align 8, !tbaa !1058
  %251 = getelementptr inbounds i8, ptr %232, i64 -64
  %252 = getelementptr inbounds i8, ptr %231, i64 -64
  %253 = load i64, ptr %251, align 8, !tbaa !212
  store i64 %253, ptr %252, align 8, !tbaa !212
  %254 = getelementptr inbounds i8, ptr %232, i64 -56
  %255 = load ptr, ptr %254, align 8, !tbaa !289
  %256 = getelementptr inbounds i8, ptr %231, i64 -56
  store ptr %255, ptr %256, align 8, !tbaa !1058
  %257 = icmp eq ptr %0, %251
  br i1 %257, label %258, label %230, !llvm.loop !1066

258:                                              ; preds = %230, %226
  store i64 %188, ptr %0, align 8, !tbaa !212
  store ptr %207, ptr %182, align 8, !tbaa !1058
  br label %293

259:                                              ; preds = %183
  %260 = load i64, ptr %186, align 8, !tbaa !212
  %261 = and i64 %260, -8
  %262 = inttoptr i64 %261 to ptr
  %263 = getelementptr inbounds nuw i8, ptr %262, i64 24
  %264 = load i32, ptr %263, align 8, !tbaa !819
  %265 = trunc i64 %260 to i32
  %266 = lshr i32 %265, 1
  %267 = and i32 %266, 3
  %268 = or i32 %267, %264
  %269 = icmp ult i32 %196, %268
  br i1 %269, label %270, label %290

270:                                              ; preds = %259, %270
  %271 = phi i64 [ %278, %270 ], [ %260, %259 ]
  %272 = phi ptr [ %277, %270 ], [ %186, %259 ]
  %273 = phi ptr [ %272, %270 ], [ %185, %259 ]
  store i64 %271, ptr %273, align 8, !tbaa !212
  %274 = getelementptr inbounds i8, ptr %273, i64 -8
  %275 = load ptr, ptr %274, align 8, !tbaa !289
  %276 = getelementptr inbounds nuw i8, ptr %273, i64 8
  store ptr %275, ptr %276, align 8, !tbaa !1058
  %277 = getelementptr inbounds i8, ptr %272, i64 -16
  %278 = load i64, ptr %277, align 8, !tbaa !212
  %279 = load i32, ptr %191, align 8, !tbaa !819
  %280 = or i32 %279, %195
  %281 = and i64 %278, -8
  %282 = inttoptr i64 %281 to ptr
  %283 = getelementptr inbounds nuw i8, ptr %282, i64 24
  %284 = load i32, ptr %283, align 8, !tbaa !819
  %285 = trunc i64 %278 to i32
  %286 = lshr i32 %285, 1
  %287 = and i32 %286, 3
  %288 = or i32 %287, %284
  %289 = icmp ult i32 %280, %288
  br i1 %289, label %270, label %290, !llvm.loop !1067

290:                                              ; preds = %270, %259
  %291 = phi ptr [ %185, %259 ], [ %272, %270 ]
  store i64 %188, ptr %291, align 8, !tbaa !212
  %292 = getelementptr inbounds nuw i8, ptr %291, i64 8
  store ptr %207, ptr %292, align 8, !tbaa !1058
  br label %293

293:                                              ; preds = %290, %258
  %294 = getelementptr inbounds nuw i8, ptr %185, i64 16
  %295 = icmp eq ptr %294, %1
  %296 = add i64 %184, 1
  br i1 %295, label %297, label %183, !llvm.loop !1068

297:                                              ; preds = %293, %171, %178, %176, %124
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr void @_ZSt13__adjust_heapIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEElS5_NS1_10less_firstEEvT_T0_S9_T1_T2_(ptr noundef %0, i64 noundef %1, i64 noundef %2, i64 %3, ptr %4) local_unnamed_addr #3 comdat {
  %6 = add nsw i64 %2, -1
  %7 = sdiv i64 %6, 2
  %8 = getelementptr i8, ptr %0, i64 16
  %9 = icmp slt i64 %1, %7
  br i1 %9, label %10, label %44

10:                                               ; preds = %5, %10
  %11 = phi i64 [ %36, %10 ], [ %1, %5 ]
  %12 = shl i64 %11, 1
  %13 = add i64 %12, 2
  %14 = getelementptr inbounds %"struct.std::pair.815", ptr %0, i64 %13
  %15 = getelementptr %"struct.std::pair.815", ptr %8, i64 %12
  %16 = load i64, ptr %15, align 8, !tbaa !212
  %17 = load i64, ptr %14, align 8
  %18 = and i64 %17, -8
  %19 = inttoptr i64 %18 to ptr
  %20 = getelementptr inbounds nuw i8, ptr %19, i64 24
  %21 = load i32, ptr %20, align 8, !tbaa !819
  %22 = trunc i64 %17 to i32
  %23 = lshr i32 %22, 1
  %24 = and i32 %23, 3
  %25 = or i32 %24, %21
  %26 = and i64 %16, -8
  %27 = inttoptr i64 %26 to ptr
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 24
  %29 = load i32, ptr %28, align 8, !tbaa !819
  %30 = trunc i64 %16 to i32
  %31 = lshr i32 %30, 1
  %32 = and i32 %31, 3
  %33 = or i32 %29, %32
  %34 = icmp ult i32 %25, %33
  %35 = or disjoint i64 %12, 1
  %36 = select i1 %34, i64 %35, i64 %13
  %37 = getelementptr inbounds %"struct.std::pair.815", ptr %0, i64 %36
  %38 = getelementptr inbounds %"struct.std::pair.815", ptr %0, i64 %11
  %39 = load i64, ptr %37, align 8, !tbaa !212
  store i64 %39, ptr %38, align 8, !tbaa !212
  %40 = getelementptr inbounds nuw i8, ptr %37, i64 8
  %41 = load ptr, ptr %40, align 8, !tbaa !289
  %42 = getelementptr inbounds nuw i8, ptr %38, i64 8
  store ptr %41, ptr %42, align 8, !tbaa !1058
  %43 = icmp slt i64 %36, %7
  br i1 %43, label %10, label %44, !llvm.loop !1071

44:                                               ; preds = %10, %5
  %45 = phi i64 [ %1, %5 ], [ %36, %10 ]
  %46 = and i64 %2, 1
  %47 = icmp eq i64 %46, 0
  br i1 %47, label %48, label %61

48:                                               ; preds = %44
  %49 = add nsw i64 %2, -2
  %50 = ashr exact i64 %49, 1
  %51 = icmp eq i64 %45, %50
  br i1 %51, label %52, label %61

52:                                               ; preds = %48
  %53 = shl nsw i64 %45, 1
  %54 = or disjoint i64 %53, 1
  %55 = getelementptr inbounds %"struct.std::pair.815", ptr %0, i64 %54
  %56 = getelementptr inbounds %"struct.std::pair.815", ptr %0, i64 %45
  %57 = load i64, ptr %55, align 8, !tbaa !212
  store i64 %57, ptr %56, align 8, !tbaa !212
  %58 = getelementptr inbounds nuw i8, ptr %55, i64 8
  %59 = load ptr, ptr %58, align 8, !tbaa !289
  %60 = getelementptr inbounds nuw i8, ptr %56, i64 8
  store ptr %59, ptr %60, align 8, !tbaa !1058
  br label %61

61:                                               ; preds = %52, %48, %44
  %62 = phi i64 [ %54, %52 ], [ %45, %48 ], [ %45, %44 ]
  %63 = icmp sgt i64 %62, %1
  br i1 %63, label %64, label %94

64:                                               ; preds = %61
  %65 = and i64 %3, -8
  %66 = inttoptr i64 %65 to ptr
  %67 = getelementptr inbounds nuw i8, ptr %66, i64 24
  %68 = trunc i64 %3 to i32
  %69 = lshr i32 %68, 1
  %70 = and i32 %69, 3
  br label %71

71:                                               ; preds = %88, %64
  %72 = phi i64 [ %62, %64 ], [ %74, %88 ]
  %73 = add nsw i64 %72, -1
  %74 = sdiv i64 %73, 2
  %75 = getelementptr inbounds %"struct.std::pair.815", ptr %0, i64 %74
  %76 = load i64, ptr %75, align 8
  %77 = and i64 %76, -8
  %78 = inttoptr i64 %77 to ptr
  %79 = getelementptr inbounds nuw i8, ptr %78, i64 24
  %80 = load i32, ptr %79, align 8, !tbaa !819
  %81 = trunc i64 %76 to i32
  %82 = lshr i32 %81, 1
  %83 = and i32 %82, 3
  %84 = or i32 %83, %80
  %85 = load i32, ptr %67, align 8, !tbaa !819
  %86 = or i32 %85, %70
  %87 = icmp ult i32 %84, %86
  br i1 %87, label %88, label %94

88:                                               ; preds = %71
  %89 = getelementptr inbounds %"struct.std::pair.815", ptr %0, i64 %72
  store i64 %76, ptr %89, align 8, !tbaa !212
  %90 = getelementptr inbounds nuw i8, ptr %75, i64 8
  %91 = load ptr, ptr %90, align 8, !tbaa !289
  %92 = getelementptr inbounds nuw i8, ptr %89, i64 8
  store ptr %91, ptr %92, align 8, !tbaa !1058
  %93 = icmp sgt i64 %74, %1
  br i1 %93, label %71, label %94, !llvm.loop !1072

94:                                               ; preds = %71, %88, %61
  %95 = phi i64 [ %62, %61 ], [ %72, %71 ], [ %74, %88 ]
  %96 = getelementptr inbounds %"struct.std::pair.815", ptr %0, i64 %95
  store i64 %3, ptr %96, align 8, !tbaa !212
  %97 = getelementptr inbounds nuw i8, ptr %96, i64 8
  store ptr %4, ptr %97, align 8, !tbaa !1058
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr void @_ZSt22__move_median_to_firstIPSt4pairIN4llvm9SlotIndexEPNS1_17MachineBasicBlockEENS1_10less_firstEEvT_S8_S8_S8_T0_(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) local_unnamed_addr #3 comdat {
  %5 = load i64, ptr %2, align 8, !tbaa !212
  %6 = load i64, ptr %1, align 8
  %7 = and i64 %6, -8
  %8 = inttoptr i64 %7 to ptr
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 24
  %10 = load i32, ptr %9, align 8, !tbaa !819
  %11 = trunc i64 %6 to i32
  %12 = lshr i32 %11, 1
  %13 = and i32 %12, 3
  %14 = or i32 %13, %10
  %15 = and i64 %5, -8
  %16 = inttoptr i64 %15 to ptr
  %17 = getelementptr inbounds nuw i8, ptr %16, i64 24
  %18 = load i32, ptr %17, align 8, !tbaa !819
  %19 = trunc i64 %5 to i32
  %20 = lshr i32 %19, 1
  %21 = and i32 %20, 3
  %22 = or i32 %18, %21
  %23 = icmp ult i32 %14, %22
  %24 = load i64, ptr %3, align 8, !tbaa !212
  %25 = and i64 %24, -8
  %26 = inttoptr i64 %25 to ptr
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 24
  %28 = load i32, ptr %27, align 8, !tbaa !819
  %29 = trunc i64 %24 to i32
  %30 = lshr i32 %29, 1
  %31 = and i32 %30, 3
  %32 = or i32 %31, %28
  br i1 %23, label %33, label %53

33:                                               ; preds = %4
  %34 = icmp ult i32 %22, %32
  br i1 %34, label %35, label %41

35:                                               ; preds = %33
  %36 = load i64, ptr %0, align 8, !tbaa !212
  store i64 %5, ptr %0, align 8, !tbaa !212
  store i64 %36, ptr %2, align 8, !tbaa !212
  %37 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %38 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %39 = load ptr, ptr %37, align 8, !tbaa !289
  %40 = load ptr, ptr %38, align 8, !tbaa !289
  store ptr %40, ptr %37, align 8, !tbaa !289
  store ptr %39, ptr %38, align 8, !tbaa !289
  br label %73

41:                                               ; preds = %33
  %42 = icmp ult i32 %14, %32
  %43 = load i64, ptr %0, align 8, !tbaa !212
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 8
  br i1 %42, label %45, label %49

45:                                               ; preds = %41
  store i64 %24, ptr %0, align 8, !tbaa !212
  store i64 %43, ptr %3, align 8, !tbaa !212
  %46 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %47 = load ptr, ptr %44, align 8, !tbaa !289
  %48 = load ptr, ptr %46, align 8, !tbaa !289
  store ptr %48, ptr %44, align 8, !tbaa !289
  store ptr %47, ptr %46, align 8, !tbaa !289
  br label %73

49:                                               ; preds = %41
  store i64 %6, ptr %0, align 8, !tbaa !212
  store i64 %43, ptr %1, align 8, !tbaa !212
  %50 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %51 = load ptr, ptr %44, align 8, !tbaa !289
  %52 = load ptr, ptr %50, align 8, !tbaa !289
  store ptr %52, ptr %44, align 8, !tbaa !289
  store ptr %51, ptr %50, align 8, !tbaa !289
  br label %73

53:                                               ; preds = %4
  %54 = icmp ult i32 %14, %32
  br i1 %54, label %55, label %61

55:                                               ; preds = %53
  %56 = load i64, ptr %0, align 8, !tbaa !212
  store i64 %6, ptr %0, align 8, !tbaa !212
  store i64 %56, ptr %1, align 8, !tbaa !212
  %57 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %58 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %59 = load ptr, ptr %57, align 8, !tbaa !289
  %60 = load ptr, ptr %58, align 8, !tbaa !289
  store ptr %60, ptr %57, align 8, !tbaa !289
  store ptr %59, ptr %58, align 8, !tbaa !289
  br label %73

61:                                               ; preds = %53
  %62 = icmp ult i32 %22, %32
  %63 = load i64, ptr %0, align 8, !tbaa !212
  %64 = getelementptr inbounds nuw i8, ptr %0, i64 8
  br i1 %62, label %65, label %69

65:                                               ; preds = %61
  store i64 %24, ptr %0, align 8, !tbaa !212
  store i64 %63, ptr %3, align 8, !tbaa !212
  %66 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %67 = load ptr, ptr %64, align 8, !tbaa !289
  %68 = load ptr, ptr %66, align 8, !tbaa !289
  store ptr %68, ptr %64, align 8, !tbaa !289
  store ptr %67, ptr %66, align 8, !tbaa !289
  br label %73

69:                                               ; preds = %61
  store i64 %5, ptr %0, align 8, !tbaa !212
  store i64 %63, ptr %2, align 8, !tbaa !212
  %70 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %71 = load ptr, ptr %64, align 8, !tbaa !289
  %72 = load ptr, ptr %70, align 8, !tbaa !289
  store ptr %72, ptr %64, align 8, !tbaa !289
  store ptr %71, ptr %70, align 8, !tbaa !289
  br label %73

73:                                               ; preds = %55, %69, %65, %35, %49, %45
  ret void
}

declare noundef i32 @_ZNK4llvm12MachineInstr18getNumExplicitDefsEv(ptr noundef nonnull align 8 dereferenceable(80)) local_unnamed_addr #4

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare void @_ZN4llvm15MachineFunction8Delegate6anchorEv(ptr noundef nonnull align 8 dereferenceable(8)) unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZN23SlotIndexUpdateDelegateD0Ev(ptr noundef nonnull align 8 dereferenceable(80) %0) unnamed_addr #3 comdat align 2 {
  store ptr getelementptr inbounds nuw inrange(-16, 48) (i8, ptr @_ZTV23SlotIndexUpdateDelegate, i64 16), ptr %0, align 8, !tbaa !4
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load ptr, ptr %2, align 8, !tbaa !787, !nonnull !17, !align !200
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 640
  store ptr null, ptr %4, align 8, !tbaa !786
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 48
  %7 = load ptr, ptr %6, align 8, !tbaa !19
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 56
  %9 = load i32, ptr %8, align 8, !tbaa !76
  %10 = zext i32 %9 to i64
  %11 = shl nuw nsw i64 %10, 3
  %12 = getelementptr inbounds nuw i8, ptr %7, i64 %11
  %13 = icmp eq i32 %9, 0
  br i1 %13, label %18, label %14

14:                                               ; preds = %1
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 16
  br label %35

16:                                               ; preds = %35
  %17 = load ptr, ptr %6, align 8, !tbaa !19
  br label %18

18:                                               ; preds = %16, %1
  %19 = phi ptr [ %17, %16 ], [ %7, %1 ]
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 64
  %21 = icmp eq ptr %19, %20
  br i1 %21, label %23, label %22

22:                                               ; preds = %18
  tail call void @free(ptr noundef %19) #33
  br label %23

23:                                               ; preds = %22, %18
  %24 = getelementptr inbounds nuw i8, ptr %0, i64 44
  %25 = load i32, ptr %24, align 4, !tbaa !788
  %26 = icmp eq i32 %25, 0
  br i1 %26, label %42, label %27

27:                                               ; preds = %23
  %28 = load ptr, ptr %5, align 8, !tbaa !789
  %29 = zext i32 %25 to i64
  %30 = shl nuw nsw i64 %29, 3
  %31 = add nuw nsw i64 %29, 31
  %32 = lshr i64 %31, 3
  %33 = and i64 %32, 1073741820
  %34 = add nuw nsw i64 %33, %30
  tail call void @_ZN4llvm17deallocate_bufferEPvmm(ptr noundef %28, i64 noundef %34, i64 noundef 8) #33
  br label %42

35:                                               ; preds = %35, %14
  %36 = phi ptr [ %7, %14 ], [ %40, %35 ]
  %37 = load ptr, ptr %36, align 8, !tbaa !481
  %38 = load ptr, ptr %15, align 8, !tbaa !772
  %39 = tail call i64 @_ZN4llvm11SlotIndexes24insertMachineInstrInMapsERNS_12MachineInstrEb(ptr noundef nonnull align 8 dereferenceable(416) %38, ptr noundef nonnull align 8 dereferenceable(80) %37, i1 noundef zeroext false)
  %40 = getelementptr inbounds nuw i8, ptr %36, i64 8
  %41 = icmp eq ptr %40, %12
  br i1 %41, label %16, label %35

42:                                               ; preds = %23, %27
  tail call void @_ZdlPvm(ptr noundef nonnull %0, i64 noundef 80) #34
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZN23SlotIndexUpdateDelegate18MF_HandleInsertionERN4llvm12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(80) %0, ptr noundef nonnull align 8 dereferenceable(80) %1) unnamed_addr #3 comdat align 2 {
  %3 = alloca ptr, align 8
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %5 = load ptr, ptr %4, align 8, !tbaa !772
  %6 = icmp eq ptr %5, null
  br i1 %6, label %10, label %7

7:                                                ; preds = %2
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 24
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3) #33
  store ptr %1, ptr %3, align 8, !tbaa !481
  %9 = call noundef zeroext i1 @_ZN4llvm9SetVectorIPNS_12MachineInstrENS_11SmallVectorIS2_Lj2EEENS_8DenseSetIS2_NS_12DenseMapInfoIS2_vEEEELj2EE6insertERKS2_(ptr noundef nonnull align 8 dereferenceable(56) %8, ptr noundef nonnull align 8 dereferenceable(8) %3)
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3) #33
  br label %10

10:                                               ; preds = %7, %2
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZN23SlotIndexUpdateDelegate16MF_HandleRemovalERN4llvm12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(80) %0, ptr noundef nonnull align 8 dereferenceable(80) %1) unnamed_addr #3 comdat align 2 {
  %3 = alloca ptr, align 8
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %5 = load ptr, ptr %4, align 8, !tbaa !772
  %6 = icmp eq ptr %5, null
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3) #33
  br i1 %6, label %12, label %7

7:                                                ; preds = %2
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 24
  store ptr %1, ptr %3, align 8, !tbaa !481
  %9 = call noundef zeroext i1 @_ZN4llvm9SetVectorIPNS_12MachineInstrENS_11SmallVectorIS2_Lj2EEENS_8DenseSetIS2_NS_12DenseMapInfoIS2_vEEEELj2EE6removeERKS2_(ptr noundef nonnull align 8 dereferenceable(56) %8, ptr noundef nonnull align 8 dereferenceable(8) %3)
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3) #33
  br i1 %9, label %13, label %10

10:                                               ; preds = %7
  %11 = load ptr, ptr %4, align 8, !tbaa !772
  call void @_ZN4llvm11SlotIndexes26removeMachineInstrFromMapsERNS_12MachineInstrEb(ptr noundef nonnull align 8 dereferenceable(416) %11, ptr noundef nonnull align 8 dereferenceable(80) %1, i1 noundef zeroext false) #33
  br label %13

12:                                               ; preds = %2
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3) #33
  br label %13

13:                                               ; preds = %12, %10, %7
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm15MachineFunction8Delegate19MF_HandleChangeDescERNS_12MachineInstrERKNS_11MCInstrDescE(ptr noundef nonnull align 8 dereferenceable(8) %0, ptr noundef nonnull align 8 dereferenceable(80) %1, ptr noundef nonnull align 8 dereferenceable(32) %2) unnamed_addr #3 comdat align 2 {
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden noundef zeroext i1 @_ZN4llvm9SetVectorIPNS_12MachineInstrENS_11SmallVectorIS2_Lj2EEENS_8DenseSetIS2_NS_12DenseMapInfoIS2_vEEEELj2EE6insertERKS2_(ptr noundef nonnull align 8 dereferenceable(56) %0, ptr noundef nonnull align 8 dereferenceable(8) %1) local_unnamed_addr #3 comdat align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %4 = load i32, ptr %3, align 8, !tbaa !1073
  %5 = icmp eq i32 %4, 0
  br i1 %5, label %6, label %71

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %8 = load ptr, ptr %7, align 8, !tbaa !19
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %10 = load i32, ptr %9, align 8, !tbaa !76
  %11 = zext i32 %10 to i64
  %12 = shl nuw nsw i64 %11, 3
  %13 = getelementptr inbounds nuw i8, ptr %8, i64 %12
  %14 = icmp eq i32 %10, 0
  br i1 %14, label %42, label %15

15:                                               ; preds = %6
  %16 = load ptr, ptr %1, align 8, !tbaa !481
  br label %17

17:                                               ; preds = %39, %15
  %18 = phi ptr [ %8, %15 ], [ %40, %39 ]
  %19 = load ptr, ptr %18, align 8, !tbaa !481
  %20 = icmp eq ptr %19, %16
  br i1 %20, label %42, label %21

21:                                               ; preds = %17
  %22 = getelementptr inbounds nuw i8, ptr %18, i64 8
  %23 = icmp eq ptr %22, %13
  br i1 %23, label %47, label %24, !llvm.loop !1074

24:                                               ; preds = %21
  %25 = load ptr, ptr %22, align 8, !tbaa !481
  %26 = icmp eq ptr %25, %16
  br i1 %26, label %42, label %27

27:                                               ; preds = %24
  %28 = getelementptr inbounds nuw i8, ptr %18, i64 16
  %29 = icmp eq ptr %28, %13
  br i1 %29, label %47, label %30, !llvm.loop !1074

30:                                               ; preds = %27
  %31 = load ptr, ptr %28, align 8, !tbaa !481
  %32 = icmp eq ptr %31, %16
  br i1 %32, label %42, label %33

33:                                               ; preds = %30
  %34 = getelementptr inbounds nuw i8, ptr %18, i64 24
  %35 = icmp eq ptr %34, %13
  br i1 %35, label %47, label %36, !llvm.loop !1074

36:                                               ; preds = %33
  %37 = load ptr, ptr %34, align 8, !tbaa !481
  %38 = icmp eq ptr %37, %16
  br i1 %38, label %42, label %39

39:                                               ; preds = %36
  %40 = getelementptr inbounds nuw i8, ptr %18, i64 32
  %41 = icmp eq ptr %40, %13
  br i1 %41, label %47, label %17, !llvm.loop !1075

42:                                               ; preds = %17, %24, %30, %36, %6
  %43 = phi ptr [ %8, %6 ], [ %18, %17 ], [ %22, %24 ], [ %28, %30 ], [ %34, %36 ]
  %44 = icmp eq ptr %43, %13
  br i1 %44, label %45, label %90

45:                                               ; preds = %42
  %46 = load ptr, ptr %1, align 8, !tbaa !481
  br label %47

47:                                               ; preds = %21, %27, %33, %39, %45
  %48 = phi ptr [ %46, %45 ], [ %16, %39 ], [ %16, %33 ], [ %16, %27 ], [ %16, %21 ]
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 36
  %50 = load i32, ptr %49, align 4, !tbaa !77
  %51 = icmp ult i32 %10, %50
  br i1 %51, label %54, label %52, !prof !483

52:                                               ; preds = %47
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_12MachineInstrELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %7, ptr noundef %48)
  %53 = load i32, ptr %9, align 8, !tbaa !76
  br label %58

54:                                               ; preds = %47
  %55 = getelementptr inbounds nuw ptr, ptr %8, i64 %11
  store ptr %48, ptr %55, align 1
  %56 = load i32, ptr %9, align 8, !tbaa !76
  %57 = add i32 %56, 1
  store i32 %57, ptr %9, align 8, !tbaa !76
  br label %58

58:                                               ; preds = %52, %54
  %59 = phi i32 [ %53, %52 ], [ %57, %54 ]
  %60 = icmp ugt i32 %59, 2
  br i1 %60, label %61, label %90

61:                                               ; preds = %58
  %62 = load ptr, ptr %7, align 8, !tbaa !19
  %63 = zext i32 %59 to i64
  %64 = shl nuw nsw i64 %63, 3
  %65 = getelementptr inbounds nuw i8, ptr %62, i64 %64
  br label %66

66:                                               ; preds = %61, %66
  %67 = phi ptr [ %69, %66 ], [ %62, %61 ]
  %68 = tail call { ptr, i8 } @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E24lookupOrInsertIntoBucketIRKS3_JEEESt4pairIPS9_bEOT_DpOT0_(ptr noundef nonnull align 8 dereferenceable(56) %0, ptr noundef nonnull align 8 dereferenceable(8) %67), !noalias !1076
  %69 = getelementptr inbounds nuw i8, ptr %67, i64 8
  %70 = icmp eq ptr %69, %65
  br i1 %70, label %90, label %66

71:                                               ; preds = %2
  %72 = tail call { ptr, i8 } @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E24lookupOrInsertIntoBucketIRKS3_JEEESt4pairIPS9_bEOT_DpOT0_(ptr noundef nonnull align 8 dereferenceable(24) %0, ptr noundef nonnull align 8 dereferenceable(8) %1), !noalias !1083
  %73 = extractvalue { ptr, i8 } %72, 1
  %74 = trunc nuw i8 %73 to i1
  br i1 %74, label %75, label %90

75:                                               ; preds = %71
  %76 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %77 = load ptr, ptr %1, align 8, !tbaa !481
  %78 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %79 = load i32, ptr %78, align 8, !tbaa !76
  %80 = getelementptr inbounds nuw i8, ptr %0, i64 36
  %81 = load i32, ptr %80, align 4, !tbaa !77
  %82 = icmp ult i32 %79, %81
  br i1 %82, label %84, label %83, !prof !483

83:                                               ; preds = %75
  tail call void @_ZN4llvm23SmallVectorTemplateBaseIPNS_12MachineInstrELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %76, ptr noundef %77)
  br label %90

84:                                               ; preds = %75
  %85 = zext i32 %79 to i64
  %86 = load ptr, ptr %76, align 8, !tbaa !19
  %87 = getelementptr inbounds nuw ptr, ptr %86, i64 %85
  store ptr %77, ptr %87, align 1
  %88 = load i32, ptr %78, align 8, !tbaa !76
  %89 = add i32 %88, 1
  store i32 %89, ptr %78, align 8, !tbaa !76
  br label %90

90:                                               ; preds = %66, %84, %83, %71, %42, %58
  %91 = phi i1 [ true, %58 ], [ false, %42 ], [ false, %71 ], [ true, %83 ], [ true, %84 ], [ true, %66 ]
  ret i1 %91
}

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm23SmallVectorTemplateBaseIPNS_12MachineInstrELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef %1) local_unnamed_addr #27 comdat align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %4 = load i32, ptr %3, align 8, !tbaa !76
  %5 = zext i32 %4 to i64
  %6 = add nuw nsw i64 %5, 1
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull %7, i64 noundef %6, i64 noundef 8) #33
  %8 = load ptr, ptr %0, align 8, !tbaa !19
  %9 = load i32, ptr %3, align 8, !tbaa !76
  %10 = zext i32 %9 to i64
  %11 = getelementptr inbounds nuw ptr, ptr %8, i64 %10
  store ptr %1, ptr %11, align 1
  %12 = load i32, ptr %3, align 8, !tbaa !76
  %13 = add i32 %12, 1
  store i32 %13, ptr %3, align 8, !tbaa !76
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden { ptr, i8 } @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E24lookupOrInsertIntoBucketIRKS3_JEEESt4pairIPS9_bEOT_DpOT0_(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr noundef nonnull align 8 dereferenceable(8) %1) local_unnamed_addr #3 comdat align 2 {
  %3 = alloca ptr, align 8
  %4 = load ptr, ptr %0, align 8, !tbaa !789, !noalias !1090
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8, !tbaa !1095, !noalias !1090
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %8 = load i32, ptr %7, align 4, !tbaa !788, !noalias !1090
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %45, label %10

10:                                               ; preds = %2
  %11 = add i32 %8, -1
  %12 = load ptr, ptr %1, align 8, !tbaa !481
  %13 = ptrtoint ptr %12 to i64
  %14 = mul i64 %13, -4658895280553007687
  %15 = lshr i64 %14, 31
  %16 = xor i64 %15, %14
  %17 = trunc i64 %16 to i32
  %18 = and i32 %11, %17
  %19 = zext i32 %18 to i64
  %20 = getelementptr inbounds nuw %"class.llvm::detail::DenseSetPair", ptr %4, i64 %19
  %21 = lshr i64 %19, 5
  %22 = getelementptr inbounds nuw i32, ptr %6, i64 %21
  %23 = load i32, ptr %22, align 4, !tbaa !451
  %24 = and i32 %18, 31
  %25 = shl nuw i32 1, %24
  %26 = and i32 %25, %23
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %45, label %28, !prof !480

28:                                               ; preds = %10, %33
  %29 = phi ptr [ %37, %33 ], [ %20, %10 ]
  %30 = phi i32 [ %35, %33 ], [ %18, %10 ]
  %31 = load ptr, ptr %29, align 8, !tbaa !481
  %32 = icmp eq ptr %12, %31
  br i1 %32, label %77, label %33, !prof !483

33:                                               ; preds = %28
  %34 = add nuw i32 %30, 1
  %35 = and i32 %34, %11
  %36 = zext i32 %35 to i64
  %37 = getelementptr inbounds nuw %"class.llvm::detail::DenseSetPair", ptr %4, i64 %36
  %38 = lshr i64 %36, 5
  %39 = getelementptr inbounds nuw i32, ptr %6, i64 %38
  %40 = load i32, ptr %39, align 4, !tbaa !451
  %41 = and i32 %35, 31
  %42 = shl nuw i32 1, %41
  %43 = and i32 %40, %42
  %44 = icmp eq i32 %43, 0
  br i1 %44, label %45, label %28, !prof !484, !llvm.loop !1096

45:                                               ; preds = %33, %2, %10
  %46 = phi ptr [ %20, %10 ], [ null, %2 ], [ %37, %33 ]
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3)
  store ptr %46, ptr %3, align 8, !tbaa !1097
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %48 = load i32, ptr %47, align 8, !tbaa !1073
  %49 = shl i32 %48, 2
  %50 = add i32 %49, 4
  %51 = mul i32 %8, 3
  %52 = icmp ult i32 %50, %51
  br i1 %52, label %59, label %53, !prof !483

53:                                               ; preds = %45
  %54 = shl i32 %8, 1
  tail call void @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E4growEj(ptr noundef nonnull align 1 dereferenceable(1) %0, i32 noundef %54)
  %55 = call noundef zeroext i1 @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E15LookupBucketForIS3_EEbRKT_RPS9_(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr noundef nonnull align 8 dereferenceable(8) %1, ptr noundef nonnull align 8 dereferenceable(8) %3)
  %56 = load ptr, ptr %3, align 8, !tbaa !1097
  %57 = load ptr, ptr %5, align 8, !tbaa !1095
  %58 = load ptr, ptr %0, align 8, !tbaa !789
  br label %59

59:                                               ; preds = %45, %53
  %60 = phi ptr [ %58, %53 ], [ %4, %45 ]
  %61 = phi ptr [ %57, %53 ], [ %6, %45 ]
  %62 = phi ptr [ %56, %53 ], [ %46, %45 ]
  %63 = ptrtoint ptr %62 to i64
  %64 = ptrtoint ptr %60 to i64
  %65 = sub i64 %63, %64
  %66 = ashr exact i64 %65, 3
  %67 = trunc i64 %66 to i32
  %68 = and i32 %67, 31
  %69 = shl nuw i32 1, %68
  %70 = lshr i64 %66, 5
  %71 = getelementptr inbounds nuw i32, ptr %61, i64 %70
  %72 = load i32, ptr %71, align 4, !tbaa !451
  %73 = or i32 %69, %72
  store i32 %73, ptr %71, align 4, !tbaa !451
  %74 = load i32, ptr %47, align 8, !tbaa !1073
  %75 = add i32 %74, 1
  store i32 %75, ptr %47, align 8, !tbaa !1073
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3)
  %76 = load ptr, ptr %1, align 8, !tbaa !481
  store ptr %76, ptr %62, align 8, !tbaa !481
  br label %77

77:                                               ; preds = %28, %59
  %78 = phi ptr [ %62, %59 ], [ %29, %28 ]
  %79 = phi i8 [ 1, %59 ], [ 0, %28 ]
  %80 = insertvalue { ptr, i8 } poison, ptr %78, 0
  %81 = insertvalue { ptr, i8 } %80, i8 %79, 1
  ret { ptr, i8 } %81
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden noundef zeroext i1 @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E15LookupBucketForIS3_EEbRKT_RPS9_(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr noundef nonnull align 8 dereferenceable(8) %1, ptr noundef nonnull align 8 dereferenceable(8) %2) local_unnamed_addr #3 comdat align 2 {
  %4 = load ptr, ptr %0, align 8, !tbaa !789, !noalias !1098
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8, !tbaa !1095, !noalias !1098
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %8 = load i32, ptr %7, align 4, !tbaa !788, !noalias !1098
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %45, label %10

10:                                               ; preds = %3
  %11 = add i32 %8, -1
  %12 = load ptr, ptr %1, align 8, !tbaa !481
  %13 = ptrtoint ptr %12 to i64
  %14 = mul i64 %13, -4658895280553007687
  %15 = lshr i64 %14, 31
  %16 = xor i64 %15, %14
  %17 = trunc i64 %16 to i32
  %18 = and i32 %11, %17
  %19 = zext i32 %18 to i64
  %20 = getelementptr inbounds nuw %"class.llvm::detail::DenseSetPair", ptr %4, i64 %19
  %21 = lshr i64 %19, 5
  %22 = getelementptr inbounds nuw i32, ptr %6, i64 %21
  %23 = load i32, ptr %22, align 4, !tbaa !451
  %24 = and i32 %18, 31
  %25 = shl nuw i32 1, %24
  %26 = and i32 %25, %23
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %45, label %28, !prof !480

28:                                               ; preds = %10, %33
  %29 = phi ptr [ %37, %33 ], [ %20, %10 ]
  %30 = phi i32 [ %35, %33 ], [ %18, %10 ]
  %31 = load ptr, ptr %29, align 8, !tbaa !481
  %32 = icmp eq ptr %12, %31
  br i1 %32, label %45, label %33, !prof !483

33:                                               ; preds = %28
  %34 = add nuw i32 %30, 1
  %35 = and i32 %34, %11
  %36 = zext i32 %35 to i64
  %37 = getelementptr inbounds nuw %"class.llvm::detail::DenseSetPair", ptr %4, i64 %36
  %38 = lshr i64 %36, 5
  %39 = getelementptr inbounds nuw i32, ptr %6, i64 %38
  %40 = load i32, ptr %39, align 4, !tbaa !451
  %41 = and i32 %35, 31
  %42 = shl nuw i32 1, %41
  %43 = and i32 %42, %40
  %44 = icmp eq i32 %43, 0
  br i1 %44, label %45, label %28, !prof !484, !llvm.loop !1096

45:                                               ; preds = %28, %33, %10, %3
  %46 = phi ptr [ null, %3 ], [ %20, %10 ], [ %37, %33 ], [ %29, %28 ]
  %47 = phi i1 [ false, %3 ], [ false, %10 ], [ %32, %33 ], [ %32, %28 ]
  store ptr %46, ptr %2, align 8, !tbaa !1097
  ret i1 %47
}

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E4growEj(ptr noundef nonnull align 1 dereferenceable(1) %0, i32 noundef %1) local_unnamed_addr #27 comdat align 2 {
  %3 = alloca %"class.llvm::DenseMap.523", align 16
  %4 = add i32 %1, -1
  %5 = zext i32 %4 to i64
  %6 = lshr i64 %5, 1
  %7 = or i64 %6, %5
  %8 = lshr i64 %7, 2
  %9 = or i64 %8, %7
  %10 = lshr i64 %9, 4
  %11 = or i64 %10, %9
  %12 = lshr i64 %11, 8
  %13 = or i64 %12, %11
  %14 = lshr i64 %13, 16
  %15 = or i64 %14, %13
  %16 = trunc nuw i64 %15 to i32
  %17 = add i32 %16, 1
  %18 = tail call noundef i32 @llvm.umax.i32(i32 %17, i32 64)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %3) #33
  %19 = getelementptr inbounds nuw i8, ptr %3, i64 20
  store i32 %18, ptr %19, align 4, !tbaa !788
  %20 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %21 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %22 = zext i32 %18 to i64
  %23 = shl nuw nsw i64 %22, 3
  %24 = add nuw nsw i64 %22, 31
  %25 = lshr i64 %24, 3
  %26 = and i64 %25, 1073741820
  %27 = add nuw nsw i64 %26, %23
  %28 = tail call noalias noundef nonnull ptr @_ZN4llvm15allocate_bufferEmm(i64 noundef %27, i64 noundef 8) #33
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 %23
  store ptr %28, ptr %3, align 16, !tbaa !789
  store ptr %29, ptr %21, align 8, !tbaa !1095
  store i32 0, ptr %20, align 16, !tbaa !1073
  tail call void @llvm.memset.p0.i64(ptr nonnull align 4 %29, i8 0, i64 %26, i1 false)
  call void @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E8moveFromERSA_(ptr noundef nonnull align 1 dereferenceable(1) %3, ptr noundef nonnull align 8 dereferenceable(24) %0)
  %30 = load <2 x ptr>, ptr %0, align 8, !tbaa !743
  %31 = load ptr, ptr %0, align 8, !tbaa !1097
  %32 = load <2 x ptr>, ptr %3, align 16, !tbaa !743
  store <2 x ptr> %32, ptr %0, align 8, !tbaa !743
  store <2 x ptr> %30, ptr %3, align 16, !tbaa !743
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %34 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %35 = load i32, ptr %34, align 4, !tbaa !451
  %36 = load <2 x i32>, ptr %33, align 4, !tbaa !451
  %37 = load <2 x i32>, ptr %20, align 16, !tbaa !451
  store <2 x i32> %37, ptr %33, align 4, !tbaa !451
  store <2 x i32> %36, ptr %20, align 16, !tbaa !451
  %38 = icmp eq i32 %35, 0
  br i1 %38, label %46, label %39

39:                                               ; preds = %2
  %40 = zext i32 %35 to i64
  %41 = shl nuw nsw i64 %40, 3
  %42 = add nuw nsw i64 %40, 31
  %43 = lshr i64 %42, 3
  %44 = and i64 %43, 1073741820
  %45 = add nuw nsw i64 %44, %41
  call void @_ZN4llvm17deallocate_bufferEPvmm(ptr noundef %31, i64 noundef %45, i64 noundef 8) #33
  br label %46

46:                                               ; preds = %2, %39
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %3) #33
  ret void
}

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E8moveFromERSA_(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr noundef nonnull align 8 dereferenceable(24) %1) local_unnamed_addr #27 comdat align 2 {
  %3 = load ptr, ptr %1, align 8, !tbaa !789
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %5 = load ptr, ptr %4, align 8, !tbaa !1095
  %6 = getelementptr inbounds nuw i8, ptr %1, i64 20
  %7 = load i32, ptr %6, align 4, !tbaa !788
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %9 = load ptr, ptr %8, align 8, !tbaa !1095
  %10 = load ptr, ptr %0, align 8, !tbaa !789
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %12 = load i32, ptr %11, align 4, !tbaa !788
  %13 = add i32 %12, -1
  %14 = icmp eq i32 %7, 0
  br i1 %14, label %15, label %19

15:                                               ; preds = %2
  %16 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %17 = load i32, ptr %16, align 8, !tbaa !1073
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store i32 %17, ptr %18, align 8, !tbaa !1073
  br label %91

19:                                               ; preds = %2
  %20 = zext i32 %7 to i64
  %21 = add nuw nsw i64 %20, 31
  %22 = lshr i64 %21, 5
  br label %23

23:                                               ; preds = %19, %75
  %24 = phi i64 [ 0, %19 ], [ %76, %75 ]
  %25 = getelementptr inbounds nuw i32, ptr %5, i64 %24
  %26 = load i32, ptr %25, align 4, !tbaa !451
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %75, label %28

28:                                               ; preds = %23
  %29 = trunc i64 %24 to i32
  %30 = shl i32 %29, 5
  br label %31

31:                                               ; preds = %28, %64
  %32 = phi i32 [ %26, %28 ], [ %73, %64 ]
  %33 = tail call noundef range(i32 0, 33) i32 @llvm.cttz.i32(i32 %32, i1 true)
  %34 = or disjoint i32 %33, %30
  %35 = zext i32 %34 to i64
  %36 = getelementptr inbounds nuw %"class.llvm::detail::DenseSetPair", ptr %3, i64 %35
  %37 = load ptr, ptr %36, align 8, !tbaa !481
  %38 = ptrtoint ptr %37 to i64
  %39 = mul i64 %38, -4658895280553007687
  %40 = lshr i64 %39, 31
  %41 = xor i64 %40, %39
  %42 = trunc i64 %41 to i32
  %43 = and i32 %13, %42
  %44 = zext i32 %43 to i64
  %45 = lshr i64 %44, 5
  %46 = getelementptr inbounds nuw i32, ptr %9, i64 %45
  %47 = load i32, ptr %46, align 4, !tbaa !451
  %48 = and i32 %43, 31
  %49 = shl nuw i32 1, %48
  %50 = and i32 %49, %47
  %51 = icmp eq i32 %50, 0
  br i1 %51, label %64, label %52

52:                                               ; preds = %31, %52
  %53 = phi i32 [ %55, %52 ], [ %43, %31 ]
  %54 = add i32 %53, 1
  %55 = and i32 %54, %13
  %56 = zext i32 %55 to i64
  %57 = lshr i64 %56, 5
  %58 = getelementptr inbounds nuw i32, ptr %9, i64 %57
  %59 = load i32, ptr %58, align 4, !tbaa !451
  %60 = and i32 %55, 31
  %61 = shl nuw i32 1, %60
  %62 = and i32 %61, %59
  %63 = icmp eq i32 %62, 0
  br i1 %63, label %64, label %52, !llvm.loop !1103

64:                                               ; preds = %52, %31
  %65 = phi i64 [ %45, %31 ], [ %57, %52 ]
  %66 = phi i64 [ %44, %31 ], [ %56, %52 ]
  %67 = phi i32 [ %47, %31 ], [ %59, %52 ]
  %68 = phi i32 [ %49, %31 ], [ %61, %52 ]
  %69 = getelementptr inbounds nuw i32, ptr %9, i64 %65
  %70 = getelementptr inbounds nuw %"class.llvm::detail::DenseSetPair", ptr %10, i64 %66
  store ptr %37, ptr %70, align 8, !tbaa !481
  %71 = or i32 %68, %67
  store i32 %71, ptr %69, align 4, !tbaa !451
  %72 = add i32 %32, -1
  %73 = and i32 %72, %32
  %74 = icmp eq i32 %73, 0
  br i1 %74, label %75, label %31, !llvm.loop !1104

75:                                               ; preds = %64, %23
  %76 = add nuw nsw i64 %24, 1
  %77 = icmp eq i64 %76, %22
  br i1 %77, label %78, label %23, !llvm.loop !1105

78:                                               ; preds = %75
  %79 = load i32, ptr %6, align 4, !tbaa !788
  %80 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %81 = load i32, ptr %80, align 8, !tbaa !1073
  %82 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store i32 %81, ptr %82, align 8, !tbaa !1073
  %83 = icmp eq i32 %79, 0
  br i1 %83, label %91, label %84

84:                                               ; preds = %78
  %85 = zext i32 %79 to i64
  %86 = shl nuw nsw i64 %85, 3
  %87 = add nuw nsw i64 %85, 31
  %88 = lshr i64 %87, 3
  %89 = and i64 %88, 1073741820
  %90 = add nuw nsw i64 %89, %86
  tail call void @_ZN4llvm17deallocate_bufferEPvmm(ptr noundef %3, i64 noundef %90, i64 noundef 8) #33
  store i32 0, ptr %6, align 4, !tbaa !788
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %1, i8 0, i64 16, i1 false)
  br label %91

91:                                               ; preds = %15, %78, %84
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.cttz.i32(i32, i1 immarg) #12

declare void @_ZN4llvm17deallocate_bufferEPvmm(ptr noundef, i64 noundef, i64 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden noundef zeroext i1 @_ZN4llvm9SetVectorIPNS_12MachineInstrENS_11SmallVectorIS2_Lj2EEENS_8DenseSetIS2_NS_12DenseMapInfoIS2_vEEEELj2EE6removeERKS2_(ptr noundef nonnull align 8 dereferenceable(56) %0, ptr noundef nonnull align 8 dereferenceable(8) %1) local_unnamed_addr #3 comdat align 2 {
  %3 = alloca %class.anon.834, align 1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %5 = load i32, ptr %4, align 8, !tbaa !1073
  %6 = icmp eq i32 %5, 0
  br i1 %6, label %7, label %62

7:                                                ; preds = %2
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %9 = load ptr, ptr %8, align 8, !tbaa !19
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %11 = load i32, ptr %10, align 8, !tbaa !76
  %12 = zext i32 %11 to i64
  %13 = shl nuw nsw i64 %12, 3
  %14 = getelementptr inbounds nuw i8, ptr %9, i64 %13
  %15 = icmp eq i32 %11, 0
  br i1 %15, label %43, label %16

16:                                               ; preds = %7
  %17 = load ptr, ptr %1, align 8, !tbaa !481
  br label %18

18:                                               ; preds = %40, %16
  %19 = phi ptr [ %9, %16 ], [ %41, %40 ]
  %20 = load ptr, ptr %19, align 8, !tbaa !481
  %21 = icmp eq ptr %20, %17
  br i1 %21, label %43, label %22

22:                                               ; preds = %18
  %23 = getelementptr inbounds nuw i8, ptr %19, i64 8
  %24 = icmp eq ptr %23, %14
  br i1 %24, label %43, label %25, !llvm.loop !1074

25:                                               ; preds = %22
  %26 = load ptr, ptr %23, align 8, !tbaa !481
  %27 = icmp eq ptr %26, %17
  br i1 %27, label %43, label %28

28:                                               ; preds = %25
  %29 = getelementptr inbounds nuw i8, ptr %19, i64 16
  %30 = icmp eq ptr %29, %14
  br i1 %30, label %43, label %31, !llvm.loop !1074

31:                                               ; preds = %28
  %32 = load ptr, ptr %29, align 8, !tbaa !481
  %33 = icmp eq ptr %32, %17
  br i1 %33, label %43, label %34

34:                                               ; preds = %31
  %35 = getelementptr inbounds nuw i8, ptr %19, i64 24
  %36 = icmp eq ptr %35, %14
  br i1 %36, label %43, label %37, !llvm.loop !1074

37:                                               ; preds = %34
  %38 = load ptr, ptr %35, align 8, !tbaa !481
  %39 = icmp eq ptr %38, %17
  br i1 %39, label %43, label %40

40:                                               ; preds = %37
  %41 = getelementptr inbounds nuw i8, ptr %19, i64 32
  %42 = icmp eq ptr %41, %14
  br i1 %42, label %43, label %18, !llvm.loop !1075

43:                                               ; preds = %18, %22, %25, %28, %31, %34, %37, %40, %7
  %44 = phi ptr [ %9, %7 ], [ %19, %18 ], [ %14, %22 ], [ %23, %25 ], [ %14, %28 ], [ %29, %31 ], [ %14, %34 ], [ %35, %37 ], [ %14, %40 ]
  %45 = getelementptr inbounds nuw ptr, ptr %9, i64 %12
  %46 = icmp eq ptr %44, %45
  br i1 %46, label %155, label %47

47:                                               ; preds = %43
  %48 = getelementptr inbounds nuw i8, ptr %44, i64 8
  %49 = ptrtoint ptr %45 to i64
  %50 = ptrtoint ptr %48 to i64
  %51 = sub i64 %49, %50
  %52 = icmp sgt i64 %51, 8
  br i1 %52, label %53, label %55, !prof !483

53:                                               ; preds = %47
  tail call void @llvm.memmove.p0.p0.i64(ptr align 8 %44, ptr nonnull align 8 %48, i64 %51, i1 false)
  %54 = load i32, ptr %10, align 8, !tbaa !76
  br label %59

55:                                               ; preds = %47
  %56 = icmp eq i64 %51, 8
  br i1 %56, label %57, label %59

57:                                               ; preds = %55
  %58 = load ptr, ptr %48, align 8, !tbaa !481
  store ptr %58, ptr %44, align 8, !tbaa !481
  br label %59

59:                                               ; preds = %53, %55, %57
  %60 = phi i32 [ %54, %53 ], [ %11, %55 ], [ %11, %57 ]
  %61 = add i32 %60, -1
  store i32 %61, ptr %10, align 8, !tbaa !76
  br label %155

62:                                               ; preds = %2
  %63 = load ptr, ptr %0, align 8, !tbaa !789, !noalias !1106
  %64 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %65 = load ptr, ptr %64, align 8, !tbaa !1095, !noalias !1106
  %66 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %67 = load i32, ptr %66, align 4, !tbaa !788, !noalias !1106
  %68 = add i32 %67, -1
  %69 = load ptr, ptr %1, align 8, !tbaa !481
  %70 = ptrtoint ptr %69 to i64
  %71 = mul i64 %70, -4658895280553007687
  %72 = lshr i64 %71, 31
  %73 = xor i64 %72, %71
  %74 = trunc i64 %73 to i32
  %75 = and i32 %68, %74
  %76 = zext i32 %75 to i64
  %77 = lshr i64 %76, 5
  %78 = getelementptr inbounds nuw i32, ptr %65, i64 %77
  %79 = load i32, ptr %78, align 4, !tbaa !451
  %80 = and i32 %75, 31
  %81 = shl nuw i32 1, %80
  %82 = and i32 %81, %79
  %83 = icmp eq i32 %82, 0
  br i1 %83, label %155, label %84, !prof !480

84:                                               ; preds = %62, %90
  %85 = phi i64 [ %93, %90 ], [ %76, %62 ]
  %86 = phi i32 [ %92, %90 ], [ %75, %62 ]
  %87 = getelementptr inbounds nuw %"class.llvm::detail::DenseSetPair", ptr %63, i64 %85
  %88 = load ptr, ptr %87, align 8, !tbaa !481
  %89 = icmp eq ptr %69, %88
  br i1 %89, label %101, label %90, !prof !483

90:                                               ; preds = %84
  %91 = add i32 %86, 1
  %92 = and i32 %91, %68
  %93 = zext i32 %92 to i64
  %94 = lshr i64 %93, 5
  %95 = getelementptr inbounds nuw i32, ptr %65, i64 %94
  %96 = load i32, ptr %95, align 4, !tbaa !451
  %97 = and i32 %92, 31
  %98 = shl nuw i32 1, %97
  %99 = and i32 %96, %98
  %100 = icmp eq i32 %99, 0
  br i1 %100, label %155, label %84, !prof !484

101:                                              ; preds = %84
  %102 = getelementptr inbounds nuw %"class.llvm::detail::DenseSetPair", ptr %63, i64 %85
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %3) #33
  call void @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E21eraseFromFilledBucketIZNSB_21eraseFromFilledBucketEPS9_EUlRS9_E_EEvSD_OT_(ptr noundef nonnull align 8 dereferenceable(24) %0, ptr noundef nonnull %102, ptr noundef nonnull align 1 dereferenceable(1) %3)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %3) #33
  %103 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %104 = load ptr, ptr %103, align 8, !tbaa !19
  %105 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %106 = load i32, ptr %105, align 8, !tbaa !76
  %107 = zext i32 %106 to i64
  %108 = shl nuw nsw i64 %107, 3
  %109 = getelementptr inbounds nuw i8, ptr %104, i64 %108
  %110 = icmp eq i32 %106, 0
  br i1 %110, label %138, label %111

111:                                              ; preds = %101
  %112 = load ptr, ptr %1, align 8, !tbaa !481
  br label %113

113:                                              ; preds = %135, %111
  %114 = phi ptr [ %104, %111 ], [ %136, %135 ]
  %115 = load ptr, ptr %114, align 8, !tbaa !481
  %116 = icmp eq ptr %115, %112
  br i1 %116, label %138, label %117

117:                                              ; preds = %113
  %118 = getelementptr inbounds nuw i8, ptr %114, i64 8
  %119 = icmp eq ptr %118, %109
  br i1 %119, label %138, label %120, !llvm.loop !1074

120:                                              ; preds = %117
  %121 = load ptr, ptr %118, align 8, !tbaa !481
  %122 = icmp eq ptr %121, %112
  br i1 %122, label %138, label %123

123:                                              ; preds = %120
  %124 = getelementptr inbounds nuw i8, ptr %114, i64 16
  %125 = icmp eq ptr %124, %109
  br i1 %125, label %138, label %126, !llvm.loop !1074

126:                                              ; preds = %123
  %127 = load ptr, ptr %124, align 8, !tbaa !481
  %128 = icmp eq ptr %127, %112
  br i1 %128, label %138, label %129

129:                                              ; preds = %126
  %130 = getelementptr inbounds nuw i8, ptr %114, i64 24
  %131 = icmp eq ptr %130, %109
  br i1 %131, label %138, label %132, !llvm.loop !1074

132:                                              ; preds = %129
  %133 = load ptr, ptr %130, align 8, !tbaa !481
  %134 = icmp eq ptr %133, %112
  br i1 %134, label %138, label %135

135:                                              ; preds = %132
  %136 = getelementptr inbounds nuw i8, ptr %114, i64 32
  %137 = icmp eq ptr %136, %109
  br i1 %137, label %138, label %113, !llvm.loop !1075

138:                                              ; preds = %113, %117, %120, %123, %126, %129, %132, %135, %101
  %139 = phi ptr [ %104, %101 ], [ %114, %113 ], [ %109, %117 ], [ %118, %120 ], [ %109, %123 ], [ %124, %126 ], [ %109, %129 ], [ %130, %132 ], [ %109, %135 ]
  %140 = getelementptr inbounds nuw i8, ptr %139, i64 8
  %141 = getelementptr inbounds nuw ptr, ptr %104, i64 %107
  %142 = ptrtoint ptr %141 to i64
  %143 = ptrtoint ptr %140 to i64
  %144 = sub i64 %142, %143
  %145 = icmp sgt i64 %144, 8
  br i1 %145, label %146, label %148, !prof !483

146:                                              ; preds = %138
  call void @llvm.memmove.p0.p0.i64(ptr align 8 %139, ptr nonnull align 8 %140, i64 %144, i1 false)
  %147 = load i32, ptr %105, align 8, !tbaa !76
  br label %152

148:                                              ; preds = %138
  %149 = icmp eq i64 %144, 8
  br i1 %149, label %150, label %152

150:                                              ; preds = %148
  %151 = load ptr, ptr %140, align 8, !tbaa !481
  store ptr %151, ptr %139, align 8, !tbaa !481
  br label %152

152:                                              ; preds = %146, %148, %150
  %153 = phi i32 [ %147, %146 ], [ %106, %148 ], [ %106, %150 ]
  %154 = add i32 %153, -1
  store i32 %154, ptr %105, align 8, !tbaa !76
  br label %155

155:                                              ; preds = %90, %62, %59, %43, %152
  %156 = phi i1 [ true, %152 ], [ false, %43 ], [ true, %59 ], [ false, %62 ], [ false, %90 ]
  ret i1 %156
}

declare void @_ZN4llvm11SlotIndexes26removeMachineInstrFromMapsERNS_12MachineInstrEb(ptr noundef nonnull align 8 dereferenceable(416), ptr noundef nonnull align 8 dereferenceable(80), i1 noundef zeroext) local_unnamed_addr #4

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E21eraseFromFilledBucketIZNSB_21eraseFromFilledBucketEPS9_EUlRS9_E_EEvSD_OT_(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr noundef %1, ptr noundef nonnull align 1 dereferenceable(1) %2) local_unnamed_addr #27 comdat align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %5 = load i32, ptr %4, align 8, !tbaa !1073
  %6 = add i32 %5, -1
  store i32 %6, ptr %4, align 8, !tbaa !1073
  %7 = load ptr, ptr %0, align 8, !tbaa !789
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %9 = load ptr, ptr %8, align 8, !tbaa !1095
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %11 = load i32, ptr %10, align 4, !tbaa !788
  %12 = add i32 %11, -1
  %13 = ptrtoint ptr %1 to i64
  %14 = ptrtoint ptr %7 to i64
  %15 = sub i64 %13, %14
  %16 = lshr exact i64 %15, 3
  %17 = trunc i64 %16 to i32
  %18 = add i32 %17, 1
  %19 = and i32 %18, %12
  %20 = zext i32 %19 to i64
  %21 = lshr i64 %20, 5
  %22 = getelementptr inbounds nuw i32, ptr %9, i64 %21
  %23 = load i32, ptr %22, align 4, !tbaa !451
  %24 = and i32 %19, 31
  %25 = shl nuw i32 1, %24
  %26 = and i32 %25, %23
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %59, label %28

28:                                               ; preds = %3, %47
  %29 = phi i64 [ %51, %47 ], [ %20, %3 ]
  %30 = phi i32 [ %50, %47 ], [ %19, %3 ]
  %31 = phi i32 [ %48, %47 ], [ %17, %3 ]
  %32 = getelementptr inbounds nuw %"class.llvm::detail::DenseSetPair", ptr %7, i64 %29
  %33 = load ptr, ptr %32, align 8, !tbaa !481
  %34 = ptrtoint ptr %33 to i64
  %35 = mul i64 %34, -4658895280553007687
  %36 = lshr i64 %35, 31
  %37 = xor i64 %36, %35
  %38 = trunc i64 %37 to i32
  %39 = sub i32 %31, %38
  %40 = and i32 %39, %12
  %41 = sub i32 %30, %38
  %42 = and i32 %41, %12
  %43 = icmp ult i32 %40, %42
  br i1 %43, label %44, label %47

44:                                               ; preds = %28
  %45 = zext i32 %31 to i64
  %46 = getelementptr inbounds nuw %"class.llvm::detail::DenseSetPair", ptr %7, i64 %45
  store ptr %33, ptr %46, align 8, !tbaa !481
  br label %47

47:                                               ; preds = %28, %44
  %48 = phi i32 [ %30, %44 ], [ %31, %28 ]
  %49 = add i32 %30, 1
  %50 = and i32 %49, %12
  %51 = zext i32 %50 to i64
  %52 = lshr i64 %51, 5
  %53 = getelementptr inbounds nuw i32, ptr %9, i64 %52
  %54 = load i32, ptr %53, align 4, !tbaa !451
  %55 = and i32 %50, 31
  %56 = shl nuw i32 1, %55
  %57 = and i32 %56, %54
  %58 = icmp eq i32 %57, 0
  br i1 %58, label %59, label %28

59:                                               ; preds = %47, %3
  %60 = phi i32 [ %17, %3 ], [ %48, %47 ]
  %61 = and i32 %60, 31
  %62 = shl nuw i32 1, %61
  %63 = xor i32 %62, -1
  %64 = lshr i32 %60, 5
  %65 = zext nneg i32 %64 to i64
  %66 = getelementptr inbounds nuw i32, ptr %9, i64 %65
  %67 = load i32, ptr %66, align 4, !tbaa !451
  %68 = and i32 %67, %63
  store i32 %68, ptr %66, align 4, !tbaa !451
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden i64 @_ZN4llvm11SlotIndexes24insertMachineInstrInMapsERNS_12MachineInstrEb(ptr noundef nonnull align 8 dereferenceable(416) %0, ptr noundef nonnull align 8 dereferenceable(80) %1, i1 noundef zeroext %2) local_unnamed_addr #3 comdat align 2 {
  %4 = alloca %"struct.std::pair.840", align 8
  br i1 %2, label %5, label %10

5:                                                ; preds = %3
  %6 = tail call i64 @_ZNK4llvm11SlotIndexes13getIndexAfterERKNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(416) %0, ptr noundef nonnull align 8 dereferenceable(80) %1)
  %7 = and i64 %6, -8
  %8 = inttoptr i64 %7 to ptr
  %9 = load ptr, ptr %8, align 8, !tbaa !595
  br label %16

10:                                               ; preds = %3
  %11 = tail call i64 @_ZNK4llvm11SlotIndexes14getIndexBeforeERKNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(416) %0, ptr noundef nonnull align 8 dereferenceable(80) %1)
  %12 = and i64 %11, -8
  %13 = inttoptr i64 %12 to ptr
  %14 = getelementptr inbounds nuw i8, ptr %13, i64 8
  %15 = load ptr, ptr %14, align 8, !tbaa !327
  br label %16

16:                                               ; preds = %10, %5
  %17 = phi ptr [ %8, %5 ], [ %15, %10 ]
  %18 = phi ptr [ %9, %5 ], [ %13, %10 ]
  %19 = getelementptr inbounds nuw i8, ptr %17, i64 24
  %20 = load i32, ptr %19, align 8, !tbaa !819
  %21 = getelementptr inbounds nuw i8, ptr %18, i64 24
  %22 = load i32, ptr %21, align 8, !tbaa !819
  %23 = sub i32 %20, %22
  %24 = lshr i32 %23, 1
  %25 = and i32 %24, 2147483644
  %26 = add i32 %25, %22
  %27 = load ptr, ptr %0, align 8, !tbaa !887
  %28 = ptrtoint ptr %27 to i64
  %29 = add i64 %28, 32
  %30 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %31 = load i64, ptr %30, align 8, !tbaa !888
  %32 = icmp ult i64 %29, %31
  br i1 %32, label %33, label %35, !prof !483

33:                                               ; preds = %16
  %34 = inttoptr i64 %29 to ptr
  store ptr %34, ptr %0, align 8, !tbaa !887
  br label %37

35:                                               ; preds = %16
  %36 = tail call noundef nonnull ptr @_ZN4llvm20BumpPtrAllocatorImplINS_15MallocAllocatorELm4096ELm4096ELm128ELm8EE12AllocateSlowEmmNS_5AlignE(ptr noundef nonnull align 8 dereferenceable(416) %0, i64 noundef 32, i64 noundef 32, i8 3)
  br label %37

37:                                               ; preds = %33, %35
  %38 = phi ptr [ %27, %33 ], [ %36, %35 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %38, i8 0, i64 16, i1 false)
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 16
  store ptr %1, ptr %39, align 8, !tbaa !1111
  %40 = getelementptr inbounds nuw i8, ptr %38, i64 24
  store i32 %26, ptr %40, align 8, !tbaa !819
  %41 = load ptr, ptr %17, align 8, !tbaa !595
  %42 = getelementptr inbounds nuw i8, ptr %38, i64 8
  store ptr %17, ptr %42, align 8, !tbaa !327
  store ptr %41, ptr %38, align 8, !tbaa !595
  %43 = getelementptr inbounds nuw i8, ptr %41, i64 8
  store ptr %38, ptr %43, align 8, !tbaa !327
  store ptr %38, ptr %17, align 8, !tbaa !595
  %44 = icmp eq i32 %25, 0
  br i1 %44, label %45, label %46

45:                                               ; preds = %37
  tail call void @_ZN4llvm11SlotIndexes15renumberIndexesENS_14ilist_iteratorINS_12ilist_detail12node_optionsINS_14IndexListEntryELb0ELb0EvLb0EvEELb0ELb0EEE(ptr noundef nonnull align 8 dereferenceable(416) %0, ptr nonnull %38) #33
  br label %46

46:                                               ; preds = %45, %37
  %47 = ptrtoint ptr %38 to i64
  %48 = and i64 %47, -7
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 104
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #33
  store ptr %1, ptr %4, align 8, !tbaa !1112
  %50 = getelementptr inbounds nuw i8, ptr %4, i64 8
  store i64 %48, ptr %50, align 8, !tbaa !212
  %51 = call { ptr, i8 } @_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E24lookupOrInsertIntoBucketIS4_JS5_EEESt4pairIPSA_bEOT_DpOT0_(ptr noundef nonnull align 1 dereferenceable(1) %49, ptr noundef nonnull align 8 dereferenceable(16) %4, ptr noundef nonnull align 8 dereferenceable(8) %50), !noalias !1114
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #33
  ret i64 %48
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden i64 @_ZNK4llvm11SlotIndexes13getIndexAfterERKNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(416) %0, ptr noundef nonnull align 8 dereferenceable(80) %1) local_unnamed_addr #3 comdat align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %4 = load ptr, ptr %3, align 8, !tbaa !294
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 48
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 104
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %8 = load i32, ptr %7, align 8
  %9 = icmp eq i32 %8, 0
  %10 = load ptr, ptr %6, align 8
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 124
  %14 = load i32, ptr %13, align 4
  %15 = add i32 %14, -1
  %16 = zext i32 %14 to i64
  br label %17

17:                                               ; preds = %53, %2
  %18 = phi ptr [ %1, %2 ], [ %38, %53 ]
  %19 = load i64, ptr %18, align 8
  %20 = and i64 %19, 4
  %21 = icmp eq i64 %20, 0
  br i1 %21, label %22, label %35

22:                                               ; preds = %17
  %23 = getelementptr inbounds nuw i8, ptr %18, i64 44
  %24 = load i32, ptr %23, align 4, !tbaa !309
  %25 = and i32 %24, 8
  %26 = icmp eq i32 %25, 0
  br i1 %26, label %35, label %27

27:                                               ; preds = %22, %27
  %28 = phi ptr [ %30, %27 ], [ %18, %22 ]
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 8
  %30 = load ptr, ptr %29, align 8, !tbaa !75
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 44
  %32 = load i32, ptr %31, align 4, !tbaa !309
  %33 = and i32 %32, 8
  %34 = icmp eq i32 %33, 0
  br i1 %34, label %35, label %27, !llvm.loop !908

35:                                               ; preds = %27, %17, %22
  %36 = phi ptr [ %18, %17 ], [ %18, %22 ], [ %30, %27 ]
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 8
  %38 = load ptr, ptr %37, align 8, !tbaa !75
  %39 = icmp eq ptr %38, %5
  br i1 %39, label %40, label %47

40:                                               ; preds = %35
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 128
  %42 = getelementptr inbounds nuw i8, ptr %4, i64 220
  %43 = load i32, ptr %42, align 4, !tbaa !292
  %44 = sext i32 %43 to i64
  %45 = load ptr, ptr %41, align 8, !tbaa !19
  %46 = getelementptr inbounds nuw %"struct.std::pair.781", ptr %45, i64 %44, i32 1
  br label %90

47:                                               ; preds = %35
  %48 = getelementptr inbounds nuw i8, ptr %38, i64 52
  %49 = load i32, ptr %48, align 4, !tbaa !306
  %50 = add i32 %49, -14
  %51 = icmp ult i32 %50, 5
  %52 = select i1 %51, i1 true, i1 %9
  br i1 %52, label %53, label %54

53:                                               ; preds = %75, %47, %54, %86
  br label %17, !llvm.loop !1119

54:                                               ; preds = %47
  %55 = ptrtoint ptr %38 to i64
  %56 = mul i64 %55, -4658895280553007687
  %57 = lshr i64 %56, 31
  %58 = xor i64 %57, %56
  %59 = trunc i64 %58 to i32
  %60 = and i32 %15, %59
  %61 = zext i32 %60 to i64
  %62 = lshr i64 %61, 5
  %63 = getelementptr inbounds nuw i32, ptr %12, i64 %62
  %64 = load i32, ptr %63, align 4, !tbaa !451, !noalias !1120
  %65 = and i32 %60, 31
  %66 = shl nuw i32 1, %65
  %67 = and i32 %64, %66
  %68 = icmp eq i32 %67, 0
  br i1 %68, label %53, label %69, !prof !480

69:                                               ; preds = %54, %75
  %70 = phi i64 [ %78, %75 ], [ %61, %54 ]
  %71 = phi i32 [ %77, %75 ], [ %60, %54 ]
  %72 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %10, i64 %70
  %73 = load ptr, ptr %72, align 8, !tbaa !481, !noalias !1120
  %74 = icmp eq ptr %38, %73
  br i1 %74, label %86, label %75, !prof !483

75:                                               ; preds = %69
  %76 = add i32 %71, 1
  %77 = and i32 %76, %15
  %78 = zext i32 %77 to i64
  %79 = lshr i64 %78, 5
  %80 = getelementptr inbounds nuw i32, ptr %12, i64 %79
  %81 = load i32, ptr %80, align 4, !tbaa !451, !noalias !1120
  %82 = and i32 %77, 31
  %83 = shl nuw i32 1, %82
  %84 = and i32 %81, %83
  %85 = icmp eq i32 %84, 0
  br i1 %85, label %53, label %69, !prof !484, !llvm.loop !1119

86:                                               ; preds = %69
  %87 = icmp samesign eq i64 %70, %16
  br i1 %87, label %53, label %88

88:                                               ; preds = %86
  %89 = getelementptr inbounds nuw i8, ptr %72, i64 8
  br label %90

90:                                               ; preds = %88, %40
  %91 = phi ptr [ %46, %40 ], [ %89, %88 ]
  %92 = load i64, ptr %91, align 8, !tbaa !212
  ret i64 %92
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden i64 @_ZNK4llvm11SlotIndexes14getIndexBeforeERKNS_12MachineInstrE(ptr noundef nonnull align 8 dereferenceable(416) %0, ptr noundef nonnull align 8 dereferenceable(80) %1) local_unnamed_addr #3 comdat align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %4 = load ptr, ptr %3, align 8, !tbaa !294
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 56
  %6 = load ptr, ptr %5, align 8, !tbaa !75
  %7 = icmp eq ptr %1, %6
  br i1 %7, label %20, label %8

8:                                                ; preds = %2
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 104
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 120
  %11 = load i32, ptr %10, align 8
  %12 = icmp eq i32 %11, 0
  %13 = load ptr, ptr %9, align 8
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 112
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 124
  %17 = load i32, ptr %16, align 4
  %18 = add i32 %17, -1
  %19 = zext i32 %17 to i64
  br label %27

20:                                               ; preds = %56, %2
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 128
  %22 = getelementptr inbounds nuw i8, ptr %4, i64 220
  %23 = load i32, ptr %22, align 4, !tbaa !292
  %24 = sext i32 %23 to i64
  %25 = load ptr, ptr %21, align 8, !tbaa !19
  %26 = getelementptr inbounds nuw %"struct.std::pair.781", ptr %25, i64 %24
  br label %94

27:                                               ; preds = %8, %56
  %28 = phi ptr [ %1, %8 ], [ %50, %56 ]
  %29 = load i64, ptr %28, align 8
  %30 = and i64 %29, -8
  %31 = inttoptr i64 %30 to ptr
  %32 = load i64, ptr %31, align 8
  %33 = and i64 %32, 4
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %35, label %49

35:                                               ; preds = %27
  %36 = getelementptr inbounds nuw i8, ptr %31, i64 44
  %37 = load i32, ptr %36, align 4, !tbaa !309
  %38 = and i32 %37, 4
  %39 = icmp eq i32 %38, 0
  br i1 %39, label %49, label %40

40:                                               ; preds = %35, %40
  %41 = phi ptr [ %44, %40 ], [ %31, %35 ]
  %42 = load i64, ptr %41, align 8
  %43 = and i64 %42, -8
  %44 = inttoptr i64 %43 to ptr
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 44
  %46 = load i32, ptr %45, align 4, !tbaa !309
  %47 = and i32 %46, 4
  %48 = icmp eq i32 %47, 0
  br i1 %48, label %49, label %40, !llvm.loop !329

49:                                               ; preds = %40, %27, %35
  %50 = phi ptr [ %31, %27 ], [ %31, %35 ], [ %44, %40 ]
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 52
  %52 = load i32, ptr %51, align 4, !tbaa !306
  %53 = add i32 %52, -14
  %54 = icmp ult i32 %53, 5
  %55 = select i1 %54, i1 true, i1 %12
  br i1 %55, label %56, label %58

56:                                               ; preds = %79, %49, %58, %90
  %57 = icmp eq ptr %50, %6
  br i1 %57, label %20, label %27, !llvm.loop !1125

58:                                               ; preds = %49
  %59 = ptrtoint ptr %50 to i64
  %60 = mul i64 %59, -4658895280553007687
  %61 = lshr i64 %60, 31
  %62 = xor i64 %61, %60
  %63 = trunc i64 %62 to i32
  %64 = and i32 %18, %63
  %65 = zext i32 %64 to i64
  %66 = lshr i64 %65, 5
  %67 = getelementptr inbounds nuw i32, ptr %15, i64 %66
  %68 = load i32, ptr %67, align 4, !tbaa !451, !noalias !1126
  %69 = and i32 %64, 31
  %70 = shl nuw i32 1, %69
  %71 = and i32 %68, %70
  %72 = icmp eq i32 %71, 0
  br i1 %72, label %56, label %73, !prof !480

73:                                               ; preds = %58, %79
  %74 = phi i64 [ %82, %79 ], [ %65, %58 ]
  %75 = phi i32 [ %81, %79 ], [ %64, %58 ]
  %76 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %13, i64 %74
  %77 = load ptr, ptr %76, align 8, !tbaa !481, !noalias !1126
  %78 = icmp eq ptr %50, %77
  br i1 %78, label %90, label %79, !prof !483

79:                                               ; preds = %73
  %80 = add i32 %75, 1
  %81 = and i32 %80, %18
  %82 = zext i32 %81 to i64
  %83 = lshr i64 %82, 5
  %84 = getelementptr inbounds nuw i32, ptr %15, i64 %83
  %85 = load i32, ptr %84, align 4, !tbaa !451, !noalias !1126
  %86 = and i32 %81, 31
  %87 = shl nuw i32 1, %86
  %88 = and i32 %85, %87
  %89 = icmp eq i32 %88, 0
  br i1 %89, label %56, label %73, !prof !484

90:                                               ; preds = %73
  %91 = icmp samesign eq i64 %74, %19
  br i1 %91, label %56, label %92

92:                                               ; preds = %90
  %93 = getelementptr inbounds nuw i8, ptr %76, i64 8
  br label %94

94:                                               ; preds = %92, %20
  %95 = phi ptr [ %26, %20 ], [ %93, %92 ]
  %96 = load i64, ptr %95, align 8, !tbaa !212
  ret i64 %96
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden { ptr, i8 } @_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E24lookupOrInsertIntoBucketIS4_JS5_EEESt4pairIPSA_bEOT_DpOT0_(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr noundef nonnull align 8 dereferenceable(8) %1, ptr noundef nonnull align 8 dereferenceable(8) %2) local_unnamed_addr #3 comdat align 2 {
  %4 = alloca ptr, align 8
  %5 = load ptr, ptr %0, align 8, !tbaa !472, !noalias !1131
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %7 = load ptr, ptr %6, align 8, !tbaa !478, !noalias !1131
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %9 = load i32, ptr %8, align 4, !tbaa !479, !noalias !1131
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %46, label %11

11:                                               ; preds = %3
  %12 = add i32 %9, -1
  %13 = load ptr, ptr %1, align 8, !tbaa !481
  %14 = ptrtoint ptr %13 to i64
  %15 = mul i64 %14, -4658895280553007687
  %16 = lshr i64 %15, 31
  %17 = xor i64 %16, %15
  %18 = trunc i64 %17 to i32
  %19 = and i32 %12, %18
  %20 = zext i32 %19 to i64
  %21 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %5, i64 %20
  %22 = lshr i64 %20, 5
  %23 = getelementptr inbounds nuw i32, ptr %7, i64 %22
  %24 = load i32, ptr %23, align 4, !tbaa !451
  %25 = and i32 %19, 31
  %26 = shl nuw i32 1, %25
  %27 = and i32 %26, %24
  %28 = icmp eq i32 %27, 0
  br i1 %28, label %46, label %29, !prof !480

29:                                               ; preds = %11, %34
  %30 = phi ptr [ %38, %34 ], [ %21, %11 ]
  %31 = phi i32 [ %36, %34 ], [ %19, %11 ]
  %32 = load ptr, ptr %30, align 8, !tbaa !481
  %33 = icmp eq ptr %13, %32
  br i1 %33, label %80, label %34, !prof !483

34:                                               ; preds = %29
  %35 = add nuw i32 %31, 1
  %36 = and i32 %35, %12
  %37 = zext i32 %36 to i64
  %38 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %5, i64 %37
  %39 = lshr i64 %37, 5
  %40 = getelementptr inbounds nuw i32, ptr %7, i64 %39
  %41 = load i32, ptr %40, align 4, !tbaa !451
  %42 = and i32 %36, 31
  %43 = shl nuw i32 1, %42
  %44 = and i32 %41, %43
  %45 = icmp eq i32 %44, 0
  br i1 %45, label %46, label %29, !prof !484, !llvm.loop !1136

46:                                               ; preds = %34, %3, %11
  %47 = phi ptr [ %21, %11 ], [ null, %3 ], [ %38, %34 ]
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %4)
  store ptr %47, ptr %4, align 8, !tbaa !1137
  %48 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %49 = load i32, ptr %48, align 8, !tbaa !469
  %50 = shl i32 %49, 2
  %51 = add i32 %50, 4
  %52 = mul i32 %9, 3
  %53 = icmp ult i32 %51, %52
  br i1 %53, label %60, label %54, !prof !483

54:                                               ; preds = %46
  %55 = shl i32 %9, 1
  tail call void @_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E4growEj(ptr noundef nonnull align 1 dereferenceable(1) %0, i32 noundef %55)
  %56 = call noundef zeroext i1 @_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E15LookupBucketForIS4_EEbRKT_RPSA_(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr noundef nonnull align 8 dereferenceable(8) %1, ptr noundef nonnull align 8 dereferenceable(8) %4)
  %57 = load ptr, ptr %4, align 8, !tbaa !1137
  %58 = load ptr, ptr %6, align 8, !tbaa !478
  %59 = load ptr, ptr %0, align 8, !tbaa !472
  br label %60

60:                                               ; preds = %46, %54
  %61 = phi ptr [ %59, %54 ], [ %5, %46 ]
  %62 = phi ptr [ %58, %54 ], [ %7, %46 ]
  %63 = phi ptr [ %57, %54 ], [ %47, %46 ]
  %64 = ptrtoint ptr %63 to i64
  %65 = ptrtoint ptr %61 to i64
  %66 = sub i64 %64, %65
  %67 = ashr exact i64 %66, 4
  %68 = trunc i64 %67 to i32
  %69 = and i32 %68, 31
  %70 = shl nuw i32 1, %69
  %71 = lshr i64 %67, 5
  %72 = getelementptr inbounds nuw i32, ptr %62, i64 %71
  %73 = load i32, ptr %72, align 4, !tbaa !451
  %74 = or i32 %70, %73
  store i32 %74, ptr %72, align 4, !tbaa !451
  %75 = load i32, ptr %48, align 8, !tbaa !469
  %76 = add i32 %75, 1
  store i32 %76, ptr %48, align 8, !tbaa !469
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %4)
  %77 = load ptr, ptr %1, align 8, !tbaa !481
  store ptr %77, ptr %63, align 8, !tbaa !481
  %78 = getelementptr inbounds nuw i8, ptr %63, i64 8
  %79 = load i64, ptr %2, align 8, !tbaa !212
  store i64 %79, ptr %78, align 8, !tbaa !212
  br label %80

80:                                               ; preds = %29, %60
  %81 = phi ptr [ %63, %60 ], [ %30, %29 ]
  %82 = phi i8 [ 1, %60 ], [ 0, %29 ]
  %83 = insertvalue { ptr, i8 } poison, ptr %81, 0
  %84 = insertvalue { ptr, i8 } %83, i8 %82, 1
  ret { ptr, i8 } %84
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden noundef zeroext i1 @_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E15LookupBucketForIS4_EEbRKT_RPSA_(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr noundef nonnull align 8 dereferenceable(8) %1, ptr noundef nonnull align 8 dereferenceable(8) %2) local_unnamed_addr #3 comdat align 2 {
  %4 = load ptr, ptr %0, align 8, !tbaa !472, !noalias !1138
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8, !tbaa !478, !noalias !1138
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %8 = load i32, ptr %7, align 4, !tbaa !479, !noalias !1138
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %45, label %10

10:                                               ; preds = %3
  %11 = add i32 %8, -1
  %12 = load ptr, ptr %1, align 8, !tbaa !481
  %13 = ptrtoint ptr %12 to i64
  %14 = mul i64 %13, -4658895280553007687
  %15 = lshr i64 %14, 31
  %16 = xor i64 %15, %14
  %17 = trunc i64 %16 to i32
  %18 = and i32 %11, %17
  %19 = zext i32 %18 to i64
  %20 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %4, i64 %19
  %21 = lshr i64 %19, 5
  %22 = getelementptr inbounds nuw i32, ptr %6, i64 %21
  %23 = load i32, ptr %22, align 4, !tbaa !451
  %24 = and i32 %18, 31
  %25 = shl nuw i32 1, %24
  %26 = and i32 %25, %23
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %45, label %28, !prof !480

28:                                               ; preds = %10, %33
  %29 = phi ptr [ %37, %33 ], [ %20, %10 ]
  %30 = phi i32 [ %35, %33 ], [ %18, %10 ]
  %31 = load ptr, ptr %29, align 8, !tbaa !481
  %32 = icmp eq ptr %12, %31
  br i1 %32, label %45, label %33, !prof !483

33:                                               ; preds = %28
  %34 = add nuw i32 %30, 1
  %35 = and i32 %34, %11
  %36 = zext i32 %35 to i64
  %37 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %4, i64 %36
  %38 = lshr i64 %36, 5
  %39 = getelementptr inbounds nuw i32, ptr %6, i64 %38
  %40 = load i32, ptr %39, align 4, !tbaa !451
  %41 = and i32 %35, 31
  %42 = shl nuw i32 1, %41
  %43 = and i32 %42, %40
  %44 = icmp eq i32 %43, 0
  br i1 %44, label %45, label %28, !prof !484, !llvm.loop !1136

45:                                               ; preds = %28, %33, %10, %3
  %46 = phi ptr [ null, %3 ], [ %20, %10 ], [ %37, %33 ], [ %29, %28 ]
  %47 = phi i1 [ false, %3 ], [ false, %10 ], [ %32, %33 ], [ %32, %28 ]
  store ptr %46, ptr %2, align 8, !tbaa !1137
  ret i1 %47
}

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E4growEj(ptr noundef nonnull align 1 dereferenceable(1) %0, i32 noundef %1) local_unnamed_addr #27 comdat align 2 {
  %3 = alloca %"class.llvm::DenseMap.376", align 16
  %4 = add i32 %1, -1
  %5 = zext i32 %4 to i64
  %6 = lshr i64 %5, 1
  %7 = or i64 %6, %5
  %8 = lshr i64 %7, 2
  %9 = or i64 %8, %7
  %10 = lshr i64 %9, 4
  %11 = or i64 %10, %9
  %12 = lshr i64 %11, 8
  %13 = or i64 %12, %11
  %14 = lshr i64 %13, 16
  %15 = or i64 %14, %13
  %16 = trunc nuw i64 %15 to i32
  %17 = add i32 %16, 1
  %18 = tail call noundef i32 @llvm.umax.i32(i32 %17, i32 64)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %3) #33
  %19 = getelementptr inbounds nuw i8, ptr %3, i64 20
  store i32 %18, ptr %19, align 4, !tbaa !479
  %20 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %21 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %22 = zext i32 %18 to i64
  %23 = shl nuw nsw i64 %22, 4
  %24 = add nuw nsw i64 %22, 31
  %25 = lshr i64 %24, 3
  %26 = and i64 %25, 1073741820
  %27 = add nuw nsw i64 %26, %23
  %28 = tail call noalias noundef nonnull ptr @_ZN4llvm15allocate_bufferEmm(i64 noundef %27, i64 noundef 8) #33
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 %23
  store ptr %28, ptr %3, align 16, !tbaa !472
  store ptr %29, ptr %21, align 8, !tbaa !478
  store i32 0, ptr %20, align 16, !tbaa !469
  tail call void @llvm.memset.p0.i64(ptr nonnull align 4 %29, i8 0, i64 %26, i1 false)
  call void @_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E8moveFromERSB_(ptr noundef nonnull align 1 dereferenceable(1) %3, ptr noundef nonnull align 8 dereferenceable(24) %0)
  %30 = load <2 x ptr>, ptr %0, align 8, !tbaa !743
  %31 = load ptr, ptr %0, align 8, !tbaa !1137
  %32 = load <2 x ptr>, ptr %3, align 16, !tbaa !743
  store <2 x ptr> %32, ptr %0, align 8, !tbaa !743
  store <2 x ptr> %30, ptr %3, align 16, !tbaa !743
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %34 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %35 = load i32, ptr %34, align 4, !tbaa !451
  %36 = load <2 x i32>, ptr %33, align 4, !tbaa !451
  %37 = load <2 x i32>, ptr %20, align 16, !tbaa !451
  store <2 x i32> %37, ptr %33, align 4, !tbaa !451
  store <2 x i32> %36, ptr %20, align 16, !tbaa !451
  %38 = icmp eq i32 %35, 0
  br i1 %38, label %46, label %39

39:                                               ; preds = %2
  %40 = zext i32 %35 to i64
  %41 = shl nuw nsw i64 %40, 4
  %42 = add nuw nsw i64 %40, 31
  %43 = lshr i64 %42, 3
  %44 = and i64 %43, 1073741820
  %45 = add nuw nsw i64 %44, %41
  call void @_ZN4llvm17deallocate_bufferEPvmm(ptr noundef %31, i64 noundef %45, i64 noundef 8) #33
  br label %46

46:                                               ; preds = %2, %39
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %3) #33
  ret void
}

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E8moveFromERSB_(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr noundef nonnull align 8 dereferenceable(24) %1) local_unnamed_addr #27 comdat align 2 {
  %3 = load ptr, ptr %1, align 8, !tbaa !472
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %5 = load ptr, ptr %4, align 8, !tbaa !478
  %6 = getelementptr inbounds nuw i8, ptr %1, i64 20
  %7 = load i32, ptr %6, align 4, !tbaa !479
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %9 = load ptr, ptr %8, align 8, !tbaa !478
  %10 = load ptr, ptr %0, align 8, !tbaa !472
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 20
  %12 = load i32, ptr %11, align 4, !tbaa !479
  %13 = add i32 %12, -1
  %14 = icmp eq i32 %7, 0
  br i1 %14, label %15, label %19

15:                                               ; preds = %2
  %16 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %17 = load i32, ptr %16, align 8, !tbaa !469
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store i32 %17, ptr %18, align 8, !tbaa !469
  br label %95

19:                                               ; preds = %2
  %20 = zext i32 %7 to i64
  %21 = add nuw nsw i64 %20, 31
  %22 = lshr i64 %21, 5
  br label %23

23:                                               ; preds = %19, %78
  %24 = phi i64 [ 0, %19 ], [ %79, %78 ]
  %25 = getelementptr inbounds nuw i32, ptr %5, i64 %24
  %26 = load i32, ptr %25, align 4, !tbaa !451
  %27 = icmp eq i32 %26, 0
  br i1 %27, label %78, label %28

28:                                               ; preds = %23
  %29 = trunc i64 %24 to i32
  %30 = shl i32 %29, 5
  br label %31

31:                                               ; preds = %28, %64
  %32 = phi i32 [ %26, %28 ], [ %76, %64 ]
  %33 = tail call noundef range(i32 0, 33) i32 @llvm.cttz.i32(i32 %32, i1 true)
  %34 = or disjoint i32 %33, %30
  %35 = zext i32 %34 to i64
  %36 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %3, i64 %35
  %37 = load ptr, ptr %36, align 8, !tbaa !481
  %38 = ptrtoint ptr %37 to i64
  %39 = mul i64 %38, -4658895280553007687
  %40 = lshr i64 %39, 31
  %41 = xor i64 %40, %39
  %42 = trunc i64 %41 to i32
  %43 = and i32 %13, %42
  %44 = zext i32 %43 to i64
  %45 = lshr i64 %44, 5
  %46 = getelementptr inbounds nuw i32, ptr %9, i64 %45
  %47 = load i32, ptr %46, align 4, !tbaa !451
  %48 = and i32 %43, 31
  %49 = shl nuw i32 1, %48
  %50 = and i32 %49, %47
  %51 = icmp eq i32 %50, 0
  br i1 %51, label %64, label %52

52:                                               ; preds = %31, %52
  %53 = phi i32 [ %55, %52 ], [ %43, %31 ]
  %54 = add i32 %53, 1
  %55 = and i32 %54, %13
  %56 = zext i32 %55 to i64
  %57 = lshr i64 %56, 5
  %58 = getelementptr inbounds nuw i32, ptr %9, i64 %57
  %59 = load i32, ptr %58, align 4, !tbaa !451
  %60 = and i32 %55, 31
  %61 = shl nuw i32 1, %60
  %62 = and i32 %61, %59
  %63 = icmp eq i32 %62, 0
  br i1 %63, label %64, label %52, !llvm.loop !1143

64:                                               ; preds = %52, %31
  %65 = phi i64 [ %44, %31 ], [ %56, %52 ]
  %66 = phi i64 [ %45, %31 ], [ %57, %52 ]
  %67 = phi i32 [ %49, %31 ], [ %61, %52 ]
  %68 = getelementptr inbounds nuw %"struct.llvm::detail::DenseMapPair", ptr %10, i64 %65
  store ptr %37, ptr %68, align 8, !tbaa !481
  %69 = getelementptr inbounds nuw i8, ptr %68, i64 8
  %70 = getelementptr inbounds nuw i8, ptr %36, i64 8
  %71 = load i64, ptr %70, align 8, !tbaa !212
  store i64 %71, ptr %69, align 8, !tbaa !212
  %72 = getelementptr inbounds nuw i32, ptr %9, i64 %66
  %73 = load i32, ptr %72, align 4, !tbaa !451
  %74 = or i32 %73, %67
  store i32 %74, ptr %72, align 4, !tbaa !451
  %75 = add i32 %32, -1
  %76 = and i32 %75, %32
  %77 = icmp eq i32 %76, 0
  br i1 %77, label %78, label %31, !llvm.loop !1144

78:                                               ; preds = %64, %23
  %79 = add nuw nsw i64 %24, 1
  %80 = icmp eq i64 %79, %22
  br i1 %80, label %81, label %23, !llvm.loop !1145

81:                                               ; preds = %78
  %82 = load i32, ptr %6, align 4, !tbaa !479
  %83 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %84 = load i32, ptr %83, align 8, !tbaa !469
  %85 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store i32 %84, ptr %85, align 8, !tbaa !469
  %86 = icmp eq i32 %82, 0
  br i1 %86, label %95, label %87

87:                                               ; preds = %81
  %88 = load ptr, ptr %1, align 8, !tbaa !472
  %89 = zext i32 %82 to i64
  %90 = shl nuw nsw i64 %89, 4
  %91 = add nuw nsw i64 %89, 31
  %92 = lshr i64 %91, 3
  %93 = and i64 %92, 1073741820
  %94 = add nuw nsw i64 %93, %90
  tail call void @_ZN4llvm17deallocate_bufferEPvmm(ptr noundef %88, i64 noundef %94, i64 noundef 8) #33
  store i32 0, ptr %6, align 4, !tbaa !479
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %1, i8 0, i64 16, i1 false)
  br label %95

95:                                               ; preds = %15, %81, %87
  ret void
}

declare noundef zeroext i1 @_ZN4llvm13LiveIntervals22computeVirtRegIntervalERNS_12LiveIntervalE(ptr noundef nonnull align 8 dereferenceable(424), ptr noundef nonnull align 8 dereferenceable(120)) local_unnamed_addr #4

declare noundef ptr @_ZN4llvm13LiveIntervals14createIntervalENS_8RegisterE(i32) local_unnamed_addr #4

declare noundef ptr @_ZN4llvm9LiveRange4findENS_9SlotIndexE(ptr noundef nonnull align 8 dereferenceable(104), i64) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm13LiveIntervals13removeRegUnitENS_9MCRegUnitE(ptr noundef nonnull align 8 dereferenceable(424) %0, i32 noundef %1) local_unnamed_addr #3 comdat align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 408
  %4 = zext i32 %1 to i64
  %5 = load ptr, ptr %3, align 8, !tbaa !19
  %6 = getelementptr inbounds nuw ptr, ptr %5, i64 %4
  %7 = load ptr, ptr %6, align 8, !tbaa !1146
  %8 = icmp eq ptr %7, null
  br i1 %8, label %29, label %9

9:                                                ; preds = %2
  %10 = getelementptr inbounds nuw i8, ptr %7, i64 96
  %11 = load ptr, ptr %10, align 8, !tbaa !1148
  %12 = icmp eq ptr %11, null
  br i1 %12, label %16, label %13

13:                                               ; preds = %9
  %14 = getelementptr inbounds nuw i8, ptr %11, i64 16
  %15 = load ptr, ptr %14, align 8, !tbaa !804
  tail call void @_ZNSt8_Rb_treeIN4llvm9LiveRange7SegmentES2_St9_IdentityIS2_ESt4lessIS2_ESaIS2_EE8_M_eraseEPSt13_Rb_tree_nodeIS2_E(ptr noundef nonnull align 8 dereferenceable(48) %11, ptr noundef %15)
  tail call void @_ZdlPvm(ptr noundef nonnull %11, i64 noundef 48) #34
  br label %16

16:                                               ; preds = %13, %9
  store ptr null, ptr %10, align 8, !tbaa !1148
  %17 = getelementptr inbounds nuw i8, ptr %7, i64 64
  %18 = load ptr, ptr %17, align 8, !tbaa !19
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 80
  %20 = icmp eq ptr %18, %19
  br i1 %20, label %22, label %21

21:                                               ; preds = %16
  tail call void @free(ptr noundef %18) #33
  br label %22

22:                                               ; preds = %21, %16
  %23 = load ptr, ptr %7, align 8, !tbaa !19
  %24 = getelementptr inbounds nuw i8, ptr %7, i64 16
  %25 = icmp eq ptr %23, %24
  br i1 %25, label %27, label %26

26:                                               ; preds = %22
  tail call void @free(ptr noundef %23) #33
  br label %27

27:                                               ; preds = %22, %26
  tail call void @_ZdlPvm(ptr noundef nonnull %7, i64 noundef 104) #34
  %28 = load ptr, ptr %3, align 8, !tbaa !19
  br label %29

29:                                               ; preds = %27, %2
  %30 = phi ptr [ %28, %27 ], [ %5, %2 ]
  %31 = getelementptr inbounds nuw ptr, ptr %30, i64 %4
  store ptr null, ptr %31, align 8, !tbaa !1146
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr void @_ZNSt8_Rb_treeIN4llvm9LiveRange7SegmentES2_St9_IdentityIS2_ESt4lessIS2_ESaIS2_EE8_M_eraseEPSt13_Rb_tree_nodeIS2_E(ptr noundef nonnull align 8 dereferenceable(48) %0, ptr noundef %1) local_unnamed_addr #3 comdat align 2 {
  %3 = icmp eq ptr %1, null
  br i1 %3, label %11, label %4

4:                                                ; preds = %2, %4
  %5 = phi ptr [ %9, %4 ], [ %1, %2 ]
  %6 = getelementptr inbounds nuw i8, ptr %5, i64 24
  %7 = load ptr, ptr %6, align 8, !tbaa !1150
  tail call void @_ZNSt8_Rb_treeIN4llvm9LiveRange7SegmentES2_St9_IdentityIS2_ESt4lessIS2_ESaIS2_EE8_M_eraseEPSt13_Rb_tree_nodeIS2_E(ptr noundef nonnull align 8 dereferenceable(48) %0, ptr noundef %7)
  %8 = getelementptr inbounds nuw i8, ptr %5, i64 16
  %9 = load ptr, ptr %8, align 8, !tbaa !1151
  tail call void @_ZdlPvm(ptr noundef nonnull %5, i64 noundef 56) #34
  %10 = icmp eq ptr %9, null
  br i1 %10, label %11, label %4, !llvm.loop !1152

11:                                               ; preds = %4, %2
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr void @_ZNSt8_Rb_treeIN4llvm8RegisterES1_St9_IdentityIS1_ESt4lessIS1_ESaIS1_EE8_M_eraseEPSt13_Rb_tree_nodeIS1_E(ptr noundef nonnull align 8 dereferenceable(48) %0, ptr noundef %1) local_unnamed_addr #3 comdat align 2 {
  %3 = icmp eq ptr %1, null
  br i1 %3, label %11, label %4

4:                                                ; preds = %2, %4
  %5 = phi ptr [ %9, %4 ], [ %1, %2 ]
  %6 = getelementptr inbounds nuw i8, ptr %5, i64 24
  %7 = load ptr, ptr %6, align 8, !tbaa !1150
  tail call void @_ZNSt8_Rb_treeIN4llvm8RegisterES1_St9_IdentityIS1_ESt4lessIS1_ESaIS1_EE8_M_eraseEPSt13_Rb_tree_nodeIS1_E(ptr noundef nonnull align 8 dereferenceable(48) %0, ptr noundef %7)
  %8 = getelementptr inbounds nuw i8, ptr %5, i64 16
  %9 = load ptr, ptr %8, align 8, !tbaa !1151
  tail call void @_ZdlPvm(ptr noundef nonnull %5, i64 noundef 40) #34
  %10 = icmp eq ptr %9, null
  br i1 %10, label %11, label %4, !llvm.loop !1153

11:                                               ; preds = %4, %2
  ret void
}

declare void @_ZN4llvm12MachineInstr16unbundleFromSuccEv(ptr noundef nonnull align 8 dereferenceable(80)) local_unnamed_addr #4

declare void @_ZN4llvm12MachineInstr16unbundleFromPredEv(ptr noundef nonnull align 8 dereferenceable(80)) local_unnamed_addr #4

declare void @_ZN4llvm18ilist_alloc_traitsINS_17MachineBasicBlockEE10deleteNodeEPS1_(ptr noundef nonnull align 1 dereferenceable(1), ptr noundef) local_unnamed_addr #4

declare noundef zeroext i1 @_ZNK4llvm14MCRegisterInfo11regsOverlapENS_10MCRegisterES1_(ptr noundef nonnull align 8 dereferenceable(240), i32, i32) local_unnamed_addr #4

declare noundef i32 @_ZNK4llvm6Triple27getDefaultExceptionHandlingEv(ptr noundef nonnull align 8 dereferenceable(56)) local_unnamed_addr #4

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm23SmallVectorTemplateBaseINS_8RegisterELb1EE15growAndPushBackES1_(ptr noundef nonnull align 8 dereferenceable(16) %0, i32 %1) local_unnamed_addr #27 comdat align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %4 = load i32, ptr %3, align 8, !tbaa !76
  %5 = zext i32 %4 to i64
  %6 = add nuw nsw i64 %5, 1
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull %7, i64 noundef %6, i64 noundef 4) #33
  %8 = load ptr, ptr %0, align 8, !tbaa !19
  %9 = load i32, ptr %3, align 8, !tbaa !76
  %10 = zext i32 %9 to i64
  %11 = getelementptr inbounds nuw %"class.llvm::Register", ptr %8, i64 %10
  store i32 %1, ptr %11, align 1
  %12 = load i32, ptr %3, align 8, !tbaa !76
  %13 = add i32 %12, 1
  store i32 %13, ptr %3, align 8, !tbaa !76
  ret void
}

declare void @_ZN4llvm2cl6OptionC2ENS0_18NumOccurrencesFlagENS0_12OptionHiddenE(ptr noundef nonnull align 8 dereferenceable(120), i32 noundef, i32 noundef) unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden noundef zeroext i1 @_ZNK4llvm2cl15OptionValueCopyIbE7compareERKNS0_18GenericOptionValueE(ptr noundef nonnull align 8 dereferenceable(10) %0, ptr noundef nonnull align 8 dereferenceable(8) %1) unnamed_addr #3 comdat align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 9
  %4 = load i8, ptr %3, align 1, !tbaa !1154, !range !16, !noundef !17
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %6, label %16

6:                                                ; preds = %2
  %7 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 9
  %9 = load i8, ptr %8, align 1, !tbaa !1154, !range !16, !noundef !17
  %10 = trunc nuw i8 %9 to i1
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %12 = load i8, ptr %11, align 8, !range !16
  %13 = load i8, ptr %7, align 8, !range !16
  %14 = icmp eq i8 %12, %13
  %15 = select i1 %10, i1 %14, i1 false
  br label %16

16:                                               ; preds = %2, %6
  %17 = phi i1 [ %15, %6 ], [ false, %2 ]
  ret i1 %17
}

declare void @_ZN4llvm2cl18GenericOptionValue6anchorEv(ptr noundef nonnull align 8 dereferenceable(8)) unnamed_addr #4

declare void @_ZN4llvm2cl6Option9setArgStrENS_9StringRefE(ptr noundef nonnull align 8 dereferenceable(120), ptr, i64) local_unnamed_addr #4

declare void @_ZN4llvm2cl6Option11addArgumentEv(ptr noundef nonnull align 8 dereferenceable(120)) local_unnamed_addr #4

declare void @_ZN4llvm15SmallVectorBaseImE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(24), ptr noundef, i64 noundef, i64 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind uwtable
define internal void @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E9_M_invokeERKSt9_Any_dataS2_"(ptr noundef nonnull readonly align 8 captures(none) dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(48) %1) #3 align 2 {
  %3 = load ptr, ptr %0, align 8, !tbaa !1157, !nonnull !17, !align !200
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %5 = load ptr, ptr %4, align 8, !tbaa !258
  %6 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %7 = load ptr, ptr %6, align 8, !tbaa !257
  %8 = icmp ult ptr %5, %7
  br i1 %8, label %11, label %9

9:                                                ; preds = %2
  %10 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEh(ptr noundef nonnull align 8 dereferenceable(48) %1, i8 noundef zeroext 37) #33
  br label %13

11:                                               ; preds = %2
  %12 = getelementptr inbounds nuw i8, ptr %5, i64 1
  store ptr %12, ptr %4, align 8, !tbaa !258
  store i8 37, ptr %5, align 1, !tbaa !212
  br label %13

13:                                               ; preds = %11, %9
  %14 = load ptr, ptr %6, align 8, !tbaa !257
  %15 = load ptr, ptr %4, align 8, !tbaa !258
  %16 = ptrtoint ptr %14 to i64
  %17 = ptrtoint ptr %15 to i64
  %18 = sub i64 %16, %17
  %19 = icmp ult i64 %18, 3
  br i1 %19, label %20, label %22

20:                                               ; preds = %13
  %21 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostream5writeEPKcm(ptr noundef nonnull align 8 dereferenceable(48) %1, ptr noundef nonnull @.str.25, i64 noundef 3) #33
  br label %25

22:                                               ; preds = %13
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %15, ptr noundef nonnull align 1 dereferenceable(3) @.str.25, i64 3, i1 false)
  %23 = load ptr, ptr %4, align 8, !tbaa !258
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 3
  store ptr %24, ptr %4, align 8, !tbaa !258
  br label %25

25:                                               ; preds = %20, %22
  %26 = phi ptr [ %21, %20 ], [ %1, %22 ]
  %27 = getelementptr inbounds nuw i8, ptr %3, i64 24
  %28 = load i32, ptr %27, align 8, !tbaa !72
  %29 = sext i32 %28 to i64
  %30 = tail call noundef nonnull align 8 dereferenceable(48) ptr @_ZN4llvm11raw_ostreamlsEl(ptr noundef nonnull align 8 dereferenceable(48) %26, i64 noundef %29) #33
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define internal noundef zeroext i1 @"_ZNSt17_Function_handlerIFvRN4llvm11raw_ostreamEEZNS0_17printMBBReferenceERKNS0_17MachineBasicBlockEE3$_0E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation"(ptr noundef nonnull writeonly align 8 captures(none) dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(16) %1, i32 noundef %2) #17 align 2 {
  switch i32 %2, label %8 [
    i32 1, label %4
    i32 0, label %5
    i32 2, label %6
  ]

4:                                                ; preds = %3
  store ptr %1, ptr %0, align 8, !tbaa !743
  br label %8

5:                                                ; preds = %3
  store ptr null, ptr %0, align 8, !tbaa !1053
  br label %8

6:                                                ; preds = %3
  %7 = load i64, ptr %1, align 8, !tbaa !289
  store i64 %7, ptr %0, align 8, !tbaa !289
  br label %8

8:                                                ; preds = %3, %6, %5, %4
  ret i1 false
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden noundef i32 @_ZN4llvm12function_refIFiPcmEE11callback_fnIZNS_lsIJjEEERNS_11raw_ostreamES7_NS_13format_objectIJDpT_EEEEUlS1_mE_EEilS1_m(i64 noundef %0, ptr noundef %1, i64 noundef %2) #3 comdat align 2 {
  %4 = inttoptr i64 %0 to ptr
  %5 = load ptr, ptr %4, align 8, !tbaa !1159, !nonnull !17, !align !200
  %6 = and i64 %2, 4294967295
  %7 = load ptr, ptr %5, align 8, !tbaa !351
  %8 = getelementptr inbounds nuw i8, ptr %5, i64 8
  %9 = load i32, ptr %8, align 8, !tbaa !451
  %10 = tail call noundef i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef %1, i64 noundef %6, ptr noundef %7, i32 noundef %9) #33
  ret i32 %10
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden noundef i32 @_ZN4llvm12function_refIFiPcmEE11callback_fnIZNS_lsIJdEEERNS_11raw_ostreamES7_NS_13format_objectIJDpT_EEEEUlS1_mE_EEilS1_m(i64 noundef %0, ptr noundef %1, i64 noundef %2) #3 comdat align 2 {
  %4 = inttoptr i64 %0 to ptr
  %5 = load ptr, ptr %4, align 8, !tbaa !1161, !nonnull !17, !align !200
  %6 = and i64 %2, 4294967295
  %7 = load ptr, ptr %5, align 8, !tbaa !366
  %8 = getelementptr inbounds nuw i8, ptr %5, i64 8
  %9 = load double, ptr %8, align 8, !tbaa !1163
  %10 = tail call noundef i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef %1, i64 noundef %6, ptr noundef %7, double noundef %9) #33
  ret i32 %10
}

; Function Attrs: mustprogress nofree nosync nounwind memory(readwrite, inaccessiblemem: none) uwtable
define internal fastcc void @"_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN4llvm17MachineBasicBlock16RegisterMaskPairESt6vectorIS4_SaIS4_EEEElZNS3_17sortUniqueLiveInsEvE3$_0EvT_SB_T0_T1_"(ptr %0, ptr %1, i64 noundef %2) unnamed_addr #13 {
  %4 = alloca %"struct.llvm::MachineBasicBlock::RegisterMaskPair", align 8
  %5 = alloca %"struct.llvm::MachineBasicBlock::RegisterMaskPair", align 8
  %6 = alloca %"struct.llvm::MachineBasicBlock::RegisterMaskPair", align 8
  %7 = alloca %"struct.llvm::MachineBasicBlock::RegisterMaskPair", align 8
  %8 = alloca %"struct.llvm::MachineBasicBlock::RegisterMaskPair", align 8
  %9 = alloca %"struct.llvm::MachineBasicBlock::RegisterMaskPair", align 8
  %10 = alloca %"struct.llvm::MachineBasicBlock::RegisterMaskPair", align 8
  %11 = ptrtoint ptr %0 to i64
  %12 = ptrtoint ptr %1 to i64
  %13 = sub i64 %12, %11
  %14 = ashr exact i64 %13, 4
  %15 = icmp sgt i64 %14, 16
  br i1 %15, label %16, label %188

16:                                               ; preds = %3
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %18 = icmp eq i64 %2, 0
  br i1 %18, label %21, label %139

19:                                               ; preds = %183
  %20 = icmp eq i64 %143, 0
  br i1 %20, label %21, label %139, !llvm.loop !1164

21:                                               ; preds = %19, %16
  %22 = phi i64 [ %14, %16 ], [ %186, %19 ]
  %23 = phi i64 [ %13, %16 ], [ %185, %19 ]
  %24 = phi ptr [ %1, %16 ], [ %171, %19 ]
  %25 = add nsw i64 %22, -2
  %26 = lshr i64 %25, 1
  %27 = add nsw i64 %22, -1
  %28 = lshr i64 %27, 1
  %29 = and i64 %23, 16
  %30 = icmp eq i64 %29, 0
  %31 = or disjoint i64 %25, 1
  %32 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %31
  %33 = getelementptr inbounds nuw %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %26
  br label %34

34:                                               ; preds = %73, %21
  %35 = phi i64 [ %26, %21 ], [ %78, %73 ]
  %36 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %35
  %37 = load i32, ptr %36, align 8, !tbaa !451
  %38 = getelementptr inbounds nuw i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8, !tbaa !454
  %40 = icmp slt i64 %35, %28
  br i1 %40, label %41, label %55

41:                                               ; preds = %34, %41
  %42 = phi i64 [ %51, %41 ], [ %35, %34 ]
  %43 = shl i64 %42, 1
  %44 = add i64 %43, 2
  %45 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %44
  %46 = or disjoint i64 %43, 1
  %47 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %46
  %48 = load i32, ptr %45, align 4, !tbaa !522
  %49 = load i32, ptr %47, align 4, !tbaa !522
  %50 = icmp ult i32 %48, %49
  %51 = select i1 %50, i64 %46, i64 %44
  %52 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %51
  %53 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %42
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %53, ptr noundef nonnull align 8 dereferenceable(16) %52, i64 16, i1 false), !tbaa.struct !526
  %54 = icmp slt i64 %51, %28
  br i1 %54, label %41, label %55, !llvm.loop !1165

55:                                               ; preds = %41, %34
  %56 = phi i64 [ %35, %34 ], [ %51, %41 ]
  %57 = icmp eq i64 %56, %26
  %58 = select i1 %30, i1 %57, i1 false
  br i1 %58, label %59, label %60

59:                                               ; preds = %55
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %33, ptr noundef nonnull align 8 dereferenceable(16) %32, i64 16, i1 false), !tbaa.struct !526
  br label %60

60:                                               ; preds = %59, %55
  %61 = phi i64 [ %31, %59 ], [ %56, %55 ]
  %62 = icmp sgt i64 %61, %35
  br i1 %62, label %63, label %73

63:                                               ; preds = %60, %70
  %64 = phi i64 [ %66, %70 ], [ %61, %60 ]
  %65 = add nsw i64 %64, -1
  %66 = sdiv i64 %65, 2
  %67 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %66
  %68 = load i32, ptr %67, align 4, !tbaa !522
  %69 = icmp ult i32 %68, %37
  br i1 %69, label %70, label %73

70:                                               ; preds = %63
  %71 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %64
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %71, ptr noundef nonnull align 8 dereferenceable(16) %67, i64 16, i1 false), !tbaa.struct !526
  %72 = icmp sgt i64 %66, %35
  br i1 %72, label %63, label %73, !llvm.loop !1166

73:                                               ; preds = %70, %63, %60
  %74 = phi i64 [ %61, %60 ], [ %64, %63 ], [ %66, %70 ]
  %75 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %74
  store i32 %37, ptr %75, align 8, !tbaa !451
  %76 = getelementptr inbounds nuw i8, ptr %75, i64 8
  store i64 %39, ptr %76, align 8, !tbaa !454
  %77 = icmp eq i64 %35, 0
  %78 = add nsw i64 %35, -1
  br i1 %77, label %79, label %34, !llvm.loop !1167

79:                                               ; preds = %73
  %80 = icmp sgt i64 %23, 16
  br i1 %80, label %81, label %188

81:                                               ; preds = %79, %134
  %82 = phi ptr [ %83, %134 ], [ %24, %79 ]
  %83 = getelementptr inbounds i8, ptr %82, i64 -16
  %84 = load i32, ptr %83, align 8, !tbaa !451
  %85 = getelementptr inbounds i8, ptr %82, i64 -8
  %86 = load i64, ptr %85, align 8, !tbaa !454
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %83, ptr noundef nonnull align 8 dereferenceable(16) %0, i64 16, i1 false), !tbaa.struct !526
  %87 = ptrtoint ptr %83 to i64
  %88 = sub i64 %87, %11
  %89 = ashr exact i64 %88, 4
  %90 = add nsw i64 %89, -1
  %91 = sdiv i64 %90, 2
  %92 = icmp sgt i64 %89, 2
  br i1 %92, label %93, label %107

93:                                               ; preds = %81, %93
  %94 = phi i64 [ %103, %93 ], [ 0, %81 ]
  %95 = shl i64 %94, 1
  %96 = add i64 %95, 2
  %97 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %96
  %98 = or disjoint i64 %95, 1
  %99 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %98
  %100 = load i32, ptr %97, align 4, !tbaa !522
  %101 = load i32, ptr %99, align 4, !tbaa !522
  %102 = icmp ult i32 %100, %101
  %103 = select i1 %102, i64 %98, i64 %96
  %104 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %103
  %105 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %94
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %105, ptr noundef nonnull align 8 dereferenceable(16) %104, i64 16, i1 false), !tbaa.struct !526
  %106 = icmp slt i64 %103, %91
  br i1 %106, label %93, label %107, !llvm.loop !1165

107:                                              ; preds = %93, %81
  %108 = phi i64 [ 0, %81 ], [ %103, %93 ]
  %109 = and i64 %88, 16
  %110 = icmp eq i64 %109, 0
  br i1 %110, label %111, label %120

111:                                              ; preds = %107
  %112 = add nsw i64 %89, -2
  %113 = ashr exact i64 %112, 1
  %114 = icmp eq i64 %108, %113
  br i1 %114, label %115, label %120

115:                                              ; preds = %111
  %116 = shl nuw nsw i64 %108, 1
  %117 = or disjoint i64 %116, 1
  %118 = getelementptr inbounds nuw %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %117
  %119 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %108
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %119, ptr noundef nonnull align 8 dereferenceable(16) %118, i64 16, i1 false), !tbaa.struct !526
  br label %122

120:                                              ; preds = %111, %107
  %121 = icmp eq i64 %108, 0
  br i1 %121, label %134, label %122

122:                                              ; preds = %120, %115
  %123 = phi i64 [ %108, %120 ], [ %117, %115 ]
  br label %124

124:                                              ; preds = %122, %131
  %125 = phi i64 [ %127, %131 ], [ %123, %122 ]
  %126 = add nsw i64 %125, -1
  %127 = lshr i64 %126, 1
  %128 = getelementptr inbounds nuw %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %127
  %129 = load i32, ptr %128, align 4, !tbaa !522
  %130 = icmp ult i32 %129, %84
  br i1 %130, label %131, label %134

131:                                              ; preds = %124
  %132 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %125
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %132, ptr noundef nonnull align 8 dereferenceable(16) %128, i64 16, i1 false), !tbaa.struct !526
  %133 = icmp ult i64 %126, 2
  br i1 %133, label %134, label %124, !llvm.loop !1166

134:                                              ; preds = %131, %124, %120
  %135 = phi i64 [ 0, %120 ], [ %125, %124 ], [ 0, %131 ]
  %136 = getelementptr inbounds %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %135
  store i32 %84, ptr %136, align 8, !tbaa !451
  %137 = getelementptr inbounds nuw i8, ptr %136, i64 8
  store i64 %86, ptr %137, align 8, !tbaa !454
  %138 = icmp sgt i64 %88, 16
  br i1 %138, label %81, label %188, !llvm.loop !1168

139:                                              ; preds = %16, %19
  %140 = phi ptr [ %171, %19 ], [ %1, %16 ]
  %141 = phi i64 [ %143, %19 ], [ %2, %16 ]
  %142 = phi i64 [ %186, %19 ], [ %14, %16 ]
  %143 = add nsw i64 %141, -1
  %144 = lshr i64 %142, 1
  %145 = getelementptr inbounds nuw %"struct.llvm::MachineBasicBlock::RegisterMaskPair", ptr %0, i64 %144
  %146 = getelementptr inbounds i8, ptr %140, i64 -16
  %147 = load i32, ptr %17, align 4, !tbaa !522
  %148 = load i32, ptr %145, align 4, !tbaa !522
  %149 = icmp ult i32 %147, %148
  %150 = load i32, ptr %146, align 4, !tbaa !522
  br i1 %149, label %151, label %158

151:                                              ; preds = %139
  %152 = icmp ult i32 %148, %150
  br i1 %152, label %153, label %154

153:                                              ; preds = %151
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %10)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %10, ptr noundef nonnull align 8 dereferenceable(16) %0, i64 16, i1 false), !tbaa.struct !526
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(16) %145, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %145, ptr noundef nonnull align 8 dereferenceable(16) %10, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %10)
  br label %165

154:                                              ; preds = %151
  %155 = icmp ult i32 %147, %150
  br i1 %155, label %156, label %157

156:                                              ; preds = %154
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %9)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %9, ptr noundef nonnull align 8 dereferenceable(16) %0, i64 16, i1 false), !tbaa.struct !526
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(16) %146, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %146, ptr noundef nonnull align 8 dereferenceable(16) %9, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %9)
  br label %165

157:                                              ; preds = %154
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %8)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %8, ptr noundef nonnull align 8 dereferenceable(16) %0, i64 16, i1 false), !tbaa.struct !526
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(16) %17, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %17, ptr noundef nonnull align 8 dereferenceable(16) %8, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8)
  br label %165

158:                                              ; preds = %139
  %159 = icmp ult i32 %147, %150
  br i1 %159, label %160, label %161

160:                                              ; preds = %158
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %7)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %7, ptr noundef nonnull align 8 dereferenceable(16) %0, i64 16, i1 false), !tbaa.struct !526
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(16) %17, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %17, ptr noundef nonnull align 8 dereferenceable(16) %7, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %7)
  br label %165

161:                                              ; preds = %158
  %162 = icmp ult i32 %148, %150
  br i1 %162, label %163, label %164

163:                                              ; preds = %161
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %6)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %6, ptr noundef nonnull align 8 dereferenceable(16) %0, i64 16, i1 false), !tbaa.struct !526
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(16) %146, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %146, ptr noundef nonnull align 8 dereferenceable(16) %6, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %6)
  br label %165

164:                                              ; preds = %161
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %5)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %5, ptr noundef nonnull align 8 dereferenceable(16) %0, i64 16, i1 false), !tbaa.struct !526
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull align 8 dereferenceable(16) %145, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %145, ptr noundef nonnull align 8 dereferenceable(16) %5, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %5)
  br label %165

165:                                              ; preds = %164, %163, %160, %157, %156, %153
  br label %166

166:                                              ; preds = %165, %182
  %167 = phi ptr [ %177, %182 ], [ %140, %165 ]
  %168 = phi ptr [ %174, %182 ], [ %17, %165 ]
  %169 = load i32, ptr %0, align 4, !tbaa !522
  br label %170

170:                                              ; preds = %170, %166
  %171 = phi ptr [ %168, %166 ], [ %174, %170 ]
  %172 = load i32, ptr %171, align 4, !tbaa !522
  %173 = icmp ult i32 %172, %169
  %174 = getelementptr inbounds nuw i8, ptr %171, i64 16
  br i1 %173, label %170, label %175, !llvm.loop !1169

175:                                              ; preds = %170, %175
  %176 = phi ptr [ %177, %175 ], [ %167, %170 ]
  %177 = getelementptr inbounds i8, ptr %176, i64 -16
  %178 = load i32, ptr %177, align 4, !tbaa !522
  %179 = icmp ult i32 %169, %178
  br i1 %179, label %175, label %180, !llvm.loop !1170

180:                                              ; preds = %175
  %181 = icmp ult ptr %171, %177
  br i1 %181, label %182, label %183

182:                                              ; preds = %180
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %4, ptr noundef nonnull align 8 dereferenceable(16) %171, i64 16, i1 false), !tbaa.struct !526
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %171, ptr noundef nonnull align 8 dereferenceable(16) %177, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %177, ptr noundef nonnull align 8 dereferenceable(16) %4, i64 16, i1 false), !tbaa.struct !526
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4)
  br label %166, !llvm.loop !1171

183:                                              ; preds = %180
  tail call fastcc void @"_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN4llvm17MachineBasicBlock16RegisterMaskPairESt6vectorIS4_SaIS4_EEEElZNS3_17sortUniqueLiveInsEvE3$_0EvT_SB_T0_T1_"(ptr nonnull %171, ptr %140, i64 noundef %143)
  %184 = ptrtoint ptr %171 to i64
  %185 = sub i64 %184, %11
  %186 = ashr exact i64 %185, 4
  %187 = icmp sgt i64 %186, 16
  br i1 %187, label %19, label %188, !llvm.loop !1164

188:                                              ; preds = %183, %134, %3, %79
  ret void
}

; Function Attrs: mustprogress noinline nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EE15growAndPushBackES2_(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef %1) local_unnamed_addr #27 comdat align 2 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %4 = load i32, ptr %3, align 8, !tbaa !76
  %5 = zext i32 %4 to i64
  %6 = add nuw nsw i64 %5, 1
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void @_ZN4llvm15SmallVectorBaseIjE8grow_podEPvmm(ptr noundef nonnull align 8 dereferenceable(16) %0, ptr noundef nonnull %7, i64 noundef %6, i64 noundef 8) #33
  %8 = load ptr, ptr %0, align 8, !tbaa !19
  %9 = load i32, ptr %3, align 8, !tbaa !76
  %10 = zext i32 %9 to i64
  %11 = getelementptr inbounds nuw ptr, ptr %8, i64 %10
  store ptr %1, ptr %11, align 1
  %12 = load i32, ptr %3, align 8, !tbaa !76
  %13 = add i32 %12, 1
  store i32 %13, ptr %3, align 8, !tbaa !76
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZN4llvm8SmallSetINS_8RegisterELj8ESt4lessIS1_EE10insertImplIRKS1_EESt4pairINS_16SmallSetIteratorIS1_Lj8ES3_EEbEOT_(ptr dead_on_unwind noalias writable sret(%"struct.std::pair.538") align 8 %0, ptr noundef nonnull align 8 dereferenceable(96) %1, ptr noundef nonnull align 4 dereferenceable(4) %2) local_unnamed_addr #3 comdat align 2 {
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 88
  %5 = load i64, ptr %4, align 8, !tbaa !807
  %6 = icmp eq i64 %5, 0
  br i1 %6, label %50, label %7

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %1, i64 64
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 56
  %10 = load ptr, ptr %8, align 8, !tbaa !833
  %11 = icmp eq ptr %10, null
  %12 = load i32, ptr %2, align 4, !tbaa !451
  br i1 %11, label %23, label %13

13:                                               ; preds = %7, %13
  %14 = phi ptr [ %20, %13 ], [ %10, %7 ]
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 32
  %16 = load i32, ptr %15, align 4, !tbaa !767
  %17 = icmp ult i32 %12, %16
  %18 = select i1 %17, i64 16, i64 24
  %19 = getelementptr inbounds nuw i8, ptr %14, i64 %18
  %20 = load ptr, ptr %19, align 8, !tbaa !833
  %21 = icmp eq ptr %20, null
  br i1 %21, label %22, label %13, !llvm.loop !1172

22:                                               ; preds = %13
  br i1 %17, label %23, label %32

23:                                               ; preds = %22, %7
  %24 = phi ptr [ %14, %22 ], [ %9, %7 ]
  %25 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %26 = load ptr, ptr %25, align 8, !tbaa !805
  %27 = icmp eq ptr %24, %26
  br i1 %27, label %37, label %28

28:                                               ; preds = %23
  %29 = tail call noundef ptr @_ZSt18_Rb_tree_decrementPSt18_Rb_tree_node_base(ptr noundef nonnull %24) #40
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 32
  %31 = load i32, ptr %30, align 4, !tbaa !767
  br label %32

32:                                               ; preds = %28, %22
  %33 = phi i32 [ %31, %28 ], [ %16, %22 ]
  %34 = phi ptr [ %24, %28 ], [ %14, %22 ]
  %35 = phi ptr [ %29, %28 ], [ %14, %22 ]
  %36 = icmp ult i32 %33, %12
  br i1 %36, label %37, label %132

37:                                               ; preds = %32, %23
  %38 = phi ptr [ %24, %23 ], [ %34, %32 ]
  %39 = icmp eq ptr %38, %9
  br i1 %39, label %44, label %40

40:                                               ; preds = %37
  %41 = getelementptr inbounds nuw i8, ptr %38, i64 32
  %42 = load i32, ptr %41, align 4, !tbaa !767
  %43 = icmp ult i32 %12, %42
  br label %44

44:                                               ; preds = %40, %37
  %45 = phi i1 [ true, %37 ], [ %43, %40 ]
  %46 = tail call noalias noundef nonnull dereferenceable(40) ptr @_Znwm(i64 noundef 40) #36
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  store i32 %12, ptr %47, align 4, !tbaa !451
  tail call void @_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_(i1 noundef zeroext %45, ptr noundef nonnull %46, ptr noundef nonnull %38, ptr noundef nonnull align 8 dereferenceable(32) %9) #33
  %48 = load i64, ptr %4, align 8, !tbaa !807
  %49 = add i64 %48, 1
  store i64 %49, ptr %4, align 8, !tbaa !807
  br label %132

50:                                               ; preds = %3
  %51 = load ptr, ptr %1, align 8, !tbaa !19
  %52 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %53 = load i32, ptr %52, align 8, !tbaa !76
  %54 = zext i32 %53 to i64
  %55 = shl nuw nsw i64 %54, 2
  %56 = getelementptr inbounds nuw i8, ptr %51, i64 %55
  %57 = icmp eq i32 %53, 0
  %58 = load i32, ptr %2, align 4, !tbaa !451
  br i1 %57, label %72, label %59

59:                                               ; preds = %50, %63
  %60 = phi ptr [ %64, %63 ], [ %51, %50 ]
  %61 = load i32, ptr %60, align 4, !tbaa !767
  %62 = icmp eq i32 %61, %58
  br i1 %62, label %66, label %63

63:                                               ; preds = %59
  %64 = getelementptr inbounds nuw i8, ptr %60, i64 4
  %65 = icmp eq ptr %64, %56
  br i1 %65, label %66, label %59, !llvm.loop !832

66:                                               ; preds = %59, %63
  %67 = phi ptr [ %60, %59 ], [ %56, %63 ]
  %68 = getelementptr inbounds nuw %"class.llvm::Register", ptr %51, i64 %54
  %69 = icmp eq ptr %67, %68
  br i1 %69, label %70, label %132

70:                                               ; preds = %66
  %71 = icmp ult i32 %53, 8
  br i1 %71, label %72, label %88

72:                                               ; preds = %50, %70
  %73 = phi ptr [ %67, %70 ], [ %51, %50 ]
  %74 = getelementptr inbounds nuw i8, ptr %1, i64 12
  %75 = load i32, ptr %74, align 4, !tbaa !77
  %76 = icmp ult i32 %53, %75
  br i1 %76, label %79, label %77, !prof !483

77:                                               ; preds = %72
  tail call void @_ZN4llvm23SmallVectorTemplateBaseINS_8RegisterELb1EE15growAndPushBackES1_(ptr noundef nonnull align 8 dereferenceable(16) %1, i32 %58)
  %78 = load i32, ptr %52, align 8, !tbaa !76
  br label %82

79:                                               ; preds = %72
  store i32 %58, ptr %73, align 1
  %80 = load i32, ptr %52, align 8, !tbaa !76
  %81 = add i32 %80, 1
  store i32 %81, ptr %52, align 8, !tbaa !76
  br label %82

82:                                               ; preds = %77, %79
  %83 = phi i32 [ %78, %77 ], [ %81, %79 ]
  %84 = load ptr, ptr %1, align 8, !tbaa !19
  %85 = zext i32 %83 to i64
  %86 = getelementptr inbounds nuw %"class.llvm::Register", ptr %84, i64 %85
  %87 = getelementptr inbounds i8, ptr %86, i64 -4
  br label %132

88:                                               ; preds = %70
  %89 = getelementptr inbounds nuw i8, ptr %1, i64 48
  tail call void @_ZNSt3setIN4llvm8RegisterESt4lessIS1_ESaIS1_EE6insertISt13move_iteratorIPS1_EEEvT_SA_(ptr noundef nonnull align 8 dereferenceable(48) %89, ptr %51, ptr nonnull %67)
  store i32 0, ptr %52, align 8, !tbaa !76
  %90 = getelementptr inbounds nuw i8, ptr %1, i64 64
  %91 = getelementptr inbounds nuw i8, ptr %1, i64 56
  %92 = load ptr, ptr %90, align 8, !tbaa !833
  %93 = icmp eq ptr %92, null
  %94 = load i32, ptr %2, align 4, !tbaa !451
  br i1 %93, label %105, label %95

95:                                               ; preds = %88, %95
  %96 = phi ptr [ %102, %95 ], [ %92, %88 ]
  %97 = getelementptr inbounds nuw i8, ptr %96, i64 32
  %98 = load i32, ptr %97, align 4, !tbaa !767
  %99 = icmp ult i32 %94, %98
  %100 = select i1 %99, i64 16, i64 24
  %101 = getelementptr inbounds nuw i8, ptr %96, i64 %100
  %102 = load ptr, ptr %101, align 8, !tbaa !833
  %103 = icmp eq ptr %102, null
  br i1 %103, label %104, label %95, !llvm.loop !1172

104:                                              ; preds = %95
  br i1 %99, label %105, label %114

105:                                              ; preds = %104, %88
  %106 = phi ptr [ %96, %104 ], [ %91, %88 ]
  %107 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %108 = load ptr, ptr %107, align 8, !tbaa !805
  %109 = icmp eq ptr %106, %108
  br i1 %109, label %119, label %110

110:                                              ; preds = %105
  %111 = tail call noundef ptr @_ZSt18_Rb_tree_decrementPSt18_Rb_tree_node_base(ptr noundef nonnull %106) #40
  %112 = getelementptr inbounds nuw i8, ptr %111, i64 32
  %113 = load i32, ptr %112, align 4, !tbaa !767
  br label %114

114:                                              ; preds = %110, %104
  %115 = phi i32 [ %113, %110 ], [ %98, %104 ]
  %116 = phi ptr [ %106, %110 ], [ %96, %104 ]
  %117 = phi ptr [ %111, %110 ], [ %96, %104 ]
  %118 = icmp ult i32 %115, %94
  br i1 %118, label %119, label %132

119:                                              ; preds = %114, %105
  %120 = phi ptr [ %106, %105 ], [ %116, %114 ]
  %121 = icmp eq ptr %120, %91
  br i1 %121, label %126, label %122

122:                                              ; preds = %119
  %123 = getelementptr inbounds nuw i8, ptr %120, i64 32
  %124 = load i32, ptr %123, align 4, !tbaa !767
  %125 = icmp ult i32 %94, %124
  br label %126

126:                                              ; preds = %122, %119
  %127 = phi i1 [ true, %119 ], [ %125, %122 ]
  %128 = tail call noalias noundef nonnull dereferenceable(40) ptr @_Znwm(i64 noundef 40) #36
  %129 = getelementptr inbounds nuw i8, ptr %128, i64 32
  store i32 %94, ptr %129, align 4, !tbaa !451
  tail call void @_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_(i1 noundef zeroext %127, ptr noundef nonnull %128, ptr noundef nonnull %120, ptr noundef nonnull align 8 dereferenceable(32) %91) #33
  %130 = load i64, ptr %4, align 8, !tbaa !807
  %131 = add i64 %130, 1
  store i64 %131, ptr %4, align 8, !tbaa !807
  br label %132

132:                                              ; preds = %126, %114, %66, %44, %32, %82
  %133 = phi i8 [ 1, %82 ], [ 0, %32 ], [ 0, %44 ], [ 1, %66 ], [ 0, %114 ], [ 0, %126 ]
  %134 = phi ptr [ %87, %82 ], [ %35, %32 ], [ %46, %44 ], [ %67, %66 ], [ %117, %114 ], [ %128, %126 ]
  %135 = phi i8 [ 1, %82 ], [ 0, %32 ], [ 1, %44 ], [ 0, %66 ], [ 1, %114 ], [ 1, %126 ]
  %136 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store i8 %133, ptr %136, align 8, !tbaa !1173
  %137 = ptrtoint ptr %134 to i64
  store i64 %137, ptr %0, align 8, !tbaa !212
  %138 = getelementptr inbounds nuw i8, ptr %0, i64 16
  store i8 %135, ptr %138, align 8, !tbaa !1175
  ret void
}

; Function Attrs: mustprogress nounwind uwtable
define linkonce_odr hidden void @_ZNSt3setIN4llvm8RegisterESt4lessIS1_ESaIS1_EE6insertISt13move_iteratorIPS1_EEEvT_SA_(ptr noundef nonnull align 8 dereferenceable(48) %0, ptr %1, ptr %2) local_unnamed_addr #3 comdat align 2 {
  %4 = icmp eq ptr %1, %2
  br i1 %4, label %64, label %5

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %11 = load i64, ptr %7, align 8, !tbaa !807
  br label %12

12:                                               ; preds = %60, %5
  %13 = phi i64 [ %11, %5 ], [ %61, %60 ]
  %14 = phi ptr [ %1, %5 ], [ %62, %60 ]
  %15 = icmp eq i64 %13, 0
  %16 = load i32, ptr %14, align 4, !tbaa !451
  br i1 %15, label %22, label %17

17:                                               ; preds = %12
  %18 = load ptr, ptr %8, align 8, !tbaa !833
  %19 = getelementptr inbounds nuw i8, ptr %18, i64 32
  %20 = load i32, ptr %19, align 4, !tbaa !767
  %21 = icmp ult i32 %20, %16
  br i1 %21, label %47, label %22

22:                                               ; preds = %17, %12
  %23 = load ptr, ptr %9, align 8, !tbaa !833
  %24 = icmp eq ptr %23, null
  br i1 %24, label %35, label %25

25:                                               ; preds = %22, %25
  %26 = phi ptr [ %32, %25 ], [ %23, %22 ]
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 32
  %28 = load i32, ptr %27, align 4, !tbaa !767
  %29 = icmp ult i32 %16, %28
  %30 = select i1 %29, i64 16, i64 24
  %31 = getelementptr inbounds nuw i8, ptr %26, i64 %30
  %32 = load ptr, ptr %31, align 8, !tbaa !833
  %33 = icmp eq ptr %32, null
  br i1 %33, label %34, label %25, !llvm.loop !1172

34:                                               ; preds = %25
  br i1 %29, label %35, label %43

35:                                               ; preds = %34, %22
  %36 = phi ptr [ %26, %34 ], [ %6, %22 ]
  %37 = load ptr, ptr %10, align 8, !tbaa !805
  %38 = icmp eq ptr %36, %37
  br i1 %38, label %47, label %39

39:                                               ; preds = %35
  %40 = tail call noundef ptr @_ZSt18_Rb_tree_decrementPSt18_Rb_tree_node_base(ptr noundef nonnull %36) #40
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 32
  %42 = load i32, ptr %41, align 4, !tbaa !767
  br label %43

43:                                               ; preds = %39, %34
  %44 = phi i32 [ %42, %39 ], [ %28, %34 ]
  %45 = phi ptr [ %36, %39 ], [ %26, %34 ]
  %46 = icmp ult i32 %44, %16
  br i1 %46, label %47, label %60

47:                                               ; preds = %43, %17, %35
  %48 = phi ptr [ %36, %35 ], [ %18, %17 ], [ %45, %43 ]
  %49 = icmp eq ptr %48, %6
  br i1 %49, label %54, label %50

50:                                               ; preds = %47
  %51 = getelementptr inbounds nuw i8, ptr %48, i64 32
  %52 = load i32, ptr %51, align 4, !tbaa !767
  %53 = icmp ult i32 %16, %52
  br label %54

54:                                               ; preds = %50, %47
  %55 = phi i1 [ true, %47 ], [ %53, %50 ]
  %56 = tail call noalias noundef nonnull dereferenceable(40) ptr @_Znwm(i64 noundef 40) #36
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 32
  store i32 %16, ptr %57, align 4, !tbaa !451
  tail call void @_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_(i1 noundef zeroext %55, ptr noundef nonnull %56, ptr noundef nonnull %48, ptr noundef nonnull align 8 dereferenceable(32) %6) #33
  %58 = load i64, ptr %7, align 8, !tbaa !807
  %59 = add i64 %58, 1
  store i64 %59, ptr %7, align 8, !tbaa !807
  br label %60

60:                                               ; preds = %43, %54
  %61 = phi i64 [ %13, %43 ], [ %59, %54 ]
  %62 = getelementptr inbounds nuw i8, ptr %14, i64 4
  %63 = icmp eq ptr %62, %2
  br i1 %63, label %64, label %12, !llvm.loop !1177

64:                                               ; preds = %60, %3
  ret void
}

; Function Attrs: mustprogress nofree nounwind willreturn memory(read)
declare noundef ptr @_ZSt18_Rb_tree_decrementPSt18_Rb_tree_node_base(ptr noundef) local_unnamed_addr #28

; Function Attrs: nounwind
declare void @_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_(i1 noundef zeroext, ptr noundef, ptr noundef, ptr noundef nonnull align 8 dereferenceable(32)) local_unnamed_addr #6

; Function Attrs: nounwind uwtable
define internal void @_GLOBAL__sub_I_MachineBasicBlock.cpp() #29 section ".text.startup" {
  tail call void @_ZN4llvm2cl6OptionC2ENS0_18NumOccurrencesFlagENS0_12OptionHiddenE(ptr noundef nonnull align 8 dereferenceable(120) @_ZL16PrintSlotIndexes, i32 noundef 0, i32 noundef 0) #33
  store i8 0, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 120), align 8, !tbaa !1178
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 136), align 8
  store ptr getelementptr inbounds nuw inrange(-16, 16) (i8, ptr @_ZTVN4llvm2cl11OptionValueIbEE, i64 16), ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 128), align 8, !tbaa !4
  store ptr getelementptr inbounds nuw inrange(-16, 88) (i8, ptr @_ZTVN4llvm2cl3optIbLb0ENS0_6parserIbEEEE, i64 16), ptr @_ZL16PrintSlotIndexes, align 8, !tbaa !4
  store ptr getelementptr inbounds nuw inrange(-16, 32) (i8, ptr @_ZTVN4llvm2cl6parserIbEE, i64 16), ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 144), align 8, !tbaa !4
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 152), i8 0, i64 32, i1 false)
  tail call void @_ZN4llvm2cl6Option9setArgStrENS_9StringRefE(ptr noundef nonnull align 8 dereferenceable(184) @_ZL16PrintSlotIndexes, ptr nonnull align 1 dereferenceable(18) @.str, i64 17) #33
  store ptr @.str.1, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 32), align 8, !tbaa !702
  store i64 90, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 40), align 8, !tbaa !454
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 120), align 8, !tbaa !1178
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 137), align 1, !tbaa !1154
  store i8 1, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 136), align 8, !tbaa !1182
  %1 = load i16, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 10), align 2
  %2 = and i16 %1, -97
  %3 = or disjoint i16 %2, 32
  store i16 %3, ptr getelementptr inbounds nuw (i8, ptr @_ZL16PrintSlotIndexes, i64 10), align 2
  tail call void @_ZN4llvm2cl6Option11addArgumentEv(ptr noundef nonnull align 8 dereferenceable(184) @_ZL16PrintSlotIndexes) #33
  %4 = tail call i32 @__cxa_atexit(ptr nonnull @_ZN4llvm2cl3optIbLb0ENS0_6parserIbEEED2Ev, ptr nonnull @_ZL16PrintSlotIndexes, ptr nonnull @__dso_handle) #33
  store i32 2, ptr @_ZN4llvm12MBBSectionID13ColdSectionIDE, align 4, !tbaa !206
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @_ZN4llvm12MBBSectionID13ColdSectionIDE, i64 4), align 4, !tbaa !1183
  %5 = tail call ptr @llvm.invariant.start.p0(i64 8, ptr nonnull @_ZN4llvm12MBBSectionID13ColdSectionIDE)
  store i32 1, ptr @_ZN4llvm12MBBSectionID18ExceptionSectionIDE, align 4, !tbaa !206
  store i32 0, ptr getelementptr inbounds nuw (i8, ptr @_ZN4llvm12MBBSectionID18ExceptionSectionIDE, i64 4), align 4, !tbaa !1183
  %6 = tail call ptr @llvm.invariant.start.p0(i64 8, ptr nonnull @_ZN4llvm12MBBSectionID18ExceptionSectionIDE)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #30

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #31

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #32

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #32

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #32

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #32

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v2i32(<2 x i32>) #32

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vector.reduce.add.v2i64(<2 x i64>) #32

attributes #0 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #1 = { inlinehint mustprogress nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree nounwind }
attributes #3 = { mustprogress nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { mustprogress nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { mustprogress nofree norecurse nosync nounwind memory(read, inaccessiblemem: write) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #13 = { mustprogress nofree nosync nounwind memory(readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #17 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #18 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #19 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #20 = { cold noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #21 = { nobuiltin allocsize(0) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #22 = { nobuiltin nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #23 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #24 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #25 = { noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #26 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #27 = { mustprogress noinline nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #28 = { mustprogress nofree nounwind willreturn memory(read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #29 = { nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #30 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #31 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #32 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #33 = { nounwind }
attributes #34 = { builtin nounwind }
attributes #35 = { cold noreturn nounwind }
attributes #36 = { builtin nounwind allocsize(0) }
attributes #37 = { nounwind allocsize(0,1) }
attributes #38 = { nounwind allocsize(0) }
attributes #39 = { noreturn nounwind }
attributes #40 = { nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{!"Ubuntu clang version 21.1.8 (6ubuntu1)"}
!4 = !{!5, !5, i64 0}
!5 = !{!"vtable pointer", !6, i64 0}
!6 = !{!"Simple C++ TBAA"}
!7 = !{!8, !10, i64 16}
!8 = !{!"_ZTSSt14_Function_base", !9, i64 0, !10, i64 16}
!9 = !{!"omnipotent char", !6, i64 0}
!10 = !{!"any pointer", !9, i64 0}
!11 = !{!12, !15, i64 16}
!12 = !{!"_ZTSN4llvm19SmallPtrSetImplBaseE", !13, i64 0, !14, i64 8, !14, i64 12, !15, i64 16}
!13 = !{!"any p2 pointer", !10, i64 0}
!14 = !{!"int", !9, i64 0}
!15 = !{!"bool", !9, i64 0}
!16 = !{i8 0, i8 2}
!17 = !{}
!18 = !{!12, !13, i64 0}
!19 = !{!20, !10, i64 0}
!20 = !{!"_ZTSN4llvm15SmallVectorBaseIjEE", !10, i64 0, !14, i64 8, !14, i64 12}
!21 = !{!22, !29, i64 16}
!22 = !{!"_ZTSN4llvm17MachineBasicBlockE", !23, i64 0, !29, i64 16, !14, i64 24, !14, i64 28, !30, i64 32, !31, i64 40, !43, i64 64, !48, i64 112, !50, i64 144, !55, i64 168, !59, i64 184, !64, i64 208, !14, i64 212, !15, i64 216, !15, i64 217, !14, i64 220, !29, i64 224, !15, i64 232, !15, i64 233, !15, i64 234, !15, i64 235, !15, i64 236, !65, i64 240, !69, i64 252, !15, i64 260, !15, i64 261, !15, i64 262, !71, i64 264, !71, i64 272, !71, i64 280}
!23 = !{!"_ZTSN4llvm22ilist_node_with_parentINS_17MachineBasicBlockENS_15MachineFunctionEJEEE", !24, i64 0}
!24 = !{!"_ZTSN4llvm10ilist_nodeINS_17MachineBasicBlockEJEEE", !25, i64 0}
!25 = !{!"_ZTSN4llvm15ilist_node_implINS_12ilist_detail12node_optionsINS_17MachineBasicBlockELb0ELb0EvLb0EvEEEE", !26, i64 0}
!26 = !{!"_ZTSN4llvm15ilist_node_baseILb0EvEE", !27, i64 0}
!27 = !{!"_ZTSN4llvm12ilist_detail18node_base_prevnextINS_15ilist_node_baseILb0EvEELb0EEE", !28, i64 0, !28, i64 8}
!28 = !{!"p1 _ZTSN4llvm15ilist_node_baseILb0EvEE", !10, i64 0}
!29 = !{!"p1 _ZTSN4llvm10BasicBlockE", !10, i64 0}
!30 = !{!"p1 _ZTSN4llvm15MachineFunctionE", !10, i64 0}
!31 = !{!"_ZTSN4llvm6iplistINS_12MachineInstrEJNS_23ilist_sentinel_trackingILb1EEEEEE", !32, i64 0}
!32 = !{!"_ZTSN4llvm11iplist_implINS_12simple_ilistINS_12MachineInstrEJNS_23ilist_sentinel_trackingILb1EEEEEENS_12ilist_traitsIS2_EEEE", !33, i64 0, !35, i64 8}
!33 = !{!"_ZTSN4llvm12ilist_traitsINS_12MachineInstrEEE", !34, i64 0}
!34 = !{!"p1 _ZTSN4llvm17MachineBasicBlockE", !10, i64 0}
!35 = !{!"_ZTSN4llvm12simple_ilistINS_12MachineInstrEJNS_23ilist_sentinel_trackingILb1EEEEEE", !36, i64 0}
!36 = !{!"_ZTSN4llvm14ilist_sentinelINS_12ilist_detail12node_optionsINS_12MachineInstrELb1ELb1EvLb0EvEEEE", !37, i64 0}
!37 = !{!"_ZTSN4llvm15ilist_node_implINS_12ilist_detail12node_optionsINS_12MachineInstrELb1ELb1EvLb0EvEEEE", !38, i64 0}
!38 = !{!"_ZTSN4llvm15ilist_node_baseILb1EvEE", !39, i64 0}
!39 = !{!"_ZTSN4llvm12ilist_detail18node_base_prevnextINS_15ilist_node_baseILb1EvEELb1EEE", !40, i64 0, !42, i64 8}
!40 = !{!"_ZTSN4llvm14PointerIntPairIPNS_15ilist_node_baseILb1EvEELj1EjNS_21PointerLikeTypeTraitsIS3_EENS_18PointerIntPairInfoIS3_Lj1ES5_EEEE", !41, i64 0}
!41 = !{!"_ZTSN4llvm6detail13PunnedPointerIPNS_15ilist_node_baseILb1EvEEEE", !9, i64 0}
!42 = !{!"p1 _ZTSN4llvm15ilist_node_baseILb1EvEE", !10, i64 0}
!43 = !{!"_ZTSN4llvm11SmallVectorIPNS_17MachineBasicBlockELj4EEE", !44, i64 0, !47, i64 16}
!44 = !{!"_ZTSN4llvm15SmallVectorImplIPNS_17MachineBasicBlockEEE", !45, i64 0}
!45 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseIPNS_17MachineBasicBlockELb1EEE", !46, i64 0}
!46 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonIPNS_17MachineBasicBlockEvEE", !20, i64 0}
!47 = !{!"_ZTSN4llvm18SmallVectorStorageIPNS_17MachineBasicBlockELj4EEE", !9, i64 0}
!48 = !{!"_ZTSN4llvm11SmallVectorIPNS_17MachineBasicBlockELj2EEE", !44, i64 0, !49, i64 16}
!49 = !{!"_ZTSN4llvm18SmallVectorStorageIPNS_17MachineBasicBlockELj2EEE", !9, i64 0}
!50 = !{!"_ZTSSt6vectorIN4llvm17BranchProbabilityESaIS1_EE", !51, i64 0}
!51 = !{!"_ZTSSt12_Vector_baseIN4llvm17BranchProbabilityESaIS1_EE", !52, i64 0}
!52 = !{!"_ZTSNSt12_Vector_baseIN4llvm17BranchProbabilityESaIS1_EE12_Vector_implE", !53, i64 0}
!53 = !{!"_ZTSNSt12_Vector_baseIN4llvm17BranchProbabilityESaIS1_EE17_Vector_impl_dataE", !54, i64 0, !54, i64 8, !54, i64 16}
!54 = !{!"p1 _ZTSN4llvm17BranchProbabilityE", !10, i64 0}
!55 = !{!"_ZTSSt8optionalImE", !56, i64 0}
!56 = !{!"_ZTSSt14_Optional_baseImLb1ELb1EE", !57, i64 0}
!57 = !{!"_ZTSSt17_Optional_payloadImLb1ELb1ELb1EE", !58, i64 0}
!58 = !{!"_ZTSSt22_Optional_payload_baseImE", !9, i64 0, !15, i64 8}
!59 = !{!"_ZTSSt6vectorIN4llvm17MachineBasicBlock16RegisterMaskPairESaIS2_EE", !60, i64 0}
!60 = !{!"_ZTSSt12_Vector_baseIN4llvm17MachineBasicBlock16RegisterMaskPairESaIS2_EE", !61, i64 0}
!61 = !{!"_ZTSNSt12_Vector_baseIN4llvm17MachineBasicBlock16RegisterMaskPairESaIS2_EE12_Vector_implE", !62, i64 0}
!62 = !{!"_ZTSNSt12_Vector_baseIN4llvm17MachineBasicBlock16RegisterMaskPairESaIS2_EE17_Vector_impl_dataE", !63, i64 0, !63, i64 8, !63, i64 16}
!63 = !{!"p1 _ZTSN4llvm17MachineBasicBlock16RegisterMaskPairE", !10, i64 0}
!64 = !{!"_ZTSN4llvm5AlignE", !9, i64 0}
!65 = !{!"_ZTSSt8optionalIN4llvm10UniqueBBIDEE", !66, i64 0}
!66 = !{!"_ZTSSt14_Optional_baseIN4llvm10UniqueBBIDELb1ELb1EE", !67, i64 0}
!67 = !{!"_ZTSSt17_Optional_payloadIN4llvm10UniqueBBIDELb1ELb1ELb1EE", !68, i64 0}
!68 = !{!"_ZTSSt22_Optional_payload_baseIN4llvm10UniqueBBIDEE", !9, i64 0, !15, i64 8}
!69 = !{!"_ZTSN4llvm12MBBSectionIDE", !70, i64 0, !14, i64 4}
!70 = !{!"_ZTSN4llvm12MBBSectionID11SectionTypeE", !9, i64 0}
!71 = !{!"p1 _ZTSN4llvm8MCSymbolE", !10, i64 0}
!72 = !{!22, !14, i64 24}
!73 = !{!22, !14, i64 28}
!74 = !{!22, !30, i64 32}
!75 = !{!39, !42, i64 8}
!76 = !{!20, !14, i64 8}
!77 = !{!20, !14, i64 12}
!78 = !{!58, !15, i64 8}
!79 = !{!22, !14, i64 212}
!80 = !{!22, !15, i64 216}
!81 = !{!22, !15, i64 217}
!82 = !{!68, !15, i64 8}
!83 = !{!33, !34, i64 0}
!84 = !{!62, !63, i64 16}
!85 = !{!62, !63, i64 0}
!86 = !{!53, !54, i64 16}
!87 = !{!53, !54, i64 0}
!88 = !{!22, !71, i64 264}
!89 = !{!90, !94, i64 24}
!90 = !{!"_ZTSN4llvm15MachineFunctionE", !91, i64 0, !92, i64 8, !93, i64 16, !94, i64 24, !95, i64 32, !96, i64 40, !97, i64 48, !98, i64 56, !99, i64 64, !100, i64 72, !101, i64 80, !102, i64 88, !14, i64 112, !14, i64 116, !107, i64 120, !119, i64 200, !121, i64 208, !127, i64 288, !129, i64 296, !14, i64 312, !64, i64 316, !15, i64 317, !15, i64 318, !15, i64 319, !133, i64 320, !136, i64 328, !143, i64 336, !148, i64 360, !148, i64 384, !153, i64 408, !158, i64 432, !161, i64 456, !163, i64 480, !165, i64 504, !15, i64 528, !15, i64 529, !15, i64 530, !15, i64 531, !15, i64 532, !15, i64 533, !15, i64 534, !14, i64 536, !170, i64 540, !171, i64 544, !173, i64 568, !178, i64 592, !178, i64 616, !182, i64 640, !183, i64 648, !184, i64 656, !186, i64 680, !188, i64 704, !14, i64 848, !193, i64 856, !198, i64 1032, !15, i64 1056}
!91 = !{!"p1 _ZTSN4llvm8FunctionE", !10, i64 0}
!92 = !{!"p1 _ZTSN4llvm13TargetMachineE", !10, i64 0}
!93 = !{!"p1 _ZTSN4llvm19TargetSubtargetInfoE", !10, i64 0}
!94 = !{!"p1 _ZTSN4llvm9MCContextE", !10, i64 0}
!95 = !{!"p1 _ZTSN4llvm19MachineRegisterInfoE", !10, i64 0}
!96 = !{!"p1 _ZTSN4llvm19MachineFunctionInfoE", !10, i64 0}
!97 = !{!"p1 _ZTSN4llvm16MachineFrameInfoE", !10, i64 0}
!98 = !{!"p1 _ZTSN4llvm19MachineConstantPoolE", !10, i64 0}
!99 = !{!"p1 _ZTSN4llvm20MachineJumpTableInfoE", !10, i64 0}
!100 = !{!"p1 _ZTSN4llvm9MCSectionE", !10, i64 0}
!101 = !{!"p1 _ZTSN4llvm13WinEHFuncInfoE", !10, i64 0}
!102 = !{!"_ZTSSt6vectorIPN4llvm17MachineBasicBlockESaIS2_EE", !103, i64 0}
!103 = !{!"_ZTSSt12_Vector_baseIPN4llvm17MachineBasicBlockESaIS2_EE", !104, i64 0}
!104 = !{!"_ZTSNSt12_Vector_baseIPN4llvm17MachineBasicBlockESaIS2_EE12_Vector_implE", !105, i64 0}
!105 = !{!"_ZTSNSt12_Vector_baseIPN4llvm17MachineBasicBlockESaIS2_EE17_Vector_impl_dataE", !106, i64 0, !106, i64 8, !106, i64 16}
!106 = !{!"p2 _ZTSN4llvm17MachineBasicBlockE", !13, i64 0}
!107 = !{!"_ZTSN4llvm20BumpPtrAllocatorImplINS_15MallocAllocatorELm4096ELm4096ELm128ELm8EEE", !108, i64 0, !109, i64 8, !110, i64 16, !115, i64 64}
!108 = !{!"p1 omnipotent char", !10, i64 0}
!109 = !{!"long", !9, i64 0}
!110 = !{!"_ZTSN4llvm11SmallVectorIPvLj4EEE", !111, i64 0, !114, i64 16}
!111 = !{!"_ZTSN4llvm15SmallVectorImplIPvEE", !112, i64 0}
!112 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseIPvLb1EEE", !113, i64 0}
!113 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonIPvvEE", !20, i64 0}
!114 = !{!"_ZTSN4llvm18SmallVectorStorageIPvLj4EEE", !9, i64 0}
!115 = !{!"_ZTSN4llvm11SmallVectorISt4pairIPvmELj0EEE", !116, i64 0}
!116 = !{!"_ZTSN4llvm15SmallVectorImplISt4pairIPvmEEE", !117, i64 0}
!117 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseISt4pairIPvmELb1EEE", !118, i64 0}
!118 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonISt4pairIPvmEvEE", !20, i64 0}
!119 = !{!"_ZTSN4llvm8RecyclerINS_12MachineInstrELm80ELm8EEE", !120, i64 0}
!120 = !{!"p1 _ZTSN4llvm8RecyclerINS_12MachineInstrELm80ELm8EE8FreeNodeE", !10, i64 0}
!121 = !{!"_ZTSN4llvm13ArrayRecyclerINS_14MachineOperandELm8EEE", !122, i64 0}
!122 = !{!"_ZTSN4llvm11SmallVectorIPNS_13ArrayRecyclerINS_14MachineOperandELm8EE8FreeListELj8EEE", !123, i64 0, !126, i64 16}
!123 = !{!"_ZTSN4llvm15SmallVectorImplIPNS_13ArrayRecyclerINS_14MachineOperandELm8EE8FreeListEEE", !124, i64 0}
!124 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseIPNS_13ArrayRecyclerINS_14MachineOperandELm8EE8FreeListELb1EEE", !125, i64 0}
!125 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonIPNS_13ArrayRecyclerINS_14MachineOperandELm8EE8FreeListEvEE", !20, i64 0}
!126 = !{!"_ZTSN4llvm18SmallVectorStorageIPNS_13ArrayRecyclerINS_14MachineOperandELm8EE8FreeListELj8EEE", !9, i64 0}
!127 = !{!"_ZTSN4llvm8RecyclerINS_17MachineBasicBlockELm288ELm8EEE", !128, i64 0}
!128 = !{!"p1 _ZTSN4llvm8RecyclerINS_17MachineBasicBlockELm288ELm8EE8FreeNodeE", !10, i64 0}
!129 = !{!"_ZTSN4llvm6iplistINS_17MachineBasicBlockEJEEE", !130, i64 0}
!130 = !{!"_ZTSN4llvm11iplist_implINS_12simple_ilistINS_17MachineBasicBlockEJEEENS_12ilist_traitsIS2_EEEE", !131, i64 0}
!131 = !{!"_ZTSN4llvm12simple_ilistINS_17MachineBasicBlockEJEEE", !132, i64 0}
!132 = !{!"_ZTSN4llvm14ilist_sentinelINS_12ilist_detail12node_optionsINS_17MachineBasicBlockELb0ELb0EvLb0EvEEEE", !25, i64 0}
!133 = !{!"_ZTSN4llvm25MachineFunctionPropertiesE", !134, i64 0}
!134 = !{!"_ZTSSt6bitsetILm12EE", !135, i64 0}
!135 = !{!"_ZTSSt12_Base_bitsetILm1EE", !109, i64 0}
!136 = !{!"_ZTSSt10unique_ptrIN4llvm24PseudoSourceValueManagerESt14default_deleteIS1_EE", !137, i64 0}
!137 = !{!"_ZTSSt15__uniq_ptr_dataIN4llvm24PseudoSourceValueManagerESt14default_deleteIS1_ELb1ELb1EE", !138, i64 0}
!138 = !{!"_ZTSSt15__uniq_ptr_implIN4llvm24PseudoSourceValueManagerESt14default_deleteIS1_EE", !139, i64 0}
!139 = !{!"_ZTSSt5tupleIJPN4llvm24PseudoSourceValueManagerESt14default_deleteIS1_EEE", !140, i64 0}
!140 = !{!"_ZTSSt11_Tuple_implILm0EJPN4llvm24PseudoSourceValueManagerESt14default_deleteIS1_EEE", !141, i64 0}
!141 = !{!"_ZTSSt10_Head_baseILm0EPN4llvm24PseudoSourceValueManagerELb0EE", !142, i64 0}
!142 = !{!"p1 _ZTSN4llvm24PseudoSourceValueManagerE", !10, i64 0}
!143 = !{!"_ZTSSt6vectorIN4llvm16MCCFIInstructionESaIS1_EE", !144, i64 0}
!144 = !{!"_ZTSSt12_Vector_baseIN4llvm16MCCFIInstructionESaIS1_EE", !145, i64 0}
!145 = !{!"_ZTSNSt12_Vector_baseIN4llvm16MCCFIInstructionESaIS1_EE12_Vector_implE", !146, i64 0}
!146 = !{!"_ZTSNSt12_Vector_baseIN4llvm16MCCFIInstructionESaIS1_EE17_Vector_impl_dataE", !147, i64 0, !147, i64 8, !147, i64 16}
!147 = !{!"p1 _ZTSN4llvm16MCCFIInstructionE", !10, i64 0}
!148 = !{!"_ZTSSt6vectorIPN4llvm8MCSymbolESaIS2_EE", !149, i64 0}
!149 = !{!"_ZTSSt12_Vector_baseIPN4llvm8MCSymbolESaIS2_EE", !150, i64 0}
!150 = !{!"_ZTSNSt12_Vector_baseIPN4llvm8MCSymbolESaIS2_EE12_Vector_implE", !151, i64 0}
!151 = !{!"_ZTSNSt12_Vector_baseIPN4llvm8MCSymbolESaIS2_EE17_Vector_impl_dataE", !152, i64 0, !152, i64 8, !152, i64 16}
!152 = !{!"p2 _ZTSN4llvm8MCSymbolE", !13, i64 0}
!153 = !{!"_ZTSSt6vectorIN4llvm14LandingPadInfoESaIS1_EE", !154, i64 0}
!154 = !{!"_ZTSSt12_Vector_baseIN4llvm14LandingPadInfoESaIS1_EE", !155, i64 0}
!155 = !{!"_ZTSNSt12_Vector_baseIN4llvm14LandingPadInfoESaIS1_EE12_Vector_implE", !156, i64 0}
!156 = !{!"_ZTSNSt12_Vector_baseIN4llvm14LandingPadInfoESaIS1_EE17_Vector_impl_dataE", !157, i64 0, !157, i64 8, !157, i64 16}
!157 = !{!"p1 _ZTSN4llvm14LandingPadInfoE", !10, i64 0}
!158 = !{!"_ZTSN4llvm8DenseMapIPNS_8MCSymbolENS_11SmallVectorIjLj4EEENS_12DenseMapInfoIS2_vEENS_6detail12DenseMapPairIS2_S4_EEEE", !159, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!159 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairIPNS_8MCSymbolENS_11SmallVectorIjLj4EEEEE", !10, i64 0}
!160 = !{!"p1 int", !10, i64 0}
!161 = !{!"_ZTSN4llvm8DenseMapIPKNS_17MachineBasicBlockEjNS_12DenseMapInfoIS3_vEENS_6detail12DenseMapPairIS3_jEEEE", !162, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!162 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairIPKNS_17MachineBasicBlockEjEE", !10, i64 0}
!163 = !{!"_ZTSN4llvm8DenseMapIPNS_8MCSymbolEjNS_12DenseMapInfoIS2_vEENS_6detail12DenseMapPairIS2_jEEEE", !164, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!164 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairIPNS_8MCSymbolEjEE", !10, i64 0}
!165 = !{!"_ZTSSt6vectorISt4pairIPN4llvm8MCSymbolEPNS1_6MDNodeEESaIS6_EE", !166, i64 0}
!166 = !{!"_ZTSSt12_Vector_baseISt4pairIPN4llvm8MCSymbolEPNS1_6MDNodeEESaIS6_EE", !167, i64 0}
!167 = !{!"_ZTSNSt12_Vector_baseISt4pairIPN4llvm8MCSymbolEPNS1_6MDNodeEESaIS6_EE12_Vector_implE", !168, i64 0}
!168 = !{!"_ZTSNSt12_Vector_baseISt4pairIPN4llvm8MCSymbolEPNS1_6MDNodeEESaIS6_EE17_Vector_impl_dataE", !169, i64 0, !169, i64 8, !169, i64 16}
!169 = !{!"p1 _ZTSSt4pairIPN4llvm8MCSymbolEPNS0_6MDNodeEE", !10, i64 0}
!170 = !{!"_ZTSN4llvm17BasicBlockSectionE", !9, i64 0}
!171 = !{!"_ZTSN4llvm8DenseMapINS_10UniqueBBIDENS_11SmallVectorIjLj12EEENS_12DenseMapInfoIS1_vEENS_6detail12DenseMapPairIS1_S3_EEEE", !172, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!172 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairINS_10UniqueBBIDENS_11SmallVectorIjLj12EEEEE", !10, i64 0}
!173 = !{!"_ZTSSt6vectorIPKN4llvm11GlobalValueESaIS3_EE", !174, i64 0}
!174 = !{!"_ZTSSt12_Vector_baseIPKN4llvm11GlobalValueESaIS3_EE", !175, i64 0}
!175 = !{!"_ZTSNSt12_Vector_baseIPKN4llvm11GlobalValueESaIS3_EE12_Vector_implE", !176, i64 0}
!176 = !{!"_ZTSNSt12_Vector_baseIPKN4llvm11GlobalValueESaIS3_EE17_Vector_impl_dataE", !177, i64 0, !177, i64 8, !177, i64 16}
!177 = !{!"p2 _ZTSN4llvm11GlobalValueE", !13, i64 0}
!178 = !{!"_ZTSSt6vectorIjSaIjEE", !179, i64 0}
!179 = !{!"_ZTSSt12_Vector_baseIjSaIjEE", !180, i64 0}
!180 = !{!"_ZTSNSt12_Vector_baseIjSaIjEE12_Vector_implE", !181, i64 0}
!181 = !{!"_ZTSNSt12_Vector_baseIjSaIjEE17_Vector_impl_dataE", !160, i64 0, !160, i64 8, !160, i64 16}
!182 = !{!"p1 _ZTSN4llvm15MachineFunction8DelegateE", !10, i64 0}
!183 = !{!"p1 _ZTSN4llvm19GISelChangeObserverE", !10, i64 0}
!184 = !{!"_ZTSN4llvm8DenseMapIPKNS_12MachineInstrENS_15MachineFunction12CallSiteInfoENS_12DenseMapInfoIS3_vEENS_6detail12DenseMapPairIS3_S5_EEEE", !185, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!185 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairIPKNS_12MachineInstrENS_15MachineFunction12CallSiteInfoEEE", !10, i64 0}
!186 = !{!"_ZTSN4llvm8DenseMapIPKNS_12MachineInstrENS_15MachineFunction16CalledGlobalInfoENS_12DenseMapInfoIS3_vEENS_6detail12DenseMapPairIS3_S5_EEEE", !187, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!187 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairIPKNS_12MachineInstrENS_15MachineFunction16CalledGlobalInfoEEE", !10, i64 0}
!188 = !{!"_ZTSN4llvm11SmallVectorINS_15MachineFunction15VariableDbgInfoELj4EEE", !189, i64 0, !192, i64 16}
!189 = !{!"_ZTSN4llvm15SmallVectorImplINS_15MachineFunction15VariableDbgInfoEEE", !190, i64 0}
!190 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseINS_15MachineFunction15VariableDbgInfoELb1EEE", !191, i64 0}
!191 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonINS_15MachineFunction15VariableDbgInfoEvEE", !20, i64 0}
!192 = !{!"_ZTSN4llvm18SmallVectorStorageINS_15MachineFunction15VariableDbgInfoELj4EEE", !9, i64 0}
!193 = !{!"_ZTSN4llvm11SmallVectorINS_15MachineFunction17DebugSubstitutionELj8EEE", !194, i64 0, !197, i64 16}
!194 = !{!"_ZTSN4llvm15SmallVectorImplINS_15MachineFunction17DebugSubstitutionEEE", !195, i64 0}
!195 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseINS_15MachineFunction17DebugSubstitutionELb1EEE", !196, i64 0}
!196 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonINS_15MachineFunction17DebugSubstitutionEvEE", !20, i64 0}
!197 = !{!"_ZTSN4llvm18SmallVectorStorageINS_15MachineFunction17DebugSubstitutionELj8EEE", !9, i64 0}
!198 = !{!"_ZTSN4llvm8DenseMapIjNS_15MachineFunction19DebugPHIRegallocPosENS_12DenseMapInfoIjvEENS_6detail12DenseMapPairIjS2_EEEE", !199, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!199 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairIjNS_15MachineFunction19DebugPHIRegallocPosEEE", !10, i64 0}
!200 = !{i64 8}
!201 = !{!90, !170, i64 540}
!202 = !{!203, !10, i64 0}
!203 = !{!"_ZTSN4llvm15SmallVectorBaseImEE", !10, i64 0, !109, i64 8, !109, i64 16}
!204 = !{!203, !109, i64 8}
!205 = !{!203, !109, i64 16}
!206 = !{!69, !70, i64 0}
!207 = !{!208, !210}
!208 = distinct !{!208, !209, !"_ZNK4llvm5Twine6concatERKS0_: argument 0"}
!209 = distinct !{!209, !"_ZNK4llvm5Twine6concatERKS0_"}
!210 = distinct !{!210, !211, !"_ZN4llvmplERKNS_5TwineES2_: argument 0"}
!211 = distinct !{!211, !"_ZN4llvmplERKNS_5TwineES2_"}
!212 = !{!9, !9, i64 0}
!213 = !{!214, !215, i64 32}
!214 = !{!"_ZTSN4llvm5TwineE", !9, i64 0, !9, i64 16, !215, i64 32, !215, i64 33}
!215 = !{!"_ZTSN4llvm5Twine8NodeKindE", !9, i64 0}
!216 = !{!214, !215, i64 33}
!217 = !{!218, !220}
!218 = distinct !{!218, !219, !"_ZNK4llvm5Twine6concatERKS0_: argument 0"}
!219 = distinct !{!219, !"_ZNK4llvm5Twine6concatERKS0_"}
!220 = distinct !{!220, !221, !"_ZN4llvmplERKNS_5TwineES2_: argument 0"}
!221 = distinct !{!221, !"_ZN4llvmplERKNS_5TwineES2_"}
!222 = !{!223, !108, i64 0}
!223 = !{!"_ZTSNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE", !224, i64 0, !109, i64 8, !9, i64 16}
!224 = !{!"_ZTSNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_Alloc_hiderE", !108, i64 0}
!225 = !{!223, !109, i64 8}
!226 = !{!227, !229}
!227 = distinct !{!227, !228, !"_ZNK4llvm5Twine6concatERKS0_: argument 0"}
!228 = distinct !{!228, !"_ZNK4llvm5Twine6concatERKS0_"}
!229 = distinct !{!229, !230, !"_ZN4llvmplERKNS_5TwineES2_: argument 0"}
!230 = distinct !{!230, !"_ZN4llvmplERKNS_5TwineES2_"}
!231 = !{!90, !14, i64 312}
!232 = !{!233, !235}
!233 = distinct !{!233, !234, !"_ZNK4llvm5Twine6concatERKS0_: argument 0"}
!234 = distinct !{!234, !"_ZNK4llvm5Twine6concatERKS0_"}
!235 = distinct !{!235, !236, !"_ZN4llvmplERKNS_5TwineES2_: argument 0"}
!236 = distinct !{!236, !"_ZN4llvmplERKNS_5TwineES2_"}
!237 = !{!238, !240}
!238 = distinct !{!238, !239, !"_ZNK4llvm5Twine6concatERKS0_: argument 0"}
!239 = distinct !{!239, !"_ZNK4llvm5Twine6concatERKS0_"}
!240 = distinct !{!240, !241, !"_ZN4llvmplERKNS_5TwineES2_: argument 0"}
!241 = distinct !{!241, !"_ZN4llvmplERKNS_5TwineES2_"}
!242 = !{!243, !245}
!243 = distinct !{!243, !244, !"_ZNK4llvm5Twine6concatERKS0_: argument 0"}
!244 = distinct !{!244, !"_ZNK4llvm5Twine6concatERKS0_"}
!245 = distinct !{!245, !246, !"_ZN4llvmplERKNS_5TwineES2_: argument 0"}
!246 = distinct !{!246, !"_ZN4llvmplERKNS_5TwineES2_"}
!247 = !{!22, !15, i64 232}
!248 = !{!22, !71, i64 272}
!249 = !{!250, !251, i64 8}
!250 = !{!"_ZTSN4llvm11raw_ostreamE", !251, i64 8, !108, i64 16, !108, i64 24, !108, i64 32, !15, i64 40, !252, i64 44}
!251 = !{!"_ZTSN4llvm11raw_ostream11OStreamKindE", !9, i64 0}
!252 = !{!"_ZTSN4llvm11raw_ostream10BufferKindE", !9, i64 0}
!253 = !{!250, !15, i64 40}
!254 = !{!250, !252, i64 44}
!255 = !{!256, !256, i64 0}
!256 = !{!"p1 _ZTSN4llvm15SmallVectorImplIcEE", !10, i64 0}
!257 = !{!250, !108, i64 24}
!258 = !{!250, !108, i64 32}
!259 = !{!22, !71, i64 280}
!260 = !{!261, !263}
!261 = distinct !{!261, !262, !"_ZNK4llvm5Twine6concatERKS0_: argument 0"}
!262 = distinct !{!262, !"_ZNK4llvm5Twine6concatERKS0_"}
!263 = distinct !{!263, !264, !"_ZN4llvmplERKNS_5TwineES2_: argument 0"}
!264 = distinct !{!264, !"_ZN4llvmplERKNS_5TwineES2_"}
!265 = !{!266, !268}
!266 = distinct !{!266, !267, !"_ZNK4llvm5Twine6concatERKS0_: argument 0"}
!267 = distinct !{!267, !"_ZNK4llvm5Twine6concatERKS0_"}
!268 = distinct !{!268, !269, !"_ZN4llvmplERKNS_5TwineES2_: argument 0"}
!269 = distinct !{!269, !"_ZN4llvmplERKNS_5TwineES2_"}
!270 = !{!271, !273}
!271 = distinct !{!271, !272, !"_ZNK4llvm5Twine6concatERKS0_: argument 0"}
!272 = distinct !{!272, !"_ZNK4llvm5Twine6concatERKS0_"}
!273 = distinct !{!273, !274, !"_ZN4llvmplERKNS_5TwineES2_: argument 0"}
!274 = distinct !{!274, !"_ZN4llvmplERKNS_5TwineES2_"}
!275 = !{!90, !91, i64 0}
!276 = !{!277, !284, i64 40}
!277 = !{!"_ZTSN4llvm11GlobalValueE", !278, i64 0, !282, i64 24, !14, i64 32, !14, i64 32, !14, i64 32, !14, i64 33, !14, i64 33, !14, i64 33, !14, i64 33, !14, i64 33, !14, i64 34, !14, i64 34, !14, i64 36, !284, i64 40}
!278 = !{!"_ZTSN4llvm8ConstantE", !279, i64 0}
!279 = !{!"_ZTSN4llvm4UserE", !280, i64 0}
!280 = !{!"_ZTSN4llvm5ValueE", !9, i64 0, !9, i64 1, !9, i64 1, !281, i64 2, !14, i64 4, !14, i64 7, !14, i64 7, !14, i64 7, !14, i64 7, !282, i64 8, !283, i64 16}
!281 = !{!"short", !9, i64 0}
!282 = !{!"p1 _ZTSN4llvm4TypeE", !10, i64 0}
!283 = !{!"p1 _ZTSN4llvm3UseE", !10, i64 0}
!284 = !{!"p1 _ZTSN4llvm6ModuleE", !10, i64 0}
!285 = !{!286, !10, i64 24}
!286 = !{!"_ZTSSt8functionIFvRN4llvm11raw_ostreamEEE", !8, i64 0, !10, i64 24}
!287 = !{!105, !106, i64 8}
!288 = !{!105, !106, i64 16}
!289 = !{!34, !34, i64 0}
!290 = !{!105, !106, i64 0}
!291 = !{!90, !14, i64 116}
!292 = !{!22, !14, i64 220}
!293 = !{!90, !95, i64 32}
!294 = !{!295, !34, i64 24}
!295 = !{!"_ZTSN4llvm12MachineInstrE", !296, i64 0, !298, i64 16, !34, i64 24, !299, i64 32, !14, i64 40, !300, i64 43, !14, i64 44, !9, i64 48, !14, i64 52, !14, i64 56, !301, i64 64, !302, i64 72}
!296 = !{!"_ZTSN4llvm22ilist_node_with_parentINS_12MachineInstrENS_17MachineBasicBlockEJNS_23ilist_sentinel_trackingILb1EEEEEE", !297, i64 0}
!297 = !{!"_ZTSN4llvm10ilist_nodeINS_12MachineInstrEJNS_23ilist_sentinel_trackingILb1EEEEEE", !37, i64 0}
!298 = !{!"p1 _ZTSN4llvm11MCInstrDescE", !10, i64 0}
!299 = !{!"p1 _ZTSN4llvm14MachineOperandE", !10, i64 0}
!300 = !{!"_ZTSN4llvm13ArrayRecyclerINS_14MachineOperandELm8EE8CapacityE", !9, i64 0}
!301 = !{!"_ZTSN4llvm14PointerSumTypeINS_12MachineInstr20ExtraInfoInlineKindsEJNS_20PointerSumTypeMemberILm0EPNS_17MachineMemOperandENS_21PointerLikeTypeTraitsIS5_EEEENS3_ILm1EPNS_8MCSymbolENS6_ISA_EEEENS3_ILm2ESA_SB_EENS3_ILm3EPNS1_9ExtraInfoENS6_ISF_EEEEEEE", !9, i64 0}
!302 = !{!"_ZTSN4llvm8DebugLocE", !303, i64 0}
!303 = !{!"p1 _ZTSN4llvm10DILocationE", !10, i64 0}
!304 = distinct !{!304, !305}
!305 = !{!"llvm.loop.mustprogress"}
!306 = !{!295, !14, i64 52}
!307 = distinct !{!307, !305}
!308 = !{!90, !93, i64 16}
!309 = !{!295, !14, i64 44}
!310 = distinct !{!310, !305}
!311 = distinct !{!311, !305}
!312 = distinct !{!312, !305}
!313 = distinct !{!313, !305}
!314 = !{!295, !298, i64 16}
!315 = !{!316, !109, i64 16}
!316 = !{!"_ZTSN4llvm11MCInstrDescE", !14, i64 0, !281, i64 4, !9, i64 6, !9, i64 7, !281, i64 8, !9, i64 10, !9, i64 11, !281, i64 12, !281, i64 14, !109, i64 16, !109, i64 24}
!317 = distinct !{!317, !305}
!318 = distinct !{!318, !305}
!319 = distinct !{!319, !305}
!320 = distinct !{!320, !305}
!321 = distinct !{!321, !305, !322}
!322 = !{!"llvm.loop.unroll.count", i32 4}
!323 = distinct !{!323, !305, !324}
!324 = !{!"llvm.loop.unroll.disable"}
!325 = distinct !{!325, !305}
!326 = distinct !{!326, !305}
!327 = !{!27, !28, i64 8}
!328 = !{!22, !15, i64 262}
!329 = distinct !{!329, !305}
!330 = !{!224, !108, i64 0}
!331 = !{!332}
!332 = distinct !{!332, !333, !"_ZN4llvmplENS_9StringRefEPKc: argument 0"}
!333 = distinct !{!333, !"_ZN4llvmplENS_9StringRefEPKc"}
!334 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!335 = !{!336, !338}
!336 = distinct !{!336, !337, !"_ZNK4llvm5Twine6concatERKS0_: argument 0"}
!337 = distinct !{!337, !"_ZNK4llvm5Twine6concatERKS0_"}
!338 = distinct !{!338, !339, !"_ZN4llvmplERKNS_5TwineES2_: argument 0"}
!339 = distinct !{!339, !"_ZN4llvmplERKNS_5TwineES2_"}
!340 = !{!341}
!341 = distinct !{!341, !342, !"_ZN4llvm17printMBBReferenceERKNS_17MachineBasicBlockE: argument 0"}
!342 = distinct !{!342, !"_ZN4llvm17printMBBReferenceERKNS_17MachineBasicBlockE"}
!343 = distinct !{!343, !344}
!344 = !{!"llvm.loop.peeled.count", i32 1}
!345 = !{!54, !54, i64 0}
!346 = !{!347}
!347 = distinct !{!347, !348, !"_ZN4llvm17printMBBReferenceERKNS_17MachineBasicBlockE: argument 0"}
!348 = distinct !{!348, !"_ZN4llvm17printMBBReferenceERKNS_17MachineBasicBlockE"}
!349 = !{!350, !14, i64 0}
!350 = !{!"_ZTSN4llvm17BranchProbabilityE", !14, i64 0}
!351 = !{!352, !108, i64 0}
!352 = !{!"_ZTSN4llvm13format_objectIJjEEE", !108, i64 0, !353, i64 8}
!353 = !{!"_ZTSSt5tupleIJjEE", !354, i64 0}
!354 = !{!"_ZTSSt11_Tuple_implILm0EJjEE", !355, i64 0}
!355 = !{!"_ZTSSt10_Head_baseILm0EjLb0EE", !14, i64 0}
!356 = !{!357}
!357 = distinct !{!357, !358, !"_ZN4llvm6formatIJjEEENS_13format_objectIJDpT_EEEPKcDpRKS2_: argument 0"}
!358 = distinct !{!358, !"_ZN4llvm6formatIJjEEENS_13format_objectIJDpT_EEEPKcDpRKS2_"}
!359 = !{!355, !14, i64 0}
!360 = !{!361, !361, i64 0}
!361 = !{!"p1 _ZTSN4llvm13format_objectIJjEEE", !10, i64 0}
!362 = distinct !{!362, !305}
!363 = !{!364}
!364 = distinct !{!364, !365, !"_ZN4llvm17printMBBReferenceERKNS_17MachineBasicBlockE: argument 0"}
!365 = distinct !{!365, !"_ZN4llvm17printMBBReferenceERKNS_17MachineBasicBlockE"}
!366 = !{!367, !108, i64 0}
!367 = !{!"_ZTSN4llvm13format_objectIJdEEE", !108, i64 0, !368, i64 8}
!368 = !{!"_ZTSSt5tupleIJdEE", !369, i64 0}
!369 = !{!"_ZTSSt11_Tuple_implILm0EJdEE", !370, i64 0}
!370 = !{!"_ZTSSt10_Head_baseILm0EdLb0EE", !371, i64 0}
!371 = !{!"double", !9, i64 0}
!372 = !{!373}
!373 = distinct !{!373, !374, !"_ZN4llvm6formatIJdEEENS_13format_objectIJDpT_EEEPKcDpRKS2_: argument 0"}
!374 = distinct !{!374, !"_ZN4llvm6formatIJdEEENS_13format_objectIJDpT_EEEPKcDpRKS2_"}
!375 = !{!370, !371, i64 0}
!376 = !{!377, !377, i64 0}
!377 = !{!"p1 _ZTSN4llvm13format_objectIJdEEE", !10, i64 0}
!378 = distinct !{!378, !305}
!379 = !{!63, !63, i64 0}
!380 = !{!381, !30, i64 0}
!381 = !{!"_ZTSN4llvm19MachineRegisterInfoE", !30, i64 0, !382, i64 8, !15, i64 40, !384, i64 48, !396, i64 88, !401, i64 144, !15, i64 168, !405, i64 176, !410, i64 232, !421, i64 296, !425, i64 312, !432, i64 320, !432, i64 392, !438, i64 464, !445, i64 496}
!382 = !{!"_ZTSN4llvm11SmallPtrSetIPNS_19MachineRegisterInfo8DelegateELj1EEE", !383, i64 0, !9, i64 24}
!383 = !{!"_ZTSN4llvm15SmallPtrSetImplIPNS_19MachineRegisterInfo8DelegateEEE", !12, i64 0}
!384 = !{!"_ZTSN4llvm10IndexedMapISt4pairINS_12PointerUnionIJPKNS_15MCRegisterClassEPKNS_12RegisterBankEEEEPNS_14MachineOperandEENS_20VirtReg2IndexFunctorEEE", !385, i64 0, !389, i64 16, !395, i64 32}
!385 = !{!"_ZTSN4llvm11SmallVectorISt4pairINS_12PointerUnionIJPKNS_15MCRegisterClassEPKNS_12RegisterBankEEEEPNS_14MachineOperandEELj0EEE", !386, i64 0}
!386 = !{!"_ZTSN4llvm15SmallVectorImplISt4pairINS_12PointerUnionIJPKNS_15MCRegisterClassEPKNS_12RegisterBankEEEEPNS_14MachineOperandEEEE", !387, i64 0}
!387 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseISt4pairINS_12PointerUnionIJPKNS_15MCRegisterClassEPKNS_12RegisterBankEEEEPNS_14MachineOperandEELb1EEE", !388, i64 0}
!388 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonISt4pairINS_12PointerUnionIJPKNS_15MCRegisterClassEPKNS_12RegisterBankEEEEPNS_14MachineOperandEEvEE", !20, i64 0}
!389 = !{!"_ZTSSt4pairIN4llvm12PointerUnionIJPKNS0_15MCRegisterClassEPKNS0_12RegisterBankEEEEPNS0_14MachineOperandEE", !390, i64 0, !299, i64 8}
!390 = !{!"_ZTSN4llvm12PointerUnionIJPKNS_15MCRegisterClassEPKNS_12RegisterBankEEEE", !391, i64 0}
!391 = !{!"_ZTSN4llvm20pointer_union_detail19PointerUnionMembersINS_12PointerUnionIJPKNS_15MCRegisterClassEPKNS_12RegisterBankEEEELi0EJS5_S8_EEE", !392, i64 0}
!392 = !{!"_ZTSN4llvm20pointer_union_detail19PointerUnionMembersINS_12PointerUnionIJPKNS_15MCRegisterClassEPKNS_12RegisterBankEEEELi1EJS8_EEE", !393, i64 0}
!393 = !{!"_ZTSN4llvm20pointer_union_detail19PointerUnionMembersINS_12PointerUnionIJPKNS_15MCRegisterClassEPKNS_12RegisterBankEEEELi2EJEEE", !394, i64 0}
!394 = !{!"_ZTSN4llvm6detail13PunnedPointerIPvEE", !9, i64 0}
!395 = !{!"_ZTSN4llvm20VirtReg2IndexFunctorE"}
!396 = !{!"_ZTSN4llvm10IndexedMapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS_20VirtReg2IndexFunctorEEE", !397, i64 0, !223, i64 16, !395, i64 48}
!397 = !{!"_ZTSN4llvm11SmallVectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEELj0EEE", !398, i64 0}
!398 = !{!"_ZTSN4llvm15SmallVectorImplINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEE", !399, i64 0}
!399 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEELb0EEE", !400, i64 0}
!400 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEvEE", !20, i64 0}
!401 = !{!"_ZTSN4llvm9StringSetINS_15MallocAllocatorEEE", !402, i64 0}
!402 = !{!"_ZTSN4llvm9StringMapINS_17EmptyStringSetTagENS_15MallocAllocatorEEE", !403, i64 0}
!403 = !{!"_ZTSN4llvm13StringMapImplE", !404, i64 0, !14, i64 8, !14, i64 12, !14, i64 16}
!404 = !{!"p2 _ZTSN4llvm18StringMapEntryBaseE", !13, i64 0}
!405 = !{!"_ZTSN4llvm11SmallVectorItLj16EEE", !406, i64 0, !409, i64 24}
!406 = !{!"_ZTSN4llvm15SmallVectorImplItEE", !407, i64 0}
!407 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseItLb1EEE", !408, i64 0}
!408 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonItvEE", !203, i64 0}
!409 = !{!"_ZTSN4llvm18SmallVectorStorageItLj16EEE", !9, i64 0}
!410 = !{!"_ZTSN4llvm10IndexedMapISt4pairIjNS_11SmallVectorINS_8RegisterELj4EEEENS_20VirtReg2IndexFunctorEEE", !411, i64 0, !415, i64 16, !395, i64 56}
!411 = !{!"_ZTSN4llvm11SmallVectorISt4pairIjNS0_INS_8RegisterELj4EEEELj0EEE", !412, i64 0}
!412 = !{!"_ZTSN4llvm15SmallVectorImplISt4pairIjNS_11SmallVectorINS_8RegisterELj4EEEEEE", !413, i64 0}
!413 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseISt4pairIjNS_11SmallVectorINS_8RegisterELj4EEEELb0EEE", !414, i64 0}
!414 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonISt4pairIjNS_11SmallVectorINS_8RegisterELj4EEEEvEE", !20, i64 0}
!415 = !{!"_ZTSSt4pairIjN4llvm11SmallVectorINS0_8RegisterELj4EEEE", !14, i64 0, !416, i64 8}
!416 = !{!"_ZTSN4llvm11SmallVectorINS_8RegisterELj4EEE", !417, i64 0, !420, i64 16}
!417 = !{!"_ZTSN4llvm15SmallVectorImplINS_8RegisterEEE", !418, i64 0}
!418 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseINS_8RegisterELb1EEE", !419, i64 0}
!419 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonINS_8RegisterEvEE", !20, i64 0}
!420 = !{!"_ZTSN4llvm18SmallVectorStorageINS_8RegisterELj4EEE", !9, i64 0}
!421 = !{!"_ZTSN4llvm11SmallVectorINS_19MachineRegisterInfo22PendingVirtRegMapEntryELj0EEE", !422, i64 0}
!422 = !{!"_ZTSN4llvm15SmallVectorImplINS_19MachineRegisterInfo22PendingVirtRegMapEntryEEE", !423, i64 0}
!423 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseINS_19MachineRegisterInfo22PendingVirtRegMapEntryELb1EEE", !424, i64 0}
!424 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonINS_19MachineRegisterInfo22PendingVirtRegMapEntryEvEE", !20, i64 0}
!425 = !{!"_ZTSSt10unique_ptrIA_PN4llvm14MachineOperandESt14default_deleteIS3_EE", !426, i64 0}
!426 = !{!"_ZTSSt15__uniq_ptr_dataIPN4llvm14MachineOperandESt14default_deleteIA_S2_ELb1ELb1EE", !427, i64 0}
!427 = !{!"_ZTSSt15__uniq_ptr_implIPN4llvm14MachineOperandESt14default_deleteIA_S2_EE", !428, i64 0}
!428 = !{!"_ZTSSt5tupleIJPPN4llvm14MachineOperandESt14default_deleteIA_S2_EEE", !429, i64 0}
!429 = !{!"_ZTSSt11_Tuple_implILm0EJPPN4llvm14MachineOperandESt14default_deleteIA_S2_EEE", !430, i64 0}
!430 = !{!"_ZTSSt10_Head_baseILm0EPPN4llvm14MachineOperandELb0EE", !431, i64 0}
!431 = !{!"p2 _ZTSN4llvm14MachineOperandE", !13, i64 0}
!432 = !{!"_ZTSN4llvm9BitVectorE", !433, i64 0, !14, i64 64}
!433 = !{!"_ZTSN4llvm11SmallVectorImLj6EEE", !434, i64 0, !437, i64 16}
!434 = !{!"_ZTSN4llvm15SmallVectorImplImEE", !435, i64 0}
!435 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseImLb1EEE", !436, i64 0}
!436 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonImvEE", !20, i64 0}
!437 = !{!"_ZTSN4llvm18SmallVectorStorageImLj6EEE", !9, i64 0}
!438 = !{!"_ZTSN4llvm10IndexedMapINS_3LLTENS_20VirtReg2IndexFunctorEEE", !439, i64 0, !443, i64 16, !395, i64 24}
!439 = !{!"_ZTSN4llvm11SmallVectorINS_3LLTELj0EEE", !440, i64 0}
!440 = !{!"_ZTSN4llvm15SmallVectorImplINS_3LLTEEE", !441, i64 0}
!441 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseINS_3LLTELb1EEE", !442, i64 0}
!442 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonINS_3LLTEvEE", !20, i64 0}
!443 = !{!"_ZTSN4llvm3LLTE", !109, i64 0, !444, i64 7}
!444 = !{!"_ZTSN4llvm3LLT4KindE", !9, i64 0}
!445 = !{!"_ZTSSt6vectorISt4pairIN4llvm10MCRegisterENS1_8RegisterEESaIS4_EE", !446, i64 0}
!446 = !{!"_ZTSSt12_Vector_baseISt4pairIN4llvm10MCRegisterENS1_8RegisterEESaIS4_EE", !447, i64 0}
!447 = !{!"_ZTSNSt12_Vector_baseISt4pairIN4llvm10MCRegisterENS1_8RegisterEESaIS4_EE12_Vector_implE", !448, i64 0}
!448 = !{!"_ZTSNSt12_Vector_baseISt4pairIN4llvm10MCRegisterENS1_8RegisterEESaIS4_EE17_Vector_impl_dataE", !449, i64 0, !449, i64 8, !449, i64 16}
!449 = !{!"p1 _ZTSSt4pairIN4llvm10MCRegisterENS0_8RegisterEE", !10, i64 0}
!450 = !{!135, !109, i64 0}
!451 = !{!14, !14, i64 0}
!452 = !{!453, !109, i64 0}
!453 = !{!"_ZTSN4llvm11LaneBitmaskE", !109, i64 0}
!454 = !{!109, !109, i64 0}
!455 = !{!456}
!456 = distinct !{!456, !457, !"_ZN4llvm13PrintLaneMaskENS_11LaneBitmaskE: argument 0"}
!457 = distinct !{!457, !"_ZN4llvm13PrintLaneMaskENS_11LaneBitmaskE"}
!458 = !{!459, !108, i64 0}
!459 = !{!"_ZTSN4llvm13format_objectIJmEEE", !108, i64 0, !460, i64 8}
!460 = !{!"_ZTSSt5tupleIJmEE", !461, i64 0}
!461 = !{!"_ZTSSt11_Tuple_implILm0EJmEE", !462, i64 0}
!462 = !{!"_ZTSSt10_Head_baseILm0EmLb0EE", !109, i64 0}
!463 = !{!464}
!464 = distinct !{!464, !465, !"_ZN4llvm6formatIJmEEENS_13format_objectIJDpT_EEEPKcDpRKS2_: argument 0"}
!465 = distinct !{!465, !"_ZN4llvm6formatIJmEEENS_13format_objectIJDpT_EEEPKcDpRKS2_"}
!466 = !{!462, !109, i64 0}
!467 = !{!468, !468, i64 0}
!468 = !{!"p1 _ZTSN4llvm13format_objectIJmEEE", !10, i64 0}
!469 = !{!470, !14, i64 16}
!470 = !{!"_ZTSN4llvm8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS3_vEENS_6detail12DenseMapPairIS3_S4_EEEE", !471, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!471 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairIPKNS_12MachineInstrENS_9SlotIndexEEE", !10, i64 0}
!472 = !{!470, !471, i64 0}
!473 = !{!474, !476}
!474 = distinct !{!474, !475, !"_ZNK4llvm8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS3_vEENS_6detail12DenseMapPairIS3_S4_EEE6getRepEv: argument 0"}
!475 = distinct !{!475, !"_ZNK4llvm8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS3_vEENS_6detail12DenseMapPairIS3_S4_EEE6getRepEv"}
!476 = distinct !{!476, !477, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E6getRepEv: argument 0"}
!477 = distinct !{!477, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E6getRepEv"}
!478 = !{!470, !160, i64 8}
!479 = !{!470, !14, i64 20}
!480 = !{!"branch_weights", i32 1999, i32 1}
!481 = !{!482, !482, i64 0}
!482 = !{!"p1 _ZTSN4llvm12MachineInstrE", !10, i64 0}
!483 = !{!"branch_weights", !"expected", i32 2000, i32 1}
!484 = !{!"branch_weights", i32 1, i32 0}
!485 = !{!486, !486, i64 0}
!486 = !{!"p1 _ZTSN4llvm17ModuleSlotTrackerE", !10, i64 0}
!487 = !{!488, !488, i64 0}
!488 = !{!"p1 _ZTSN4llvm11raw_ostreamE", !10, i64 0}
!489 = !{!490, !490, i64 0}
!490 = !{!"p2 _ZTSN4llvm17ModuleSlotTrackerE", !13, i64 0}
!491 = !{!22, !29, i64 224}
!492 = !{!22, !15, i64 235}
!493 = !{!22, !15, i64 233}
!494 = distinct !{!494, !305}
!495 = distinct !{!495, !305}
!496 = distinct !{!496, !305}
!497 = !{!498, !500}
!498 = distinct !{!498, !499, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E7find_asIS4_EENS_16DenseMapIteratorIS4_S5_S7_SA_Lb1EEERKT_: argument 0"}
!499 = distinct !{!499, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E7find_asIS4_EENS_16DenseMapIteratorIS4_S5_S7_SA_Lb1EEERKT_"}
!500 = distinct !{!500, !501, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E4findES4_: argument 0"}
!501 = distinct !{!501, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E4findES4_"}
!502 = !{!503, !498, !500}
!503 = distinct !{!503, !504, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E3endEv: argument 0"}
!504 = distinct !{!504, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E3endEv"}
!505 = !{!506, !488, i64 0}
!506 = !{!"_ZTSZNK4llvm17MachineBasicBlock9printNameERNS_11raw_ostreamEjPNS_17ModuleSlotTrackerEE3$_0", !488, i64 0, !490, i64 8}
!507 = !{!506, !490, i64 8}
!508 = !{!509, !91, i64 72}
!509 = !{!"_ZTSN4llvm10BasicBlockE", !280, i64 0, !510, i64 24, !14, i64 40, !513, i64 48, !91, i64 72}
!510 = !{!"_ZTSN4llvm22ilist_node_with_parentINS_10BasicBlockENS_8FunctionEJEEE", !511, i64 0}
!511 = !{!"_ZTSN4llvm10ilist_nodeINS_10BasicBlockEJEEE", !512, i64 0}
!512 = !{!"_ZTSN4llvm15ilist_node_implINS_12ilist_detail12node_optionsINS_10BasicBlockELb0ELb0EvLb0EvEEEE", !26, i64 0}
!513 = !{!"_ZTSN4llvm15SymbolTableListINS_11InstructionEJNS_19ilist_iterator_bitsILb1EEENS_12ilist_parentINS_10BasicBlockEEEEEE", !514, i64 0}
!514 = !{!"_ZTSN4llvm11iplist_implINS_12simple_ilistINS_11InstructionEJNS_19ilist_iterator_bitsILb1EEENS_12ilist_parentINS_10BasicBlockEEEEEENS_21SymbolTableListTraitsIS2_JS4_S7_EEEEE", !515, i64 0}
!515 = !{!"_ZTSN4llvm12simple_ilistINS_11InstructionEJNS_19ilist_iterator_bitsILb1EEENS_12ilist_parentINS_10BasicBlockEEEEEE", !516, i64 0}
!516 = !{!"_ZTSN4llvm14ilist_sentinelINS_12ilist_detail12node_optionsINS_11InstructionELb0ELb0EvLb1ENS_10BasicBlockEEEEE", !517, i64 0}
!517 = !{!"_ZTSN4llvm15ilist_node_implINS_12ilist_detail12node_optionsINS_11InstructionELb0ELb0EvLb1ENS_10BasicBlockEEEEE", !518, i64 0}
!518 = !{!"_ZTSN4llvm15ilist_node_baseILb0ENS_10BasicBlockEEE", !519, i64 0, !521, i64 16}
!519 = !{!"_ZTSN4llvm12ilist_detail18node_base_prevnextINS_15ilist_node_baseILb0ENS_10BasicBlockEEELb0EEE", !520, i64 0, !520, i64 8}
!520 = !{!"p1 _ZTSN4llvm15ilist_node_baseILb0ENS_10BasicBlockEEE", !10, i64 0}
!521 = !{!"_ZTSN4llvm12ilist_detail16node_base_parentINS_10BasicBlockEEE", !29, i64 0}
!522 = !{!523, !14, i64 0}
!523 = !{!"_ZTSN4llvm10MCRegisterE", !14, i64 0}
!524 = distinct !{!524, !305, !322}
!525 = distinct !{!525, !305, !324}
!526 = !{i64 0, i64 4, !451, i64 8, i64 8, !454}
!527 = !{!62, !63, i64 8}
!528 = !{!529, !532, i64 56}
!529 = !{!"_ZTSN4llvm14MCRegisterInfoE", !530, i64 8, !14, i64 16, !523, i64 20, !523, i64 24, !531, i64 32, !14, i64 40, !14, i64 44, !532, i64 48, !532, i64 56, !533, i64 64, !108, i64 72, !108, i64 80, !532, i64 88, !14, i64 96, !532, i64 104, !160, i64 112, !14, i64 120, !14, i64 124, !14, i64 128, !14, i64 132, !534, i64 136, !534, i64 144, !534, i64 152, !534, i64 160, !535, i64 168, !535, i64 192, !537, i64 216}
!530 = !{!"p1 _ZTSN4llvm14MCRegisterDescE", !10, i64 0}
!531 = !{!"p1 _ZTSN4llvm15MCRegisterClassE", !10, i64 0}
!532 = !{!"p1 short", !10, i64 0}
!533 = !{!"p1 _ZTSN4llvm11LaneBitmaskE", !10, i64 0}
!534 = !{!"p1 _ZTSN4llvm14MCRegisterInfo16DwarfLLVMRegPairE", !10, i64 0}
!535 = !{!"_ZTSN4llvm8DenseMapINS_10MCRegisterEiNS_12DenseMapInfoIS1_vEENS_6detail12DenseMapPairIS1_iEEEE", !536, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!536 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairINS_10MCRegisterEiEE", !10, i64 0}
!537 = !{!"_ZTSSt6vectorIS_ItSaItEESaIS1_EE", !538, i64 0}
!538 = !{!"_ZTSSt12_Vector_baseISt6vectorItSaItEESaIS2_EE", !539, i64 0}
!539 = !{!"_ZTSNSt12_Vector_baseISt6vectorItSaItEESaIS2_EE12_Vector_implE", !540, i64 0}
!540 = !{!"_ZTSNSt12_Vector_baseISt6vectorItSaItEESaIS2_EE17_Vector_impl_dataE", !541, i64 0, !541, i64 8, !541, i64 16}
!541 = !{!"p1 _ZTSSt6vectorItSaItEE", !10, i64 0}
!542 = !{!543}
!543 = distinct !{!543, !544, !"_ZNK4llvm14MCRegisterInfo17subregs_inclusiveENS_10MCRegisterE: argument 0"}
!544 = distinct !{!544, !"_ZNK4llvm14MCRegisterInfo17subregs_inclusiveENS_10MCRegisterE"}
!545 = !{!529, !530, i64 8}
!546 = !{!547}
!547 = distinct !{!547, !548, !"_ZNK4llvm14MCRegisterInfo9superregsENS_10MCRegisterE: argument 0"}
!548 = distinct !{!548, !"_ZNK4llvm14MCRegisterInfo9superregsENS_10MCRegisterE"}
!549 = !{!550, !14, i64 4}
!550 = !{!"_ZTSN4llvm14MCRegisterDescE", !14, i64 0, !14, i64 4, !14, i64 8, !14, i64 12, !14, i64 16, !281, i64 20, !15, i64 22, !15, i64 23}
!551 = !{!550, !14, i64 8}
!552 = !{!281, !281, i64 0}
!553 = !{!529, !532, i64 88}
!554 = !{!550, !14, i64 12}
!555 = !{!556, !533, i64 280}
!556 = !{!"_ZTSN4llvm18TargetRegisterInfoE", !529, i64 0, !557, i64 240, !108, i64 248, !558, i64 256, !559, i64 272, !533, i64 280, !453, i64 288, !560, i64 296, !10, i64 304, !14, i64 312}
!557 = !{!"p1 _ZTSN4llvm22TargetRegisterInfoDescE", !10, i64 0}
!558 = !{!"_ZTSN4llvm8ArrayRefIjEE", !160, i64 0, !109, i64 8}
!559 = !{!"p1 _ZTSN4llvm18TargetRegisterInfo17SubRegCoveredBitsE", !10, i64 0}
!560 = !{!"p1 _ZTSN4llvm18TargetRegisterInfo12RegClassInfoE", !10, i64 0}
!561 = distinct !{!561, !305}
!562 = distinct !{!562, !305, !322}
!563 = distinct !{!563, !305, !324}
!564 = !{!"branch_weights", !"expected", i32 -2147483648, i32 0}
!565 = !{i64 4, i64 8, !454}
!566 = distinct !{!566, !305}
!567 = distinct !{!567, !305}
!568 = distinct !{!568, !305}
!569 = distinct !{!569, !305}
!570 = distinct !{!570, !305}
!571 = !{!295, !299, i64 32}
!572 = distinct !{!572, !305}
!573 = !{!574, !298, i64 0}
!574 = !{!"_ZTSN4llvm11MCInstrInfoE", !298, i64 0, !160, i64 8, !108, i64 16, !108, i64 24, !10, i64 32, !14, i64 40, !532, i64 48, !281, i64 56}
!575 = !{!576, !482, i64 8}
!576 = !{!"_ZTSN4llvm14MachineOperandE", !14, i64 0, !14, i64 1, !14, i64 2, !14, i64 3, !14, i64 3, !14, i64 3, !14, i64 3, !14, i64 3, !14, i64 3, !14, i64 3, !14, i64 3, !9, i64 4, !482, i64 8, !9, i64 16}
!577 = !{!578}
!578 = distinct !{!578, !579, !"_ZN4llvm14MachineOperand9CreateRegENS_8RegisterEbbbbbbjbbb: argument 0"}
!579 = distinct !{!579, !"_ZN4llvm14MachineOperand9CreateRegENS_8RegisterEbbbbbbjbbb"}
!580 = !{!581, !583}
!581 = distinct !{!581, !582, !"_ZSt19__relocate_object_aIN4llvm17MachineBasicBlock16RegisterMaskPairES2_SaIS2_EEvPT_PT0_RT1_: argument 0"}
!582 = distinct !{!582, !"_ZSt19__relocate_object_aIN4llvm17MachineBasicBlock16RegisterMaskPairES2_SaIS2_EEvPT_PT0_RT1_"}
!583 = distinct !{!583, !582, !"_ZSt19__relocate_object_aIN4llvm17MachineBasicBlock16RegisterMaskPairES2_SaIS2_EEvPT_PT0_RT1_: argument 1"}
!584 = distinct !{!584, !305}
!585 = !{!303, !303, i64 0}
!586 = !{!587, !588, i64 8}
!587 = !{!"_ZTSN4llvm10MIMetadataE", !302, i64 0, !588, i64 8, !588, i64 16, !589, i64 24}
!588 = !{!"p1 _ZTSN4llvm6MDNodeE", !10, i64 0}
!589 = !{!"p1 _ZTSN4llvm5ValueE", !10, i64 0}
!590 = !{!587, !588, i64 16}
!591 = !{!587, !589, i64 24}
!592 = !{!593}
!593 = distinct !{!593, !594, !"_ZN4llvm14MachineOperand9CreateRegENS_8RegisterEbbbbbbjbbb: argument 0"}
!594 = distinct !{!594, !"_ZN4llvm14MachineOperand9CreateRegENS_8RegisterEbbbbbbjbbb"}
!595 = !{!27, !28, i64 0}
!596 = distinct !{!596, !305, !322}
!597 = distinct !{!597, !305, !324}
!598 = distinct !{!598, !305}
!599 = distinct !{!599, !305}
!600 = !{!53, !54, i64 8}
!601 = !{!602}
!602 = distinct !{!602, !603, !"_ZSt19__relocate_object_aIN4llvm17BranchProbabilityES1_SaIS1_EEvPT_PT0_RT1_: argument 0"}
!603 = distinct !{!603, !"_ZSt19__relocate_object_aIN4llvm17BranchProbabilityES1_SaIS1_EEvPT_PT0_RT1_"}
!604 = !{!605}
!605 = distinct !{!605, !603, !"_ZSt19__relocate_object_aIN4llvm17BranchProbabilityES1_SaIS1_EEvPT_PT0_RT1_: argument 1"}
!606 = distinct !{!606, !305, !607, !608}
!607 = !{!"llvm.loop.isvectorized", i32 1}
!608 = !{!"llvm.loop.unroll.runtime.disable"}
!609 = distinct !{!609, !305, !607}
!610 = distinct !{!610, !305, !322}
!611 = distinct !{!611, !305, !324}
!612 = distinct !{!612, !305, !607, !608}
!613 = distinct !{!613, !305, !608, !607}
!614 = distinct !{!614, !305, !607, !608}
!615 = distinct !{!615, !305, !608, !607}
!616 = distinct !{!616, !305, !607, !608}
!617 = distinct !{!617, !305, !608, !607}
!618 = distinct !{!618, !305}
!619 = distinct !{!619, !305, !607, !608}
!620 = distinct !{!620, !305, !608, !607}
!621 = distinct !{!621, !305, !607, !608}
!622 = distinct !{!622, !305, !608, !607}
!623 = distinct !{!623, !305, !607, !608}
!624 = distinct !{!624, !305, !608, !607}
!625 = !{!626, !628, !630, !632}
!626 = distinct !{!626, !627, !"_ZN4llvm25SmallVectorTemplateCommonIPNS_17MachineBasicBlockEvE6rbeginEv: argument 0"}
!627 = distinct !{!627, !"_ZN4llvm25SmallVectorTemplateCommonIPNS_17MachineBasicBlockEvE6rbeginEv"}
!628 = distinct !{!628, !629, !"_ZN4llvm10adl_detail11rbegin_implIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTcl6rbeginclsr3stdE7forwardIT_Efp_EEEOS7_: argument 0"}
!629 = distinct !{!629, !"_ZN4llvm10adl_detail11rbegin_implIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTcl6rbeginclsr3stdE7forwardIT_Efp_EEEOS7_"}
!630 = distinct !{!630, !631, !"_ZN4llvm10adl_rbeginIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTclsr10adl_detailE11rbegin_implclsr3stdE7forwardIT_Efp_EEEOS6_: argument 0"}
!631 = distinct !{!631, !"_ZN4llvm10adl_rbeginIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTclsr10adl_detailE11rbegin_implclsr3stdE7forwardIT_Efp_EEEOS6_"}
!632 = distinct !{!632, !633, !"_ZN4llvm7reverseIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDaOT_: argument 0"}
!633 = distinct !{!633, !"_ZN4llvm7reverseIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDaOT_"}
!634 = !{!635, !637, !639}
!635 = distinct !{!635, !636, !"_ZSt9__find_ifISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEEN9__gnu_cxx5__ops14_Comp_with_valISt8equal_toIvES3_Lb1EEEET_SC_SC_T0_: argument 0"}
!636 = distinct !{!636, !"_ZSt9__find_ifISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEEN9__gnu_cxx5__ops14_Comp_with_valISt8equal_toIvES3_Lb1EEEET_SC_SC_T0_"}
!637 = distinct !{!637, !638, !"_ZSt4findISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEES3_ET_S6_S6_RKT0_: argument 0"}
!638 = distinct !{!638, !"_ZSt4findISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEES3_ET_S6_S6_RKT0_"}
!639 = distinct !{!639, !640, !"_ZN4llvm4findINS_14iterator_rangeISt16reverse_iteratorIPPNS_17MachineBasicBlockEEEES4_EEDaOT_RKT0_: argument 0"}
!640 = distinct !{!640, !"_ZN4llvm4findINS_14iterator_rangeISt16reverse_iteratorIPPNS_17MachineBasicBlockEEEES4_EEDaOT_RKT0_"}
!641 = distinct !{!641, !305, !322}
!642 = distinct !{!642, !305, !324}
!643 = !{!644, !646, !648, !650}
!644 = distinct !{!644, !645, !"_ZN4llvm25SmallVectorTemplateCommonIPNS_17MachineBasicBlockEvE6rbeginEv: argument 0"}
!645 = distinct !{!645, !"_ZN4llvm25SmallVectorTemplateCommonIPNS_17MachineBasicBlockEvE6rbeginEv"}
!646 = distinct !{!646, !647, !"_ZN4llvm10adl_detail11rbegin_implIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTcl6rbeginclsr3stdE7forwardIT_Efp_EEEOS7_: argument 0"}
!647 = distinct !{!647, !"_ZN4llvm10adl_detail11rbegin_implIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTcl6rbeginclsr3stdE7forwardIT_Efp_EEEOS7_"}
!648 = distinct !{!648, !649, !"_ZN4llvm10adl_rbeginIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTclsr10adl_detailE11rbegin_implclsr3stdE7forwardIT_Efp_EEEOS6_: argument 0"}
!649 = distinct !{!649, !"_ZN4llvm10adl_rbeginIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTclsr10adl_detailE11rbegin_implclsr3stdE7forwardIT_Efp_EEEOS6_"}
!650 = distinct !{!650, !651, !"_ZN4llvm7reverseIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDaOT_: argument 0"}
!651 = distinct !{!651, !"_ZN4llvm7reverseIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDaOT_"}
!652 = !{!653, !655, !657}
!653 = distinct !{!653, !654, !"_ZSt9__find_ifISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEEN9__gnu_cxx5__ops14_Comp_with_valISt8equal_toIvES3_Lb1EEEET_SC_SC_T0_: argument 0"}
!654 = distinct !{!654, !"_ZSt9__find_ifISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEEN9__gnu_cxx5__ops14_Comp_with_valISt8equal_toIvES3_Lb1EEEET_SC_SC_T0_"}
!655 = distinct !{!655, !656, !"_ZSt4findISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEES3_ET_S6_S6_RKT0_: argument 0"}
!656 = distinct !{!656, !"_ZSt4findISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEES3_ET_S6_S6_RKT0_"}
!657 = distinct !{!657, !658, !"_ZN4llvm4findINS_14iterator_rangeISt16reverse_iteratorIPPNS_17MachineBasicBlockEEEES4_EEDaOT_RKT0_: argument 0"}
!658 = distinct !{!658, !"_ZN4llvm4findINS_14iterator_rangeISt16reverse_iteratorIPPNS_17MachineBasicBlockEEEES4_EEDaOT_RKT0_"}
!659 = distinct !{!659, !305}
!660 = !{!661, !663, !665, !667}
!661 = distinct !{!661, !662, !"_ZN4llvm25SmallVectorTemplateCommonIPNS_17MachineBasicBlockEvE6rbeginEv: argument 0"}
!662 = distinct !{!662, !"_ZN4llvm25SmallVectorTemplateCommonIPNS_17MachineBasicBlockEvE6rbeginEv"}
!663 = distinct !{!663, !664, !"_ZN4llvm10adl_detail11rbegin_implIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTcl6rbeginclsr3stdE7forwardIT_Efp_EEEOS7_: argument 0"}
!664 = distinct !{!664, !"_ZN4llvm10adl_detail11rbegin_implIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTcl6rbeginclsr3stdE7forwardIT_Efp_EEEOS7_"}
!665 = distinct !{!665, !666, !"_ZN4llvm10adl_rbeginIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTclsr10adl_detailE11rbegin_implclsr3stdE7forwardIT_Efp_EEEOS6_: argument 0"}
!666 = distinct !{!666, !"_ZN4llvm10adl_rbeginIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDTclsr10adl_detailE11rbegin_implclsr3stdE7forwardIT_Efp_EEEOS6_"}
!667 = distinct !{!667, !668, !"_ZN4llvm7reverseIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDaOT_: argument 0"}
!668 = distinct !{!668, !"_ZN4llvm7reverseIRNS_11SmallVectorIPNS_17MachineBasicBlockELj4EEEEEDaOT_"}
!669 = !{!670, !672, !674}
!670 = distinct !{!670, !671, !"_ZSt9__find_ifISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEEN9__gnu_cxx5__ops14_Comp_with_valISt8equal_toIvES3_Lb1EEEET_SC_SC_T0_: argument 0"}
!671 = distinct !{!671, !"_ZSt9__find_ifISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEEN9__gnu_cxx5__ops14_Comp_with_valISt8equal_toIvES3_Lb1EEEET_SC_SC_T0_"}
!672 = distinct !{!672, !673, !"_ZSt4findISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEES3_ET_S6_S6_RKT0_: argument 0"}
!673 = distinct !{!673, !"_ZSt4findISt16reverse_iteratorIPPN4llvm17MachineBasicBlockEES3_ET_S6_S6_RKT0_"}
!674 = distinct !{!674, !675, !"_ZN4llvm4findINS_14iterator_rangeISt16reverse_iteratorIPPNS_17MachineBasicBlockEEEES4_EEDaOT_RKT0_: argument 0"}
!675 = distinct !{!675, !"_ZN4llvm4findINS_14iterator_rangeISt16reverse_iteratorIPPNS_17MachineBasicBlockEEEES4_EEDaOT_RKT0_"}
!676 = distinct !{!676, !305}
!677 = distinct !{!677, !305}
!678 = distinct !{!678, !305}
!679 = distinct !{!679, !305, !607, !608}
!680 = distinct !{!680, !305, !608, !607}
!681 = distinct !{!681, !305, !607, !608}
!682 = distinct !{!682, !305, !608, !607}
!683 = distinct !{!683, !305, !607, !608}
!684 = distinct !{!684, !305, !608, !607}
!685 = !{!686, !687, i64 0}
!686 = !{!"_ZTSN4llvm12LivePhysRegsE", !687, i64 0, !688, i64 8}
!687 = !{!"p1 _ZTSN4llvm18TargetRegisterInfoE", !10, i64 0}
!688 = !{!"_ZTSN4llvm9SparseSetIttNS_8identityEhEE", !689, i64 0, !691, i64 40, !14, i64 48, !697, i64 52, !698, i64 53}
!689 = !{!"_ZTSN4llvm11SmallVectorItLj8EEE", !406, i64 0, !690, i64 24}
!690 = !{!"_ZTSN4llvm18SmallVectorStorageItLj8EEE", !9, i64 0}
!691 = !{!"_ZTSSt10unique_ptrIA_hN4llvm9SparseSetIttNS1_8identityEhE7DeleterEE", !692, i64 0}
!692 = !{!"_ZTSSt15__uniq_ptr_dataIhN4llvm9SparseSetIttNS0_8identityEhE7DeleterELb1ELb1EE", !693, i64 0}
!693 = !{!"_ZTSSt15__uniq_ptr_implIhN4llvm9SparseSetIttNS0_8identityEhE7DeleterEE", !694, i64 0}
!694 = !{!"_ZTSSt5tupleIJPhN4llvm9SparseSetIttNS1_8identityEhE7DeleterEEE", !695, i64 0}
!695 = !{!"_ZTSSt11_Tuple_implILm0EJPhN4llvm9SparseSetIttNS1_8identityEhE7DeleterEEE", !696, i64 0}
!696 = !{!"_ZTSSt10_Head_baseILm0EPhLb0EE", !108, i64 0}
!697 = !{!"_ZTSN4llvm8identityE"}
!698 = !{!"_ZTSN4llvm19SparseSetValFunctorIttNS_8identityEEE"}
!699 = !{!696, !108, i64 0}
!700 = !{!688, !14, i64 48}
!701 = !{!529, !14, i64 16}
!702 = !{!108, !108, i64 0}
!703 = distinct !{!703, !305}
!704 = !{!705, !706, i64 8}
!705 = !{!"_ZTSN4llvm4PassE", !706, i64 8, !10, i64 16, !707, i64 24}
!706 = !{!"p1 _ZTSN4llvm16AnalysisResolverE", !10, i64 0}
!707 = !{!"_ZTSN4llvm8PassKindE", !9, i64 0}
!708 = !{!709, !14, i64 16}
!709 = !{!"_ZTSN4llvm8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS4_NS_15AnalysisManagerIS4_JEE11InvalidatorEEENS_12DenseMapInfoIS6_vEENS7_12DenseMapPairIS6_SD_EEEE", !710, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!710 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS0_21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEEEE", !10, i64 0}
!711 = !{!712, !714}
!712 = distinct !{!712, !713, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E7find_asIS7_EENS_16DenseMapIteratorIS7_SE_SG_SI_Lb1EEERKT_: argument 0"}
!713 = distinct !{!713, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E7find_asIS7_EENS_16DenseMapIteratorIS7_SE_SG_SI_Lb1EEERKT_"}
!714 = distinct !{!714, !715, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E4findERKS7_: argument 0"}
!715 = distinct !{!715, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E4findERKS7_"}
!716 = !{!709, !710, i64 0}
!717 = !{!718, !712, !714}
!718 = distinct !{!718, !719, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E3endEv: argument 0"}
!719 = distinct !{!719, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E3endEv"}
!720 = !{!709, !160, i64 8}
!721 = !{!709, !14, i64 20}
!722 = !{!723, !724, i64 0}
!723 = !{!"_ZTSSt4pairIPN4llvm11AnalysisKeyEPNS0_15MachineFunctionEE", !724, i64 0, !30, i64 8}
!724 = !{!"p1 _ZTSN4llvm11AnalysisKeyE", !10, i64 0}
!725 = !{!726, !727, i64 16}
!726 = !{!"_ZTSN4llvm6detail12DenseMapPairISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS0_21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEEEE", !723, i64 0, !727, i64 16}
!727 = !{!"p1 _ZTSN4llvm6detail21AnalysisResultConceptINS_15MachineFunctionENS_15AnalysisManagerIS2_JEE11InvalidatorEEE", !10, i64 0}
!728 = !{!729, !731}
!729 = distinct !{!729, !730, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E7find_asIS7_EENS_16DenseMapIteratorIS7_SE_SG_SI_Lb1EEERKT_: argument 0"}
!730 = distinct !{!730, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E7find_asIS7_EENS_16DenseMapIteratorIS7_SE_SG_SI_Lb1EEERKT_"}
!731 = distinct !{!731, !732, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E4findERKS7_: argument 0"}
!732 = distinct !{!732, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E4findERKS7_"}
!733 = !{!734, !736}
!734 = distinct !{!734, !735, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E7find_asIS7_EENS_16DenseMapIteratorIS7_SE_SG_SI_Lb1EEERKT_: argument 0"}
!735 = distinct !{!735, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E7find_asIS7_EENS_16DenseMapIteratorIS7_SE_SG_SI_Lb1EEERKT_"}
!736 = distinct !{!736, !737, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E4findERKS7_: argument 0"}
!737 = distinct !{!737, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E4findERKS7_"}
!738 = !{!739, !741}
!739 = distinct !{!739, !740, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E7find_asIS7_EENS_16DenseMapIteratorIS7_SE_SG_SI_Lb1EEERKT_: argument 0"}
!740 = distinct !{!740, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E7find_asIS7_EENS_16DenseMapIteratorIS7_SE_SG_SI_Lb1EEERKT_"}
!741 = distinct !{!741, !742, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E4findERKS7_: argument 0"}
!742 = distinct !{!742, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapISt4pairIPNS_11AnalysisKeyEPNS_15MachineFunctionEEPNS_6detail21AnalysisResultConceptIS5_NS_15AnalysisManagerIS5_JEE11InvalidatorEEENS_12DenseMapInfoIS7_vEENS8_12DenseMapPairIS7_SE_EEEES7_SE_SG_SI_E4findERKS7_"}
!743 = !{!10, !10, i64 0}
!744 = !{!745, !749, i64 24}
!745 = !{!"_ZTSN4llvm17MachineBasicBlock25SplitCriticalEdgeAnalysesE", !746, i64 0, !747, i64 8, !748, i64 16, !749, i64 24}
!746 = !{!"p1 _ZTSN4llvm13LiveIntervalsE", !10, i64 0}
!747 = !{!"p1 _ZTSN4llvm11SlotIndexesE", !10, i64 0}
!748 = !{!"p1 _ZTSN4llvm13LiveVariablesE", !10, i64 0}
!749 = !{!"p1 _ZTSN4llvm15MachineLoopInfoE", !10, i64 0}
!750 = !{!90, !99, i64 64}
!751 = !{!745, !746, i64 0}
!752 = !{!745, !747, i64 8}
!753 = !{!745, !748, i64 16}
!754 = !{!755}
!755 = distinct !{!755, !756, !"_ZN4llvm12MachineInstr8all_usesEv: argument 0"}
!756 = distinct !{!756, !"_ZN4llvm12MachineInstr8all_usesEv"}
!757 = !{!758, !755}
!758 = distinct !{!758, !759, !"_ZN4llvm17make_filter_rangeINS_14iterator_rangeIPNS_14MachineOperandEEEPFbRKS2_EEENS1_INS_20filter_iterator_implIDTcl9adl_beginclsr3stdE7declvalIRT_EEEET0_NSt11conditionalIXsr3stdE12is_base_of_vISt26bidirectional_iterator_tagNSt15iterator_traitsISC_E17iterator_categoryEEESF_St20forward_iterator_tagE4typeEEEEEOSA_SD_: argument 0"}
!759 = distinct !{!759, !"_ZN4llvm17make_filter_rangeINS_14iterator_rangeIPNS_14MachineOperandEEEPFbRKS2_EEENS1_INS_20filter_iterator_implIDTcl9adl_beginclsr3stdE7declvalIRT_EEEET0_NSt11conditionalIXsr3stdE12is_base_of_vISt26bidirectional_iterator_tagNSt15iterator_traitsISC_E17iterator_categoryEEESF_St20forward_iterator_tagE4typeEEEEEOSA_SD_"}
!760 = distinct !{!760, !305}
!761 = !{!762, !762, i64 0}
!762 = !{!"p2 _ZTSN4llvm12MachineInstrE", !13, i64 0}
!763 = distinct !{!763, !305, !322}
!764 = distinct !{!764, !305, !324}
!765 = !{!766, !762, i64 8}
!766 = !{!"_ZTSNSt12_Vector_baseIPN4llvm12MachineInstrESaIS2_EE17_Vector_impl_dataE", !762, i64 0, !762, i64 8, !762, i64 16}
!767 = !{!768, !14, i64 0}
!768 = !{!"_ZTSN4llvm8RegisterE", !14, i64 0}
!769 = distinct !{!769, !305, !322}
!770 = distinct !{!770, !305, !324}
!771 = !{!30, !30, i64 0}
!772 = !{!773, !747, i64 16}
!773 = !{!"_ZTS23SlotIndexUpdateDelegate", !774, i64 0, !30, i64 8, !747, i64 16, !775, i64 24}
!774 = !{!"_ZTSN4llvm15MachineFunction8DelegateE"}
!775 = !{!"_ZTSN4llvm14SmallSetVectorIPNS_12MachineInstrELj2EEE", !776, i64 0}
!776 = !{!"_ZTSN4llvm9SetVectorIPNS_12MachineInstrENS_11SmallVectorIS2_Lj2EEENS_8DenseSetIS2_NS_12DenseMapInfoIS2_vEEEELj2EEE", !777, i64 0, !781, i64 24}
!777 = !{!"_ZTSN4llvm8DenseSetIPNS_12MachineInstrENS_12DenseMapInfoIS2_vEEEE", !778, i64 0}
!778 = !{!"_ZTSN4llvm6detail12DenseSetImplIPNS_12MachineInstrENS_8DenseMapIS3_NS0_13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS0_12DenseSetPairIS3_EEEEEE", !779, i64 0}
!779 = !{!"_ZTSN4llvm8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS2_vEENS3_12DenseSetPairIS2_EEEE", !780, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!780 = !{!"p1 _ZTSN4llvm6detail12DenseSetPairIPNS_12MachineInstrEEE", !10, i64 0}
!781 = !{!"_ZTSN4llvm11SmallVectorIPNS_12MachineInstrELj2EEE", !782, i64 0, !785, i64 16}
!782 = !{!"_ZTSN4llvm15SmallVectorImplIPNS_12MachineInstrEEE", !783, i64 0}
!783 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseIPNS_12MachineInstrELb1EEE", !784, i64 0}
!784 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonIPNS_12MachineInstrEvEE", !20, i64 0}
!785 = !{!"_ZTSN4llvm18SmallVectorStorageIPNS_12MachineInstrELj2EEE", !9, i64 0}
!786 = !{!90, !182, i64 640}
!787 = !{!773, !30, i64 8}
!788 = !{!779, !14, i64 20}
!789 = !{!779, !780, i64 0}
!790 = !{!302, !303, i64 0}
!791 = !{!792, !794}
!792 = distinct !{!792, !793, !"_ZSt19__relocate_object_aIN4llvm17MachineBasicBlock16RegisterMaskPairES2_SaIS2_EEvPT_PT0_RT1_: argument 0"}
!793 = distinct !{!793, !"_ZSt19__relocate_object_aIN4llvm17MachineBasicBlock16RegisterMaskPairES2_SaIS2_EEvPT_PT0_RT1_"}
!794 = distinct !{!794, !793, !"_ZSt19__relocate_object_aIN4llvm17MachineBasicBlock16RegisterMaskPairES2_SaIS2_EEvPT_PT0_RT1_: argument 1"}
!795 = distinct !{!795, !305}
!796 = !{!766, !762, i64 16}
!797 = !{!766, !762, i64 0}
!798 = distinct !{!798, !305}
!799 = !{!800, !802, i64 0}
!800 = !{!"_ZTSSt15_Rb_tree_header", !801, i64 0, !109, i64 32}
!801 = !{!"_ZTSSt18_Rb_tree_node_base", !802, i64 0, !803, i64 8, !803, i64 16, !803, i64 24}
!802 = !{!"_ZTSSt14_Rb_tree_color", !9, i64 0}
!803 = !{!"p1 _ZTSSt18_Rb_tree_node_base", !10, i64 0}
!804 = !{!800, !803, i64 8}
!805 = !{!800, !803, i64 16}
!806 = !{!800, !803, i64 24}
!807 = !{!800, !109, i64 32}
!808 = distinct !{!808, !305}
!809 = !{!810, !810, i64 0}
!810 = !{!"p1 _ZTSN4llvm12LiveIntervalE", !10, i64 0}
!811 = !{!812, !810, i64 16}
!812 = !{!"_ZTSN4llvm10IndexedMapIPNS_12LiveIntervalENS_20VirtReg2IndexFunctorEEE", !813, i64 0, !810, i64 16, !395, i64 24}
!813 = !{!"_ZTSN4llvm11SmallVectorIPNS_12LiveIntervalELj0EEE", !814, i64 0}
!814 = !{!"_ZTSN4llvm15SmallVectorImplIPNS_12LiveIntervalEEE", !815, i64 0}
!815 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseIPNS_12LiveIntervalELb1EEE", !816, i64 0}
!816 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonIPNS_12LiveIntervalEvEE", !20, i64 0}
!817 = distinct !{!817, !305, !607, !608}
!818 = distinct !{!818, !305, !608, !607}
!819 = !{!820, !14, i64 24}
!820 = !{!"_ZTSN4llvm14IndexListEntryE", !821, i64 0, !482, i64 16, !14, i64 24}
!821 = !{!"_ZTSN4llvm10ilist_nodeINS_14IndexListEntryEJEEE", !822, i64 0}
!822 = !{!"_ZTSN4llvm15ilist_node_implINS_12ilist_detail12node_optionsINS_14IndexListEntryELb0ELb0EvLb0EvEEEE", !26, i64 0}
!823 = !{!824, !828, i64 16}
!824 = !{!"_ZTSN4llvm9LiveRange7SegmentE", !825, i64 0, !825, i64 8, !828, i64 16}
!825 = !{!"_ZTSN4llvm9SlotIndexE", !826, i64 0}
!826 = !{!"_ZTSN4llvm14PointerIntPairIPNS_14IndexListEntryELj2EjNS_21PointerLikeTypeTraitsIS2_EENS_18PointerIntPairInfoIS2_Lj2ES4_EEEE", !827, i64 0}
!827 = !{!"_ZTSN4llvm6detail13PunnedPointerIPNS_14IndexListEntryEEE", !9, i64 0}
!828 = !{!"p1 _ZTSN4llvm6VNInfoE", !10, i64 0}
!829 = !{!830, !830, i64 0}
!830 = !{!"p1 _ZTSN4llvm12LiveInterval8SubRangeE", !10, i64 0}
!831 = distinct !{!831, !305}
!832 = distinct !{!832, !305}
!833 = !{!803, !803, i64 0}
!834 = distinct !{!834, !305}
!835 = !{!836, !747, i64 32}
!836 = !{!"_ZTSN4llvm13LiveIntervalsE", !30, i64 0, !95, i64 8, !687, i64 16, !837, i64 24, !747, i64 32, !838, i64 40, !839, i64 48, !107, i64 56, !812, i64 136, !846, i64 168, !851, i64 248, !856, i64 328, !861, i64 408}
!837 = !{!"p1 _ZTSN4llvm15TargetInstrInfoE", !10, i64 0}
!838 = !{!"p1 _ZTSN4llvm20MachineDominatorTreeE", !10, i64 0}
!839 = !{!"_ZTSSt10unique_ptrIN4llvm16LiveIntervalCalcESt14default_deleteIS1_EE", !840, i64 0}
!840 = !{!"_ZTSSt15__uniq_ptr_dataIN4llvm16LiveIntervalCalcESt14default_deleteIS1_ELb1ELb1EE", !841, i64 0}
!841 = !{!"_ZTSSt15__uniq_ptr_implIN4llvm16LiveIntervalCalcESt14default_deleteIS1_EE", !842, i64 0}
!842 = !{!"_ZTSSt5tupleIJPN4llvm16LiveIntervalCalcESt14default_deleteIS1_EEE", !843, i64 0}
!843 = !{!"_ZTSSt11_Tuple_implILm0EJPN4llvm16LiveIntervalCalcESt14default_deleteIS1_EEE", !844, i64 0}
!844 = !{!"_ZTSSt10_Head_baseILm0EPN4llvm16LiveIntervalCalcELb0EE", !845, i64 0}
!845 = !{!"p1 _ZTSN4llvm16LiveIntervalCalcE", !10, i64 0}
!846 = !{!"_ZTSN4llvm11SmallVectorINS_9SlotIndexELj8EEE", !847, i64 0, !850, i64 16}
!847 = !{!"_ZTSN4llvm15SmallVectorImplINS_9SlotIndexEEE", !848, i64 0}
!848 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseINS_9SlotIndexELb1EEE", !849, i64 0}
!849 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonINS_9SlotIndexEvEE", !20, i64 0}
!850 = !{!"_ZTSN4llvm18SmallVectorStorageINS_9SlotIndexELj8EEE", !9, i64 0}
!851 = !{!"_ZTSN4llvm11SmallVectorIPKjLj8EEE", !852, i64 0, !855, i64 16}
!852 = !{!"_ZTSN4llvm15SmallVectorImplIPKjEE", !853, i64 0}
!853 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseIPKjLb1EEE", !854, i64 0}
!854 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonIPKjvEE", !20, i64 0}
!855 = !{!"_ZTSN4llvm18SmallVectorStorageIPKjLj8EEE", !9, i64 0}
!856 = !{!"_ZTSN4llvm11SmallVectorISt4pairIjjELj8EEE", !857, i64 0, !860, i64 16}
!857 = !{!"_ZTSN4llvm15SmallVectorImplISt4pairIjjEEE", !858, i64 0}
!858 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseISt4pairIjjELb1EEE", !859, i64 0}
!859 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonISt4pairIjjEvEE", !20, i64 0}
!860 = !{!"_ZTSN4llvm18SmallVectorStorageISt4pairIjjELj8EEE", !9, i64 0}
!861 = !{!"_ZTSN4llvm11SmallVectorIPNS_9LiveRangeELj0EEE", !862, i64 0}
!862 = !{!"_ZTSN4llvm15SmallVectorImplIPNS_9LiveRangeEEE", !863, i64 0}
!863 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseIPNS_9LiveRangeELb1EEE", !864, i64 0}
!864 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonIPNS_9LiveRangeEvEE", !20, i64 0}
!865 = distinct !{!865, !305}
!866 = !{!836, !687, i64 16}
!867 = !{!868}
!868 = distinct !{!868, !869, !"_ZNK4llvm14MCRegisterInfo8regunitsENS_10MCRegisterE: argument 0"}
!869 = distinct !{!869, !"_ZNK4llvm14MCRegisterInfo8regunitsENS_10MCRegisterE"}
!870 = !{!550, !14, i64 16}
!871 = !{!872, !872, i64 0}
!872 = !{!"p1 _ZTSN4llvm11MachineLoopE", !10, i64 0}
!873 = !{!874, !872, i64 0}
!874 = !{!"_ZTSN4llvm8LoopBaseINS_17MachineBasicBlockENS_11MachineLoopEEE", !872, i64 0, !875, i64 8, !9, i64 32, !14, i64 40, !14, i64 44, !880, i64 48}
!875 = !{!"_ZTSSt6vectorIPN4llvm11MachineLoopESaIS2_EE", !876, i64 0}
!876 = !{!"_ZTSSt12_Vector_baseIPN4llvm11MachineLoopESaIS2_EE", !877, i64 0}
!877 = !{!"_ZTSNSt12_Vector_baseIPN4llvm11MachineLoopESaIS2_EE12_Vector_implE", !878, i64 0}
!878 = !{!"_ZTSNSt12_Vector_baseIPN4llvm11MachineLoopESaIS2_EE17_Vector_impl_dataE", !879, i64 0, !879, i64 8, !879, i64 16}
!879 = !{!"p2 _ZTSN4llvm11MachineLoopE", !13, i64 0}
!880 = !{!"p1 _ZTSN4llvm12LoopInfoBaseINS_17MachineBasicBlockENS_11MachineLoopEEE", !10, i64 0}
!881 = distinct !{!881, !305}
!882 = !{!90, !92, i64 8}
!883 = !{!884, !885, i64 0}
!884 = !{!"_ZTSNSt12_Vector_baseIN4llvm21MachineJumpTableEntryESaIS1_EE17_Vector_impl_dataE", !885, i64 0, !885, i64 8, !885, i64 16}
!885 = !{!"p1 _ZTSN4llvm21MachineJumpTableEntryE", !10, i64 0}
!886 = !{!106, !106, i64 0}
!887 = !{!107, !108, i64 0}
!888 = !{!107, !109, i64 8}
!889 = distinct !{!889, !305}
!890 = distinct !{!890, !305}
!891 = distinct !{!891, !305}
!892 = distinct !{!892, !305}
!893 = distinct !{!893, !305}
!894 = distinct !{!894, !305, !607, !608}
!895 = distinct !{!895, !305, !608, !607}
!896 = distinct !{!896, !305, !607, !608}
!897 = distinct !{!897, !305, !608, !607}
!898 = distinct !{!898, !305, !607, !608}
!899 = distinct !{!899, !305, !608, !607}
!900 = distinct !{!900, !305}
!901 = distinct !{!901, !305, !607, !608}
!902 = distinct !{!902, !305, !608, !607}
!903 = distinct !{!903, !305, !607, !608}
!904 = distinct !{!904, !305, !608, !607}
!905 = distinct !{!905, !305, !607, !608}
!906 = distinct !{!906, !305, !608, !607}
!907 = distinct !{!907, !305}
!908 = distinct !{!908, !305}
!909 = distinct !{!909, !305}
!910 = distinct !{!910, !305}
!911 = distinct !{!911, !305}
!912 = !{!280, !281, i64 2}
!913 = !{!914, !92, i64 8}
!914 = !{!"_ZTSN4llvm18TargetLoweringBaseE", !92, i64 8, !15, i64 16, !915, i64 24, !15, i64 48, !917, i64 52, !917, i64 56, !917, i64 60, !918, i64 64, !64, i64 65, !64, i64 66, !64, i64 67, !64, i64 68, !14, i64 72, !14, i64 76, !14, i64 80, !14, i64 84, !14, i64 88, !14, i64 92, !14, i64 96, !15, i64 100, !768, i64 104, !9, i64 112, !9, i64 2248, !9, i64 2782, !9, i64 3320, !9, i64 5456, !9, i64 5724, !9, i64 6258, !9, i64 133084, !9, i64 275662, !9, i64 418240, !9, i64 489530, !9, i64 492200, !919, i64 495464, !921, i64 495488, !923, i64 495512, !9, i64 495779, !924, i64 495840, !929, i64 495888, !933, i64 508024, !14, i64 511416, !14, i64 511420, !14, i64 511424, !14, i64 511428, !14, i64 511432, !14, i64 511436, !14, i64 511440, !14, i64 511444, !14, i64 511448, !14, i64 511452, !15, i64 511456, !15, i64 511457, !15, i64 511458}
!915 = !{!"_ZTSN4llvm8DenseMapIjjNS_12DenseMapInfoIjvEENS_6detail12DenseMapPairIjjEEEE", !916, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!916 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairIjjEE", !10, i64 0}
!917 = !{!"_ZTSN4llvm18TargetLoweringBase14BooleanContentE", !9, i64 0}
!918 = !{!"_ZTSN4llvm5Sched10PreferenceE", !9, i64 0}
!919 = !{!"_ZTSN4llvm8DenseMapISt5tupleIJjNS_3MVT15SimpleValueTypeES3_EENS_18TargetLoweringBase14LegalizeActionENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S6_EEEE", !920, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!920 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairISt5tupleIJjNS_3MVT15SimpleValueTypeES4_EENS_18TargetLoweringBase14LegalizeActionEEE", !10, i64 0}
!921 = !{!"_ZTSN4llvm8DenseMapISt5tupleIJjjNS_3MVT15SimpleValueTypeEEENS_18TargetLoweringBase14LegalizeActionENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S6_EEEE", !922, i64 0, !160, i64 8, !14, i64 16, !14, i64 20}
!922 = !{!"p1 _ZTSN4llvm6detail12DenseMapPairISt5tupleIJjjNS_3MVT15SimpleValueTypeEEENS_18TargetLoweringBase14LegalizeActionEEE", !10, i64 0}
!923 = !{!"_ZTSN4llvm18TargetLoweringBase19ValueTypeActionImplE", !9, i64 0}
!924 = !{!"_ZTSSt3mapISt4pairIjN4llvm3MVT15SimpleValueTypeEES3_St4lessIS4_ESaIS0_IKS4_S3_EEE", !925, i64 0}
!925 = !{!"_ZTSSt8_Rb_treeISt4pairIjN4llvm3MVT15SimpleValueTypeEES0_IKS4_S3_ESt10_Select1stIS6_ESt4lessIS4_ESaIS6_EE", !926, i64 0}
!926 = !{!"_ZTSNSt8_Rb_treeISt4pairIjN4llvm3MVT15SimpleValueTypeEES0_IKS4_S3_ESt10_Select1stIS6_ESt4lessIS4_ESaIS6_EE13_Rb_tree_implISA_Lb1EEE", !927, i64 0, !800, i64 8}
!927 = !{!"_ZTSSt20_Rb_tree_key_compareISt4lessISt4pairIjN4llvm3MVT15SimpleValueTypeEEEE", !928, i64 0}
!928 = !{!"_ZTSSt4lessISt4pairIjN4llvm3MVT15SimpleValueTypeEEE"}
!929 = !{!"_ZTSN4llvm5RTLIB19RuntimeLibcallsInfoE", !930, i64 0, !9, i64 368}
!930 = !{!"_ZTSN4llvm5RTLIB17LibcallImplBitsetE", !931, i64 0}
!931 = !{!"_ZTSN4llvm6BitsetILj2941EEE", !932, i64 0}
!932 = !{!"_ZTSSt5arrayImLm46EE", !9, i64 0}
!933 = !{!"_ZTSN4llvm19LibcallLoweringInfoE", !934, i64 0, !9, i64 8}
!934 = !{!"p1 _ZTSN4llvm5RTLIB19RuntimeLibcallsInfoE", !10, i64 0}
!935 = !{!936, !1019, i64 1380}
!936 = !{!"_ZTSN4llvm13TargetMachineE", !937, i64 8, !938, i64 16, !965, i64 928, !223, i64 984, !223, i64 1016, !972, i64 1048, !973, i64 1052, !109, i64 1056, !974, i64 1064, !975, i64 1072, !982, i64 1080, !989, i64 1088, !996, i64 1096, !1003, i64 1104, !14, i64 1128, !14, i64 1128, !1004, i64 1136, !1009, i64 1288}
!937 = !{!"p1 _ZTSN4llvm6TargetE", !10, i64 0}
!938 = !{!"_ZTSN4llvm10DataLayoutE", !15, i64 0, !15, i64 1, !14, i64 4, !14, i64 8, !14, i64 12, !939, i64 16, !939, i64 18, !944, i64 20, !945, i64 24, !946, i64 32, !951, i64 64, !956, i64 128, !958, i64 176, !960, i64 272, !223, i64 864, !64, i64 896, !64, i64 897, !10, i64 904}
!939 = !{!"_ZTSN4llvm10MaybeAlignE", !940, i64 0}
!940 = !{!"_ZTSSt8optionalIN4llvm5AlignEE", !941, i64 0}
!941 = !{!"_ZTSSt14_Optional_baseIN4llvm5AlignELb1ELb1EE", !942, i64 0}
!942 = !{!"_ZTSSt17_Optional_payloadIN4llvm5AlignELb1ELb1ELb1EE", !943, i64 0}
!943 = !{!"_ZTSSt22_Optional_payload_baseIN4llvm5AlignEE", !9, i64 0, !15, i64 1}
!944 = !{!"_ZTSN4llvm10DataLayout20FunctionPtrAlignTypeE", !9, i64 0}
!945 = !{!"_ZTSN4llvm10DataLayout13ManglingModeTE", !9, i64 0}
!946 = !{!"_ZTSN4llvm11SmallVectorIhLj8EEE", !947, i64 0, !950, i64 24}
!947 = !{!"_ZTSN4llvm15SmallVectorImplIhEE", !948, i64 0}
!948 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseIhLb1EEE", !949, i64 0}
!949 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonIhvEE", !203, i64 0}
!950 = !{!"_ZTSN4llvm18SmallVectorStorageIhLj8EEE", !9, i64 0}
!951 = !{!"_ZTSN4llvm11SmallVectorINS_10DataLayout13PrimitiveSpecELj6EEE", !952, i64 0, !955, i64 16}
!952 = !{!"_ZTSN4llvm15SmallVectorImplINS_10DataLayout13PrimitiveSpecEEE", !953, i64 0}
!953 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseINS_10DataLayout13PrimitiveSpecELb1EEE", !954, i64 0}
!954 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonINS_10DataLayout13PrimitiveSpecEvEE", !20, i64 0}
!955 = !{!"_ZTSN4llvm18SmallVectorStorageINS_10DataLayout13PrimitiveSpecELj6EEE", !9, i64 0}
!956 = !{!"_ZTSN4llvm11SmallVectorINS_10DataLayout13PrimitiveSpecELj4EEE", !952, i64 0, !957, i64 16}
!957 = !{!"_ZTSN4llvm18SmallVectorStorageINS_10DataLayout13PrimitiveSpecELj4EEE", !9, i64 0}
!958 = !{!"_ZTSN4llvm11SmallVectorINS_10DataLayout13PrimitiveSpecELj10EEE", !952, i64 0, !959, i64 16}
!959 = !{!"_ZTSN4llvm18SmallVectorStorageINS_10DataLayout13PrimitiveSpecELj10EEE", !9, i64 0}
!960 = !{!"_ZTSN4llvm11SmallVectorINS_10DataLayout11PointerSpecELj8EEE", !961, i64 0, !964, i64 16}
!961 = !{!"_ZTSN4llvm15SmallVectorImplINS_10DataLayout11PointerSpecEEE", !962, i64 0}
!962 = !{!"_ZTSN4llvm23SmallVectorTemplateBaseINS_10DataLayout11PointerSpecELb0EEE", !963, i64 0}
!963 = !{!"_ZTSN4llvm25SmallVectorTemplateCommonINS_10DataLayout11PointerSpecEvEE", !20, i64 0}
!964 = !{!"_ZTSN4llvm18SmallVectorStorageINS_10DataLayout11PointerSpecELj8EEE", !9, i64 0}
!965 = !{!"_ZTSN4llvm6TripleE", !223, i64 0, !966, i64 32, !967, i64 36, !968, i64 40, !969, i64 44, !970, i64 48, !971, i64 52}
!966 = !{!"_ZTSN4llvm6Triple8ArchTypeE", !9, i64 0}
!967 = !{!"_ZTSN4llvm6Triple11SubArchTypeE", !9, i64 0}
!968 = !{!"_ZTSN4llvm6Triple10VendorTypeE", !9, i64 0}
!969 = !{!"_ZTSN4llvm6Triple6OSTypeE", !9, i64 0}
!970 = !{!"_ZTSN4llvm6Triple15EnvironmentTypeE", !9, i64 0}
!971 = !{!"_ZTSN4llvm6Triple16ObjectFormatTypeE", !9, i64 0}
!972 = !{!"_ZTSN4llvm5Reloc5ModelE", !9, i64 0}
!973 = !{!"_ZTSN4llvm9CodeModel5ModelE", !9, i64 0}
!974 = !{!"_ZTSN4llvm15CodeGenOptLevelE", !9, i64 0}
!975 = !{!"_ZTSSt10unique_ptrIKN4llvm9MCAsmInfoESt14default_deleteIS2_EE", !976, i64 0}
!976 = !{!"_ZTSSt15__uniq_ptr_dataIKN4llvm9MCAsmInfoESt14default_deleteIS2_ELb1ELb1EE", !977, i64 0}
!977 = !{!"_ZTSSt15__uniq_ptr_implIKN4llvm9MCAsmInfoESt14default_deleteIS2_EE", !978, i64 0}
!978 = !{!"_ZTSSt5tupleIJPKN4llvm9MCAsmInfoESt14default_deleteIS2_EEE", !979, i64 0}
!979 = !{!"_ZTSSt11_Tuple_implILm0EJPKN4llvm9MCAsmInfoESt14default_deleteIS2_EEE", !980, i64 0}
!980 = !{!"_ZTSSt10_Head_baseILm0EPKN4llvm9MCAsmInfoELb0EE", !981, i64 0}
!981 = !{!"p1 _ZTSN4llvm9MCAsmInfoE", !10, i64 0}
!982 = !{!"_ZTSSt10unique_ptrIKN4llvm14MCRegisterInfoESt14default_deleteIS2_EE", !983, i64 0}
!983 = !{!"_ZTSSt15__uniq_ptr_dataIKN4llvm14MCRegisterInfoESt14default_deleteIS2_ELb1ELb1EE", !984, i64 0}
!984 = !{!"_ZTSSt15__uniq_ptr_implIKN4llvm14MCRegisterInfoESt14default_deleteIS2_EE", !985, i64 0}
!985 = !{!"_ZTSSt5tupleIJPKN4llvm14MCRegisterInfoESt14default_deleteIS2_EEE", !986, i64 0}
!986 = !{!"_ZTSSt11_Tuple_implILm0EJPKN4llvm14MCRegisterInfoESt14default_deleteIS2_EEE", !987, i64 0}
!987 = !{!"_ZTSSt10_Head_baseILm0EPKN4llvm14MCRegisterInfoELb0EE", !988, i64 0}
!988 = !{!"p1 _ZTSN4llvm14MCRegisterInfoE", !10, i64 0}
!989 = !{!"_ZTSSt10unique_ptrIKN4llvm11MCInstrInfoESt14default_deleteIS2_EE", !990, i64 0}
!990 = !{!"_ZTSSt15__uniq_ptr_dataIKN4llvm11MCInstrInfoESt14default_deleteIS2_ELb1ELb1EE", !991, i64 0}
!991 = !{!"_ZTSSt15__uniq_ptr_implIKN4llvm11MCInstrInfoESt14default_deleteIS2_EE", !992, i64 0}
!992 = !{!"_ZTSSt5tupleIJPKN4llvm11MCInstrInfoESt14default_deleteIS2_EEE", !993, i64 0}
!993 = !{!"_ZTSSt11_Tuple_implILm0EJPKN4llvm11MCInstrInfoESt14default_deleteIS2_EEE", !994, i64 0}
!994 = !{!"_ZTSSt10_Head_baseILm0EPKN4llvm11MCInstrInfoELb0EE", !995, i64 0}
!995 = !{!"p1 _ZTSN4llvm11MCInstrInfoE", !10, i64 0}
!996 = !{!"_ZTSSt10unique_ptrIKN4llvm15MCSubtargetInfoESt14default_deleteIS2_EE", !997, i64 0}
!997 = !{!"_ZTSSt15__uniq_ptr_dataIKN4llvm15MCSubtargetInfoESt14default_deleteIS2_ELb1ELb1EE", !998, i64 0}
!998 = !{!"_ZTSSt15__uniq_ptr_implIKN4llvm15MCSubtargetInfoESt14default_deleteIS2_EE", !999, i64 0}
!999 = !{!"_ZTSSt5tupleIJPKN4llvm15MCSubtargetInfoESt14default_deleteIS2_EEE", !1000, i64 0}
!1000 = !{!"_ZTSSt11_Tuple_implILm0EJPKN4llvm15MCSubtargetInfoESt14default_deleteIS2_EEE", !1001, i64 0}
!1001 = !{!"_ZTSSt10_Head_baseILm0EPKN4llvm15MCSubtargetInfoELb0EE", !1002, i64 0}
!1002 = !{!"p1 _ZTSN4llvm15MCSubtargetInfoE", !10, i64 0}
!1003 = !{!"_ZTSN4llvm9StringMapISt10unique_ptrIKNS_15MCSubtargetInfoESt14default_deleteIS3_EENS_15MallocAllocatorEEE", !403, i64 0}
!1004 = !{!"_ZTSSt8optionalIN4llvm10PGOOptionsEE", !1005, i64 0}
!1005 = !{!"_ZTSSt14_Optional_baseIN4llvm10PGOOptionsELb0ELb0EE", !1006, i64 0}
!1006 = !{!"_ZTSSt17_Optional_payloadIN4llvm10PGOOptionsELb0ELb0ELb0EE", !1007, i64 0}
!1007 = !{!"_ZTSSt17_Optional_payloadIN4llvm10PGOOptionsELb1ELb0ELb0EE", !1008, i64 0}
!1008 = !{!"_ZTSSt22_Optional_payload_baseIN4llvm10PGOOptionsEE", !9, i64 0, !15, i64 144}
!1009 = !{!"_ZTSN4llvm13TargetOptionsE", !14, i64 0, !14, i64 0, !14, i64 0, !14, i64 0, !14, i64 0, !1010, i64 4, !1011, i64 8, !14, i64 12, !14, i64 12, !14, i64 12, !14, i64 12, !14, i64 12, !14, i64 12, !14, i64 12, !14, i64 12, !14, i64 13, !14, i64 13, !14, i64 13, !14, i64 14, !14, i64 14, !14, i64 14, !14, i64 14, !14, i64 14, !14, i64 14, !14, i64 15, !14, i64 15, !14, i64 15, !14, i64 15, !14, i64 15, !170, i64 16, !1012, i64 24, !14, i64 40, !14, i64 40, !14, i64 40, !14, i64 40, !14, i64 40, !14, i64 40, !14, i64 40, !14, i64 40, !14, i64 41, !14, i64 41, !14, i64 41, !14, i64 41, !14, i64 41, !14, i64 41, !223, i64 48, !14, i64 80, !1017, i64 84, !1018, i64 88, !1019, i64 92, !1020, i64 96, !223, i64 392}
!1010 = !{!"_ZTSN4llvm19GlobalISelAbortModeE", !9, i64 0}
!1011 = !{!"_ZTSN4llvm26SwiftAsyncFramePointerModeE", !9, i64 0}
!1012 = !{!"_ZTSSt10shared_ptrIN4llvm12MemoryBufferEE", !1013, i64 0}
!1013 = !{!"_ZTSSt12__shared_ptrIN4llvm12MemoryBufferELN9__gnu_cxx12_Lock_policyE2EE", !1014, i64 0, !1015, i64 8}
!1014 = !{!"p1 _ZTSN4llvm12MemoryBufferE", !10, i64 0}
!1015 = !{!"_ZTSSt14__shared_countILN9__gnu_cxx12_Lock_policyE2EE", !1016, i64 0}
!1016 = !{!"p1 _ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE", !10, i64 0}
!1017 = !{!"_ZTSN4llvm12DebuggerKindE", !9, i64 0}
!1018 = !{!"_ZTSN4llvm13VectorLibraryE", !9, i64 0}
!1019 = !{!"_ZTSN4llvm17ExceptionHandlingE", !9, i64 0}
!1020 = !{!"_ZTSN4llvm15MCTargetOptionsE", !15, i64 0, !15, i64 0, !15, i64 0, !15, i64 0, !15, i64 0, !15, i64 0, !15, i64 0, !15, i64 0, !15, i64 1, !15, i64 1, !15, i64 1, !15, i64 1, !15, i64 1, !15, i64 1, !15, i64 2, !15, i64 3, !15, i64 4, !15, i64 5, !15, i64 6, !1021, i64 8, !1022, i64 12, !1026, i64 20, !14, i64 24, !1027, i64 28, !1028, i64 36, !1029, i64 40, !223, i64 48, !223, i64 80, !223, i64 112, !223, i64 144, !223, i64 176, !223, i64 208, !1030, i64 240, !1030, i64 264, !15, i64 288, !15, i64 288, !15, i64 288, !15, i64 289}
!1021 = !{!"_ZTSN4llvm19RelocSectionSymTypeE", !9, i64 0}
!1022 = !{!"_ZTSSt8optionalIjE", !1023, i64 0}
!1023 = !{!"_ZTSSt14_Optional_baseIjLb1ELb1EE", !1024, i64 0}
!1024 = !{!"_ZTSSt17_Optional_payloadIjLb1ELb1ELb1EE", !1025, i64 0}
!1025 = !{!"_ZTSSt22_Optional_payload_baseIjE", !9, i64 0, !15, i64 4}
!1026 = !{!"_ZTSN4llvm19EmitDwarfUnwindTypeE", !9, i64 0}
!1027 = !{!"_ZTSSt4pairIiiE", !14, i64 0, !14, i64 4}
!1028 = !{!"_ZTSN4llvm15MCTargetOptions14DwarfDirectoryE", !9, i64 0}
!1029 = !{!"_ZTSN4llvm20DebugCompressionTypeE", !9, i64 0}
!1030 = !{!"_ZTSSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EE", !1031, i64 0}
!1031 = !{!"_ZTSSt12_Vector_baseINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EE", !1032, i64 0}
!1032 = !{!"_ZTSNSt12_Vector_baseINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EE12_Vector_implE", !1033, i64 0}
!1033 = !{!"_ZTSNSt12_Vector_baseINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EE17_Vector_impl_dataE", !1034, i64 0, !1034, i64 8, !1034, i64 16}
!1034 = !{!"p1 _ZTSNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE", !10, i64 0}
!1035 = !{!1036, !106, i64 8}
!1036 = !{!"_ZTSN4llvm17MachineBasicBlock16liveout_iteratorE", !523, i64 0, !523, i64 4, !106, i64 8, !106, i64 16, !1037, i64 24}
!1037 = !{!"_ZTSN9__gnu_cxx17__normal_iteratorIPKN4llvm17MachineBasicBlock16RegisterMaskPairESt6vectorIS3_SaIS3_EEEE", !63, i64 0}
!1038 = !{!1036, !106, i64 16}
!1039 = !{!1037, !63, i64 0}
!1040 = distinct !{!1040, !305}
!1041 = distinct !{!1041, !305}
!1042 = !{!1043, !1045}
!1043 = distinct !{!1043, !1044, !"_ZN4llvm17make_filter_rangeINS_14iterator_rangeINS_26MachineInstrBundleIteratorIKNS_12MachineInstrELb0EEEEEZNS_24instructionsWithoutDebugIS5_EEDaT_S8_bEUlRS4_E_EENS1_INS_20filter_iterator_implIDTcl9adl_beginclsr3stdE7declvalIRS8_EEEET0_NSt11conditionalIXsr3stdE12is_base_of_vISt26bidirectional_iterator_tagNSt15iterator_traitsISD_E17iterator_categoryEEESG_St20forward_iterator_tagE4typeEEEEEOS8_SE_: argument 0"}
!1044 = distinct !{!1044, !"_ZN4llvm17make_filter_rangeINS_14iterator_rangeINS_26MachineInstrBundleIteratorIKNS_12MachineInstrELb0EEEEEZNS_24instructionsWithoutDebugIS5_EEDaT_S8_bEUlRS4_E_EENS1_INS_20filter_iterator_implIDTcl9adl_beginclsr3stdE7declvalIRS8_EEEET0_NSt11conditionalIXsr3stdE12is_base_of_vISt26bidirectional_iterator_tagNSt15iterator_traitsISD_E17iterator_categoryEEESG_St20forward_iterator_tagE4typeEEEEEOS8_SE_"}
!1045 = distinct !{!1045, !1046, !"_ZN4llvm24instructionsWithoutDebugINS_26MachineInstrBundleIteratorIKNS_12MachineInstrELb0EEEEEDaT_S5_b: argument 0"}
!1046 = distinct !{!1046, !"_ZN4llvm24instructionsWithoutDebugINS_26MachineInstrBundleIteratorIKNS_12MachineInstrELb0EEEEEDaT_S5_b"}
!1047 = distinct !{!1047, !305}
!1048 = distinct !{!1048, !305}
!1049 = distinct !{!1049, !305}
!1050 = !{!1051}
!1051 = distinct !{!1051, !1052, !"_ZN4llvm6formatIJmEEENS_13format_objectIJDpT_EEEPKcDpRKS2_: argument 0"}
!1052 = distinct !{!1052, !"_ZN4llvm6formatIJmEEENS_13format_objectIJDpT_EEEPKcDpRKS2_"}
!1053 = !{!1054, !1054, i64 0}
!1054 = !{!"p1 _ZTSSt9type_info", !10, i64 0}
!1055 = !{!1056, !468, i64 0}
!1056 = !{!"_ZTSZN4llvmlsIJmEEERNS_11raw_ostreamES2_NS_13format_objectIJDpT_EEEEUlPcmE_", !468, i64 0}
!1057 = distinct !{!1057, !305}
!1058 = !{!1059, !34, i64 8}
!1059 = !{!"_ZTSSt4pairIN4llvm9SlotIndexEPNS0_17MachineBasicBlockEE", !825, i64 0, !34, i64 8}
!1060 = distinct !{!1060, !305}
!1061 = distinct !{!1061, !305}
!1062 = distinct !{!1062, !305}
!1063 = distinct !{!1063, !305}
!1064 = distinct !{!1064, !305}
!1065 = distinct !{!1065, !324}
!1066 = distinct !{!1066, !305}
!1067 = distinct !{!1067, !305}
!1068 = distinct !{!1068, !305}
!1069 = distinct !{!1069, !305}
!1070 = distinct !{!1070, !324}
!1071 = distinct !{!1071, !305}
!1072 = distinct !{!1072, !305}
!1073 = !{!779, !14, i64 16}
!1074 = distinct !{!1074, !305, !322}
!1075 = distinct !{!1075, !305, !324}
!1076 = !{!1077, !1079, !1081}
!1077 = distinct !{!1077, !1078, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E16try_emplace_implIRKS3_JEEESt4pairINS_16DenseMapIteratorIS3_S5_S7_S9_Lb0EEEbEOT_DpOT0_: argument 0"}
!1078 = distinct !{!1078, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E16try_emplace_implIRKS3_JEEESt4pairINS_16DenseMapIteratorIS3_S5_S7_S9_Lb0EEEbEOT_DpOT0_"}
!1079 = distinct !{!1079, !1080, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E11try_emplaceIJEEESt4pairINS_16DenseMapIteratorIS3_S5_S7_S9_Lb0EEEbERKS3_DpOT_: argument 0"}
!1080 = distinct !{!1080, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E11try_emplaceIJEEESt4pairINS_16DenseMapIteratorIS3_S5_S7_S9_Lb0EEEbERKS3_DpOT_"}
!1081 = distinct !{!1081, !1082, !"_ZN4llvm6detail12DenseSetImplIPNS_12MachineInstrENS_8DenseMapIS3_NS0_13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS0_12DenseSetPairIS3_EEEEE6insertERKS3_: argument 0"}
!1082 = distinct !{!1082, !"_ZN4llvm6detail12DenseSetImplIPNS_12MachineInstrENS_8DenseMapIS3_NS0_13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS0_12DenseSetPairIS3_EEEEE6insertERKS3_"}
!1083 = !{!1084, !1086, !1088}
!1084 = distinct !{!1084, !1085, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E16try_emplace_implIRKS3_JEEESt4pairINS_16DenseMapIteratorIS3_S5_S7_S9_Lb0EEEbEOT_DpOT0_: argument 0"}
!1085 = distinct !{!1085, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E16try_emplace_implIRKS3_JEEESt4pairINS_16DenseMapIteratorIS3_S5_S7_S9_Lb0EEEbEOT_DpOT0_"}
!1086 = distinct !{!1086, !1087, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E11try_emplaceIJEEESt4pairINS_16DenseMapIteratorIS3_S5_S7_S9_Lb0EEEbERKS3_DpOT_: argument 0"}
!1087 = distinct !{!1087, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E11try_emplaceIJEEESt4pairINS_16DenseMapIteratorIS3_S5_S7_S9_Lb0EEEbERKS3_DpOT_"}
!1088 = distinct !{!1088, !1089, !"_ZN4llvm6detail12DenseSetImplIPNS_12MachineInstrENS_8DenseMapIS3_NS0_13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS0_12DenseSetPairIS3_EEEEE6insertERKS3_: argument 0"}
!1089 = distinct !{!1089, !"_ZN4llvm6detail12DenseSetImplIPNS_12MachineInstrENS_8DenseMapIS3_NS0_13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS0_12DenseSetPairIS3_EEEEE6insertERKS3_"}
!1090 = !{!1091, !1093}
!1091 = distinct !{!1091, !1092, !"_ZNK4llvm8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS2_vEENS3_12DenseSetPairIS2_EEE6getRepEv: argument 0"}
!1092 = distinct !{!1092, !"_ZNK4llvm8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS2_vEENS3_12DenseSetPairIS2_EEE6getRepEv"}
!1093 = distinct !{!1093, !1094, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E6getRepEv: argument 0"}
!1094 = distinct !{!1094, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E6getRepEv"}
!1095 = !{!779, !160, i64 8}
!1096 = distinct !{!1096, !305}
!1097 = !{!780, !780, i64 0}
!1098 = !{!1099, !1101}
!1099 = distinct !{!1099, !1100, !"_ZNK4llvm8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS2_vEENS3_12DenseSetPairIS2_EEE6getRepEv: argument 0"}
!1100 = distinct !{!1100, !"_ZNK4llvm8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS2_vEENS3_12DenseSetPairIS2_EEE6getRepEv"}
!1101 = distinct !{!1101, !1102, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E6getRepEv: argument 0"}
!1102 = distinct !{!1102, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E6getRepEv"}
!1103 = distinct !{!1103, !305}
!1104 = distinct !{!1104, !305}
!1105 = distinct !{!1105, !305}
!1106 = !{!1107, !1109}
!1107 = distinct !{!1107, !1108, !"_ZNK4llvm8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS2_vEENS3_12DenseSetPairIS2_EEE6getRepEv: argument 0"}
!1108 = distinct !{!1108, !"_ZNK4llvm8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS2_vEENS3_12DenseSetPairIS2_EEE6getRepEv"}
!1109 = distinct !{!1109, !1110, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E6getRepEv: argument 0"}
!1110 = distinct !{!1110, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPNS_12MachineInstrENS_6detail13DenseSetEmptyENS_12DenseMapInfoIS3_vEENS4_12DenseSetPairIS3_EEEES3_S5_S7_S9_E6getRepEv"}
!1111 = !{!820, !482, i64 16}
!1112 = !{!1113, !482, i64 0}
!1113 = !{!"_ZTSSt4pairIPKN4llvm12MachineInstrENS0_9SlotIndexEE", !482, i64 0, !825, i64 8}
!1114 = !{!1115, !1117}
!1115 = distinct !{!1115, !1116, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E16try_emplace_implIS4_JS5_EEESt4pairINS_16DenseMapIteratorIS4_S5_S7_SA_Lb0EEEbEOT_DpOT0_: argument 0"}
!1116 = distinct !{!1116, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E16try_emplace_implIS4_JS5_EEESt4pairINS_16DenseMapIteratorIS4_S5_S7_SA_Lb0EEEbEOT_DpOT0_"}
!1117 = distinct !{!1117, !1118, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E6insertEOSt4pairIS4_S5_E: argument 0"}
!1118 = distinct !{!1118, !"_ZN4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E6insertEOSt4pairIS4_S5_E"}
!1119 = distinct !{!1119, !305}
!1120 = !{!1121, !1123}
!1121 = distinct !{!1121, !1122, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E7find_asIS4_EENS_16DenseMapIteratorIS4_S5_S7_SA_Lb1EEERKT_: argument 0"}
!1122 = distinct !{!1122, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E7find_asIS4_EENS_16DenseMapIteratorIS4_S5_S7_SA_Lb1EEERKT_"}
!1123 = distinct !{!1123, !1124, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E4findES4_: argument 0"}
!1124 = distinct !{!1124, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E4findES4_"}
!1125 = distinct !{!1125, !305}
!1126 = !{!1127, !1129}
!1127 = distinct !{!1127, !1128, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E7find_asIS4_EENS_16DenseMapIteratorIS4_S5_S7_SA_Lb1EEERKT_: argument 0"}
!1128 = distinct !{!1128, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E7find_asIS4_EENS_16DenseMapIteratorIS4_S5_S7_SA_Lb1EEERKT_"}
!1129 = distinct !{!1129, !1130, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E4findES4_: argument 0"}
!1130 = distinct !{!1130, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E4findES4_"}
!1131 = !{!1132, !1134}
!1132 = distinct !{!1132, !1133, !"_ZNK4llvm8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS3_vEENS_6detail12DenseMapPairIS3_S4_EEE6getRepEv: argument 0"}
!1133 = distinct !{!1133, !"_ZNK4llvm8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS3_vEENS_6detail12DenseMapPairIS3_S4_EEE6getRepEv"}
!1134 = distinct !{!1134, !1135, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E6getRepEv: argument 0"}
!1135 = distinct !{!1135, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E6getRepEv"}
!1136 = distinct !{!1136, !305}
!1137 = !{!471, !471, i64 0}
!1138 = !{!1139, !1141}
!1139 = distinct !{!1139, !1140, !"_ZNK4llvm8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS3_vEENS_6detail12DenseMapPairIS3_S4_EEE6getRepEv: argument 0"}
!1140 = distinct !{!1140, !"_ZNK4llvm8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS3_vEENS_6detail12DenseMapPairIS3_S4_EEE6getRepEv"}
!1141 = distinct !{!1141, !1142, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E6getRepEv: argument 0"}
!1142 = distinct !{!1142, !"_ZNK4llvm12DenseMapBaseINS_8DenseMapIPKNS_12MachineInstrENS_9SlotIndexENS_12DenseMapInfoIS4_vEENS_6detail12DenseMapPairIS4_S5_EEEES4_S5_S7_SA_E6getRepEv"}
!1143 = distinct !{!1143, !305}
!1144 = distinct !{!1144, !305}
!1145 = distinct !{!1145, !305}
!1146 = !{!1147, !1147, i64 0}
!1147 = !{!"p1 _ZTSN4llvm9LiveRangeE", !10, i64 0}
!1148 = !{!1149, !1149, i64 0}
!1149 = !{!"p1 _ZTSSt3setIN4llvm9LiveRange7SegmentESt4lessIS2_ESaIS2_EE", !10, i64 0}
!1150 = !{!801, !803, i64 24}
!1151 = !{!801, !803, i64 16}
!1152 = distinct !{!1152, !305}
!1153 = distinct !{!1153, !305}
!1154 = !{!1155, !15, i64 9}
!1155 = !{!"_ZTSN4llvm2cl15OptionValueCopyIbEE", !1156, i64 0, !15, i64 8, !15, i64 9}
!1156 = !{!"_ZTSN4llvm2cl18GenericOptionValueE"}
!1157 = !{!1158, !34, i64 0}
!1158 = !{!"_ZTSZN4llvm17printMBBReferenceERKNS_17MachineBasicBlockEE3$_0", !34, i64 0}
!1159 = !{!1160, !361, i64 0}
!1160 = !{!"_ZTSZN4llvmlsIJjEEERNS_11raw_ostreamES2_NS_13format_objectIJDpT_EEEEUlPcmE_", !361, i64 0}
!1161 = !{!1162, !377, i64 0}
!1162 = !{!"_ZTSZN4llvmlsIJdEEERNS_11raw_ostreamES2_NS_13format_objectIJDpT_EEEEUlPcmE_", !377, i64 0}
!1163 = !{!371, !371, i64 0}
!1164 = distinct !{!1164, !305}
!1165 = distinct !{!1165, !305}
!1166 = distinct !{!1166, !305}
!1167 = distinct !{!1167, !305}
!1168 = distinct !{!1168, !305}
!1169 = distinct !{!1169, !305}
!1170 = distinct !{!1170, !305}
!1171 = distinct !{!1171, !305}
!1172 = distinct !{!1172, !305}
!1173 = !{!1174, !15, i64 8}
!1174 = !{!"_ZTSN4llvm16SmallSetIteratorINS_8RegisterELj8ESt4lessIS1_EEE", !9, i64 0, !15, i64 8}
!1175 = !{!1176, !15, i64 16}
!1176 = !{!"_ZTSSt4pairIN4llvm16SmallSetIteratorINS0_8RegisterELj8ESt4lessIS2_EEEbE", !1174, i64 0, !15, i64 16}
!1177 = distinct !{!1177, !305}
!1178 = !{!1179, !15, i64 0}
!1179 = !{!"_ZTSN4llvm2cl11opt_storageIbLb0ELb0EEE", !15, i64 0, !1180, i64 8}
!1180 = !{!"_ZTSN4llvm2cl11OptionValueIbEE", !1181, i64 0}
!1181 = !{!"_ZTSN4llvm2cl15OptionValueBaseIbLb0EEE", !1155, i64 0}
!1182 = !{!1155, !15, i64 8}
!1183 = !{!69, !14, i64 4}
