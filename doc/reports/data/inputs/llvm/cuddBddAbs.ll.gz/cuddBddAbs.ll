; ModuleID = '/home/tilir/cudd/cudd/cuddBddAbs.c'
source_filename = "/home/tilir/cudd/cudd/cuddBddAbs.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@.str = private unnamed_addr constant [41 x i8] c"Error: Can only abstract positive cubes\0A\00", align 1

; Function Attrs: nounwind uwtable
define dso_local ptr @Cudd_bddExistAbstract(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = ptrtoint ptr %2 to i64
  %5 = and i64 %4, 1
  %6 = icmp eq i64 %5, 0
  br i1 %6, label %7, label %31

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %9 = load ptr, ptr %8, align 8, !tbaa !5
  %10 = ptrtoint ptr %9 to i64
  %11 = xor i64 %10, 1
  %12 = inttoptr i64 %11 to ptr
  br label %13

13:                                               ; preds = %25, %7
  %14 = phi ptr [ %2, %7 ], [ %27, %25 ]
  %15 = icmp eq ptr %14, %9
  br i1 %15, label %16, label %18

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 432
  br label %36

18:                                               ; preds = %13
  %19 = load i32, ptr %14, align 8, !tbaa !27
  %20 = icmp eq i32 %19, 2147483647
  br i1 %20, label %31, label %21

21:                                               ; preds = %18
  %22 = getelementptr inbounds nuw i8, ptr %14, i64 24
  %23 = load ptr, ptr %22, align 8, !tbaa !28
  %24 = icmp eq ptr %23, %12
  br i1 %24, label %25, label %31

25:                                               ; preds = %21
  %26 = getelementptr inbounds nuw i8, ptr %14, i64 16
  %27 = load ptr, ptr %26, align 8, !tbaa !28
  %28 = ptrtoint ptr %27 to i64
  %29 = and i64 %28, 1
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %13, label %31

31:                                               ; preds = %21, %18, %25, %3
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 616
  %33 = load ptr, ptr %32, align 8, !tbaa !29
  %34 = tail call i64 @fwrite(ptr nonnull @.str, i64 40, i64 1, ptr %33)
  %35 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 6, ptr %35, align 8, !tbaa !30
  br label %51

36:                                               ; preds = %16, %36
  store i32 0, ptr %17, align 8, !tbaa !31
  %37 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef %0, ptr noundef %1, ptr noundef %2)
  %38 = load i32, ptr %17, align 8, !tbaa !31
  %39 = icmp eq i32 %38, 1
  br i1 %39, label %36, label %40, !llvm.loop !32

40:                                               ; preds = %36
  %41 = getelementptr inbounds nuw i8, ptr %0, i64 624
  %42 = load i32, ptr %41, align 8, !tbaa !30
  %43 = icmp eq i32 %42, 4
  br i1 %43, label %44, label %51

44:                                               ; preds = %40
  %45 = getelementptr inbounds nuw i8, ptr %0, i64 672
  %46 = load ptr, ptr %45, align 8, !tbaa !34
  %47 = icmp eq ptr %46, null
  br i1 %47, label %51, label %48

48:                                               ; preds = %44
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 680
  %50 = load ptr, ptr %49, align 8, !tbaa !35
  tail call void %46(ptr noundef nonnull %0, ptr noundef %50) #4
  br label %51

51:                                               ; preds = %40, %44, %48, %31
  %52 = phi ptr [ null, %31 ], [ %37, %48 ], [ %37, %44 ], [ %37, %40 ]
  ret ptr %52
}

; Function Attrs: nounwind uwtable
define dso_local ptr @cuddBddExistAbstractRecur(ptr noundef %0, ptr noundef %1, ptr noundef %2) local_unnamed_addr #0 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %5 = load ptr, ptr %4, align 8, !tbaa !5
  %6 = ptrtoint ptr %1 to i64
  %7 = and i64 %6, -2
  %8 = inttoptr i64 %7 to ptr
  %9 = icmp eq ptr %2, %5
  %10 = icmp eq ptr %5, %8
  %11 = or i1 %9, %10
  br i1 %11, label %178, label %12

12:                                               ; preds = %3
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 288
  %14 = load ptr, ptr %13, align 8, !tbaa !36
  %15 = load i32, ptr %8, align 8, !tbaa !27
  %16 = zext i32 %15 to i64
  %17 = getelementptr inbounds nuw i32, ptr %14, i64 %16
  %18 = load i32, ptr %17, align 4, !tbaa !37
  br label %19

19:                                               ; preds = %12, %26
  %20 = phi ptr [ %28, %26 ], [ %2, %12 ]
  %21 = load i32, ptr %20, align 8, !tbaa !27
  %22 = zext i32 %21 to i64
  %23 = getelementptr inbounds nuw i32, ptr %14, i64 %22
  %24 = load i32, ptr %23, align 4, !tbaa !37
  %25 = icmp sgt i32 %18, %24
  br i1 %25, label %26, label %30

26:                                               ; preds = %19
  %27 = getelementptr inbounds nuw i8, ptr %20, i64 16
  %28 = load ptr, ptr %27, align 8, !tbaa !28
  %29 = icmp eq ptr %28, %5
  br i1 %29, label %178, label %19, !llvm.loop !38

30:                                               ; preds = %19
  %31 = getelementptr inbounds nuw i8, ptr %8, i64 4
  %32 = load i32, ptr %31, align 4, !tbaa !39
  %33 = icmp eq i32 %32, 1
  br i1 %33, label %37, label %34

34:                                               ; preds = %30
  %35 = tail call ptr @cuddCacheLookup2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_bddExistAbstract, ptr noundef %1, ptr noundef nonnull %20) #4
  %36 = icmp eq ptr %35, null
  br i1 %36, label %37, label %178

37:                                               ; preds = %30, %34
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 96
  %39 = load double, ptr %38, align 8, !tbaa !40
  %40 = fptosi double %39 to i64
  %41 = and i64 %40, 2047
  %42 = icmp eq i64 %41, 0
  br i1 %42, label %43, label %64

43:                                               ; preds = %37
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 648
  %45 = load ptr, ptr %44, align 8, !tbaa !41
  %46 = icmp eq ptr %45, null
  br i1 %46, label %54, label %47

47:                                               ; preds = %43
  %48 = getelementptr inbounds nuw i8, ptr %0, i64 656
  %49 = load ptr, ptr %48, align 8, !tbaa !42
  %50 = tail call i32 %45(ptr noundef %49) #4
  %51 = icmp eq i32 %50, 0
  br i1 %51, label %54, label %52

52:                                               ; preds = %47
  %53 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 5, ptr %53, align 8, !tbaa !30
  br label %178

54:                                               ; preds = %47, %43
  %55 = tail call i64 @util_cpu_time() #4
  %56 = getelementptr inbounds nuw i8, ptr %0, i64 632
  %57 = load i64, ptr %56, align 8, !tbaa !43
  %58 = sub i64 %55, %57
  %59 = getelementptr inbounds nuw i8, ptr %0, i64 640
  %60 = load i64, ptr %59, align 8, !tbaa !44
  %61 = icmp ugt i64 %58, %60
  br i1 %61, label %62, label %64

62:                                               ; preds = %54
  %63 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 4, ptr %63, align 8, !tbaa !30
  br label %178

64:                                               ; preds = %54, %37
  %65 = getelementptr inbounds nuw i8, ptr %8, i64 16
  %66 = load ptr, ptr %65, align 8, !tbaa !28
  %67 = getelementptr inbounds nuw i8, ptr %8, i64 24
  %68 = load ptr, ptr %67, align 8, !tbaa !28
  %69 = icmp eq ptr %1, %8
  %70 = ptrtoint ptr %66 to i64
  %71 = xor i64 %70, 1
  %72 = inttoptr i64 %71 to ptr
  %73 = ptrtoint ptr %68 to i64
  %74 = xor i64 %73, 1
  %75 = inttoptr i64 %74 to ptr
  %76 = select i1 %69, ptr %66, ptr %72
  %77 = select i1 %69, ptr %68, ptr %75
  %78 = load i32, ptr %8, align 8, !tbaa !27
  %79 = load i32, ptr %20, align 8, !tbaa !27
  %80 = icmp eq i32 %78, %79
  br i1 %80, label %81, label %141

81:                                               ; preds = %64
  %82 = icmp eq ptr %76, %5
  %83 = icmp eq ptr %77, %5
  %84 = select i1 %82, i1 true, i1 %83
  %85 = ptrtoint ptr %77 to i64
  %86 = xor i64 %85, 1
  %87 = inttoptr i64 %86 to ptr
  %88 = icmp eq ptr %76, %87
  %89 = select i1 %84, i1 true, i1 %88
  br i1 %89, label %178, label %90

90:                                               ; preds = %81
  %91 = getelementptr inbounds nuw i8, ptr %20, i64 16
  %92 = load ptr, ptr %91, align 8, !tbaa !28
  %93 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %76, ptr noundef %92)
  %94 = icmp eq ptr %93, null
  br i1 %94, label %178, label %95

95:                                               ; preds = %90
  %96 = icmp eq ptr %93, %5
  br i1 %96, label %97, label %101

97:                                               ; preds = %95
  %98 = load i32, ptr %31, align 4, !tbaa !39
  %99 = icmp eq i32 %98, 1
  br i1 %99, label %178, label %100

100:                                              ; preds = %97
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_bddExistAbstract, ptr noundef %1, ptr noundef nonnull %20, ptr noundef %5) #4
  br label %178

101:                                              ; preds = %95
  %102 = ptrtoint ptr %93 to i64
  %103 = and i64 %102, -2
  %104 = inttoptr i64 %103 to ptr
  %105 = getelementptr inbounds nuw i8, ptr %104, i64 4
  %106 = load i32, ptr %105, align 4, !tbaa !39
  %107 = add i32 %106, 1
  store i32 %107, ptr %105, align 4, !tbaa !39
  %108 = load ptr, ptr %91, align 8, !tbaa !28
  %109 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %77, ptr noundef %108)
  %110 = icmp eq ptr %109, null
  br i1 %110, label %111, label %112

111:                                              ; preds = %101
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %93) #4
  br label %178

112:                                              ; preds = %101
  %113 = ptrtoint ptr %109 to i64
  %114 = and i64 %113, -2
  %115 = inttoptr i64 %114 to ptr
  %116 = getelementptr inbounds nuw i8, ptr %115, i64 4
  %117 = load i32, ptr %116, align 4, !tbaa !39
  %118 = add i32 %117, 1
  store i32 %118, ptr %116, align 4, !tbaa !39
  %119 = xor i64 %102, 1
  %120 = inttoptr i64 %119 to ptr
  %121 = xor i64 %113, 1
  %122 = inttoptr i64 %121 to ptr
  %123 = tail call ptr @cuddBddAndRecur(ptr noundef nonnull %0, ptr noundef %120, ptr noundef %122) #4
  %124 = icmp eq ptr %123, null
  br i1 %124, label %125, label %126

125:                                              ; preds = %112
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %93) #4
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %109) #4
  br label %178

126:                                              ; preds = %112
  %127 = ptrtoint ptr %123 to i64
  %128 = xor i64 %127, 1
  %129 = inttoptr i64 %128 to ptr
  %130 = and i64 %127, -2
  %131 = inttoptr i64 %130 to ptr
  %132 = getelementptr inbounds nuw i8, ptr %131, i64 4
  %133 = load i32, ptr %132, align 4, !tbaa !39
  %134 = add i32 %133, 1
  store i32 %134, ptr %132, align 4, !tbaa !39
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %93) #4
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %109) #4
  %135 = load i32, ptr %31, align 4, !tbaa !39
  %136 = icmp eq i32 %135, 1
  br i1 %136, label %138, label %137

137:                                              ; preds = %126
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_bddExistAbstract, ptr noundef %1, ptr noundef nonnull %20, ptr noundef %129) #4
  br label %138

138:                                              ; preds = %137, %126
  %139 = load i32, ptr %132, align 4, !tbaa !39
  %140 = add i32 %139, -1
  store i32 %140, ptr %132, align 4, !tbaa !39
  br label %178

141:                                              ; preds = %64
  %142 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %76, ptr noundef nonnull %20)
  %143 = icmp eq ptr %142, null
  br i1 %143, label %178, label %144

144:                                              ; preds = %141
  %145 = ptrtoint ptr %142 to i64
  %146 = and i64 %145, -2
  %147 = inttoptr i64 %146 to ptr
  %148 = getelementptr inbounds nuw i8, ptr %147, i64 4
  %149 = load i32, ptr %148, align 4, !tbaa !39
  %150 = add i32 %149, 1
  store i32 %150, ptr %148, align 4, !tbaa !39
  %151 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %77, ptr noundef nonnull %20)
  %152 = icmp eq ptr %151, null
  br i1 %152, label %153, label %154

153:                                              ; preds = %144
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %142) #4
  br label %178

154:                                              ; preds = %144
  %155 = ptrtoint ptr %151 to i64
  %156 = and i64 %155, -2
  %157 = inttoptr i64 %156 to ptr
  %158 = getelementptr inbounds nuw i8, ptr %157, i64 4
  %159 = load i32, ptr %158, align 4, !tbaa !39
  %160 = add i32 %159, 1
  store i32 %160, ptr %158, align 4, !tbaa !39
  %161 = getelementptr inbounds nuw i8, ptr %0, i64 320
  %162 = load ptr, ptr %161, align 8, !tbaa !45
  %163 = load i32, ptr %8, align 8, !tbaa !27
  %164 = zext i32 %163 to i64
  %165 = getelementptr inbounds nuw ptr, ptr %162, i64 %164
  %166 = load ptr, ptr %165, align 8, !tbaa !46
  %167 = tail call ptr @cuddBddIteRecur(ptr noundef nonnull %0, ptr noundef %166, ptr noundef nonnull %142, ptr noundef nonnull %151) #4
  %168 = icmp eq ptr %167, null
  br i1 %168, label %169, label %170

169:                                              ; preds = %154
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %142) #4
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %151) #4
  br label %178

170:                                              ; preds = %154
  %171 = load i32, ptr %148, align 4, !tbaa !39
  %172 = add i32 %171, -1
  store i32 %172, ptr %148, align 4, !tbaa !39
  %173 = load i32, ptr %158, align 4, !tbaa !39
  %174 = add i32 %173, -1
  store i32 %174, ptr %158, align 4, !tbaa !39
  %175 = load i32, ptr %31, align 4, !tbaa !39
  %176 = icmp eq i32 %175, 1
  br i1 %176, label %178, label %177

177:                                              ; preds = %170
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_bddExistAbstract, ptr noundef %1, ptr noundef nonnull %20, ptr noundef nonnull %167) #4
  br label %178

178:                                              ; preds = %26, %170, %177, %141, %97, %100, %90, %81, %34, %3, %169, %153, %138, %125, %111, %62, %52
  %179 = phi ptr [ null, %52 ], [ null, %62 ], [ null, %111 ], [ null, %125 ], [ %129, %138 ], [ null, %153 ], [ null, %169 ], [ %1, %3 ], [ %35, %34 ], [ %5, %81 ], [ null, %90 ], [ %5, %100 ], [ %5, %97 ], [ null, %141 ], [ %167, %177 ], [ %167, %170 ], [ %1, %26 ]
  ret ptr %179
}

; Function Attrs: nounwind uwtable
define dso_local ptr @Cudd_bddExistAbstractLimit(ptr noundef %0, ptr noundef %1, ptr noundef %2, i32 noundef %3) local_unnamed_addr #0 {
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 236
  %6 = load i32, ptr %5, align 4, !tbaa !47
  %7 = ptrtoint ptr %2 to i64
  %8 = and i64 %7, 1
  %9 = icmp eq i64 %8, 0
  br i1 %9, label %10, label %32

10:                                               ; preds = %4
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %12 = load ptr, ptr %11, align 8, !tbaa !5
  %13 = ptrtoint ptr %12 to i64
  %14 = xor i64 %13, 1
  %15 = inttoptr i64 %14 to ptr
  br label %16

16:                                               ; preds = %26, %10
  %17 = phi ptr [ %2, %10 ], [ %28, %26 ]
  %18 = icmp eq ptr %17, %12
  br i1 %18, label %37, label %19

19:                                               ; preds = %16
  %20 = load i32, ptr %17, align 8, !tbaa !27
  %21 = icmp eq i32 %20, 2147483647
  br i1 %21, label %32, label %22

22:                                               ; preds = %19
  %23 = getelementptr inbounds nuw i8, ptr %17, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !28
  %25 = icmp eq ptr %24, %15
  br i1 %25, label %26, label %32

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw i8, ptr %17, i64 16
  %28 = load ptr, ptr %27, align 8, !tbaa !28
  %29 = ptrtoint ptr %28 to i64
  %30 = and i64 %29, 1
  %31 = icmp eq i64 %30, 0
  br i1 %31, label %16, label %32

32:                                               ; preds = %22, %19, %26, %4
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 616
  %34 = load ptr, ptr %33, align 8, !tbaa !29
  %35 = tail call i64 @fwrite(ptr nonnull @.str, i64 40, i64 1, ptr %34)
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 6, ptr %36, align 8, !tbaa !30
  br label %66

37:                                               ; preds = %16
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 220
  %39 = load i32, ptr %38, align 4, !tbaa !48
  %40 = getelementptr inbounds nuw i8, ptr %0, i64 228
  %41 = load i32, ptr %40, align 4, !tbaa !49
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 224
  %43 = load i32, ptr %42, align 8, !tbaa !50
  %44 = getelementptr inbounds nuw i8, ptr %0, i64 232
  %45 = load i32, ptr %44, align 8, !tbaa !51
  %46 = add i32 %39, %3
  %47 = add i32 %46, %43
  %48 = add i32 %41, %45
  %49 = sub i32 %47, %48
  store i32 %49, ptr %5, align 4, !tbaa !47
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 432
  br label %51

51:                                               ; preds = %51, %37
  store i32 0, ptr %50, align 8, !tbaa !31
  %52 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %1, ptr noundef %2)
  %53 = load i32, ptr %50, align 8, !tbaa !31
  %54 = icmp eq i32 %53, 1
  br i1 %54, label %51, label %55, !llvm.loop !52

55:                                               ; preds = %51
  store i32 %6, ptr %5, align 4, !tbaa !47
  %56 = getelementptr inbounds nuw i8, ptr %0, i64 624
  %57 = load i32, ptr %56, align 8, !tbaa !30
  %58 = icmp eq i32 %57, 4
  br i1 %58, label %59, label %66

59:                                               ; preds = %55
  %60 = getelementptr inbounds nuw i8, ptr %0, i64 672
  %61 = load ptr, ptr %60, align 8, !tbaa !34
  %62 = icmp eq ptr %61, null
  br i1 %62, label %66, label %63

63:                                               ; preds = %59
  %64 = getelementptr inbounds nuw i8, ptr %0, i64 680
  %65 = load ptr, ptr %64, align 8, !tbaa !35
  tail call void %61(ptr noundef nonnull %0, ptr noundef %65) #4
  br label %66

66:                                               ; preds = %55, %59, %63, %32
  %67 = phi ptr [ null, %32 ], [ %52, %63 ], [ %52, %59 ], [ %52, %55 ]
  ret ptr %67
}

; Function Attrs: nounwind uwtable
define dso_local ptr @Cudd_bddXorExistAbstract(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) local_unnamed_addr #0 {
  %5 = ptrtoint ptr %3 to i64
  %6 = and i64 %5, 1
  %7 = icmp eq i64 %6, 0
  br i1 %7, label %8, label %32

8:                                                ; preds = %4
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %10 = load ptr, ptr %9, align 8, !tbaa !5
  %11 = ptrtoint ptr %10 to i64
  %12 = xor i64 %11, 1
  %13 = inttoptr i64 %12 to ptr
  br label %14

14:                                               ; preds = %26, %8
  %15 = phi ptr [ %3, %8 ], [ %28, %26 ]
  %16 = icmp eq ptr %15, %10
  br i1 %16, label %17, label %19

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 432
  br label %37

19:                                               ; preds = %14
  %20 = load i32, ptr %15, align 8, !tbaa !27
  %21 = icmp eq i32 %20, 2147483647
  br i1 %21, label %32, label %22

22:                                               ; preds = %19
  %23 = getelementptr inbounds nuw i8, ptr %15, i64 24
  %24 = load ptr, ptr %23, align 8, !tbaa !28
  %25 = icmp eq ptr %24, %13
  br i1 %25, label %26, label %32

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw i8, ptr %15, i64 16
  %28 = load ptr, ptr %27, align 8, !tbaa !28
  %29 = ptrtoint ptr %28 to i64
  %30 = and i64 %29, 1
  %31 = icmp eq i64 %30, 0
  br i1 %31, label %14, label %32

32:                                               ; preds = %22, %19, %26, %4
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 616
  %34 = load ptr, ptr %33, align 8, !tbaa !29
  %35 = tail call i64 @fwrite(ptr nonnull @.str, i64 40, i64 1, ptr %34)
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 6, ptr %36, align 8, !tbaa !30
  br label %52

37:                                               ; preds = %17, %37
  store i32 0, ptr %18, align 8, !tbaa !31
  %38 = tail call ptr @cuddBddXorExistAbstractRecur(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3)
  %39 = load i32, ptr %18, align 8, !tbaa !31
  %40 = icmp eq i32 %39, 1
  br i1 %40, label %37, label %41, !llvm.loop !53

41:                                               ; preds = %37
  %42 = getelementptr inbounds nuw i8, ptr %0, i64 624
  %43 = load i32, ptr %42, align 8, !tbaa !30
  %44 = icmp eq i32 %43, 4
  br i1 %44, label %45, label %52

45:                                               ; preds = %41
  %46 = getelementptr inbounds nuw i8, ptr %0, i64 672
  %47 = load ptr, ptr %46, align 8, !tbaa !34
  %48 = icmp eq ptr %47, null
  br i1 %48, label %52, label %49

49:                                               ; preds = %45
  %50 = getelementptr inbounds nuw i8, ptr %0, i64 680
  %51 = load ptr, ptr %50, align 8, !tbaa !35
  tail call void %47(ptr noundef nonnull %0, ptr noundef %51) #4
  br label %52

52:                                               ; preds = %41, %45, %49, %32
  %53 = phi ptr [ null, %32 ], [ %38, %49 ], [ %38, %45 ], [ %38, %41 ]
  ret ptr %53
}

; Function Attrs: nounwind uwtable
define dso_local ptr @cuddBddXorExistAbstractRecur(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) local_unnamed_addr #0 {
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %6 = load ptr, ptr %5, align 8, !tbaa !5
  %7 = ptrtoint ptr %6 to i64
  %8 = xor i64 %7, 1
  %9 = inttoptr i64 %8 to ptr
  %10 = icmp eq ptr %1, %2
  br i1 %10, label %227, label %11

11:                                               ; preds = %4
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 96
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 648
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 656
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 632
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 640
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 288
  br label %18

18:                                               ; preds = %11, %101
  %19 = phi ptr [ %9, %11 ], [ %107, %101 ]
  %20 = phi ptr [ %6, %11 ], [ %104, %101 ]
  %21 = phi ptr [ %3, %11 ], [ %103, %101 ]
  %22 = phi ptr [ %2, %11 ], [ %53, %101 ]
  %23 = phi ptr [ %1, %11 ], [ %54, %101 ]
  %24 = ptrtoint ptr %22 to i64
  %25 = xor i64 %24, 1
  %26 = inttoptr i64 %25 to ptr
  %27 = icmp eq ptr %23, %26
  br i1 %27, label %227, label %28

28:                                               ; preds = %18
  %29 = icmp eq ptr %21, %20
  br i1 %29, label %30, label %32

30:                                               ; preds = %28
  %31 = tail call ptr @cuddBddXorRecur(ptr noundef nonnull %0, ptr noundef %23, ptr noundef %22) #4
  br label %227

32:                                               ; preds = %28
  %33 = icmp eq ptr %23, %20
  br i1 %33, label %34, label %36

34:                                               ; preds = %32
  %35 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %26, ptr noundef %21)
  br label %227

36:                                               ; preds = %32
  %37 = icmp eq ptr %22, %20
  br i1 %37, label %38, label %43

38:                                               ; preds = %36
  %39 = ptrtoint ptr %23 to i64
  %40 = xor i64 %39, 1
  %41 = inttoptr i64 %40 to ptr
  %42 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %41, ptr noundef %21)
  br label %227

43:                                               ; preds = %36
  %44 = icmp eq ptr %23, %19
  br i1 %44, label %45, label %47

45:                                               ; preds = %43
  %46 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %22, ptr noundef %21)
  br label %227

47:                                               ; preds = %43
  %48 = icmp eq ptr %22, %19
  br i1 %48, label %49, label %51

49:                                               ; preds = %47
  %50 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %23, ptr noundef %21)
  br label %227

51:                                               ; preds = %47
  %52 = icmp ugt ptr %23, %22
  %53 = select i1 %52, ptr %23, ptr %22
  %54 = select i1 %52, ptr %22, ptr %23
  %55 = tail call ptr @cuddCacheLookup(ptr noundef nonnull %0, i64 noundef 10, ptr noundef %54, ptr noundef %53, ptr noundef %21) #4
  %56 = icmp eq ptr %55, null
  br i1 %56, label %57, label %227

57:                                               ; preds = %51
  %58 = load double, ptr %12, align 8, !tbaa !40
  %59 = fptosi double %58 to i64
  %60 = and i64 %59, 2047
  %61 = icmp eq i64 %60, 0
  br i1 %61, label %62, label %79

62:                                               ; preds = %57
  %63 = load ptr, ptr %13, align 8, !tbaa !41
  %64 = icmp eq ptr %63, null
  br i1 %64, label %71, label %65

65:                                               ; preds = %62
  %66 = load ptr, ptr %14, align 8, !tbaa !42
  %67 = tail call i32 %63(ptr noundef %66) #4
  %68 = icmp eq i32 %67, 0
  br i1 %68, label %71, label %69

69:                                               ; preds = %65
  %70 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 5, ptr %70, align 8, !tbaa !30
  br label %227

71:                                               ; preds = %65, %62
  %72 = tail call i64 @util_cpu_time() #4
  %73 = load i64, ptr %15, align 8, !tbaa !43
  %74 = sub i64 %72, %73
  %75 = load i64, ptr %16, align 8, !tbaa !44
  %76 = icmp ugt i64 %74, %75
  br i1 %76, label %77, label %79

77:                                               ; preds = %71
  %78 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 4, ptr %78, align 8, !tbaa !30
  br label %227

79:                                               ; preds = %71, %57
  %80 = ptrtoint ptr %54 to i64
  %81 = and i64 %80, -2
  %82 = inttoptr i64 %81 to ptr
  %83 = load ptr, ptr %17, align 8, !tbaa !36
  %84 = load i32, ptr %82, align 8, !tbaa !27
  %85 = zext i32 %84 to i64
  %86 = getelementptr inbounds nuw i32, ptr %83, i64 %85
  %87 = load i32, ptr %86, align 4, !tbaa !37
  %88 = ptrtoint ptr %53 to i64
  %89 = and i64 %88, -2
  %90 = inttoptr i64 %89 to ptr
  %91 = load i32, ptr %90, align 8, !tbaa !27
  %92 = zext i32 %91 to i64
  %93 = getelementptr inbounds nuw i32, ptr %83, i64 %92
  %94 = load i32, ptr %93, align 4, !tbaa !37
  %95 = tail call i32 @llvm.smin.i32(i32 %94, i32 %87)
  %96 = load i32, ptr %21, align 8, !tbaa !27
  %97 = zext i32 %96 to i64
  %98 = getelementptr inbounds nuw i32, ptr %83, i64 %97
  %99 = load i32, ptr %98, align 4, !tbaa !37
  %100 = icmp slt i32 %99, %95
  br i1 %100, label %101, label %109

101:                                              ; preds = %79
  %102 = getelementptr inbounds nuw i8, ptr %21, i64 16
  %103 = load ptr, ptr %102, align 8, !tbaa !28
  %104 = load ptr, ptr %5, align 8, !tbaa !5
  %105 = ptrtoint ptr %104 to i64
  %106 = xor i64 %105, 1
  %107 = inttoptr i64 %106 to ptr
  %108 = icmp eq ptr %22, %23
  br i1 %108, label %227, label %18

109:                                              ; preds = %79
  %110 = icmp sgt i32 %87, %94
  br i1 %110, label %125, label %111

111:                                              ; preds = %109
  %112 = getelementptr inbounds nuw i8, ptr %82, i64 16
  %113 = load ptr, ptr %112, align 8, !tbaa !28
  %114 = getelementptr inbounds nuw i8, ptr %82, i64 24
  %115 = load ptr, ptr %114, align 8, !tbaa !28
  %116 = and i64 %80, 1
  %117 = icmp eq i64 %116, 0
  br i1 %117, label %125, label %118

118:                                              ; preds = %111
  %119 = ptrtoint ptr %113 to i64
  %120 = xor i64 %119, 1
  %121 = inttoptr i64 %120 to ptr
  %122 = ptrtoint ptr %115 to i64
  %123 = xor i64 %122, 1
  %124 = inttoptr i64 %123 to ptr
  br label %125

125:                                              ; preds = %109, %111, %118
  %126 = phi ptr [ %124, %118 ], [ %115, %111 ], [ %54, %109 ]
  %127 = phi ptr [ %121, %118 ], [ %113, %111 ], [ %54, %109 ]
  %128 = phi i32 [ %84, %118 ], [ %84, %111 ], [ %91, %109 ]
  %129 = icmp sgt i32 %94, %87
  br i1 %129, label %144, label %130

130:                                              ; preds = %125
  %131 = getelementptr inbounds nuw i8, ptr %90, i64 16
  %132 = load ptr, ptr %131, align 8, !tbaa !28
  %133 = getelementptr inbounds nuw i8, ptr %90, i64 24
  %134 = load ptr, ptr %133, align 8, !tbaa !28
  %135 = and i64 %88, 1
  %136 = icmp eq i64 %135, 0
  br i1 %136, label %144, label %137

137:                                              ; preds = %130
  %138 = ptrtoint ptr %132 to i64
  %139 = xor i64 %138, 1
  %140 = inttoptr i64 %139 to ptr
  %141 = ptrtoint ptr %134 to i64
  %142 = xor i64 %141, 1
  %143 = inttoptr i64 %142 to ptr
  br label %144

144:                                              ; preds = %125, %130, %137
  %145 = phi ptr [ %143, %137 ], [ %134, %130 ], [ %53, %125 ]
  %146 = phi ptr [ %140, %137 ], [ %132, %130 ], [ %53, %125 ]
  %147 = icmp ne i32 %99, %95
  br i1 %147, label %151, label %148

148:                                              ; preds = %144
  %149 = getelementptr inbounds nuw i8, ptr %21, i64 16
  %150 = load ptr, ptr %149, align 8, !tbaa !28
  br label %151

151:                                              ; preds = %144, %148
  %152 = phi ptr [ %150, %148 ], [ %21, %144 ]
  %153 = tail call ptr @cuddBddXorExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %127, ptr noundef %146, ptr noundef %152)
  %154 = icmp eq ptr %153, null
  br i1 %154, label %227, label %155

155:                                              ; preds = %151
  %156 = icmp ne ptr %153, %20
  %157 = or i1 %147, %156
  br i1 %157, label %159, label %158

158:                                              ; preds = %155
  tail call void @cuddCacheInsert(ptr noundef nonnull %0, i64 noundef 10, ptr noundef %54, ptr noundef %53, ptr noundef nonnull %21, ptr noundef %20) #4
  br label %227

159:                                              ; preds = %155
  %160 = ptrtoint ptr %153 to i64
  %161 = and i64 %160, -2
  %162 = inttoptr i64 %161 to ptr
  %163 = getelementptr inbounds nuw i8, ptr %162, i64 4
  %164 = load i32, ptr %163, align 4, !tbaa !39
  %165 = add i32 %164, 1
  store i32 %165, ptr %163, align 4, !tbaa !39
  %166 = tail call ptr @cuddBddXorExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %126, ptr noundef %145, ptr noundef %152)
  %167 = icmp eq ptr %166, null
  br i1 %167, label %168, label %169

168:                                              ; preds = %159
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %153) #4
  br label %227

169:                                              ; preds = %159
  %170 = ptrtoint ptr %166 to i64
  %171 = and i64 %170, -2
  %172 = inttoptr i64 %171 to ptr
  %173 = getelementptr inbounds nuw i8, ptr %172, i64 4
  %174 = load i32, ptr %173, align 4, !tbaa !39
  %175 = add i32 %174, 1
  store i32 %175, ptr %173, align 4, !tbaa !39
  br i1 %147, label %195, label %176

176:                                              ; preds = %169
  %177 = xor i64 %160, 1
  %178 = inttoptr i64 %177 to ptr
  %179 = xor i64 %170, 1
  %180 = inttoptr i64 %179 to ptr
  %181 = tail call ptr @cuddBddAndRecur(ptr noundef nonnull %0, ptr noundef %178, ptr noundef %180) #4
  %182 = icmp eq ptr %181, null
  br i1 %182, label %183, label %184

183:                                              ; preds = %176
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %153) #4
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %166) #4
  br label %227

184:                                              ; preds = %176
  %185 = ptrtoint ptr %181 to i64
  %186 = xor i64 %185, 1
  %187 = inttoptr i64 %186 to ptr
  %188 = and i64 %185, -2
  %189 = inttoptr i64 %188 to ptr
  %190 = getelementptr inbounds nuw i8, ptr %189, i64 4
  %191 = load i32, ptr %190, align 4, !tbaa !39
  %192 = add i32 %191, 1
  store i32 %192, ptr %190, align 4, !tbaa !39
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %153) #4
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %166) #4
  %193 = load i32, ptr %190, align 4, !tbaa !39
  %194 = add i32 %193, -1
  store i32 %194, ptr %190, align 4, !tbaa !39
  br label %225

195:                                              ; preds = %169
  %196 = icmp eq ptr %153, %166
  br i1 %196, label %197, label %202

197:                                              ; preds = %195
  %198 = load i32, ptr %163, align 4, !tbaa !39
  %199 = add i32 %198, -1
  store i32 %199, ptr %163, align 4, !tbaa !39
  %200 = load i32, ptr %173, align 4, !tbaa !39
  %201 = add i32 %200, -1
  store i32 %201, ptr %173, align 4, !tbaa !39
  br label %225

202:                                              ; preds = %195
  %203 = and i64 %160, 1
  %204 = icmp eq i64 %203, 0
  br i1 %204, label %215, label %205

205:                                              ; preds = %202
  %206 = xor i64 %170, 1
  %207 = inttoptr i64 %206 to ptr
  %208 = tail call ptr @cuddUniqueInter(ptr noundef nonnull %0, i32 noundef %128, ptr noundef nonnull %162, ptr noundef %207) #4
  %209 = icmp eq ptr %208, null
  br i1 %209, label %210, label %211

210:                                              ; preds = %205
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %153) #4
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %166) #4
  br label %227

211:                                              ; preds = %205
  %212 = ptrtoint ptr %208 to i64
  %213 = xor i64 %212, 1
  %214 = inttoptr i64 %213 to ptr
  br label %219

215:                                              ; preds = %202
  %216 = tail call ptr @cuddUniqueInter(ptr noundef nonnull %0, i32 noundef %128, ptr noundef nonnull %153, ptr noundef nonnull %166) #4
  %217 = icmp eq ptr %216, null
  br i1 %217, label %218, label %219

218:                                              ; preds = %215
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %153) #4
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %166) #4
  br label %227

219:                                              ; preds = %215, %211
  %220 = phi ptr [ %214, %211 ], [ %216, %215 ]
  %221 = load i32, ptr %173, align 4, !tbaa !39
  %222 = add i32 %221, -1
  store i32 %222, ptr %173, align 4, !tbaa !39
  %223 = load i32, ptr %163, align 4, !tbaa !39
  %224 = add i32 %223, -1
  store i32 %224, ptr %163, align 4, !tbaa !39
  br label %225

225:                                              ; preds = %197, %219, %184
  %226 = phi ptr [ %187, %184 ], [ %153, %197 ], [ %220, %219 ]
  tail call void @cuddCacheInsert(ptr noundef nonnull %0, i64 noundef 10, ptr noundef %54, ptr noundef %53, ptr noundef nonnull %21, ptr noundef %226) #4
  br label %227

227:                                              ; preds = %101, %18, %51, %4, %151, %225, %218, %210, %183, %168, %158, %77, %69, %49, %45, %38, %34, %30
  %228 = phi ptr [ %31, %30 ], [ %35, %34 ], [ %42, %38 ], [ %46, %45 ], [ %50, %49 ], [ null, %69 ], [ null, %77 ], [ %20, %158 ], [ null, %168 ], [ null, %183 ], [ %226, %225 ], [ null, %210 ], [ null, %218 ], [ null, %151 ], [ %9, %4 ], [ %107, %101 ], [ %20, %18 ], [ %55, %51 ]
  ret ptr %228
}

; Function Attrs: nounwind uwtable
define dso_local ptr @Cudd_bddUnivAbstract(ptr noundef %0, ptr noundef %1, ptr noundef %2) local_unnamed_addr #0 {
  %4 = ptrtoint ptr %2 to i64
  %5 = and i64 %4, 1
  %6 = icmp eq i64 %5, 0
  br i1 %6, label %7, label %34

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %9 = load ptr, ptr %8, align 8, !tbaa !5
  %10 = ptrtoint ptr %9 to i64
  %11 = xor i64 %10, 1
  %12 = inttoptr i64 %11 to ptr
  br label %13

13:                                               ; preds = %28, %7
  %14 = phi ptr [ %2, %7 ], [ %30, %28 ]
  %15 = icmp eq ptr %14, %9
  br i1 %15, label %16, label %21

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 432
  %18 = ptrtoint ptr %1 to i64
  %19 = xor i64 %18, 1
  %20 = inttoptr i64 %19 to ptr
  br label %39

21:                                               ; preds = %13
  %22 = load i32, ptr %14, align 8, !tbaa !27
  %23 = icmp eq i32 %22, 2147483647
  br i1 %23, label %34, label %24

24:                                               ; preds = %21
  %25 = getelementptr inbounds nuw i8, ptr %14, i64 24
  %26 = load ptr, ptr %25, align 8, !tbaa !28
  %27 = icmp eq ptr %26, %12
  br i1 %27, label %28, label %34

28:                                               ; preds = %24
  %29 = getelementptr inbounds nuw i8, ptr %14, i64 16
  %30 = load ptr, ptr %29, align 8, !tbaa !28
  %31 = ptrtoint ptr %30 to i64
  %32 = and i64 %31, 1
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %13, label %34

34:                                               ; preds = %24, %21, %28, %3
  %35 = getelementptr inbounds nuw i8, ptr %0, i64 616
  %36 = load ptr, ptr %35, align 8, !tbaa !29
  %37 = tail call i64 @fwrite(ptr nonnull @.str, i64 40, i64 1, ptr %36)
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 6, ptr %38, align 8, !tbaa !30
  br label %59

39:                                               ; preds = %16, %39
  store i32 0, ptr %17, align 8, !tbaa !31
  %40 = tail call ptr @cuddBddExistAbstractRecur(ptr noundef %0, ptr noundef %20, ptr noundef %2)
  %41 = load i32, ptr %17, align 8, !tbaa !31
  %42 = icmp eq i32 %41, 1
  br i1 %42, label %39, label %43, !llvm.loop !54

43:                                               ; preds = %39
  %44 = icmp eq ptr %40, null
  %45 = ptrtoint ptr %40 to i64
  %46 = xor i64 %45, 1
  %47 = inttoptr i64 %46 to ptr
  %48 = select i1 %44, ptr null, ptr %47
  %49 = getelementptr inbounds nuw i8, ptr %0, i64 624
  %50 = load i32, ptr %49, align 8, !tbaa !30
  %51 = icmp eq i32 %50, 4
  br i1 %51, label %52, label %59

52:                                               ; preds = %43
  %53 = getelementptr inbounds nuw i8, ptr %0, i64 672
  %54 = load ptr, ptr %53, align 8, !tbaa !34
  %55 = icmp eq ptr %54, null
  br i1 %55, label %59, label %56

56:                                               ; preds = %52
  %57 = getelementptr inbounds nuw i8, ptr %0, i64 680
  %58 = load ptr, ptr %57, align 8, !tbaa !35
  tail call void %54(ptr noundef nonnull %0, ptr noundef %58) #4
  br label %59

59:                                               ; preds = %43, %52, %56, %34
  %60 = phi ptr [ null, %34 ], [ %48, %56 ], [ %48, %52 ], [ %48, %43 ]
  ret ptr %60
}

; Function Attrs: nounwind uwtable
define dso_local ptr @Cudd_bddBooleanDiff(ptr noundef %0, ptr noundef %1, i32 noundef %2) local_unnamed_addr #0 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 128
  %5 = load i32, ptr %4, align 8, !tbaa !55
  %6 = icmp slt i32 %2, %5
  br i1 %6, label %13, label %7

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %9 = load ptr, ptr %8, align 8, !tbaa !5
  %10 = ptrtoint ptr %9 to i64
  %11 = xor i64 %10, 1
  %12 = inttoptr i64 %11 to ptr
  br label %38

13:                                               ; preds = %3
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 320
  %15 = load ptr, ptr %14, align 8, !tbaa !45
  %16 = sext i32 %2 to i64
  %17 = getelementptr inbounds ptr, ptr %15, i64 %16
  %18 = load ptr, ptr %17, align 8, !tbaa !46
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 432
  %20 = ptrtoint ptr %1 to i64
  %21 = and i64 %20, -2
  %22 = inttoptr i64 %21 to ptr
  br label %23

23:                                               ; preds = %23, %13
  store i32 0, ptr %19, align 8, !tbaa !31
  %24 = tail call ptr @cuddBddBooleanDiffRecur(ptr noundef nonnull %0, ptr noundef %22, ptr noundef %18)
  %25 = load i32, ptr %19, align 8, !tbaa !31
  %26 = icmp eq i32 %25, 1
  br i1 %26, label %23, label %27, !llvm.loop !56

27:                                               ; preds = %23
  %28 = getelementptr inbounds nuw i8, ptr %0, i64 624
  %29 = load i32, ptr %28, align 8, !tbaa !30
  %30 = icmp eq i32 %29, 4
  br i1 %30, label %31, label %38

31:                                               ; preds = %27
  %32 = getelementptr inbounds nuw i8, ptr %0, i64 672
  %33 = load ptr, ptr %32, align 8, !tbaa !34
  %34 = icmp eq ptr %33, null
  br i1 %34, label %38, label %35

35:                                               ; preds = %31
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 680
  %37 = load ptr, ptr %36, align 8, !tbaa !35
  tail call void %33(ptr noundef nonnull %0, ptr noundef %37) #4
  br label %38

38:                                               ; preds = %27, %31, %35, %7
  %39 = phi ptr [ %12, %7 ], [ %24, %35 ], [ %24, %31 ], [ %24, %27 ]
  ret ptr %39
}

; Function Attrs: nounwind uwtable
define dso_local ptr @cuddBddBooleanDiffRecur(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = load i32, ptr %1, align 8, !tbaa !27
  %5 = icmp eq i32 %4, 2147483647
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 288
  %7 = load ptr, ptr %6, align 8, !tbaa !36
  br i1 %5, label %12, label %8

8:                                                ; preds = %3
  %9 = zext i32 %4 to i64
  %10 = getelementptr inbounds nuw i32, ptr %7, i64 %9
  %11 = load i32, ptr %10, align 4, !tbaa !37
  br label %12

12:                                               ; preds = %3, %8
  %13 = phi i32 [ %11, %8 ], [ 2147483647, %3 ]
  %14 = load i32, ptr %2, align 8, !tbaa !27
  %15 = zext i32 %14 to i64
  %16 = getelementptr inbounds nuw i32, ptr %7, i64 %15
  %17 = load i32, ptr %16, align 4, !tbaa !37
  %18 = icmp sgt i32 %13, %17
  br i1 %18, label %19, label %25

19:                                               ; preds = %12
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %21 = load ptr, ptr %20, align 8, !tbaa !5
  %22 = ptrtoint ptr %21 to i64
  %23 = xor i64 %22, 1
  %24 = inttoptr i64 %23 to ptr
  br label %77

25:                                               ; preds = %12
  %26 = icmp eq i32 %4, %14
  br i1 %26, label %27, label %33

27:                                               ; preds = %25
  %28 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %29 = load ptr, ptr %28, align 8, !tbaa !28
  %30 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %31 = load ptr, ptr %30, align 8, !tbaa !28
  %32 = tail call ptr @cuddBddXorRecur(ptr noundef nonnull %0, ptr noundef %29, ptr noundef %31) #4
  br label %77

33:                                               ; preds = %25
  %34 = tail call ptr @cuddCacheLookup2(ptr noundef nonnull %0, ptr noundef nonnull @cuddBddBooleanDiffRecur, ptr noundef nonnull %1, ptr noundef nonnull %2) #4
  %35 = icmp eq ptr %34, null
  br i1 %35, label %36, label %77

36:                                               ; preds = %33
  %37 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %38 = load ptr, ptr %37, align 8, !tbaa !28
  %39 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %40 = load ptr, ptr %39, align 8, !tbaa !28
  %41 = tail call ptr @cuddBddBooleanDiffRecur(ptr noundef nonnull %0, ptr noundef %38, ptr noundef nonnull %2)
  %42 = icmp eq ptr %41, null
  br i1 %42, label %77, label %43

43:                                               ; preds = %36
  %44 = ptrtoint ptr %41 to i64
  %45 = and i64 %44, -2
  %46 = inttoptr i64 %45 to ptr
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 4
  %48 = load i32, ptr %47, align 4, !tbaa !39
  %49 = add i32 %48, 1
  store i32 %49, ptr %47, align 4, !tbaa !39
  %50 = ptrtoint ptr %40 to i64
  %51 = and i64 %50, -2
  %52 = inttoptr i64 %51 to ptr
  %53 = tail call ptr @cuddBddBooleanDiffRecur(ptr noundef nonnull %0, ptr noundef %52, ptr noundef nonnull %2)
  %54 = icmp eq ptr %53, null
  br i1 %54, label %55, label %56

55:                                               ; preds = %43
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %41) #4
  br label %77

56:                                               ; preds = %43
  %57 = ptrtoint ptr %53 to i64
  %58 = and i64 %57, -2
  %59 = inttoptr i64 %58 to ptr
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 4
  %61 = load i32, ptr %60, align 4, !tbaa !39
  %62 = add i32 %61, 1
  store i32 %62, ptr %60, align 4, !tbaa !39
  %63 = getelementptr inbounds nuw i8, ptr %0, i64 320
  %64 = load ptr, ptr %63, align 8, !tbaa !45
  %65 = load i32, ptr %1, align 8, !tbaa !27
  %66 = zext i32 %65 to i64
  %67 = getelementptr inbounds nuw ptr, ptr %64, i64 %66
  %68 = load ptr, ptr %67, align 8, !tbaa !46
  %69 = tail call ptr @cuddBddIteRecur(ptr noundef nonnull %0, ptr noundef %68, ptr noundef nonnull %41, ptr noundef nonnull %53) #4
  %70 = icmp eq ptr %69, null
  br i1 %70, label %71, label %72

71:                                               ; preds = %56
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %41) #4
  tail call void @Cudd_IterDerefBdd(ptr noundef nonnull %0, ptr noundef nonnull %53) #4
  br label %77

72:                                               ; preds = %56
  %73 = load i32, ptr %47, align 4, !tbaa !39
  %74 = add i32 %73, -1
  store i32 %74, ptr %47, align 4, !tbaa !39
  %75 = load i32, ptr %60, align 4, !tbaa !39
  %76 = add i32 %75, -1
  store i32 %76, ptr %60, align 4, !tbaa !39
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @cuddBddBooleanDiffRecur, ptr noundef nonnull %1, ptr noundef nonnull %2, ptr noundef nonnull %69) #4
  br label %77

77:                                               ; preds = %36, %33, %72, %71, %55, %27, %19
  %78 = phi ptr [ %24, %19 ], [ %32, %27 ], [ null, %55 ], [ null, %71 ], [ %69, %72 ], [ %34, %33 ], [ null, %36 ]
  ret ptr %78
}

; Function Attrs: nounwind uwtable
define dso_local i32 @Cudd_bddVarIsDependent(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %5 = load ptr, ptr %4, align 8, !tbaa !5
  %6 = ptrtoint ptr %5 to i64
  %7 = xor i64 %6, 1
  %8 = inttoptr i64 %7 to ptr
  %9 = ptrtoint ptr %1 to i64
  %10 = and i64 %9, -2
  %11 = inttoptr i64 %10 to ptr
  %12 = load i32, ptr %11, align 8, !tbaa !27
  %13 = icmp eq i32 %12, 2147483647
  br i1 %13, label %14, label %17

14:                                               ; preds = %3
  %15 = icmp eq ptr %1, %8
  %16 = zext i1 %15 to i32
  br label %64

17:                                               ; preds = %3
  %18 = getelementptr inbounds nuw i8, ptr %0, i64 288
  %19 = load ptr, ptr %18, align 8, !tbaa !36
  %20 = zext i32 %12 to i64
  %21 = getelementptr inbounds nuw i32, ptr %19, i64 %20
  %22 = load i32, ptr %21, align 4, !tbaa !37
  %23 = load i32, ptr %2, align 8, !tbaa !27
  %24 = zext i32 %23 to i64
  %25 = getelementptr inbounds nuw i32, ptr %19, i64 %24
  %26 = load i32, ptr %25, align 4, !tbaa !37
  %27 = icmp ugt i32 %22, %26
  br i1 %27, label %64, label %28

28:                                               ; preds = %17
  %29 = tail call ptr @cuddCacheLookup2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_bddVarIsDependent, ptr noundef %1, ptr noundef nonnull %2) #4
  %30 = icmp eq ptr %29, null
  br i1 %30, label %34, label %31

31:                                               ; preds = %28
  %32 = icmp ne ptr %29, %8
  %33 = zext i1 %32 to i32
  br label %64

34:                                               ; preds = %28
  %35 = getelementptr inbounds nuw i8, ptr %11, i64 16
  %36 = load ptr, ptr %35, align 8, !tbaa !28
  %37 = ptrtoint ptr %36 to i64
  %38 = icmp ne ptr %1, %11
  %39 = zext i1 %38 to i64
  %40 = xor i64 %37, %39
  %41 = inttoptr i64 %40 to ptr
  %42 = getelementptr inbounds nuw i8, ptr %11, i64 24
  %43 = load ptr, ptr %42, align 8, !tbaa !28
  %44 = ptrtoint ptr %43 to i64
  %45 = xor i64 %44, %39
  %46 = inttoptr i64 %45 to ptr
  %47 = icmp eq i32 %22, %26
  br i1 %47, label %48, label %52

48:                                               ; preds = %34
  %49 = xor i64 %45, 1
  %50 = inttoptr i64 %49 to ptr
  %51 = tail call i32 @Cudd_bddLeq(ptr noundef nonnull %0, ptr noundef %41, ptr noundef %50) #4
  br label %59

52:                                               ; preds = %34
  %53 = tail call i32 @Cudd_bddVarIsDependent(ptr noundef nonnull %0, ptr noundef %41, ptr noundef nonnull %2)
  %54 = icmp eq i32 %53, 0
  br i1 %54, label %59, label %55

55:                                               ; preds = %52
  %56 = tail call i32 @Cudd_bddVarIsDependent(ptr noundef nonnull %0, ptr noundef %46, ptr noundef nonnull %2)
  %57 = icmp ne i32 %56, 0
  %58 = zext i1 %57 to i32
  br label %59

59:                                               ; preds = %52, %55, %48
  %60 = phi i32 [ %51, %48 ], [ 0, %52 ], [ %58, %55 ]
  %61 = sext i32 %60 to i64
  %62 = xor i64 %7, %61
  %63 = inttoptr i64 %62 to ptr
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_bddVarIsDependent, ptr noundef %1, ptr noundef nonnull %2, ptr noundef %63) #4
  br label %64

64:                                               ; preds = %17, %59, %31, %14
  %65 = phi i32 [ %16, %14 ], [ %33, %31 ], [ %60, %59 ], [ 0, %17 ]
  ret i32 %65
}

declare ptr @cuddCacheLookup2(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare i32 @Cudd_bddLeq(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare void @cuddCacheInsert2(ptr noundef, ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare i64 @util_cpu_time() local_unnamed_addr #1

declare void @Cudd_IterDerefBdd(ptr noundef, ptr noundef) local_unnamed_addr #1

declare ptr @cuddBddAndRecur(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare ptr @cuddBddIteRecur(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare ptr @cuddBddXorRecur(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare ptr @cuddCacheLookup(ptr noundef, i64 noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare void @cuddCacheInsert(ptr noundef, i64 noundef, ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare ptr @cuddUniqueInter(ptr noundef, i32 noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: nofree nounwind
declare noundef i64 @fwrite(ptr noundef readonly captures(none), i64 noundef, i64 noundef, ptr noundef captures(none)) local_unnamed_addr #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #3

attributes #0 = { nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree nounwind }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Ubuntu clang version 21.1.8 (6ubuntu1)"}
!5 = !{!6, !11, i64 32}
!6 = !{!"DdManager", !7, i64 0, !11, i64 32, !11, i64 40, !11, i64 48, !11, i64 56, !11, i64 64, !13, i64 72, !13, i64 80, !8, i64 88, !8, i64 92, !14, i64 96, !14, i64 104, !14, i64 112, !8, i64 120, !8, i64 124, !8, i64 128, !8, i64 132, !8, i64 136, !8, i64 140, !15, i64 144, !15, i64 152, !16, i64 160, !8, i64 216, !8, i64 220, !8, i64 224, !8, i64 228, !8, i64 232, !8, i64 236, !8, i64 240, !8, i64 244, !14, i64 248, !8, i64 256, !8, i64 260, !17, i64 264, !14, i64 272, !14, i64 280, !19, i64 288, !19, i64 296, !19, i64 304, !19, i64 312, !17, i64 320, !19, i64 328, !17, i64 336, !8, i64 344, !8, i64 348, !8, i64 352, !20, i64 360, !20, i64 368, !17, i64 376, !11, i64 384, !21, i64 392, !17, i64 400, !8, i64 408, !8, i64 412, !8, i64 416, !14, i64 424, !8, i64 432, !8, i64 436, !8, i64 440, !8, i64 444, !8, i64 448, !8, i64 452, !8, i64 456, !8, i64 460, !14, i64 464, !14, i64 472, !8, i64 480, !8, i64 484, !8, i64 488, !8, i64 492, !8, i64 496, !8, i64 500, !8, i64 504, !8, i64 508, !22, i64 512, !22, i64 520, !8, i64 528, !8, i64 532, !8, i64 536, !8, i64 540, !8, i64 544, !8, i64 548, !8, i64 552, !23, i64 560, !12, i64 568, !24, i64 576, !24, i64 584, !24, i64 592, !24, i64 600, !25, i64 608, !25, i64 616, !8, i64 624, !26, i64 632, !26, i64 640, !12, i64 648, !12, i64 656, !12, i64 664, !12, i64 672, !12, i64 680, !26, i64 688, !26, i64 696, !26, i64 704, !8, i64 712, !26, i64 720, !26, i64 728, !14, i64 736, !14, i64 744, !14, i64 752, !14, i64 760, !14, i64 768, !14, i64 776, !8, i64 784, !8, i64 788, !8, i64 792, !8, i64 796, !9, i64 800}
!7 = !{!"DdNode", !8, i64 0, !8, i64 4, !11, i64 8, !9, i64 16}
!8 = !{!"int", !9, i64 0}
!9 = !{!"omnipotent char", !10, i64 0}
!10 = !{!"Simple C/C++ TBAA"}
!11 = !{!"p1 _ZTS6DdNode", !12, i64 0}
!12 = !{!"any pointer", !9, i64 0}
!13 = !{!"p1 _ZTS7DdCache", !12, i64 0}
!14 = !{!"double", !9, i64 0}
!15 = !{!"p1 _ZTS10DdSubtable", !12, i64 0}
!16 = !{!"DdSubtable", !17, i64 0, !8, i64 8, !8, i64 12, !8, i64 16, !8, i64 20, !8, i64 24, !8, i64 28, !8, i64 32, !8, i64 36, !8, i64 40, !8, i64 44, !8, i64 48}
!17 = !{!"p2 _ZTS6DdNode", !18, i64 0}
!18 = !{!"any p2 pointer", !12, i64 0}
!19 = !{!"p1 int", !12, i64 0}
!20 = !{!"p1 long", !12, i64 0}
!21 = !{!"p1 omnipotent char", !12, i64 0}
!22 = !{!"p1 _ZTS8MtrNode_", !12, i64 0}
!23 = !{!"p1 _ZTS12DdLocalCache", !12, i64 0}
!24 = !{!"p1 _ZTS6DdHook", !12, i64 0}
!25 = !{!"p1 _ZTS8_IO_FILE", !12, i64 0}
!26 = !{!"long", !9, i64 0}
!27 = !{!7, !8, i64 0}
!28 = !{!9, !9, i64 0}
!29 = !{!6, !25, i64 616}
!30 = !{!6, !8, i64 624}
!31 = !{!6, !8, i64 432}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.mustprogress"}
!34 = !{!6, !12, i64 672}
!35 = !{!6, !12, i64 680}
!36 = !{!6, !19, i64 288}
!37 = !{!8, !8, i64 0}
!38 = distinct !{!38, !33}
!39 = !{!7, !8, i64 4}
!40 = !{!6, !14, i64 96}
!41 = !{!6, !12, i64 648}
!42 = !{!6, !12, i64 656}
!43 = !{!6, !26, i64 632}
!44 = !{!6, !26, i64 640}
!45 = !{!6, !17, i64 320}
!46 = !{!11, !11, i64 0}
!47 = !{!6, !8, i64 236}
!48 = !{!6, !8, i64 220}
!49 = !{!6, !8, i64 228}
!50 = !{!6, !8, i64 224}
!51 = !{!6, !8, i64 232}
!52 = distinct !{!52, !33}
!53 = distinct !{!53, !33}
!54 = distinct !{!54, !33}
!55 = !{!6, !8, i64 128}
!56 = distinct !{!56, !33}
