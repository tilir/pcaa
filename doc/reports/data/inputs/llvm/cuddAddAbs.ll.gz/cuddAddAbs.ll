; ModuleID = '/home/tilir/cudd/cudd/cuddAddAbs.c'
source_filename = "/home/tilir/cudd/cudd/cuddAddAbs.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@.str = private unnamed_addr constant [31 x i8] c"Error: Can only abstract cubes\00", align 1
@.str.1 = private unnamed_addr constant [32 x i8] c"Error:  Can only abstract cubes\00", align 1

; Function Attrs: nounwind uwtable
define dso_local ptr @Cudd_addExistAbstract(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = ptrtoint ptr %2 to i64
  %5 = and i64 %4, 1
  %6 = icmp eq i64 %5, 0
  br i1 %6, label %7, label %30

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %9 = load ptr, ptr %8, align 8, !tbaa !5
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 40
  br label %11

11:                                               ; preds = %24, %7
  %12 = phi ptr [ %2, %7 ], [ %26, %24 ]
  %13 = icmp eq ptr %12, %9
  br i1 %13, label %14, label %16

14:                                               ; preds = %11
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 432
  br label %34

16:                                               ; preds = %11
  %17 = load i32, ptr %12, align 8, !tbaa !27
  %18 = icmp eq i32 %17, 2147483647
  br i1 %18, label %30, label %19

19:                                               ; preds = %16
  %20 = getelementptr inbounds nuw i8, ptr %12, i64 24
  %21 = load ptr, ptr %20, align 8, !tbaa !28
  %22 = load ptr, ptr %10, align 8, !tbaa !29
  %23 = icmp eq ptr %21, %22
  br i1 %23, label %24, label %30

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %12, i64 16
  %26 = load ptr, ptr %25, align 8, !tbaa !28
  %27 = ptrtoint ptr %26 to i64
  %28 = and i64 %27, 1
  %29 = icmp eq i64 %28, 0
  br i1 %29, label %11, label %30

30:                                               ; preds = %19, %16, %24, %3
  %31 = getelementptr inbounds nuw i8, ptr %0, i64 616
  %32 = load ptr, ptr %31, align 8, !tbaa !30
  %33 = tail call i64 @fwrite(ptr nonnull @.str, i64 30, i64 1, ptr %32)
  br label %49

34:                                               ; preds = %14, %34
  store i32 0, ptr %15, align 8, !tbaa !31
  %35 = tail call ptr @cuddAddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %1, ptr noundef %2)
  %36 = load i32, ptr %15, align 8, !tbaa !31
  %37 = icmp eq i32 %36, 1
  br i1 %37, label %34, label %38, !llvm.loop !32

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 624
  %40 = load i32, ptr %39, align 8, !tbaa !34
  %41 = icmp eq i32 %40, 4
  br i1 %41, label %42, label %49

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 672
  %44 = load ptr, ptr %43, align 8, !tbaa !35
  %45 = icmp eq ptr %44, null
  br i1 %45, label %49, label %46

46:                                               ; preds = %42
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 680
  %48 = load ptr, ptr %47, align 8, !tbaa !36
  tail call void %44(ptr noundef nonnull %0, ptr noundef %48) #3
  br label %49

49:                                               ; preds = %38, %42, %46, %30
  %50 = phi ptr [ null, %30 ], [ %35, %46 ], [ %35, %42 ], [ %35, %38 ]
  ret ptr %50
}

; Function Attrs: nounwind uwtable
define dso_local ptr @cuddAddExistAbstractRecur(ptr noundef %0, ptr noundef %1, ptr noundef %2) local_unnamed_addr #0 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %5 = load ptr, ptr %4, align 8, !tbaa !29
  %6 = icmp eq ptr %1, %5
  br i1 %6, label %154, label %7

7:                                                ; preds = %3
  %8 = load i32, ptr %2, align 8, !tbaa !27
  %9 = icmp eq i32 %8, 2147483647
  br i1 %9, label %154, label %10

10:                                               ; preds = %7
  %11 = load i32, ptr %1, align 8, !tbaa !27
  %12 = icmp eq i32 %11, 2147483647
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 288
  %14 = load ptr, ptr %13, align 8, !tbaa !37
  br i1 %12, label %19, label %15

15:                                               ; preds = %10
  %16 = zext i32 %11 to i64
  %17 = getelementptr inbounds nuw i32, ptr %14, i64 %16
  %18 = load i32, ptr %17, align 4, !tbaa !38
  br label %19

19:                                               ; preds = %10, %15
  %20 = phi i32 [ %18, %15 ], [ 2147483647, %10 ]
  %21 = zext i32 %8 to i64
  %22 = getelementptr inbounds nuw i32, ptr %14, i64 %21
  %23 = load i32, ptr %22, align 4, !tbaa !38
  %24 = icmp sgt i32 %20, %23
  br i1 %24, label %25, label %49

25:                                               ; preds = %19
  %26 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %27 = load ptr, ptr %26, align 8, !tbaa !28
  %28 = tail call ptr @cuddAddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef nonnull %1, ptr noundef %27)
  %29 = icmp eq ptr %28, null
  br i1 %29, label %154, label %30

30:                                               ; preds = %25
  %31 = ptrtoint ptr %28 to i64
  %32 = and i64 %31, -2
  %33 = inttoptr i64 %32 to ptr
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 4
  %35 = load i32, ptr %34, align 4, !tbaa !39
  %36 = add i32 %35, 1
  store i32 %36, ptr %34, align 4, !tbaa !39
  %37 = tail call ptr @cuddAddApplyRecur(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addPlus, ptr noundef nonnull %28, ptr noundef nonnull %28) #3
  %38 = icmp eq ptr %37, null
  br i1 %38, label %39, label %40

39:                                               ; preds = %30
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %28) #3
  br label %154

40:                                               ; preds = %30
  %41 = ptrtoint ptr %37 to i64
  %42 = and i64 %41, -2
  %43 = inttoptr i64 %42 to ptr
  %44 = getelementptr inbounds nuw i8, ptr %43, i64 4
  %45 = load i32, ptr %44, align 4, !tbaa !39
  %46 = add i32 %45, 1
  store i32 %46, ptr %44, align 4, !tbaa !39
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %28) #3
  %47 = load i32, ptr %44, align 4, !tbaa !39
  %48 = add i32 %47, -1
  store i32 %48, ptr %44, align 4, !tbaa !39
  br label %154

49:                                               ; preds = %19
  %50 = tail call ptr @cuddCacheLookup2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addExistAbstract, ptr noundef nonnull %1, ptr noundef nonnull %2) #3
  %51 = icmp eq ptr %50, null
  br i1 %51, label %52, label %154

52:                                               ; preds = %49
  %53 = getelementptr inbounds nuw i8, ptr %0, i64 96
  %54 = load double, ptr %53, align 8, !tbaa !40
  %55 = fptosi double %54 to i64
  %56 = and i64 %55, 2047
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %58, label %79

58:                                               ; preds = %52
  %59 = getelementptr inbounds nuw i8, ptr %0, i64 648
  %60 = load ptr, ptr %59, align 8, !tbaa !41
  %61 = icmp eq ptr %60, null
  br i1 %61, label %69, label %62

62:                                               ; preds = %58
  %63 = getelementptr inbounds nuw i8, ptr %0, i64 656
  %64 = load ptr, ptr %63, align 8, !tbaa !42
  %65 = tail call i32 %60(ptr noundef %64) #3
  %66 = icmp eq i32 %65, 0
  br i1 %66, label %69, label %67

67:                                               ; preds = %62
  %68 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 5, ptr %68, align 8, !tbaa !34
  br label %154

69:                                               ; preds = %62, %58
  %70 = tail call i64 @util_cpu_time() #3
  %71 = getelementptr inbounds nuw i8, ptr %0, i64 632
  %72 = load i64, ptr %71, align 8, !tbaa !43
  %73 = sub i64 %70, %72
  %74 = getelementptr inbounds nuw i8, ptr %0, i64 640
  %75 = load i64, ptr %74, align 8, !tbaa !44
  %76 = icmp ugt i64 %73, %75
  br i1 %76, label %77, label %79

77:                                               ; preds = %69
  %78 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 4, ptr %78, align 8, !tbaa !34
  br label %154

79:                                               ; preds = %69, %52
  %80 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %81 = load ptr, ptr %80, align 8, !tbaa !28
  %82 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %83 = load ptr, ptr %82, align 8, !tbaa !28
  %84 = load i32, ptr %1, align 8, !tbaa !27
  %85 = load i32, ptr %2, align 8, !tbaa !27
  %86 = icmp eq i32 %84, %85
  br i1 %86, label %87, label %122

87:                                               ; preds = %79
  %88 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %89 = load ptr, ptr %88, align 8, !tbaa !28
  %90 = tail call ptr @cuddAddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %81, ptr noundef %89)
  %91 = icmp eq ptr %90, null
  br i1 %91, label %154, label %92

92:                                               ; preds = %87
  %93 = ptrtoint ptr %90 to i64
  %94 = and i64 %93, -2
  %95 = inttoptr i64 %94 to ptr
  %96 = getelementptr inbounds nuw i8, ptr %95, i64 4
  %97 = load i32, ptr %96, align 4, !tbaa !39
  %98 = add i32 %97, 1
  store i32 %98, ptr %96, align 4, !tbaa !39
  %99 = load ptr, ptr %88, align 8, !tbaa !28
  %100 = tail call ptr @cuddAddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %83, ptr noundef %99)
  %101 = icmp eq ptr %100, null
  br i1 %101, label %102, label %103

102:                                              ; preds = %92
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %90) #3
  br label %154

103:                                              ; preds = %92
  %104 = ptrtoint ptr %100 to i64
  %105 = and i64 %104, -2
  %106 = inttoptr i64 %105 to ptr
  %107 = getelementptr inbounds nuw i8, ptr %106, i64 4
  %108 = load i32, ptr %107, align 4, !tbaa !39
  %109 = add i32 %108, 1
  store i32 %109, ptr %107, align 4, !tbaa !39
  %110 = tail call ptr @cuddAddApplyRecur(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addPlus, ptr noundef nonnull %90, ptr noundef nonnull %100) #3
  %111 = icmp eq ptr %110, null
  br i1 %111, label %112, label %113

112:                                              ; preds = %103
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %90) #3
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %100) #3
  br label %154

113:                                              ; preds = %103
  %114 = ptrtoint ptr %110 to i64
  %115 = and i64 %114, -2
  %116 = inttoptr i64 %115 to ptr
  %117 = getelementptr inbounds nuw i8, ptr %116, i64 4
  %118 = load i32, ptr %117, align 4, !tbaa !39
  %119 = add i32 %118, 1
  store i32 %119, ptr %117, align 4, !tbaa !39
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %90) #3
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %100) #3
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addExistAbstract, ptr noundef nonnull %1, ptr noundef nonnull %2, ptr noundef nonnull %110) #3
  %120 = load i32, ptr %117, align 4, !tbaa !39
  %121 = add i32 %120, -1
  store i32 %121, ptr %117, align 4, !tbaa !39
  br label %154

122:                                              ; preds = %79
  %123 = tail call ptr @cuddAddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %81, ptr noundef nonnull %2)
  %124 = icmp eq ptr %123, null
  br i1 %124, label %154, label %125

125:                                              ; preds = %122
  %126 = ptrtoint ptr %123 to i64
  %127 = and i64 %126, -2
  %128 = inttoptr i64 %127 to ptr
  %129 = getelementptr inbounds nuw i8, ptr %128, i64 4
  %130 = load i32, ptr %129, align 4, !tbaa !39
  %131 = add i32 %130, 1
  store i32 %131, ptr %129, align 4, !tbaa !39
  %132 = tail call ptr @cuddAddExistAbstractRecur(ptr noundef nonnull %0, ptr noundef %83, ptr noundef nonnull %2)
  %133 = icmp eq ptr %132, null
  br i1 %133, label %134, label %135

134:                                              ; preds = %125
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %123) #3
  br label %154

135:                                              ; preds = %125
  %136 = ptrtoint ptr %132 to i64
  %137 = and i64 %136, -2
  %138 = inttoptr i64 %137 to ptr
  %139 = getelementptr inbounds nuw i8, ptr %138, i64 4
  %140 = load i32, ptr %139, align 4, !tbaa !39
  %141 = add i32 %140, 1
  store i32 %141, ptr %139, align 4, !tbaa !39
  %142 = icmp eq ptr %123, %132
  br i1 %142, label %148, label %143

143:                                              ; preds = %135
  %144 = load i32, ptr %1, align 8, !tbaa !27
  %145 = tail call ptr @cuddUniqueInter(ptr noundef nonnull %0, i32 noundef %144, ptr noundef nonnull %123, ptr noundef nonnull %132) #3
  %146 = icmp eq ptr %145, null
  br i1 %146, label %147, label %148

147:                                              ; preds = %143
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %123) #3
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %132) #3
  br label %154

148:                                              ; preds = %135, %143
  %149 = phi ptr [ %145, %143 ], [ %123, %135 ]
  %150 = load i32, ptr %129, align 4, !tbaa !39
  %151 = add i32 %150, -1
  store i32 %151, ptr %129, align 4, !tbaa !39
  %152 = load i32, ptr %139, align 4, !tbaa !39
  %153 = add i32 %152, -1
  store i32 %153, ptr %139, align 4, !tbaa !39
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addExistAbstract, ptr noundef nonnull %1, ptr noundef nonnull %2, ptr noundef nonnull %149) #3
  br label %154

154:                                              ; preds = %122, %87, %49, %25, %3, %7, %148, %147, %134, %113, %112, %102, %77, %67, %40, %39
  %155 = phi ptr [ null, %39 ], [ %37, %40 ], [ null, %67 ], [ null, %77 ], [ null, %102 ], [ null, %112 ], [ %110, %113 ], [ null, %134 ], [ null, %147 ], [ %149, %148 ], [ %1, %7 ], [ %1, %3 ], [ null, %25 ], [ %50, %49 ], [ null, %87 ], [ null, %122 ]
  ret ptr %155
}

; Function Attrs: nounwind uwtable
define dso_local ptr @Cudd_addUnivAbstract(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = ptrtoint ptr %2 to i64
  %5 = and i64 %4, 1
  %6 = icmp eq i64 %5, 0
  br i1 %6, label %7, label %30

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %9 = load ptr, ptr %8, align 8, !tbaa !5
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 40
  br label %11

11:                                               ; preds = %24, %7
  %12 = phi ptr [ %2, %7 ], [ %26, %24 ]
  %13 = icmp eq ptr %12, %9
  br i1 %13, label %14, label %16

14:                                               ; preds = %11
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 432
  br label %34

16:                                               ; preds = %11
  %17 = load i32, ptr %12, align 8, !tbaa !27
  %18 = icmp eq i32 %17, 2147483647
  br i1 %18, label %30, label %19

19:                                               ; preds = %16
  %20 = getelementptr inbounds nuw i8, ptr %12, i64 24
  %21 = load ptr, ptr %20, align 8, !tbaa !28
  %22 = load ptr, ptr %10, align 8, !tbaa !29
  %23 = icmp eq ptr %21, %22
  br i1 %23, label %24, label %30

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %12, i64 16
  %26 = load ptr, ptr %25, align 8, !tbaa !28
  %27 = ptrtoint ptr %26 to i64
  %28 = and i64 %27, 1
  %29 = icmp eq i64 %28, 0
  br i1 %29, label %11, label %30

30:                                               ; preds = %19, %16, %24, %3
  %31 = getelementptr inbounds nuw i8, ptr %0, i64 616
  %32 = load ptr, ptr %31, align 8, !tbaa !30
  %33 = tail call i64 @fwrite(ptr nonnull @.str.1, i64 31, i64 1, ptr %32)
  br label %49

34:                                               ; preds = %14, %34
  store i32 0, ptr %15, align 8, !tbaa !31
  %35 = tail call ptr @cuddAddUnivAbstractRecur(ptr noundef nonnull %0, ptr noundef %1, ptr noundef %2)
  %36 = load i32, ptr %15, align 8, !tbaa !31
  %37 = icmp eq i32 %36, 1
  br i1 %37, label %34, label %38, !llvm.loop !45

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 624
  %40 = load i32, ptr %39, align 8, !tbaa !34
  %41 = icmp eq i32 %40, 4
  br i1 %41, label %42, label %49

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 672
  %44 = load ptr, ptr %43, align 8, !tbaa !35
  %45 = icmp eq ptr %44, null
  br i1 %45, label %49, label %46

46:                                               ; preds = %42
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 680
  %48 = load ptr, ptr %47, align 8, !tbaa !36
  tail call void %44(ptr noundef nonnull %0, ptr noundef %48) #3
  br label %49

49:                                               ; preds = %38, %42, %46, %30
  %50 = phi ptr [ null, %30 ], [ %35, %46 ], [ %35, %42 ], [ %35, %38 ]
  ret ptr %50
}

; Function Attrs: nounwind uwtable
define dso_local ptr @cuddAddUnivAbstractRecur(ptr noundef %0, ptr noundef %1, ptr noundef %2) local_unnamed_addr #0 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %5 = load ptr, ptr %4, align 8, !tbaa !5
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %7 = load ptr, ptr %6, align 8, !tbaa !29
  %8 = icmp eq ptr %1, %7
  %9 = icmp eq ptr %1, %5
  %10 = icmp eq ptr %2, %5
  %11 = or i1 %9, %10
  %12 = select i1 %8, i1 true, i1 %11
  br i1 %12, label %164, label %13

13:                                               ; preds = %3
  %14 = load i32, ptr %1, align 8, !tbaa !27
  %15 = icmp eq i32 %14, 2147483647
  br i1 %15, label %22, label %16

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 288
  %18 = load ptr, ptr %17, align 8, !tbaa !37
  %19 = zext i32 %14 to i64
  %20 = getelementptr inbounds nuw i32, ptr %18, i64 %19
  %21 = load i32, ptr %20, align 4, !tbaa !38
  br label %22

22:                                               ; preds = %13, %16
  %23 = phi i32 [ %21, %16 ], [ 2147483647, %13 ]
  %24 = load i32, ptr %2, align 8, !tbaa !27
  %25 = icmp eq i32 %24, 2147483647
  br i1 %25, label %32, label %26

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw i8, ptr %0, i64 288
  %28 = load ptr, ptr %27, align 8, !tbaa !37
  %29 = zext i32 %24 to i64
  %30 = getelementptr inbounds nuw i32, ptr %28, i64 %29
  %31 = load i32, ptr %30, align 4, !tbaa !38
  br label %32

32:                                               ; preds = %22, %26
  %33 = phi i32 [ %31, %26 ], [ 2147483647, %22 ]
  %34 = icmp sgt i32 %23, %33
  br i1 %34, label %35, label %59

35:                                               ; preds = %32
  %36 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %37 = load ptr, ptr %36, align 8, !tbaa !28
  %38 = tail call ptr @cuddAddUnivAbstractRecur(ptr noundef nonnull %0, ptr noundef nonnull %1, ptr noundef %37)
  %39 = icmp eq ptr %38, null
  br i1 %39, label %164, label %40

40:                                               ; preds = %35
  %41 = ptrtoint ptr %38 to i64
  %42 = and i64 %41, -2
  %43 = inttoptr i64 %42 to ptr
  %44 = getelementptr inbounds nuw i8, ptr %43, i64 4
  %45 = load i32, ptr %44, align 4, !tbaa !39
  %46 = add i32 %45, 1
  store i32 %46, ptr %44, align 4, !tbaa !39
  %47 = tail call ptr @cuddAddApplyRecur(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addTimes, ptr noundef nonnull %38, ptr noundef nonnull %38) #3
  %48 = icmp eq ptr %47, null
  br i1 %48, label %49, label %50

49:                                               ; preds = %40
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %38) #3
  br label %164

50:                                               ; preds = %40
  %51 = ptrtoint ptr %47 to i64
  %52 = and i64 %51, -2
  %53 = inttoptr i64 %52 to ptr
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 4
  %55 = load i32, ptr %54, align 4, !tbaa !39
  %56 = add i32 %55, 1
  store i32 %56, ptr %54, align 4, !tbaa !39
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %38) #3
  %57 = load i32, ptr %54, align 4, !tbaa !39
  %58 = add i32 %57, -1
  store i32 %58, ptr %54, align 4, !tbaa !39
  br label %164

59:                                               ; preds = %32
  %60 = tail call ptr @cuddCacheLookup2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addUnivAbstract, ptr noundef nonnull %1, ptr noundef nonnull %2) #3
  %61 = icmp eq ptr %60, null
  br i1 %61, label %62, label %164

62:                                               ; preds = %59
  %63 = getelementptr inbounds nuw i8, ptr %0, i64 96
  %64 = load double, ptr %63, align 8, !tbaa !40
  %65 = fptosi double %64 to i64
  %66 = and i64 %65, 2047
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %68, label %89

68:                                               ; preds = %62
  %69 = getelementptr inbounds nuw i8, ptr %0, i64 648
  %70 = load ptr, ptr %69, align 8, !tbaa !41
  %71 = icmp eq ptr %70, null
  br i1 %71, label %79, label %72

72:                                               ; preds = %68
  %73 = getelementptr inbounds nuw i8, ptr %0, i64 656
  %74 = load ptr, ptr %73, align 8, !tbaa !42
  %75 = tail call i32 %70(ptr noundef %74) #3
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %79, label %77

77:                                               ; preds = %72
  %78 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 5, ptr %78, align 8, !tbaa !34
  br label %164

79:                                               ; preds = %72, %68
  %80 = tail call i64 @util_cpu_time() #3
  %81 = getelementptr inbounds nuw i8, ptr %0, i64 632
  %82 = load i64, ptr %81, align 8, !tbaa !43
  %83 = sub i64 %80, %82
  %84 = getelementptr inbounds nuw i8, ptr %0, i64 640
  %85 = load i64, ptr %84, align 8, !tbaa !44
  %86 = icmp ugt i64 %83, %85
  br i1 %86, label %87, label %89

87:                                               ; preds = %79
  %88 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 4, ptr %88, align 8, !tbaa !34
  br label %164

89:                                               ; preds = %79, %62
  %90 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %91 = load ptr, ptr %90, align 8, !tbaa !28
  %92 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %93 = load ptr, ptr %92, align 8, !tbaa !28
  %94 = load i32, ptr %1, align 8, !tbaa !27
  %95 = load i32, ptr %2, align 8, !tbaa !27
  %96 = icmp eq i32 %94, %95
  br i1 %96, label %97, label %132

97:                                               ; preds = %89
  %98 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %99 = load ptr, ptr %98, align 8, !tbaa !28
  %100 = tail call ptr @cuddAddUnivAbstractRecur(ptr noundef nonnull %0, ptr noundef %91, ptr noundef %99)
  %101 = icmp eq ptr %100, null
  br i1 %101, label %164, label %102

102:                                              ; preds = %97
  %103 = ptrtoint ptr %100 to i64
  %104 = and i64 %103, -2
  %105 = inttoptr i64 %104 to ptr
  %106 = getelementptr inbounds nuw i8, ptr %105, i64 4
  %107 = load i32, ptr %106, align 4, !tbaa !39
  %108 = add i32 %107, 1
  store i32 %108, ptr %106, align 4, !tbaa !39
  %109 = load ptr, ptr %98, align 8, !tbaa !28
  %110 = tail call ptr @cuddAddUnivAbstractRecur(ptr noundef nonnull %0, ptr noundef %93, ptr noundef %109)
  %111 = icmp eq ptr %110, null
  br i1 %111, label %112, label %113

112:                                              ; preds = %102
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %100) #3
  br label %164

113:                                              ; preds = %102
  %114 = ptrtoint ptr %110 to i64
  %115 = and i64 %114, -2
  %116 = inttoptr i64 %115 to ptr
  %117 = getelementptr inbounds nuw i8, ptr %116, i64 4
  %118 = load i32, ptr %117, align 4, !tbaa !39
  %119 = add i32 %118, 1
  store i32 %119, ptr %117, align 4, !tbaa !39
  %120 = tail call ptr @cuddAddApplyRecur(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addTimes, ptr noundef nonnull %100, ptr noundef nonnull %110) #3
  %121 = icmp eq ptr %120, null
  br i1 %121, label %122, label %123

122:                                              ; preds = %113
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %100) #3
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %110) #3
  br label %164

123:                                              ; preds = %113
  %124 = ptrtoint ptr %120 to i64
  %125 = and i64 %124, -2
  %126 = inttoptr i64 %125 to ptr
  %127 = getelementptr inbounds nuw i8, ptr %126, i64 4
  %128 = load i32, ptr %127, align 4, !tbaa !39
  %129 = add i32 %128, 1
  store i32 %129, ptr %127, align 4, !tbaa !39
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %100) #3
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %110) #3
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addUnivAbstract, ptr noundef nonnull %1, ptr noundef nonnull %2, ptr noundef nonnull %120) #3
  %130 = load i32, ptr %127, align 4, !tbaa !39
  %131 = add i32 %130, -1
  store i32 %131, ptr %127, align 4, !tbaa !39
  br label %164

132:                                              ; preds = %89
  %133 = tail call ptr @cuddAddUnivAbstractRecur(ptr noundef nonnull %0, ptr noundef %91, ptr noundef nonnull %2)
  %134 = icmp eq ptr %133, null
  br i1 %134, label %164, label %135

135:                                              ; preds = %132
  %136 = ptrtoint ptr %133 to i64
  %137 = and i64 %136, -2
  %138 = inttoptr i64 %137 to ptr
  %139 = getelementptr inbounds nuw i8, ptr %138, i64 4
  %140 = load i32, ptr %139, align 4, !tbaa !39
  %141 = add i32 %140, 1
  store i32 %141, ptr %139, align 4, !tbaa !39
  %142 = tail call ptr @cuddAddUnivAbstractRecur(ptr noundef nonnull %0, ptr noundef %93, ptr noundef nonnull %2)
  %143 = icmp eq ptr %142, null
  br i1 %143, label %144, label %145

144:                                              ; preds = %135
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %133) #3
  br label %164

145:                                              ; preds = %135
  %146 = ptrtoint ptr %142 to i64
  %147 = and i64 %146, -2
  %148 = inttoptr i64 %147 to ptr
  %149 = getelementptr inbounds nuw i8, ptr %148, i64 4
  %150 = load i32, ptr %149, align 4, !tbaa !39
  %151 = add i32 %150, 1
  store i32 %151, ptr %149, align 4, !tbaa !39
  %152 = icmp eq ptr %133, %142
  br i1 %152, label %158, label %153

153:                                              ; preds = %145
  %154 = load i32, ptr %1, align 8, !tbaa !27
  %155 = tail call ptr @cuddUniqueInter(ptr noundef nonnull %0, i32 noundef %154, ptr noundef nonnull %133, ptr noundef nonnull %142) #3
  %156 = icmp eq ptr %155, null
  br i1 %156, label %157, label %158

157:                                              ; preds = %153
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %133) #3
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %142) #3
  br label %164

158:                                              ; preds = %145, %153
  %159 = phi ptr [ %155, %153 ], [ %133, %145 ]
  %160 = load i32, ptr %139, align 4, !tbaa !39
  %161 = add i32 %160, -1
  store i32 %161, ptr %139, align 4, !tbaa !39
  %162 = load i32, ptr %149, align 4, !tbaa !39
  %163 = add i32 %162, -1
  store i32 %163, ptr %149, align 4, !tbaa !39
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addUnivAbstract, ptr noundef nonnull %1, ptr noundef nonnull %2, ptr noundef nonnull %159) #3
  br label %164

164:                                              ; preds = %132, %97, %59, %35, %3, %158, %157, %144, %123, %122, %112, %87, %77, %50, %49
  %165 = phi ptr [ null, %49 ], [ %47, %50 ], [ null, %77 ], [ null, %87 ], [ null, %112 ], [ null, %122 ], [ %120, %123 ], [ null, %144 ], [ null, %157 ], [ %159, %158 ], [ %1, %3 ], [ null, %35 ], [ %60, %59 ], [ null, %97 ], [ null, %132 ]
  ret ptr %165
}

; Function Attrs: nounwind uwtable
define dso_local ptr @Cudd_addOrAbstract(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = ptrtoint ptr %2 to i64
  %5 = and i64 %4, 1
  %6 = icmp eq i64 %5, 0
  br i1 %6, label %7, label %30

7:                                                ; preds = %3
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %9 = load ptr, ptr %8, align 8, !tbaa !5
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 40
  br label %11

11:                                               ; preds = %24, %7
  %12 = phi ptr [ %2, %7 ], [ %26, %24 ]
  %13 = icmp eq ptr %12, %9
  br i1 %13, label %14, label %16

14:                                               ; preds = %11
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 432
  br label %34

16:                                               ; preds = %11
  %17 = load i32, ptr %12, align 8, !tbaa !27
  %18 = icmp eq i32 %17, 2147483647
  br i1 %18, label %30, label %19

19:                                               ; preds = %16
  %20 = getelementptr inbounds nuw i8, ptr %12, i64 24
  %21 = load ptr, ptr %20, align 8, !tbaa !28
  %22 = load ptr, ptr %10, align 8, !tbaa !29
  %23 = icmp eq ptr %21, %22
  br i1 %23, label %24, label %30

24:                                               ; preds = %19
  %25 = getelementptr inbounds nuw i8, ptr %12, i64 16
  %26 = load ptr, ptr %25, align 8, !tbaa !28
  %27 = ptrtoint ptr %26 to i64
  %28 = and i64 %27, 1
  %29 = icmp eq i64 %28, 0
  br i1 %29, label %11, label %30

30:                                               ; preds = %19, %16, %24, %3
  %31 = getelementptr inbounds nuw i8, ptr %0, i64 616
  %32 = load ptr, ptr %31, align 8, !tbaa !30
  %33 = tail call i64 @fwrite(ptr nonnull @.str, i64 30, i64 1, ptr %32)
  br label %49

34:                                               ; preds = %14, %34
  store i32 0, ptr %15, align 8, !tbaa !31
  %35 = tail call ptr @cuddAddOrAbstractRecur(ptr noundef nonnull %0, ptr noundef %1, ptr noundef %2)
  %36 = load i32, ptr %15, align 8, !tbaa !31
  %37 = icmp eq i32 %36, 1
  br i1 %37, label %34, label %38, !llvm.loop !46

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 624
  %40 = load i32, ptr %39, align 8, !tbaa !34
  %41 = icmp eq i32 %40, 4
  br i1 %41, label %42, label %49

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 672
  %44 = load ptr, ptr %43, align 8, !tbaa !35
  %45 = icmp eq ptr %44, null
  br i1 %45, label %49, label %46

46:                                               ; preds = %42
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 680
  %48 = load ptr, ptr %47, align 8, !tbaa !36
  tail call void %44(ptr noundef nonnull %0, ptr noundef %48) #3
  br label %49

49:                                               ; preds = %38, %42, %46, %30
  %50 = phi ptr [ null, %30 ], [ %35, %46 ], [ %35, %42 ], [ %35, %38 ]
  ret ptr %50
}

; Function Attrs: nounwind uwtable
define dso_local ptr @cuddAddOrAbstractRecur(ptr noundef %0, ptr noundef %1, ptr noundef %2) local_unnamed_addr #0 {
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %5 = load ptr, ptr %4, align 8, !tbaa !5
  %6 = load i32, ptr %1, align 8, !tbaa !27
  %7 = icmp eq i32 %6, 2147483647
  %8 = icmp eq ptr %2, %5
  %9 = select i1 %7, i1 true, i1 %8
  br i1 %9, label %140, label %10

10:                                               ; preds = %3
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 288
  %12 = zext i32 %6 to i64
  br label %13

13:                                               ; preds = %10, %25
  %14 = phi ptr [ %2, %10 ], [ %27, %25 ]
  %15 = load i32, ptr %14, align 8, !tbaa !27
  %16 = icmp eq i32 %15, 2147483647
  br i1 %16, label %29, label %17

17:                                               ; preds = %13
  %18 = load ptr, ptr %11, align 8, !tbaa !37
  %19 = getelementptr inbounds nuw i32, ptr %18, i64 %12
  %20 = load i32, ptr %19, align 4, !tbaa !38
  %21 = zext i32 %15 to i64
  %22 = getelementptr inbounds nuw i32, ptr %18, i64 %21
  %23 = load i32, ptr %22, align 4, !tbaa !38
  %24 = icmp sgt i32 %20, %23
  br i1 %24, label %25, label %29

25:                                               ; preds = %17
  %26 = getelementptr inbounds nuw i8, ptr %14, i64 16
  %27 = load ptr, ptr %26, align 8, !tbaa !28
  %28 = icmp eq ptr %27, %5
  br i1 %28, label %140, label %13

29:                                               ; preds = %13, %17
  %30 = tail call ptr @cuddCacheLookup2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addOrAbstract, ptr noundef nonnull %1, ptr noundef nonnull %14) #3
  %31 = icmp eq ptr %30, null
  br i1 %31, label %32, label %140

32:                                               ; preds = %29
  %33 = getelementptr inbounds nuw i8, ptr %0, i64 96
  %34 = load double, ptr %33, align 8, !tbaa !40
  %35 = fptosi double %34 to i64
  %36 = and i64 %35, 2047
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %38, label %59

38:                                               ; preds = %32
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 648
  %40 = load ptr, ptr %39, align 8, !tbaa !41
  %41 = icmp eq ptr %40, null
  br i1 %41, label %49, label %42

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw i8, ptr %0, i64 656
  %44 = load ptr, ptr %43, align 8, !tbaa !42
  %45 = tail call i32 %40(ptr noundef %44) #3
  %46 = icmp eq i32 %45, 0
  br i1 %46, label %49, label %47

47:                                               ; preds = %42
  %48 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 5, ptr %48, align 8, !tbaa !34
  br label %140

49:                                               ; preds = %42, %38
  %50 = tail call i64 @util_cpu_time() #3
  %51 = getelementptr inbounds nuw i8, ptr %0, i64 632
  %52 = load i64, ptr %51, align 8, !tbaa !43
  %53 = sub i64 %50, %52
  %54 = getelementptr inbounds nuw i8, ptr %0, i64 640
  %55 = load i64, ptr %54, align 8, !tbaa !44
  %56 = icmp ugt i64 %53, %55
  br i1 %56, label %57, label %59

57:                                               ; preds = %49
  %58 = getelementptr inbounds nuw i8, ptr %0, i64 624
  store i32 4, ptr %58, align 8, !tbaa !34
  br label %140

59:                                               ; preds = %49, %32
  %60 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %61 = load ptr, ptr %60, align 8, !tbaa !28
  %62 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %63 = load ptr, ptr %62, align 8, !tbaa !28
  %64 = load i32, ptr %1, align 8, !tbaa !27
  %65 = load i32, ptr %14, align 8, !tbaa !27
  %66 = icmp eq i32 %64, %65
  br i1 %66, label %67, label %108

67:                                               ; preds = %59
  %68 = getelementptr inbounds nuw i8, ptr %14, i64 16
  %69 = load ptr, ptr %68, align 8, !tbaa !28
  %70 = tail call ptr @cuddAddOrAbstractRecur(ptr noundef nonnull %0, ptr noundef %61, ptr noundef %69)
  %71 = icmp eq ptr %70, null
  br i1 %71, label %140, label %72

72:                                               ; preds = %67
  %73 = ptrtoint ptr %70 to i64
  %74 = and i64 %73, -2
  %75 = inttoptr i64 %74 to ptr
  %76 = getelementptr inbounds nuw i8, ptr %75, i64 4
  %77 = load i32, ptr %76, align 4, !tbaa !39
  %78 = add i32 %77, 1
  store i32 %78, ptr %76, align 4, !tbaa !39
  %79 = icmp eq ptr %70, %5
  br i1 %79, label %102, label %80

80:                                               ; preds = %72
  %81 = load ptr, ptr %68, align 8, !tbaa !28
  %82 = tail call ptr @cuddAddOrAbstractRecur(ptr noundef nonnull %0, ptr noundef %63, ptr noundef %81)
  %83 = icmp eq ptr %82, null
  br i1 %83, label %84, label %85

84:                                               ; preds = %80
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %70) #3
  br label %140

85:                                               ; preds = %80
  %86 = ptrtoint ptr %82 to i64
  %87 = and i64 %86, -2
  %88 = inttoptr i64 %87 to ptr
  %89 = getelementptr inbounds nuw i8, ptr %88, i64 4
  %90 = load i32, ptr %89, align 4, !tbaa !39
  %91 = add i32 %90, 1
  store i32 %91, ptr %89, align 4, !tbaa !39
  %92 = tail call ptr @cuddAddApplyRecur(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addOr, ptr noundef nonnull %70, ptr noundef nonnull %82) #3
  %93 = icmp eq ptr %92, null
  br i1 %93, label %94, label %95

94:                                               ; preds = %85
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %70) #3
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %82) #3
  br label %140

95:                                               ; preds = %85
  %96 = ptrtoint ptr %92 to i64
  %97 = and i64 %96, -2
  %98 = inttoptr i64 %97 to ptr
  %99 = getelementptr inbounds nuw i8, ptr %98, i64 4
  %100 = load i32, ptr %99, align 4, !tbaa !39
  %101 = add i32 %100, 1
  store i32 %101, ptr %99, align 4, !tbaa !39
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %70) #3
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %82) #3
  br label %102

102:                                              ; preds = %72, %95
  %103 = phi ptr [ %75, %72 ], [ %98, %95 ]
  %104 = phi ptr [ %70, %72 ], [ %92, %95 ]
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addOrAbstract, ptr noundef nonnull %1, ptr noundef nonnull %14, ptr noundef nonnull %104) #3
  %105 = getelementptr inbounds nuw i8, ptr %103, i64 4
  %106 = load i32, ptr %105, align 4, !tbaa !39
  %107 = add i32 %106, -1
  store i32 %107, ptr %105, align 4, !tbaa !39
  br label %140

108:                                              ; preds = %59
  %109 = tail call ptr @cuddAddOrAbstractRecur(ptr noundef nonnull %0, ptr noundef %61, ptr noundef nonnull %14)
  %110 = icmp eq ptr %109, null
  br i1 %110, label %140, label %111

111:                                              ; preds = %108
  %112 = ptrtoint ptr %109 to i64
  %113 = and i64 %112, -2
  %114 = inttoptr i64 %113 to ptr
  %115 = getelementptr inbounds nuw i8, ptr %114, i64 4
  %116 = load i32, ptr %115, align 4, !tbaa !39
  %117 = add i32 %116, 1
  store i32 %117, ptr %115, align 4, !tbaa !39
  %118 = tail call ptr @cuddAddOrAbstractRecur(ptr noundef nonnull %0, ptr noundef %63, ptr noundef nonnull %14)
  %119 = icmp eq ptr %118, null
  br i1 %119, label %120, label %121

120:                                              ; preds = %111
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %109) #3
  br label %140

121:                                              ; preds = %111
  %122 = ptrtoint ptr %118 to i64
  %123 = and i64 %122, -2
  %124 = inttoptr i64 %123 to ptr
  %125 = getelementptr inbounds nuw i8, ptr %124, i64 4
  %126 = load i32, ptr %125, align 4, !tbaa !39
  %127 = add i32 %126, 1
  store i32 %127, ptr %125, align 4, !tbaa !39
  %128 = icmp eq ptr %109, %118
  br i1 %128, label %134, label %129

129:                                              ; preds = %121
  %130 = load i32, ptr %1, align 8, !tbaa !27
  %131 = tail call ptr @cuddUniqueInter(ptr noundef nonnull %0, i32 noundef %130, ptr noundef nonnull %109, ptr noundef nonnull %118) #3
  %132 = icmp eq ptr %131, null
  br i1 %132, label %133, label %134

133:                                              ; preds = %129
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %109) #3
  tail call void @Cudd_RecursiveDeref(ptr noundef nonnull %0, ptr noundef nonnull %118) #3
  br label %140

134:                                              ; preds = %121, %129
  %135 = phi ptr [ %131, %129 ], [ %109, %121 ]
  %136 = load i32, ptr %115, align 4, !tbaa !39
  %137 = add i32 %136, -1
  store i32 %137, ptr %115, align 4, !tbaa !39
  %138 = load i32, ptr %125, align 4, !tbaa !39
  %139 = add i32 %138, -1
  store i32 %139, ptr %125, align 4, !tbaa !39
  tail call void @cuddCacheInsert2(ptr noundef nonnull %0, ptr noundef nonnull @Cudd_addOrAbstract, ptr noundef nonnull %1, ptr noundef nonnull %14, ptr noundef nonnull %135) #3
  br label %140

140:                                              ; preds = %25, %3, %108, %67, %29, %134, %133, %120, %102, %94, %84, %57, %47
  %141 = phi ptr [ null, %47 ], [ null, %57 ], [ null, %84 ], [ null, %94 ], [ %104, %102 ], [ null, %120 ], [ null, %133 ], [ %135, %134 ], [ %30, %29 ], [ null, %67 ], [ null, %108 ], [ %1, %3 ], [ %1, %25 ]
  ret ptr %141
}

declare ptr @cuddAddApplyRecur(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare ptr @Cudd_addPlus(ptr noundef, ptr noundef, ptr noundef) #1

declare void @Cudd_RecursiveDeref(ptr noundef, ptr noundef) local_unnamed_addr #1

declare ptr @cuddCacheLookup2(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare i64 @util_cpu_time() local_unnamed_addr #1

declare void @cuddCacheInsert2(ptr noundef, ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare ptr @cuddUniqueInter(ptr noundef, i32 noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare ptr @Cudd_addTimes(ptr noundef, ptr noundef, ptr noundef) #1

declare ptr @Cudd_addOr(ptr noundef, ptr noundef, ptr noundef) #1

; Function Attrs: nofree nounwind
declare noundef i64 @fwrite(ptr noundef readonly captures(none), i64 noundef, i64 noundef, ptr noundef captures(none)) local_unnamed_addr #2

attributes #0 = { nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree nounwind }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Ubuntu clang version 21.1.8 (6ubuntu1)"}
!5 = !{!6, !11, i64 32}
!6 = !{!"DdManager", !7, i64 0, !11, i64 32, !11, i64 40, !11, i64 48, !11, i64 56, !11, i64 64, !13, i64 72, !13, i64 80, !8, i64 88, !8, i64 92, !14, i64 96, !14, i64 104, !14, i64 112, !8, i64 120, !8, i64 124, !8, i64 128, !8, i64 132, !8, i64 136, !8, i64 140, !15, i64 144, !15, i64 152, !16, i64 160, !8, i64 216, !8, i64 220, !8, i64 224, !8, i64 228, !8, i64 232, !8, i64 236, !8, i64 240, !8, i64 244, !14, i64 248, !8, i64 256, !8, i64 260, !17, i64 264, !14, i64 272, !14, i64 280, !19, i64 288, !19, i64 296, !19, i64 304, !19, i64 312, !17, i64 320, !19, i64 328, !17, i64 336, !8, i64 344, !8, i64 348, !8, i64 352, !20, i64 360, !20, i64 368, !17, i64 376, !11, i64 384, !21, i64 392, !17, i64 400, !8, i64 408, !8, i64 412, !8, i64 416, !14, i64 424, !8, i64 432, !8, i64 436, !8, i64 440, !8, i64 444, !8, i64 448, !8, i64 452, !8, i64 456, !8, i64 460, !14, i64 464, !14, i64 472, !8, i64 480, !8, i64 484, !8, i64 488, !8, i64 492, !8, i64 496, !8, i64 500, !8, i64 504, !8, i64 508, !22, i64 512, !22, i64 520, !8, i64 528, !8, i64 532, !8, i64 536, !8, i64 540, !8, i64 544, !8, i64 548, !8, i64 552, !23, i64 560, !12, i64 568, !24, i64 576, !24, i64 584, !24, i64 592, !24, i64 600, !25, i64 608, !25, i64 616, !8, i64 624, !26, i64 632, !26, i64 640, !12, i64 648, !12, i64 656, !12, i64 664, !12, i64 672, !12, i64 680, !26, i64 688, !26, i64 696, !26, i64 704, !8, i64 712, !26, i64 720, !26, i64 728, !14, i64 736, !14, i64 744, !14, i64 752, !14, i64 760, !14, i64 768, !14, i64 776, !8, i64 784, !8, i64 788, !8, i64 792, !8, i64 796, !9, i64 800}
!7 = !{!"DdNode", !8, i64 0, !8, i64 4, !11, i64 8, !9, i64 16}
!8 = !{!"int", !9, i64 0}
!9 = !{!"omnipotent char", !10, i64 0}
!10 = !{!"Simple C/C++ TBAA"}
!11 = !{!"p1 _ZTS6DdNode", !12, i64 0}
!12 = !{!"any pointer", !9, i64 0}
!13 = !{!"p1 _ZTS7DdCache", !12, i64 0}
!14 = !{!"double", !9, i64 0}
!15 = !{!"p1 _ZTS10DdSubtable", !12, i64 0}
!16 = !{!"DdSubtable", !17, i64 0, !8, i64 8, !8, i64 12, !8, i64 16, !8, i64 20, !8, i64 24, !8, i64 28, !8, i64 32, !8, i64 36, !8, i64 40, !8, i64 44, !8, i64 48}
!17 = !{!"p2 _ZTS6DdNode", !18, i64 0}
!18 = !{!"any p2 pointer", !12, i64 0}
!19 = !{!"p1 int", !12, i64 0}
!20 = !{!"p1 long", !12, i64 0}
!21 = !{!"p1 omnipotent char", !12, i64 0}
!22 = !{!"p1 _ZTS8MtrNode_", !12, i64 0}
!23 = !{!"p1 _ZTS12DdLocalCache", !12, i64 0}
!24 = !{!"p1 _ZTS6DdHook", !12, i64 0}
!25 = !{!"p1 _ZTS8_IO_FILE", !12, i64 0}
!26 = !{!"long", !9, i64 0}
!27 = !{!7, !8, i64 0}
!28 = !{!9, !9, i64 0}
!29 = !{!6, !11, i64 40}
!30 = !{!6, !25, i64 616}
!31 = !{!6, !8, i64 432}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.mustprogress"}
!34 = !{!6, !8, i64 624}
!35 = !{!6, !12, i64 672}
!36 = !{!6, !12, i64 680}
!37 = !{!6, !19, i64 288}
!38 = !{!8, !8, i64 0}
!39 = !{!7, !8, i64 4}
!40 = !{!6, !14, i64 96}
!41 = !{!6, !12, i64 648}
!42 = !{!6, !12, i64 656}
!43 = !{!6, !26, i64 632}
!44 = !{!6, !26, i64 640}
!45 = distinct !{!45, !33}
!46 = distinct !{!46, !33}
